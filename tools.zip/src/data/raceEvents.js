/**
 * Race event registry.
 *
 * Each event is authored as an ordered list of road-mesh node names (resolved
 * to world centres via src/data/road-nodes.json) plus metadata. The manager
 * builds a drivable track from the nodes (buildTrackFromNodes), shows at most
 * three ACTIVE events at a time, and advances the progression as the player
 * finishes them. See the plan and raceManager.js.
 *
 * type:
 *   "RACE"      - beat the AI field; podium = finishing position.
 *   "TIME"      - solo against the clock; podium = gold/silver/bronze time.
 *   "NOCOLLIDE" - solo with TRAFFIC ON; podium = fewest contacts of any kind.
 * open:  true = point-to-point sprint (finish != start); false = closed loop.
 * traffic: ambient traffic left running during the event (only NOCOLLIDE).
 * opponents: AI rivals (0 for solo TIME / NOCOLLIDE). fieldSize = opponents + 1.
 * approach: optional node name the grid lines up to arrive FROM, for a smooth
 *           run into a start that joins at an angle (else it is auto-detected).
 * targetTimes: optional explicit [1st, 2nd, 3rd] seconds for a TIME trial,
 *           overriding the speed-derived tiers (use when the global speeds
 *           don't fit the event).
 * order: lower unlocks first; the active set is the lowest-order events not yet
 *        mastered (capped at 3).
 */
export const RACE_EVENTS = [
  // ==========================================
  // TIER 1: Foundations (Events 1-6) - Easy / Learning
  // ==========================================
  {
    id: "evt1",
    name: "Home Loop",
    type: "RACE",
    open: false,
    laps: 1,
    opponents: 3,
    traffic: false,
    order: 10,
    approach: "road_b_15.003",
    nodes: [
      "road_b_14.001", "road_b_15.002", "road_b_15.001", "road_b_14.004",
      "road_b_15.004", "road_b_15.003", "road_b_14.001",
    ],
  },
  {
    id: "evt2",
    name: "Bridge Run",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 20,
    targetTimes: [38, 46, 56],
    approach: "road_c_01",
    nodes: [
      "road_c_03.003", "road_c_01.002", "road_b_12.004", "road_b_06.003",
      "road_c_02.003", "bridge_a", "road_c_02.004", "road_b_14.001", "road_b_22.004",
    ],
  },
  {
    id: "evt3",
    name: "Clean Line",
    type: "NOCOLLIDE",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: true,
    order: 30,
    approach: "road_a_06.006",
    nodes: [
      "road_a_02.115", "road_a_06.005", "road_a_02.152", "road_b_12.004",
      "road_b_22.002", "road_b_06.003", "road_c_02.003", "bridge_a", "road_c_02.004",
      "road_b_14.001", "road_b_09.008", "road_a_02.192", "road_a_02.217",
      "road_b_09.012", "road_b_14.004",
    ],
  },
  {
    id: "evt4",
    name: "West Loop",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 2,
    traffic: false,
    order: 40,
    approach: "road_b_15.005",
    nodes: [
      "road_b_24.002", "road_b_15.006", "road_b_14.005",
      "road_b_14.004", "road_b_15.005", "road_b_24.002",
    ],
  },
  {
    id: "evt5",
    name: "Market Dash",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 50,
    targetTimes: [30, 36, 45],
    approach: "road_a_06.006",
    nodes: [
      "road_a_02.128", "road_b_12.005", "road_b_22.043",
      "road_b_12.004", "road_c_02.002", "road_c_01.002", "road_c_02.002",
      "road_b_12.004", "road_a_02.076", "road_a_06.003",
    ],
  },
  {
    id: "evt6",
    name: "North Circuit",
    type: "RACE",
    open: false,
    laps: 1,
    opponents: 3,
    traffic: false,
    order: 60,
    approach: "road_b_15.001",
    nodes: [
      "road_b_22.019", "road_b_09.006", "road_b_14.004",
      "road_b_22.021", "road_b_14.002", "road_b_15.005", "road_b_15.006",
      "road_b_14.005", "road_b_14.004", "road_b_15.001", "road_b_22.019",
    ],
  },

  // ==========================================
  // TIER 2: Novice (Events 7-12)
  // ==========================================
  {
    id: "evt7",
    name: "North Sprint",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 70,
    targetTimes: [28, 34, 42],
    approach: "road_b_15.001",
    nodes: [
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.009", "road_a_06.010", "road_a_06.011",
    ],
  },
  {
    id: "evt8",
    name: "East Grid Loop",
    type: "RACE",
    open: false,
    laps: 1,
    opponents: 3,
    traffic: false,
    order: 80,
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.003", "road_a_05.003", "road_b_12.001", "road_b_12.002",
      "road_a_05.001", "road_a_05.002", "road_b_12.003", "road_b_12.003",
      "road_a_06.004", "road_a_06.003",
    ],
  },
  {
    id: "evt9",
    name: "Coastal Sprint",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 90,
    targetTimes: [25, 30, 37],
    approach: "road_c_01",
    nodes: [
      "road_c_03.003", "road_c_03.001", "road_c_03", "road_c_01.002",
      "road_c_03.008", "road_c_03.007", "road_c_03.005", "road_c_03.011",
      "road_c_03.014", "road_c_03.017", "road_c_03.019",
    ],
  },
  {
    id: "evt10",
    name: "Boulevard Dash",
    type: "NOCOLLIDE",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: true,
    order: 100,
    approach: "road_b_14.004",
    nodes: [
      "road_b_15.001", "road_b_14.004", "road_b_15.005", "road_b_15.006",
      "road_b_14.005", "road_b_15.004", "road_b_15.003", "road_b_14.001",
      "road_b_15.002",
    ],
  },
  {
    id: "evt11",
    name: "Inner Ring",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 3,
    traffic: false,
    order: 110,
    approach: "road_b_09.006",
    nodes: [
      "road_b_15.002", "road_b_15.001", "road_b_09.006", "road_b_09.002",
      "road_b_09.008", "road_b_09.012", "road_b_15.004", "road_b_15.003",
    ],
  },
  {
    id: "evt12",
    name: "Harbor Gate",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 3,
    traffic: false,
    order: 120,
    approach: "road_b_15.001",
    nodes: [
      "road_b_15.002", "road_b_15.001", "road_b_09.005", "road_a_13.002",
      "road_a_12.003", "road_b_09.006", "road_b_15.004", "road_b_15.003",
      "road_b_15.002",
    ],
  },

  // ==========================================
  // TIER 3: Intermediate (Events 13-18)
  // ==========================================
  {
    id: "evt13",
    name: "Hillside Circuit",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 3,
    traffic: false,
    order: 130,
    approach: "road_b_14.004",
    nodes: [
      "road_b_15.001", "road_b_14.004", "road_b_15.005", "road_b_15.006",
      "road_b_14.005", "road_b_09.012", "road_b_09.008", "road_b_15.002",
      "road_b_15.001",
    ],
  },
  {
    id: "evt14",
    name: "East Park Time Attack",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 140,
    targetTimes: [41, 48, 60],
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.003", "road_a_06.004", "road_a_06.006", "road_a_05.005",
      "road_b_12.003", "road_b_12.002", "road_a_05.004", "road_a_05.006",
      "road_b_12.001", "road_b_12.004", "road_a_06.003",
    ],
  },
  {
    id: "evt15",
    name: "Western Sweep",
    type: "NOCOLLIDE",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: true,
    order: 150,
    approach: "road_b_09.002",
    nodes: [
      "road_b_09.002", "road_a_02.160", "road_b_14.004", "road_b_15.005",
      "road_b_15.006", "road_b_14.005", "road_b_15.004", "road_b_15.003",
    ],
  },
  {
    id: "evt16",
    name: "Grand Boulevard GP",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 4,
    traffic: false,
    order: 160,
    approach: "road_b_09.002",
    nodes: [
      "road_b_09.002", "road_a_02.160", "road_b_14.004", "road_b_15.005",
      "road_b_15.006", "road_b_14.005", "road_b_15.004", "road_b_15.003",
      "road_b_09.002",
    ],
  },
  {
    id: "evt17",
    name: "Dockside Express",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 170,
    targetTimes: [46, 55, 67],
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.003", "road_a_06.004", "road_b_12.005", "road_b_14.001",
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_a_02.270",
    ],
  },
  {
    id: "evt18",
    name: "Metro Speedway",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 4,
    traffic: false,
    order: 180,
    approach: "road_b_15.001",
    nodes: [
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003", "road_b_15.002",
    ],
  },

  // ==========================================
  // TIER 4: Advanced (Events 19-24)
  // ==========================================
  {
    id: "evt19",
    name: "Outer Belt Speedway",
    type: "RACE",
    open: false,
    laps: 2,
    opponents: 4,
    traffic: false,
    order: 190,
    approach: "road_b_14.004",
    nodes: [
      "road_b_15.001", "road_b_14.004", "road_b_15.005", "road_b_15.006",
      "road_b_14.005", "road_b_15.004", "road_b_15.003", "road_b_15.002",
      "road_b_15.001",
    ],
  },
  {
    id: "evt20",
    name: "Citywide Chase",
    type: "RACE",
    open: false,
    laps: 3,
    opponents: 4,
    traffic: false,
    order: 200,
    approach: "road_b_09.002",
    nodes: [
      "road_b_09.002", "road_a_02.160", "road_b_14.004", "road_b_15.005",
      "road_b_15.006", "road_b_14.005", "road_b_15.004", "road_b_15.003",
      "road_b_09.002",
    ],
  },
  {
    id: "evt21",
    name: "Eastside Endurance",
    type: "TIME",
    open: false,
    laps: 2,
    opponents: 0,
    traffic: false,
    order: 210,
    targetTimes: [58, 67, 82],
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.003", "road_a_06.004", "road_a_06.006", "road_a_05.005",
      "road_b_12.003", "road_b_12.002", "road_a_05.004", "road_a_05.006",
      "road_b_12.001", "road_b_12.004", "road_a_06.003",
    ],
  },
  {
    id: "evt22",
    name: "Midnight Rush",
    type: "NOCOLLIDE",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: true,
    order: 220,
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.005", "road_a_05.006", "road_b_12.001", "road_b_12.002",
      "road_a_05.004", "road_a_05.005", "road_b_12.003", "road_b_14.001",
      "road_b_09.008", "road_b_09.012", "road_b_09.006", "road_b_09.002",
      "road_b_15.002", "road_b_15.001", "road_b_15.004", "road_b_15.003",
    ],
  },
  {
    id: "evt23",
    name: "Coastal Endurance",
    type: "TIME",
    open: false,
    laps: 2,
    opponents: 0,
    traffic: false,
    order: 230,
    targetTimes: [65, 77, 94],
    approach: "road_c_01",
    nodes: [
      "road_c_01.002", "road_c_03.008", "road_c_03.007", "road_c_03.005",
      "road_c_03.011", "road_c_03.014", "road_c_03.017", "road_c_03.019",
      "road_c_03.020", "road_c_03.018", "road_c_03.015", "road_c_03.013",
      "road_c_03.006", "road_c_03.002", "road_c_01.003", "road_c_03.009",
      "road_c_03.010", "road_c_03.004", "road_c_01.005", "road_c_03.012",
      "road_c_01", "road_c_03.003", "road_c_03.001", "road_c_03",
      "road_c_01.002",
    ],
  },
  {
    id: "evt24",
    name: "Apex Grand Prix",
    type: "RACE",
    open: false,
    laps: 3,
    opponents: 5,
    traffic: false,
    order: 240,
    approach: "road_b_15.001",
    nodes: [
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003", "road_b_15.002",
    ],
  },

  // ==========================================
  // TIER 5: Master / Climax (Events 25-30)
  // ==========================================
  {
    id: "evt25",
    name: "Continental Tour",
    type: "RACE",
    open: false,
    laps: 3,
    opponents: 5,
    traffic: false,
    order: 250,
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.003", "road_a_06.004", "road_b_12.005", "road_b_14.001",
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003", "road_b_14.001", "road_b_12.005",
      "road_a_06.004", "road_a_06.003",
    ],
  },
  {
    id: "evt26",
    name: "The Oceanway",
    type: "TIME",
    open: false,
    laps: 3,
    opponents: 0,
    traffic: false,
    order: 260,
    targetTimes: [94, 110, 132],
    approach: "road_c_01",
    nodes: [
      "road_c_01.002", "road_c_03.008", "road_c_03.007", "road_c_03.005",
      "road_c_03.011", "road_c_03.014", "road_c_03.017", "road_c_03.019",
      "road_c_03.020", "road_c_03.018", "road_c_03.015", "road_c_03.013",
      "road_c_03.006", "road_c_03.002", "road_c_01.003", "road_c_03.009",
      "road_c_03.010", "road_c_03.004", "road_c_01.005", "road_c_03.012",
      "road_c_01", "road_c_03.003", "road_c_03.001", "road_c_03",
      "road_c_01.002",
    ],
  },
  {
    id: "evt27",
    name: "Zero Margin",
    type: "NOCOLLIDE",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: true,
    order: 270,
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.005", "road_a_05.006", "road_b_12.001", "road_b_12.002",
      "road_a_05.004", "road_a_05.005", "road_b_12.003", "road_b_14.001",
      "road_b_09.008", "road_b_09.012", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003",
    ],
  },
  {
    id: "evt28",
    name: "Metropolis GP",
    type: "RACE",
    open: false,
    laps: 3,
    opponents: 5,
    traffic: false,
    order: 280,
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.005", "road_a_05.006", "road_b_12.001", "road_b_12.002",
      "road_a_05.004", "road_a_05.005", "road_b_12.003", "road_b_14.001",
      "road_b_09.008", "road_b_09.012", "road_b_09.006", "road_b_09.002",
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003", "road_b_14.001", "road_b_12.005",
      "road_a_06.004", "road_a_06.003", "road_a_05.003", "road_b_12.001",
      "road_b_12.004", "road_a_06.005",
    ],
  },
  {
    id: "evt29",
    name: "Ultimate Time Trial",
    type: "TIME",
    open: true,
    laps: 1,
    opponents: 0,
    traffic: false,
    order: 290,
    targetTimes: [86, 102, 122],
    approach: "road_a_06.004",
    nodes: [
      "road_a_06.003", "road_a_06.004", "road_b_12.005", "road_b_14.001",
      "road_b_09.008", "road_b_09.012", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003", "road_b_15.002", "road_b_15.001",
      "road_b_09.005", "road_a_13.002", "road_a_12.003", "road_b_09.006",
      "road_b_09.002", "road_a_02.160", "road_b_14.004",
    ],
  },
  {
    id: "evt30",
    name: "Grand City Finale",
    type: "RACE",
    open: false,
    laps: 4,
    opponents: 5,
    traffic: false,
    order: 300,
    approach: "road_b_15.001",
    nodes: [
      "road_b_15.002", "road_b_15.001", "road_b_14.004", "road_b_15.005",
      "road_b_09.015", "road_a_05.012", "road_a_06.011", "road_a_06.010",
      "road_a_06.012", "road_b_09.014", "road_b_15.006", "road_b_14.005",
      "road_b_15.004", "road_b_15.003", "road_b_14.001", "road_b_12.005",
      "road_a_06.004", "road_a_06.003", "road_a_05.003", "road_b_12.001",
      "road_b_12.002", "road_a_05.004", "road_a_05.005", "road_b_12.003",
      "road_b_14.001", "road_b_09.008", "road_b_09.012", "road_b_09.006",
      "road_b_09.002", "road_b_15.002",
    ],
  },
];

/** road_a_* roads are the narrow family (no centre divider). */
export function isNarrowNode(name) {
  return /^road_a_/i.test(name || "");
}

/**
 * TIME-trial podium thresholds, as average speeds (m/s) over the track: the
 * player must finish inside `trackLength*laps / speed` to claim that place.
 * Relaxed default average speeds: 90 km/h = 1st, 78 = 2nd, 66 = 3rd.
 * Specific events pin their own hand-tuned targetTimes.
 */
export const TIME_SPEEDS = [90 / 3.6, 78 / 3.6, 66 / 3.6];

/** NO-COLLISION podium thresholds: max car contacts for 1st / 2nd / 3rd. */
export const HIT_TIERS = [0, 2, 5];

