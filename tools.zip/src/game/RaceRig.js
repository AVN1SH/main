import { TransformNode, Vector3 } from "@babylonjs/core";
import { CAR } from "./driving.js";
import { WHEEL_RE, classifyAxles } from "./raceCarAxles.js";

/**
 * Rig for the race cars in `public/assets/`.
 *
 * These are NOT the traffic models and NOT the player's car, and they break
 * every assumption the other two rigs are allowed to make:
 *
 *   - `VehicleRig` (player, `car1.glb`) knows its wheels are named
 *     `lFWheel`/`rrWheel`, that front/rear can be read from the name, and that
 *     the wheel nodes are off-centre so each one needs pivot surgery.
 *   - `TrafficRig` (`vehicles/*.glb`) knows its wheels end in `_TireFL` and
 *     that the body carries a baked +90 deg X rotation, so steering acts on
 *     local Z and spin on local Y.
 *
 * The race cars use two different authoring conventions between them:
 *
 *   family A  `car2/3/4.glb`, car1's convention: wheels are `lfWheel.003`,
 *             `rrWheel.001`, ... and the car's long axis is X.
 *   family B  `Sport Car_39.glb`, `Hatchback Car_15.glb`, ...: the root mesh is
 *             both the body and the wheels' parent, wheels are named
 *             `<Car> FL Tire` / `<Car> BR Tire`, and the long axis is Z.
 *
 * And the names are not even trustworthy inside family A: `car2.glb` ships two
 * wheels called `rfWheel` (one of them on the rear axle). So this rig measures
 * everything it needs instead of parsing it:
 *
 *   1. wheels are found by name (`tire`/`wheel`, case-insensitive),
 *   2. the car's LONG axis comes from the body's own bounding box,
 *   3. the wheels are clustered into two axles by position along that axis, and
 *      which cluster is the FRONT one is decided by a vote of the wheel names
 *      (which is correct for `car2` even though one name contradicts it),
 *   4. the model is yaw-fixed so the measured forward reads as +Z, matching the
 *      rest of the game (`heading = atan2(fwd.x, fwd.z)`),
 *   5. each wheel's steering axis is whichever local axis is closest to world
 *      up, and its spin axis is whichever is closest to the wheel's own axle
 *      direction (the thinnest axis of the wheel's box),
 *   6. the two rotation SIGNS are calibrated by probing, exactly as the other
 *      two rigs do - the imported handedness cannot be reasoned out.
 *
 * The collision footprint is deliberately capped at the player's own envelope
 * (see `halfLength`/`halfWidth`): the race lane is validated for that
 * footprint, so a rival that is a few centimetres wider than the player would
 * scrape kerbs the player clears, and would be a moving obstacle rather than a
 * fair opponent.
 */

export class RaceRig {
  /**
   * @param scene  Babylon scene
   * @param asset  one entry from `loadRaceCarAssets`
   * @param label  node-name prefix (debug only)
   */
  constructor(scene, asset, label = "rival") {
    this.scene = scene;
    this.asset = asset;
    this.label = label;
    this.diagnostics = {};

    // --- instantiate ------------------------------------------------------
    const entries = asset.container.instantiateModelsToScene((n) => n, false);
    const loadedRoot = entries.rootNodes[0];
    if (!loadedRoot) throw new Error(`${label}: race car asset produced no root node`);

    this.root = new TransformNode(`${label}_root`, scene);
    this.ground = new TransformNode(`${label}_ground`, scene);
    this.ground.parent = this.root;
    this.model = new TransformNode(`${label}_model`, scene);
    this.model.parent = this.ground;

    loadedRoot.parent = this.model;
    this._forceUpdate();

    // --- collect meshes ---------------------------------------------------
    const meshes = [...loadedRoot.getChildMeshes(false)];
    const rootIsMesh = typeof loadedRoot.getClassName === "function" && loadedRoot.getClassName() === "Mesh";
    if (rootIsMesh) meshes.push(loadedRoot);

    const wheelMeshes = meshes.filter((m) => WHEEL_RE.test(m.name));
    if (wheelMeshes.length !== 4) {
      throw new Error(`${label}: expected 4 wheel meshes, found ${wheelMeshes.length}`);
    }
    this.wheelMeshes = wheelMeshes;
    this.bodyMeshes = meshes.filter((m) => !wheelMeshes.includes(m));
    if (!this.bodyMeshes.length) throw new Error(`${label}: no body mesh found`);
    // The tinted "body" is the root mesh when there is one (both families make
    // the body the root and hang the wheels off it); otherwise the biggest
    // non-wheel mesh, so a model whose root is a bare TransformNode still gets
    // a sensible body to paint.
    this.bodyMesh = rootIsMesh ? loadedRoot : this._largest(this.bodyMeshes);

    // --- scale to the target length --------------------------------------
    // Measured before anything else moves, from the body alone, so the number
    // fed to the scale is the car's real length rather than the length of the
    // longest stray trim piece.
    const rawBody = this._unionBounds(this.bodyMeshes);
    const rawLength = Math.max(rawBody.max.x - rawBody.min.x, rawBody.max.z - rawBody.min.z);
    const targetLength = asset.targetLength ?? 4.4;
    this.scale = targetLength / Math.max(rawLength, 0.5);
    this.model.scaling.setAll(this.scale);
    this.diagnostics.sourceLength = round(rawLength, 2);
    this.diagnostics.scale = round(this.scale, 3);
    this._forceUpdate();

    // --- axles: long axis, then wheel clusters along it --------------------
    const body = this._unionBounds(this.bodyMeshes);
    const centres = wheelMeshes.map((m) => this._meshWorldCentre(m));
    const axles = classifyAxles(body, centres, wheelMeshes.map((m) => m.name));
    this.longAxis = axles.longAxis;
    this.lateralAxis = axles.lateralAxis;
    const isFront = axles.isFront;
    this.diagnostics.longAxis = axles.longAxis;
    this.diagnostics.axleVotes = axles.votes;
    this.diagnostics.wheelEnds = wheelMeshes.map((m, i) => ({
      name: m.name,
      named: axles.ends[i].named,
      measured: axles.ends[i].measured,
    }));

    // --- yaw fix: measured forward reads as +Z ----------------------------
    const frontMid = this._mean(centres.filter((_, i) => isFront[i]));
    const rearMid = this._mean(centres.filter((_, i) => !isFront[i]));
    const fwd = frontMid.subtract(rearMid);
    fwd.y = 0;
    if (fwd.lengthSquared() < 1e-6) throw new Error(`${label}: could not determine the car's forward direction`);
    fwd.normalize();
    const yawFix = -Math.atan2(fwd.x, fwd.z);
    this.model.rotation.y += yawFix;
    this.diagnostics.forwardInModelSpace = [round(fwd.x, 3), 0, round(fwd.z, 3)];
    this.diagnostics.yawFixDeg = round((yawFix * 180) / Math.PI, 1);
    this._forceUpdate();

    // --- wheel pivots ------------------------------------------------------
    this.wheels = [];
    for (let i = 0; i < wheelMeshes.length; i++) {
      const mesh = wheelMeshes[i];
      const parent = mesh.parent;
      const centerParent = this._worldToSpace(this._meshWorldCentre(mesh), parent);
      const saved = captureTransform(mesh);

      // Steering axis: whichever local axis of the frame the wheel lives in
      // points most nearly at world up. Spin axis: whichever points most nearly
      // along the wheel's own axle (its thinnest box axis).
      const frameInv = parent.getWorldMatrix().clone().invert();
      const upLocal = Vector3.TransformNormal(new Vector3(0, 1, 0), frameInv);
      const axleWorld = Vector3.TransformNormal(this._axleAxisLocal(mesh), mesh.getWorldMatrix());
      const axleLocal = Vector3.TransformNormal(axleWorld, frameInv);

      const steerAxis = dominantAxis(upLocal);
      const spinAxis = dominantAxis(axleLocal);

      const steerPivot = new TransformNode(`${label}_steer_${i}`, this.scene);
      steerPivot.parent = parent;
      steerPivot.position.copyFrom(centerParent);
      steerPivot.rotationQuaternion = null;
      steerPivot.rotation.setAll(0);

      const spinPivot = new TransformNode(`${label}_spin_${i}`, this.scene);
      spinPivot.parent = steerPivot;
      spinPivot.position.setAll(0);
      spinPivot.rotationQuaternion = null;
      spinPivot.rotation.setAll(0);

      // Reparent, then re-express the mesh's offset so the geometry does not
      // move. Several of these models put the wheel's node origin well away
      // from the wheel itself, so the offset is measured, never assumed.
      mesh.parent = spinPivot;
      mesh.position.copyFrom(saved.position.subtract(centerParent));
      mesh.scaling.copyFrom(saved.scaling);
      if (saved.rotationQuaternion) {
        mesh.rotationQuaternion = saved.rotationQuaternion.clone();
      } else {
        mesh.rotationQuaternion = null;
        mesh.rotation.copyFrom(saved.rotation);
      }

      const ext = mesh.getBoundingInfo().boundingBox.extendSizeWorld;
      this.wheels.push({
        name: mesh.name,
        mesh,
        steerPivot,
        spinPivot,
        front: isFront[i],
        restPos: centerParent.clone(),
        steerAxis,
        spinAxis,
        radius: Math.max(ext.x, ext.y, ext.z),
      });
    }
    this._forceUpdate();

    // World up expressed in the wheel frame, left un-normalised so its length
    // (1/scale) turns a metre of suspension travel into a metre of movement.
    const frame = wheelMeshes[0].parent;
    this._suspensionUp = Vector3.TransformNormal(new Vector3(0, 1, 0), frame.getWorldMatrix().clone().invert());

    this.steerAngle = 0;
    this._calibrate();

    // --- measurements the terrain follower and the race AI need -----------
    this.wheelRadius = this.wheels.reduce((s, w) => s + w.radius, 0) / this.wheels.length;
    this.wheelOffsets = this.wheels.map((w) => {
      const p = this._worldToSpace(w.steerPivot.getAbsolutePosition(), this.root);
      return { name: w.name, x: p.x, z: p.z, radius: w.radius, front: w.front };
    });
    const fronts = this.wheelOffsets.filter((w) => w.front);
    const rears = this.wheelOffsets.filter((w) => !w.front);
    const posX = this.wheelOffsets.filter((w) => w.x > 0);
    const negX = this.wheelOffsets.filter((w) => w.x < 0);
    const avg = (list, key) => list.reduce((s, w) => s + w[key], 0) / (list.length || 1);
    this.wheelBase = Math.max(avg(fronts, "z") - avg(rears, "z"), 0.5);
    this.track = Math.max(avg(posX, "x") - avg(negX, "x"), 0.5);

    // Footprint: the body's own box, capped to the player's envelope. The race
    // lane was validated for `CAR.length x CAR.width`, so a rival wider than
    // `CAR.width` would clip kerbs the player clears; capping makes every
    // competitor fit exactly where the player fits.
    const bodySizeX = body.max.x - body.min.x;
    const bodySizeZ = body.max.z - body.min.z;
    this.measuredHalfWidth = Math.min(bodySizeX, bodySizeZ) / 2;
    this.measuredHalfLength = Math.max(bodySizeX, bodySizeZ) / 2;
    this.halfLength = Math.min(this.measuredHalfLength, CAR.length / 2);
    this.halfWidth = Math.min(this.measuredHalfWidth, CAR.width / 2);
    this.height = Math.max(Math.min(body.max.y - body.min.y, CAR.height * 1.15), 0.6);
    this.clearance = CAR.clearance;

    // --- seat the car on its wheels, not its belly -------------------------
    // The terrain follower drops the ROOT onto the road, so the wheel contact
    // plane has to be at the root origin. These models put the origin at the
    // body with the tyres hanging below it, which would sink the tyres into the
    // tarmac; measure the mean wheel-bottom height at rest and lift the model
    // by exactly that.
    const centresRoot = this.wheels.map((w) => this._worldToSpace(w.steerPivot.getAbsolutePosition(), this.root));
    const contactY = centresRoot.reduce((s, p) => s + p.y, 0) / centresRoot.length - this.wheelRadius;
    this.model.position.y -= contactY;
    this.diagnostics.wheelSeatY = round(contactY, 3);
    this._forceUpdate();

    this.setSuspension(this.wheels.map(() => 0));
    this.setSteer(0);
    this.spinWheels(0);

    this.diagnostics.wheelBase = round(this.wheelBase, 3);
    this.diagnostics.track = round(this.track, 3);
    this.diagnostics.wheelRadius = round(this.wheelRadius, 3);
    this.diagnostics.footprint = {
      length: round(this.halfLength * 2, 2),
      width: round(this.halfWidth * 2, 2),
      height: round(this.height, 2),
      measuredLength: round(this.measuredHalfLength * 2, 2),
      measuredWidth: round(this.measuredHalfWidth * 2, 2),
    };
    this.diagnostics.wheels = this.wheels.map((w) => ({
      name: w.name,
      front: w.front,
      steerAxis: w.steerAxis,
      spinAxis: w.spinAxis,
      radius: round(w.radius, 3),
      // The pivot must sit ON the wheel centre, or steering would swing the
      // wheel around the chassis instead of turning it in place.
      pivotError: round(Vector3.Distance(w.steerPivot.getAbsolutePosition(), this._meshWorldCentre(w.mesh)), 4),
    }));
    this.diagnostics.suspensionUp = [round(this._suspensionUp.x, 3), round(this._suspensionUp.y, 3), round(this._suspensionUp.z, 3)];
  }

  /**
   * Measures the two rotation signs that decide whether the wheels look right.
   *
   *  - `steerSign`  radians of axle yaw produced per radian of pivot rotation.
   *    `setSteer` divides by it, so a steering command comes out as a wheel
   *    angle in the game's convention (positive = left).
   *  - `spinSign`   rotating the spin pivot by +eps must carry the TOP of the
   *    wheel forward. The top is the honest point to watch: the contact patch
   *    is the instantaneous centre of rotation and barely moves.
   */
  _calibrate() {
    const probe = this.wheels.find((w) => w.front) ?? this.wheels[0];
    const eps = 0.05;

    const axle0 = this._axleDirInRoot(probe);
    probe.steerPivot.rotation[probe.steerAxis] = eps;
    this._forceUpdate();
    const axle1 = this._axleDirInRoot(probe);
    probe.steerPivot.rotation[probe.steerAxis] = 0;
    this._forceUpdate();
    const cross = axle0.x * axle1.z - axle0.z * axle1.x;
    const dot = axle0.x * axle1.x + axle0.z * axle1.z;
    const turned = Math.atan2(cross, dot);
    this.steerSign = Math.abs(turned) < 1e-6 ? -1 : turned / eps;

    const centerRoot = this._worldToSpace(this._meshWorldCentre(probe.mesh), this.root);
    const topRoot = new Vector3(centerRoot.x, centerRoot.y + probe.radius, centerRoot.z);
    const topWorld = Vector3.TransformCoordinates(topRoot, this.root.getWorldMatrix());
    const topInSpin = Vector3.TransformCoordinates(topWorld, probe.spinPivot.getWorldMatrix().clone().invert());
    probe.spinPivot.rotation[probe.spinAxis] = eps;
    this._forceUpdate();
    const movedWorld = Vector3.TransformCoordinates(topInSpin, probe.spinPivot.getWorldMatrix());
    probe.spinPivot.rotation[probe.spinAxis] = 0;
    this._forceUpdate();
    const movedRoot = this._worldToSpace(movedWorld, this.root);
    this.spinSign = movedRoot.z - topRoot.z >= 0 ? 1 : -1;

    this.diagnostics.calibration = {
      axleTurnPerRadian: round(turned / eps, 3),
      steerSign: round(this.steerSign, 3),
      topMovedForward: round(movedRoot.z - topRoot.z, 5),
      spinSign: this.spinSign,
    };
  }

  /** The wheel's axle direction (thinnest box axis) flattened into root space. */
  _axleDirInRoot(w) {
    const world = Vector3.TransformNormal(this._axleAxisLocal(w.mesh), w.mesh.getWorldMatrix());
    const inRoot = Vector3.TransformNormal(world, this.root.getWorldMatrix().clone().invert());
    inRoot.y = 0;
    if (inRoot.lengthSquared() < 1e-9) return new Vector3(1, 0, 0);
    return inRoot.normalize();
  }

  /** Mesh-local unit vector along the axle (the wheel's thinnest axis). */
  _axleAxisLocal(mesh) {
    const e = mesh.getBoundingInfo().boundingBox.extendSize;
    if (e.y <= e.x && e.y <= e.z) return new Vector3(0, 1, 0);
    if (e.x <= e.y && e.x <= e.z) return new Vector3(1, 0, 0);
    return new Vector3(0, 0, 1);
  }

  _meshWorldCentre(mesh) {
    mesh.computeWorldMatrix(true);
    return Vector3.TransformCoordinates(mesh.getBoundingInfo().boundingBox.center, mesh.getWorldMatrix());
  }

  _largest(meshes) {
    let best = meshes[0];
    let bestVol = -1;
    for (const m of meshes) {
      const e = m.getBoundingInfo().boundingBox.extendSizeWorld;
      const vol = e.x * e.y * e.z;
      if (vol > bestVol) {
        bestVol = vol;
        best = m;
      }
    }
    return best;
  }

  /** World AABB covering every mesh in `list`. */
  _unionBounds(list) {
    const min = new Vector3(Infinity, Infinity, Infinity);
    const max = new Vector3(-Infinity, -Infinity, -Infinity);
    for (const mesh of list) {
      mesh.computeWorldMatrix(true);
      const bb = mesh.getBoundingInfo().boundingBox;
      min.minimizeInPlace(bb.minimumWorld);
      max.maximizeInPlace(bb.maximumWorld);
    }
    return { min, max };
  }

  _mean(points) {
    const out = new Vector3(0, 0, 0);
    for (const p of points) out.addInPlace(p);
    return out.scaleInPlace(1 / (points.length || 1));
  }

  _worldToSpace(worldPoint, space) {
    space.computeWorldMatrix(true);
    return Vector3.TransformCoordinates(worldPoint, space.getWorldMatrix().clone().invert());
  }

  _forceUpdate() {
    this.root.computeWorldMatrix(true);
    this.ground.computeWorldMatrix(true);
    this.model.computeWorldMatrix(true);
    for (const w of this.wheels ?? []) {
      w.steerPivot?.computeWorldMatrix(true);
      w.spinPivot?.computeWorldMatrix(true);
      w.mesh.computeWorldMatrix(true);
    }
    for (const m of this.wheelMeshes ?? []) m.computeWorldMatrix(true);
  }

  setPosition(x, y, z) {
    this.root.position.set(x, y, z);
  }

  setHeading(heading) {
    this.root.rotation.y = heading;
  }

  /** Terrain pitch/roll applied to the whole car, wheels included. */
  setGroundTilt(pitch, roll) {
    this.ground.rotationQuaternion = null;
    this.ground.rotation.set(pitch ?? 0, 0, roll ?? 0);
  }

  /**
   * Vertical suspension offset per wheel (index matches `this.wheels`).
   * Positive lifts the wheel toward the body, negative lets it droop; zero
   * restores the modelled position.
   */
  setSuspension(travels) {
    const up = this._suspensionUp;
    if (!up) return;
    for (let i = 0; i < this.wheels.length; i++) {
      const w = this.wheels[i];
      const t = travels?.[i] ?? 0;
      w.steerPivot.position.set(
        w.restPos.x + up.x * t,
        w.restPos.y + up.y * t,
        w.restPos.z + up.z * t,
      );
    }
  }

  /**
   * Steer the front wheels. @param angle radians; positive steers LEFT, the
   * convention the bicycle model in driving.js uses, so the visible wheels turn
   * the way the car is actually turning.
   */
  setSteer(angle) {
    this.steerAngle = angle;
    if (this.steerSign === undefined) return;
    const v = Math.abs(this.steerSign) < 1e-6 ? -angle : angle / this.steerSign;
    for (const w of this.wheels) {
      if (w.front) w.steerPivot.rotation[w.steerAxis] = v;
    }
  }

  /** Roll every wheel. @param distance signed metres travelled this frame. */
  spinWheels(distance) {
    if (!distance || !this.spinSign) return;
    const delta = (distance / this.wheelRadius) * this.spinSign;
    for (const w of this.wheels) {
      let a = w.spinPivot.rotation[w.spinAxis] + delta;
      if (a > Math.PI) a -= Math.PI * 2;
      else if (a < -Math.PI) a += Math.PI * 2;
      w.spinPivot.rotation[w.spinAxis] = a;
    }
  }

  /**
   * Rivals deliberately have no body-only lean. In these models the body mesh
   * is also the wheels' parent, so leaning it would lift the tyres off the road
   * - the reason `VehicleRig` has to rebuild the whole wheel hierarchy before it
   * can lean the player's car. The rivals ride the surface through
   * `setGroundTilt`, which is what the traffic fleet does too.
   */

  /** Tint the body so two rivals of the same model are not identical. */
  setColor(color) {
    if (!this.bodyMesh) return;
    const mat = this.bodyMesh.material;
    if (!mat) return;
    const clone = mat.clone(`${this.label}_bodyMat`);
    if (clone.albedoColor) clone.albedoColor = color.clone();
    else if (clone.diffuseColor) clone.diffuseColor = color.clone();
    else return;
    clone.markAsDirty?.();
    this.bodyMesh.material = clone;
  }

  setVisible(visible) {
    this.root.setEnabled(visible);
  }

  /**
   * Fade the whole car for the race-intro reveal (1 = fully visible).
   * Per-mesh `visibility` works regardless of material sharing between
   * instances, so sibling cars are unaffected.
   */
  setFade(v) {
    const f = Math.max(0, Math.min(1, v));
    const meshes = this.root?.getChildMeshes?.(false) ?? [];
    for (const m of meshes) m.visibility = f;
  }

  dispose() {
    this.root.dispose(false, false);
  }
}

// ---------------------------------------------------------------- helpers

/** The dominant axis of a (possibly scaled) direction, as "x" | "y" | "z". */
function dominantAxis(v) {
  const ax = Math.abs(v.x);
  const ay = Math.abs(v.y);
  const az = Math.abs(v.z);
  if (ay >= ax && ay >= az) return "y";
  if (ax >= az) return "x";
  return "z";
}

function captureTransform(node) {
  return {
    position: node.position.clone(),
    rotation: node.rotation.clone(),
    rotationQuaternion: node.rotationQuaternion ? node.rotationQuaternion.clone() : null,
    scaling: node.scaling.clone(),
  };
}

const round = (v, d = 2) => Math.round(v * 10 ** d) / 10 ** d;
