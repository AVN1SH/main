/**
 * Destructible roadside objects.
 *
 * The town's props are baked into the collision grid at load, so a fence or a
 * sign post stops the car exactly like a wall does. That is correct until the
 * player hits one at speed, at which point the prop should give way rather than
 * act as an invisible barrier. This module adds that reaction without turning
 * the game into a rigid-body simulation:
 *
 *  - At load, the solid meshes whose names match `DESTRUCTIBLE_FAMILIES` are
 *    catalogued into a coarse spatial hash. Nothing else is touched, so adding
 *    a family is a one-line change and costs nothing until one is hit.
 *  - Only the PLAYER car reports impacts, and only when its speed is above
 *    `IMPACT_SPEED_KMH`. The report comes from the terrain sweep, i.e. from a
 *    collision that actually happened - not from being near a prop.
 *  - The prop itself is reparented onto a pivot placed at its base (or centre)
 *    and swung/tumbled by a small custom integrator. The mesh is never baked,
 *    hidden or replaced - it stays the exact node the renderer was already
 *    drawing - so the break is always visible. No physics engine, no
 *    per-object solver, and each prop stops integrating as soon as it settles.
 *  - The collision cells the prop owned are released, so the car ploughs on
 *    through the gap it just made instead of stopping behind an invisible box.
 *
 * Extending it: add an entry to `DESTRUCTIBLE_FAMILIES` naming a mesh family
 * and pick one of the behaviours in `BEHAVIORS` (`flex` = bends and folds,
 * `topple` = falls over from the ground, `tumble` = knocked free and tumbles,
 * `roll` = cylindrical, rolls). Mesh names are the trailing numeric suffix
 * stripped, exactly as `tools/analyze-map.mjs` reports them.
 */
import {
  Matrix,
  Mesh,
  Quaternion,
  TransformNode,
  Vector3,
  VertexBuffer,
  VertexData,
} from "@babylonjs/core";
import { soundManager } from "./soundManager.js";

/**
 * Speed above which a player impact destroys a roadside object, in km/h - the
 * same unit the HUD shows. Below this the prop behaves as solid scenery, so
 * ordinary low-speed nudges keep their normal collision response.
 */
export const IMPACT_SPEED_KMH = 20;

/**
 * Speed above which a RACE RIVAL breaks a roadside object, in km/h.
 *
 * A rival hits a prop exactly like the player does: traffic ignores the
 * destructible families in the collision grid and drives through them, but a
 * race rival does not - a sign is solid to its sweep, and the block is the hit
 * (see RaceDriver). What differs is the price and the gate: the player must be
 * doing at least 50 km/h to break one and pays half their speed for it, while a
 * rival breaks one at the speed it arrives with and carries straight on.
 *
 * The gate is only there to separate a moving contact from a coincidence - a
 * car locked on the grid (speed 0) never reaches this path at all - so it sits
 * well under the slowest racing speed. It has to: once a prop has blocked a
 * rival, the block costs it most of its speed, so a gate high enough to reject
 * that slowed-down contact would leave the car wedged against a sign it is
 * already touching.
 */
export const AI_IMPACT_SPEED_KMH = 3;

/** Downward acceleration used by the loose-prop integrator, m/s^2. */
const GRAVITY = 20;
/** Coarse grid cell used to find candidate props, metres. */
const GRID_CELL = 4;

/**
 * Angle at which a hinged prop has fallen flat. Past this it would be rotating
 * through the road, so the fall stops here and it lies on the surface.
 */
const HINGE_FALL_LIMIT = Math.PI * 0.5 + 0.15;

/**
 * How hard a resting loose prop is tipped onto its largest face, 1/s^2. A body
 * that pivots about its own centre gets no torque from gravity, so without this
 * it would freeze wherever its spin happened to die.
 */
const REST_STRENGTH = 26;
/** Below this tilt (sin of the angle from vertical) a prop counts as resting. */
const REST_TOLERANCE = 0.03;

/**
 * Tuning for the impact throw.
 *
 * The reaction is driven by the hit: speed scales the shove up and mass scales
 * it down, so a fast hit on a light fence flings it while a slow tap on a heavy
 * sign only lurches. Mass comes from the prop's bounding volume at a low
 * density, because a prop's box is mostly air (a barrel is a shell, a crate is a
 * frame) and what matters is only the spread between props.
 */
const PHYS = {
  density: 24, // kg per m^3 of bounding volume
  minMass: 2.5,
  maxMass: 240,
  referenceMass: 18,
  referenceSpeed: 14, // m/s (about 50 km/h)
  /**
   * Outgoing speed as a multiple of the car's own hit speed, before the mass
   * factor. 1.0 means a reference-mass prop leaves at the speed it was hit; the
   * mass factor spreads that from roughly 2x (a light street sign) down to a
   * fraction (a heavy prop), so both plainly carry the force of the impact.
   */
  speedFactor: 1.0,
  minLaunch: 1.5,
  maxLaunch: 42, // m/s, safety cap so a very fast hit cannot fling a prop off-map
};

/**
 * What each material does when hit.
 *
 * `hinge`  - the prop is attached at the ground: it rotates about a horizontal
 *            axis through its base and falls under a gravity torque, so once
 *            the hit tips it off vertical it topples flat - from any direction.
 * `solid`  - the prop is loose: it gets a shove and spins, falls under gravity,
 *            bounces a little and finally settles.
 */
const BEHAVIORS = {
  // Flexible/light: buckles where it was struck, then folds right over.
  flex: { mode: "hinge", omega: 7, fall: 8, damp: 4.4, push: 1.2, bend: 0.9 },
  // Rigid items struck at speed (sign posts, poles, benches): knocked free, tumble under gravity, and rest flat.
  topple: { mode: "solid", spin: 5.5, push: 1.6, hop: 0.8, restitution: 0.2, friction: 0.85 },
  // Loose rigid clutter: knocked free and tumbling.
  tumble: { mode: "solid", spin: 5.5, push: 1.8, hop: 1.0, restitution: 0.25, friction: 0.7 },
  // Cylindrical things: roll away instead of tumbling.
  roll: { mode: "solid", spin: 9, push: 2.4, hop: 0.2, restitution: 0.15, friction: 0.9, roll: true },
};

/**
 * Roadside families the player can destroy. `re` is tested against the mesh
 * name; the first match wins, so more specific families should come first.
 */
export const DESTRUCTIBLE_FAMILIES = [
  { id: "fence", re: /^fence_/i, behavior: "flex", label: "fence panel" },
  { id: "gate", re: /^gate_/i, behavior: "flex", label: "gate" },
  { id: "sign", re: /^streetsign/i, behavior: "topple", label: "street sign" },
  { id: "bench", re: /^bench_/i, behavior: "topple", label: "bench" },
  { id: "mailbox", re: /^mailbox_/i, behavior: "topple", label: "mailbox" },
  { id: "barrel", re: /^barrel_/i, behavior: "roll", label: "barrel" },
  { id: "cart", re: /^cart_/i, behavior: "roll", label: "hand cart" },
  { id: "log", re: /^logs_/i, behavior: "roll", label: "log stack" },
  { id: "crate", re: /^cratebox_/i, behavior: "tumble", label: "crate" },
  { id: "timber", re: /^timber_/i, behavior: "tumble", label: "timber" },
  { id: "mower", re: /^lawn_mower_/i, behavior: "tumble", label: "lawn mower" },
];

/**
 * Individual meshes that must stay solid even though their family is normally
 * destructible. These six street signs are the oversized, heavy ones - they are
 * meant to stop the car like scenery, not be smashed aside.
 */
const EXCLUDED_MESHES = /^streetsigns\.(024|025|026|027|028|029)(?![0-9])/i;

/** The family a mesh name belongs to, or null if it is not destructible. */
export function findDestructibleFamily(name) {
  if (!name) return null;
  if (EXCLUDED_MESHES.test(name)) return null;
  for (const family of DESTRUCTIBLE_FAMILIES) {
    if (family.re.test(name)) return family;
  }
  return null;
}

/**
 * `groupKey` for `MapCollision`: roadside props claim the obstacle cells they
 * bake, so their collision can be released later. Everything else returns null
 * and the bake skips the bookkeeping entirely.
 */
export function destructibleGroupKey(mesh) {
  return findDestructibleFamily(mesh?.name) ? mesh : null;
}

export class DestructibleSystem {
  /**
   * @param scene     Babylon scene the props live in
   * @param meshes    every map mesh, with world matrices already computed
   * @param collision MapCollision baked WITH `groupKey: destructibleGroupKey`
   */
  constructor(scene, meshes, collision, {
    speedThresholdKmh = IMPACT_SPEED_KMH,
    maxDebris = 60,
    respawnDistance = 45,
  } = {}) {
    this.scene = scene;
    this.collision = collision;
    this.speedThresholdKmh = speedThresholdKmh;
    this.maxDebris = maxDebris;
    /** How far the player must be from a broken prop before it repairs, metres. */
    this.respawnDistance = respawnDistance;

    this.objects = [];
    this.grid = new Map();
    this.active = [];
    this.debris = [];
    /** Objects currently broken and awaiting repair. */
    this.damaged = [];
    this.stats = { objects: 0, families: 0, destroyed: 0, restored: 0, active: 0, clearedCells: 0 };

    const seen = new Set();
    for (const mesh of meshes) {
      const family = findDestructibleFamily(mesh.name);
      if (!family) continue;
      if (!mesh.getTotalVertices || mesh.getTotalVertices() < 3) continue;
      const box = worldAabb(mesh);
      if (!box) continue;
      const object = {
        index: this.objects.length,
        mesh,
        // `MapCollision` keys the baked cells by the mesh it was handed at load
        // time, and a flexible prop's mesh may be swapped for a standalone copy
        // when it breaks, so the collision key is pinned here.
        collisionMesh: mesh,
        family,
        box,
        center: new Vector3(
          (box.minX + box.maxX) / 2,
          (box.minY + box.maxY) / 2,
          (box.minZ + box.maxZ) / 2,
        ),
        halfX: (box.maxX - box.minX) / 2,
        halfZ: (box.maxZ - box.minZ) / 2,
        halfY: (box.maxY - box.minY) / 2,
        // The mesh's own (unrotated) half-extents. Which of these is smallest
        // says which way the prop lies when it settles, since a prop at rest
        // sits on its largest face.
        localHalf: localHalfExtents(mesh),
        mass: meshMass(box),
        alive: true,
      };
      this.objects.push(object);
      this._insert(object);
      seen.add(family.id);
    }
    this.stats.objects = this.objects.length;
    this.stats.families = seen.size;
  }

  // ------------------------------------------------------------- indexing

  _insert(object) {
    const c0 = Math.floor(object.box.minX / GRID_CELL);
    const c1 = Math.floor(object.box.maxX / GRID_CELL);
    const r0 = Math.floor(object.box.minZ / GRID_CELL);
    const r1 = Math.floor(object.box.maxZ / GRID_CELL);
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const key = `${c},${r}`;
        let list = this.grid.get(key);
        if (!list) {
          list = [];
          this.grid.set(key, list);
        }
        list.push(object.index);
      }
    }
  }

  // -------------------------------------------------------------- impact

  /**
   * Called by a car when its swept motion is blocked. Returns true if anything
   * was destroyed, which tells the caller the way is now clear.
   *
   * @param info { x, z, heading, speed, y, clearance, height,
   *               halfLength, halfWidth, prevX?, prevZ? } - the pose the car
   *               could NOT reach, plus the length/width used for the collision
   *               footprint.
   * @param opts.thresholdKmh override for the speed gate. The player leaves it
   *   alone; a race rival passes its own, much lower one
   *   (AI_IMPACT_SPEED_KMH), because a racer breaking a sign at racing pace is
   *   not a crash - it is the line it chose.
   */
  handleImpact(info, { thresholdKmh = this.speedThresholdKmh } = {}) {
    if (!info) return false;
    const speedKmh = Math.abs(info.speed) * 3.6;
    // The gate that makes this an impact rather than a proximity trigger:
    // nothing happens unless the caller proved contact AND the car was at
    // least at the threshold. `>=` (not `>`) so a hit metering exactly
    // 50.0 km/h still breaks instead of surviving on rounding.
    if (!(speedKmh >= thresholdKmh)) return false;

    const hits = this._findHits(info);
    if (hits.length === 0) return false;

    const direction = this._impactDirection(info);
    for (const object of hits) this._destroy(object, info, direction);
    return true;
  }

  /** Props whose geometry overlaps the car's footprint at the blocked pose. */
  _findHits(info) {
    const sin = Math.sin(info.heading);
    const cos = Math.cos(info.heading);
    const ux = sin;
    const uz = cos; // car forward
    const vx = cos;
    const vz = -sin; // car right
    const hl = info.halfLength;
    const hw = info.halfWidth;
    const bottom = info.y + info.clearance;
    const top = info.y + info.height;

    // Tolerance matching the baked collision grid: obstacle cells are
    // `obstacleCell` wide while a fence panel or sign post is far thinner, so
    // the sweep (which tests cell centres widened by half a cell) stops the
    // car up to half a cell BEFORE the exact mesh box is touched. Without the
    // same slack here, shallow-angle and side-graze hits stop the car yet
    // report "no contact" - the exact miss. Half a cell plus a hair, so any
    // genuine contact the sweep proved always counts as a hit.
    const tol = (this.collision?.obstacleCell ?? 0.5) * 0.5 + 0.05;

    const reach = Math.hypot(hl, hw);
    const c0 = Math.floor((info.x - reach) / GRID_CELL);
    const c1 = Math.floor((info.x + reach) / GRID_CELL);
    const r0 = Math.floor((info.z - reach) / GRID_CELL);
    const r1 = Math.floor((info.z + reach) / GRID_CELL);

    const out = [];
    const seen = new Set();
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const list = this.grid.get(`${c},${r}`);
        if (!list) continue;
        for (const index of list) {
          if (seen.has(index)) continue;
          seen.add(index);
          const o = this.objects[index];
          if (!o.alive) continue;
          // The chassis must overlap the prop vertically, or an overhead sign
          // board would be "hit" by the car passing underneath it.
          if (o.box.minY >= top + tol || o.box.maxY <= bottom - tol) continue;
          // 2D separating-axis test between the car's oriented rectangle and
          // the prop's axis-aligned box. Axes are the car's two plus the world
          // two; a separating axis on any of them means no contact.
          const dx = o.center.x - info.x;
          const dz = o.center.z - info.z;
          if (
            Math.abs(dx * ux + dz * uz) >
            hl + o.halfX * Math.abs(ux) + o.halfZ * Math.abs(uz) + tol
          ) {
            continue;
          }
          if (
            Math.abs(dx * vx + dz * vz) >
            hw + o.halfX * Math.abs(vx) + o.halfZ * Math.abs(vz) + tol
          ) {
            continue;
          }
          if (Math.abs(dx) > o.halfX + hl * Math.abs(ux) + hw * Math.abs(vx) + tol) continue;
          if (Math.abs(dz) > o.halfZ + hl * Math.abs(uz) + hw * Math.abs(vz) + tol) continue;
          out.push(o);
        }
      }
    }
    return out;
  }

  _impactDirection(info) {
    if (info?.prevX !== undefined && info?.x !== undefined) {
      const dx = info.x - info.prevX;
      const dz = info.z - info.prevZ;
      const len = Math.hypot(dx, dz);
      if (len > 1e-4) return new Vector3(dx / len, 0, dz / len);
    }
    const sign = info.speed >= 0 ? 1 : -1;
    return new Vector3(Math.sin(info.heading) * sign, 0, Math.cos(info.heading) * sign);
  }

  // ------------------------------------------------------------ destroying

  _destroy(object, info, dir) {
    object.alive = false;
    this.stats.destroyed++;

    // Prop-break SFX: flavour follows the family (signs clang, fences crack).
    // Volume follows the hit speed; only played for the player car.
    try {
      if (info?.isPlayer) {
        const speedKmh = Math.abs(info?.speed ?? 0) * 3.6;
        const intensity = Math.min(1, Math.max(0.4, (speedKmh - 30) / 70));
        soundManager.playPropBreak(object.family?.id, { intensity });
      }
    } catch {
      /* audio must never interrupt the break */
    }

    const cfg = BEHAVIORS[object.family.behavior] ?? BEHAVIORS.tumble;
    // A flexible prop bends by rewriting its own vertices. An InstancedMesh
    // cannot do that without dragging every sibling along (`makeGeometryUnique`
    // does not exist on an instance), so it gets its own copy first - at the
    // identical transform, with no geometry baking - and only then is it bent.
    const mesh = cfg.mode === "hinge" && cfg.bend ? this._standalone(object) : object.mesh;
    const world = mesh.getWorldMatrix().clone();

    // Remember everything needed to put the prop back exactly where it was, so
    // it can repair itself once the player has driven away.
    object.restore = {
      parent: mesh.parent,
      position: mesh.position.clone(),
      rotation: mesh.rotation.clone(),
      rotationQuaternion: mesh.rotationQuaternion ? mesh.rotationQuaternion.clone() : null,
      scaling: mesh.scaling.clone(),
      geometry: null,
    };
    if (cfg.mode === "hinge" && cfg.bend) {
      // A flexible prop is bent by rewriting its vertices; keep a copy so the
      // bend can be undone on respawn.
      const positions = mesh.getVerticesData(VertexBuffer.PositionKind);
      const normals = mesh.getVerticesData(VertexBuffer.NormalKind);
      object.restore.geometry = {
        positions: positions ? Float32Array.from(positions) : null,
        normals: normals ? Float32Array.from(normals) : null,
      };
    }
    if (!this.damaged.includes(object)) this.damaged.push(object);

    // Free the space the prop occupied before moving it, so the car drives
    // through it rather than stopping behind a ghost wall.
    if (this.collision?.clearGroup) {
      this.stats.clearedCells += this.collision.clearGroup(object.collisionMesh);
    }

    const solid = cfg.mode === "solid";
    const pivotPos = solid
      ? object.center.clone()
      : new Vector3(object.center.x, object.box.minY, object.center.z);

    // Reparent the mesh itself onto a pivot (the same trick VehicleRig uses for
    // the wheels) rather than cloning it: nothing is duplicated, and the prop
    // is genuinely moved, not hidden and replaced.
    const pivot = new TransformNode(`${mesh.name}__pivot`, this.scene);
    pivot.position.copyFrom(pivotPos);
    pivot.rotationQuaternion = Quaternion.Identity();
    pivot.computeWorldMatrix(true);

    mesh.unfreezeWorldMatrix();
    mesh.doNotSyncBoundingInfo = false;
    mesh.isPickable = false;
    // The prop must never be hidden, disabled or culled while it breaks. A
    // stale bounding box (the map is frozen at load) can otherwise drop the
    // mesh from the draw list, which reads as the prop vanishing the instant it
    // is hit even though it is still in the scene.
    mesh.isVisible = true;
    mesh.visibility = 1;
    if (!mesh.isEnabled()) mesh.setEnabled(true);
    mesh.alwaysSelectAsActiveMesh = true;
    const local = world.multiply(Matrix.Invert(pivot.getWorldMatrix()));
    mesh.parent = pivot;
    mesh.rotationQuaternion = new Quaternion();
    local.decompose(mesh.scaling, mesh.rotationQuaternion, mesh.position);
    mesh.computeWorldMatrix(true);

    // Axis the prop rotates about. It must be horizontal and perpendicular to
    // the way the car was going so the prop falls AWAY. The imported town is
    // mirrored, so which way a positive rotation actually moves the top is
    // measured here instead of reasoned out.
    const axis = Vector3.Cross(Vector3.Up(), dir);
    if (axis.lengthSquared() < 1e-6) axis.setAll(1, 0, 0);
    axis.normalize();
    pivot.computeWorldMatrix(true);
    const invPivot = Matrix.Invert(pivot.getWorldMatrix());
    const localTop = Vector3.TransformCoordinates(
      new Vector3(object.center.x, object.box.maxY, object.center.z),
      invPivot,
    );
    const before = Vector3.TransformCoordinates(localTop, pivot.getWorldMatrix());
    pivot.rotationQuaternion = Quaternion.RotationAxis(axis, 0.1);
    pivot.computeWorldMatrix(true);
    const after = Vector3.TransformCoordinates(localTop, pivot.getWorldMatrix());
    if (
      (after.x - before.x) * dir.x + (after.z - before.z) * dir.z < 0
    ) {
      axis.negateInPlace();
    }
    pivot.rotationQuaternion = Quaternion.Identity();
    pivot.computeWorldMatrix(true);

    // A little variation between props so a row of identical fences does not
    // collapse in lockstep.
    const jitter = 0.82 + ((object.index % 9) / 9) * 0.36;

    // Impact-driven throw. The outgoing speed tracks the car's OWN speed: it is
    // the hit speed times a mass factor, so a light street sign leaves at close
    // to twice the hit speed while a heavy prop leaves slower - and both
    // visibly leave the coordinates they were hit at.
    const speed = Math.abs(info.speed);
    const massT = clamp(Math.sqrt(PHYS.referenceMass / object.mass), 0.5, 2.2);
    const launchSpeed = clamp(speed * PHYS.speedFactor * massT, PHYS.minLaunch, PHYS.maxLaunch);
    const hopT = launchSpeed / PHYS.referenceSpeed;
    // How fast the hit tips the prop over. Faster hits topple it faster, but it
    // is always given enough to tip off vertical so gravity can finish the job.
    const tipScale = clamp(speed / PHYS.referenceSpeed, 0.8, 2.0);

    if (cfg.mode === "hinge") {
      if (cfg.bend) this._bend(mesh, pivot, pivotPos, dir, cfg.bend);
      // Knocked off its footing at the impact speed, then folded as it travels.
      // A little lift so it is not glued to the road.
      const launch = launchSpeed * (0.9 + 0.2 * jitter);
      this.active.push({
        mode: "hinge",
        object,
        pivot,
        mesh,
        cfg,
        axis,
        base: pivotPos.clone(),
        dir: dir.clone(),
        angle: 0,
        angVel: cfg.omega * jitter * tipScale,
        vel: new Vector3(dir.x * launch, launchSpeed * 0.12, dir.z * launch),
        groundY: object.box.minY,
        age: 0,
        settled: false,
      });
    } else {
      const launch = launchSpeed * (0.9 + 0.2 * jitter);
      this.active.push({
        mode: "solid",
        object,
        pivot,
        mesh,
        cfg,
        axis,
        vel: new Vector3(dir.x * launch, cfg.hop * hopT, dir.z * launch),
        angVel: axis.scale(cfg.spin * jitter * (0.6 + massT)),
        halfY: object.halfY,
        groundY: object.box.minY,
        age: 0,
        settled: false,
      });
    }
    object.state = this.active[this.active.length - 1];
    this.stats.active = this.active.length;
  }

  /**
   * Return a mesh this prop can own outright, giving an InstancedMesh its own
   * copy of the source geometry.
   *
   * A flexible prop is deformed by rewriting its vertices in place. That cannot
   * be done on an InstancedMesh: it has no `makeGeometryUnique`, and rewriting
   * the shared buffer would bend every sibling in the row. One copy is made per
   * broken prop, at the instance's exact transform, and the original instance is
   * retired only once that copy is in the scene and genuinely renderable - so
   * the prop never blinks out. Nothing is baked or re-centred.
   */
  _standalone(object) {
    const mesh = object.mesh;
    if (typeof mesh.makeGeometryUnique === "function") return mesh;

    const source = mesh.sourceMesh ?? mesh;
    const positions = source.getVerticesData(VertexBuffer.PositionKind);
    if (!positions || positions.length < 9) return mesh;

    const copy = new Mesh(`${mesh.name}__prop`, this.scene);
    copy.material = mesh.material ?? source.material;
    copy.parent = mesh.parent;
    copy.position.copyFrom(mesh.position);
    copy.rotation.copyFrom(mesh.rotation);
    copy.rotationQuaternion = mesh.rotationQuaternion
      ? mesh.rotationQuaternion.clone()
      : null;
    copy.scaling.copyFrom(mesh.scaling);
    copy.isPickable = false;
    copy.computeWorldMatrix(true);

    const data = new VertexData();
    data.positions = Array.from(positions);
    const normals = source.getVerticesData(VertexBuffer.NormalKind);
    if (normals) data.normals = Array.from(normals);
    const uvs = source.getVerticesData(VertexBuffer.UVKind);
    if (uvs) data.uvs = Array.from(uvs);
    const indices = source.getIndices();
    if (indices) data.indices = Array.from(indices);
    data.applyToMesh(copy, false);
    copy.computeWorldMatrix(true);
    copy.refreshBoundingInfo();

    // Only retire the original once the replacement has real geometry; trading
    // a visible instance for an empty copy would be the prop vanishing.
    if (!copy.getTotalVertices || copy.getTotalVertices() < 3) {
      copy.dispose();
      return mesh;
    }

    object.mesh = copy;
    mesh.dispose();
    return copy;
  }

  /**
   * One-off bend of a flexible prop's geometry, so a fence visibly gives where
   * it was struck instead of pivoting like a rigid board. Vertices are curled
   * about a horizontal axis, with the deflection growing toward the top, then
   * the mesh is left with that permanent kink and animated normally.
   *
   * Runs once per hit, on a small mesh, so the cost is a few hundred vertex
   * writes - not a per-frame deformation.
   */
  _bend(mesh, pivot, pivotPos, dir, amount) {
    try {
      const positions = mesh.getVerticesData(VertexBuffer.PositionKind);
      if (!positions || positions.length < 9 || positions.length > 12000) return;
      mesh.makeGeometryUnique();
      mesh.computeWorldMatrix(true);
      const inv = Matrix.Invert(mesh.getWorldMatrix());
      const upLocal = Vector3.TransformNormal(Vector3.Up(), inv);
      if (upLocal.lengthSquared() < 1e-9) return;
      upLocal.normalize();
      const dirRaw = Vector3.TransformNormal(dir, inv);
      const dirLocal = dirRaw.subtract(upLocal.scale(Vector3.Dot(dirRaw, upLocal)));
      if (dirLocal.lengthSquared() < 1e-9) return;
      dirLocal.normalize();
      const base = Vector3.TransformCoordinates(pivotPos, inv);

      const count = positions.length / 3;
      const heights = new Float32Array(count);
      let maxH = 1e-3;
      for (let i = 0; i < count; i++) {
        const i3 = i * 3;
        const dx = positions[i3] - base.x;
        const dy = positions[i3 + 1] - base.y;
        const dz = positions[i3 + 2] - base.z;
        const h = dx * upLocal.x + dy * upLocal.y + dz * upLocal.z;
        heights[i] = h;
        if (h > maxH) maxH = h;
      }
      for (let i = 0; i < count; i++) {
        const i3 = i * 3;
        const dx = positions[i3] - base.x;
        const dy = positions[i3 + 1] - base.y;
        const dz = positions[i3 + 2] - base.z;
        const h = heights[i];
        const s = dx * dirLocal.x + dy * dirLocal.y + dz * dirLocal.z;
        // Component off the bending plane, preserved verbatim.
        const px = dx - h * upLocal.x - s * dirLocal.x;
        const py = dy - h * upLocal.y - s * dirLocal.y;
        const pz = dz - h * upLocal.z - s * dirLocal.z;
        const t = clamp(h / maxH, 0, 1);
        const th = amount * t * t;
        const cs = Math.cos(th);
        const sn = Math.sin(th);
        const s2 = s * cs + h * sn;
        const h2 = -s * sn + h * cs;
        positions[i3] = base.x + s2 * dirLocal.x + h2 * upLocal.x + px;
        positions[i3 + 1] = base.y + s2 * dirLocal.y + h2 * upLocal.y + py;
        positions[i3 + 2] = base.z + s2 * dirLocal.z + h2 * upLocal.z + pz;
      }
      mesh.updateVerticesData(VertexBuffer.PositionKind, positions);
      const indices = mesh.getIndices();
      if (indices) {
        const normals = new Float32Array(positions.length);
        VertexData.ComputeNormals(positions, indices, normals);
        mesh.setVerticesData(VertexBuffer.NormalKind, normals);
      }
      mesh.refreshBoundingInfo();
    } catch {
      // The bend is decorative; if the geometry will not cooperate the prop
      // still folds on its hinge, so an error here must not abort the impact.
    }
  }

  // --------------------------------------------------------------- update

  /**
   * Advance every prop that is still moving, then repair any prop the player
   * has left behind. Cheap when nothing is broken: the loop is skipped and
   * only the (usually empty) damaged list is walked.
   *
   * @param dt        seconds
   * @param playerPos current player position, used for the repair check
   */
  update(dt, playerPos = null) {
    const step = Math.min(dt, 0.05);
    for (let i = this.active.length - 1; i >= 0; i--) {
      const state = this.active[i];
      if (state.mode === "hinge") this._stepHinge(state, step);
      else this._stepSolid(state, step);
      if (state.settled) {
        this.active.splice(i, 1);
        this.debris.push(state);
        this._trimDebris();
      }
    }
    this.stats.active = this.active.length;
    if (playerPos) this._respawn(playerPos);
  }

  /**
   * Put back every broken prop that is now well behind the player. Racing games
   * reset scenery this way so the road is never left permanently missing a
   * sign, and the player never watches it happen because it is out of range.
   */
  _respawn(playerPos) {
    const range = this.respawnDistance * this.respawnDistance;
    for (let i = this.damaged.length - 1; i >= 0; i--) {
      const object = this.damaged[i];
      const dx = object.center.x - playerPos.x;
      const dz = object.center.z - playerPos.z;
      if (dx * dx + dz * dz > range) this._restore(object);
    }
  }

  /** Put one prop back exactly as it was, geometry and collision included. */
  _restore(object) {
    const restore = object.restore;
    if (!restore) return 0;
    const mesh = object.mesh;
    const damagedIndex = this.damaged.indexOf(object);
    if (damagedIndex >= 0) this.damaged.splice(damagedIndex, 1);

    // Undo a flexible prop's bend before it goes back.
    if (restore.geometry) {
      if (restore.geometry.positions) {
        mesh.setVerticesData(VertexBuffer.PositionKind, restore.geometry.positions);
      }
      if (restore.geometry.normals) {
        mesh.setVerticesData(VertexBuffer.NormalKind, restore.geometry.normals);
      }
    }

    // Detach from the debris pivot, then restore the map's original transform
    // and its frozen-matrix treatment.
    mesh.parent = restore.parent;
    mesh.position.copyFrom(restore.position);
    if (restore.rotationQuaternion) {
      mesh.rotationQuaternion = restore.rotationQuaternion.clone();
    } else {
      mesh.rotationQuaternion = null;
      mesh.rotation.copyFrom(restore.rotation);
    }
    mesh.scaling.copyFrom(restore.scaling);
    mesh.doNotSyncBoundingInfo = true;
    mesh.isPickable = false;
    mesh.isVisible = true;
    mesh.visibility = 1;
    mesh.alwaysSelectAsActiveMesh = false;
    mesh.computeWorldMatrix(true);
    mesh.freezeWorldMatrix();
    mesh.refreshBoundingInfo();

    const state = object.state;
    if (state) {
      const activeIndex = this.active.indexOf(state);
      if (activeIndex >= 0) this.active.splice(activeIndex, 1);
      const debrisIndex = this.debris.indexOf(state);
      if (debrisIndex >= 0) this.debris.splice(debrisIndex, 1);
      state.pivot.dispose();
    }

    this.collision?.restoreGroup?.(object.collisionMesh);
    object.state = null;
    object.restore = null;
    object.alive = true;
    this.stats.restored++;
    this.stats.active = this.active.length;
    return 1;
  }

  _stepHinge(state, dt) {
    const cfg = state.cfg;
    // Fall under gravity about the hinge, like an inverted pendulum: the
    // restoring torque is zero at the balance point and grows with sin(angle),
    // so once the hit has tipped the prop off vertical it accelerates over and
    // CANNOT stand itself back up - whichever direction it was hit from. There
    // is no fixed "lean" it springs back to.
    const accel =
      (cfg.fall ?? 9) * Math.sin(Math.max(state.angle, 0)) - cfg.damp * state.angVel;
    state.angVel += accel * dt;
    state.angle += state.angVel * dt;
    if (state.angle < 0) {
      state.angle = 0;
      state.angVel *= -0.2;
    }
    // Past a few degrees the prop is committed: gravity does not let a leaning
    // fixture stop halfway. A floor on the angular speed means damping or a
    // ground clamp can never leave it frozen standing at an angle.
    if (state.angle > 0.06 && state.angVel < 1.2) state.angVel = 1.2;
    // Lying flat: do not keep rotating through the road.
    if (state.angle > HINGE_FALL_LIMIT) {
      state.angle = HINGE_FALL_LIMIT;
      if (state.angVel > 0) state.angVel = 0;
    }
    // A bad value would fold the prop through an undefined pose and read as a
    // glitch; snap it back onto the hinge instead.
    if (!Number.isFinite(state.angle) || !Number.isFinite(state.angVel)) {
      state.angle = 0;
      state.angVel = 0;
    }
    state.pivot.rotationQuaternion = Quaternion.RotationAxis(state.axis, state.angle);

    // Momentum: the prop is knocked OFF its footing and slides/falls under
    // gravity rather than folding in place. The pivot sits on the prop's base,
    // so it is clamped to the road surface as it travels and never sinks into
    // the mesh it is resting on.
    const prevX = state.pivot.position.x;
    const prevZ = state.pivot.position.z;
    state.vel.y -= GRAVITY * dt;
    state.pivot.position.addInPlace(state.vel.scale(dt));
    this._blockWorld(state, prevX, prevZ);
    if (this._keepAboveGround(state)) {
      if (state.vel.y < 0) state.vel.y = 0;
      const grip = Math.max(0, 1 - 1.6 * dt);
      state.vel.x *= grip;
      state.vel.z *= grip;
    }

    state.age += dt;
    const fallen = state.angle >= HINGE_FALL_LIMIT - 0.02;
    const quiet = state.vel.lengthSquared() < 0.09 && Math.abs(state.angVel) < 0.2;
    if ((fallen && quiet && state.age > 0.4) || state.age > 8) {
      state.pivot.rotationQuaternion = Quaternion.RotationAxis(state.axis, state.angle);
      state.settled = true;
    }
  }

  _stepSolid(state, dt) {
    const cfg = state.cfg;
    // A NaN position is unrecoverable and would fling the prop to an invisible
    // corner of the world; stop there and let it settle instead.
    const p = state.pivot.position;
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || !Number.isFinite(p.z)) {
      state.settled = true;
      return;
    }
    const prevX = state.pivot.position.x;
    const prevZ = state.pivot.position.z;
    state.vel.y -= GRAVITY * dt;
    state.pivot.position.addInPlace(state.vel.scale(dt));
    this._blockWorld(state, prevX, prevZ);

    const spin = state.angVel.length();
    if (spin > 1e-4) {
      const delta = Quaternion.RotationAxis(state.angVel.scale(1 / spin), spin * dt);
      state.pivot.rotationQuaternion = delta.multiply(state.pivot.rotationQuaternion);
      state.pivot.rotationQuaternion.normalize();
    }

    if (this._keepAboveGround(state)) {
      if (state.vel.y < 0) {
        state.vel.y = Math.abs(state.vel.y) > 1.4 ? -state.vel.y * cfg.restitution : 0;
      }
      const grip = Math.max(0, 1 - cfg.friction * dt);
      state.vel.x *= grip;
      state.vel.z *= grip;
      if (cfg.roll) {
        // No-slip rolling: spin follows the remaining ground speed, so the
        // barrel slows down and its rotation slows with it.
        const speed = Math.hypot(state.vel.x, state.vel.z);
        state.angVel = state.axis.scale(speed / Math.max(state.halfY, 0.15));
      } else {
        state.angVel.scaleInPlace(Math.max(0, 1 - cfg.friction * dt));
        // A barrel rolls away; anything else is tipped over onto its largest
        // face rather than left balanced on a corner or leaning on nothing.
        if (state.angVel.lengthSquared() < 4.0) this._restOnFace(state, dt);
      }
    }

    state.age += dt;
    const quiet = state.vel.lengthSquared() < 0.09 && state.angVel.lengthSquared() < 0.09;
    const resting = cfg.roll || state.resting;
    // `age > 8` is a safety net so a prop wedged on a slope cannot integrate
    // forever; it simply comes to rest where it is.
    if ((state.age > 1.0 && quiet && resting) || state.age > 8) state.settled = true;
  }

  /**
   * Tip a grounded prop onto its largest face.
   *
   * A loose prop is pivoted about its own centre, so gravity acts through the
   * pivot and contributes no torque - it would otherwise stop dead in whatever
   * pose its tumble ended in, leaning on nothing. Real bodies fall onto their
   * stable face, so this steers the short axis toward vertical (the pose with
   * the biggest face on the ground) and marks the prop resting once it is
   * aligned and slow. Rolling props are exempt: for them lying on the side is
   * the correct rest pose and the roll integrator already handles it.
   */
  _restOnFace(state, dt) {
    const half = state.object.localHalf;
    // The mesh's own shortest axis is the one that belongs vertical once the
    // prop has settled onto its largest face.
    let k = 0;
    if (half.y <= half.x && half.y <= half.z) k = 1;
    else if (half.z <= half.x && half.z <= half.y) k = 2;

    // That axis, in world space, is column k of the mesh's world matrix.
    const m = state.mesh.getWorldMatrix().m;
    const len = Math.hypot(m[k * 4], m[k * 4 + 1], m[k * 4 + 2]) || 1;
    let ux = m[k * 4] / len;
    let uy = m[k * 4 + 1] / len;
    let uz = m[k * 4 + 2] / len;
    // Pick whichever end of the axis points up, so the prop turns the short
    // way round instead of rolling through a full half-turn.
    if (uy < 0) {
      ux = -ux;
      uy = -uy;
      uz = -uz;
    }

    const tilt = Math.hypot(ux, uz);
    if (!Number.isFinite(tilt)) return;
    if (tilt < REST_TOLERANCE) {
      state.resting = true;
      return;
    }

    // Torque about cross(axis, up): a rotation about that axis lifts the short
    // axis back toward vertical, i.e. drops the prop onto its largest face.
    state.angVel.x -= uz * REST_STRENGTH * dt;
    state.angVel.z += ux * REST_STRENGTH * dt;
    // Damp it so it settles rather than rocking past the upright pose.
    state.angVel.scaleInPlace(Math.max(0, 1 - 5 * dt));
  }

  /**
   * Stop a moving prop from crossing into map geometry.
   *
   * Motion is swept against the same baked obstacle grid the car uses, using
   * the prop's own footprint, so a thrown sign bounces off a building, a kerb
   * or another intact prop instead of passing through it. On a block the move
   * is refused and the velocity reflected/damped; when only one axis is clear
   * the prop slides along the wall, exactly like the car does.
   */
  _blockWorld(state, prevX, prevZ) {
    const collision = this.collision;
    if (!collision?.blockedRect) return;
    const object = state.object;
    const p = state.pivot.position;
    const hx = clamp(object.halfX, 0.1, 1.2);
    const hz = clamp(object.halfZ, 0.1, 1.2);
    const bottom = p.y - 0.1;
    const top = p.y + clamp(object.halfY, 0.5, 2.0) + 0.2;
    const blocked = (x, z) => collision.blockedRect(x, z, 0, hx, hz, bottom, top);
    if (!blocked(p.x, p.z)) return false;
    // If the prop already overlapped geometry (it was resting against a wall
    // when it broke, or was nudged in by the car), let it keep moving rather
    // than trapping it where it stands.
    if (blocked(prevX, prevZ)) return false;

    const okX = !blocked(p.x, prevZ);
    const okZ = !blocked(prevX, p.z);
    if (okX && !okZ) {
      p.z = prevZ;
      state.vel.z *= -0.25;
    } else if (okZ && !okX) {
      p.x = prevX;
      state.vel.x *= -0.25;
    } else {
      p.x = prevX;
      p.z = prevZ;
      state.vel.x *= -0.25;
      state.vel.z *= -0.25;
    }
    return true;
  }

  /**
   * Keep the whole prop above the road surface.
   *
   * The clamp uses the mesh's REAL world bounding box, not the pivot plus a
   * half-height. A folded fence, a sign lying flat or a tumbling crate has no
   * single "bottom" on its pivot, so measuring the actual lowest geometry is the
   * only way to stop it sinking into the road as it turns over. Returns true
   * when the prop is resting on the surface.
   */
  _keepAboveGround(state) {
    const p = state.pivot.position;
    const probe = this.collision?.groundAt?.(p.x, p.z, p.y, { stepUp: 4, reach: 10 });
    if (probe && probe.y !== null && probe.kind !== "wall") state.groundY = probe.y;

    // Derived from the mesh's own geometry and world matrix rather than its
    // synced bounding info, so it is correct even for an instanced prop or right
    // after the flexible bend has rewritten vertices.
    const box = worldAabb(state.mesh);
    if (!box) return false;
    if (box.minY < state.groundY) {
      p.y += state.groundY - box.minY;
      return true;
    }
    return false;
  }

  _trimDebris() {
    // Over the debris budget: repair the oldest broken prop rather than delete
    // it, which keeps the world self-healing and bounds the live debris count.
    while (this.debris.length > this.maxDebris) {
      const oldest = this.debris[0];
      if (oldest?.object) this._restore(oldest.object);
      else this.debris.shift();
    }
  }
}

// ---------------------------------------------------------------- helpers

const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

/** A mesh's own half-extents, before any world rotation, metres. */
function localHalfExtents(mesh) {
  const e = mesh.getBoundingInfo().boundingBox.extendSize;
  const sx = Math.abs(mesh.scaling?.x ?? 1);
  const sy = Math.abs(mesh.scaling?.y ?? 1);
  const sz = Math.abs(mesh.scaling?.z ?? 1);
  return { x: Math.abs(e.x) * sx, y: Math.abs(e.y) * sy, z: Math.abs(e.z) * sz };
}

/** Rough mass of a prop from its bounding volume, kg. */
function meshMass(box) {
  const volume = Math.max(
    (box.maxX - box.minX) * (box.maxY - box.minY) * (box.maxZ - box.minZ),
    0.02,
  );
  return clamp(volume * PHYS.density, PHYS.minMass, PHYS.maxMass);
}

/** World-space AABB of a mesh, from its local bounds and world matrix. */
function worldAabb(mesh) {
  if (!mesh.getTotalVertices || mesh.getTotalVertices() < 3) return null;
  mesh.computeWorldMatrix(true);
  const bb = mesh.getBoundingInfo().boundingBox;
  const m = mesh.getWorldMatrix().m;
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;
  for (let i = 0; i < 8; i++) {
    const x = i & 1 ? bb.maximum.x : bb.minimum.x;
    const y = i & 2 ? bb.maximum.y : bb.minimum.y;
    const z = i & 4 ? bb.maximum.z : bb.minimum.z;
    const wx = m[0] * x + m[4] * y + m[8] * z + m[12];
    const wy = m[1] * x + m[5] * y + m[9] * z + m[13];
    const wz = m[2] * x + m[6] * y + m[10] * z + m[14];
    if (wx < minX) minX = wx;
    if (wy < minY) minY = wy;
    if (wz < minZ) minZ = wz;
    if (wx > maxX) maxX = wx;
    if (wy > maxY) maxY = wy;
    if (wz > maxZ) maxZ = wz;
  }
  if (!Number.isFinite(minX)) return null;
  return { minX, minY, minZ, maxX, maxY, maxZ };
}
