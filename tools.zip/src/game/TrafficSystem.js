import { Color3 } from "@babylonjs/core";
import { Path } from "./driving.js";
import { TrafficVehicle } from "./TrafficVehicle.js";
import { TrafficRig } from "./TrafficRig.js";
import { buildLaneRoutes } from "./laneBuilder.js";
import { boxesOverlap, resolveVehicleCollision } from "./vehicleCollision.js";

/**
 * Palette so the traffic does not look like one car copied 40 times.
 * Picked to be reasonably visible against grey tarmac and green grass.
 */
const TRAFFIC_COLORS = [
  new Color3(0.80, 0.15, 0.16),
  new Color3(0.16, 0.30, 0.75),
  new Color3(0.92, 0.92, 0.94),
  new Color3(0.12, 0.12, 0.14),
  new Color3(0.90, 0.72, 0.12),
  new Color3(0.20, 0.55, 0.32),
  new Color3(0.55, 0.58, 0.62),
  new Color3(0.85, 0.45, 0.10),
];

/**
 * The default vehicle count for the city. Ambient but visibly dense traffic
 * spread across the whole map - 24 cars so every district reads as alive
 * without turning the roads into a jam, and still a predictable per-frame
 * AI cost.
 */
const DEFAULT_MAX_VEHICLES = 24;

/**
 * Minimum spacing between two spawned vehicles along the same lane,
 * metres. Prevents cars from spawning right next to each other.
 */
const MIN_LANE_SPACING = 28;

/**
 * Spawns and drives all AI traffic.
 *
 * The traffic system is built around the catalogue of vehicle assets in
 * `public/assets/vehicles/` (loaded once at startup by the main module
 * and passed in as `assets`). Cars are picked per spawn with a "no
 * recent repeat" rule: each new spawn tries to use a model that was not
 * used by either of the previous two cars on the same lane, so a single
 * model does not appear three times in a row.
 *
 * Density is deliberately ambient-but-dense: ~24 cars total, distributed
 * across the chosen routes proportional to each route's length, with a hard
 * minimum spacing so two cars never sit on top of each other. Spawns are
 * staggered in both space and speed (golden-ratio phase + per-car jitter)
 * so traffic reads as spread all over the map at different times and
 * locations - never a jam, never a desert, never a convoy.
 *
 * Routes themselves come from laneBuilder.js, which constructs them at
 * runtime from the baked collision model's roadway mask. They are
 * closed loops, so a car that finishes a circuit simply continues
 * around. The off-screen recovery in TrafficVehicle._maybeRecoverOffscreen
 * re-seeds any car that ends up off its lane.
 */
export class TrafficSystem {
  /**
   * @param scene          Babylon scene.
   * @param assets         array of asset entries from `loadVehicleAssets`.
   * @param routeData      parsed routes.json (only bounds/spawn info still used).
   * @param options.maxVehicles  upper bound on spawned vehicles (perf guard).
   * @param options.collision    MapCollision used to build lanes and drive cars.
   * @param options.player       the player vehicle (so AI can detect it ahead).
   */
  constructor(scene, assets, routeData, { maxVehicles = DEFAULT_MAX_VEHICLES, maxRoutes = 8, collision = null, player = null } = {}) {
    this.maxRoutes = maxRoutes;
    this.scene = scene;
    this.collision = collision;
    this.assets = assets;
    this.player = player;
    this.vehicles = [];
    /**
     * Vehicles that are not traffic but should still be seen and avoided by
     * it - the race field, while a race is running. They are NOT updated here
     * (the RaceSystem drives them); they only enter the blocker scan, so
     * ambient cars brake for a race car crossing their path instead of driving
     * through it.
     */
    this.extraVehicles = [];

    /**
     * Ambient vehicles parked for the duration of a race (see `holdCircuit`).
     * Kept out of `vehicles` so no existing consumer - the AI blocker scan,
     * the player's collision sweep, `clearArea` - can see them until the race
     * is over.
     */
    this.heldVehicles = [];
    this._heldPath = null;

    if (!collision) throw new Error("TrafficSystem requires a collision model");
    if (!assets || !assets.length) throw new Error("TrafficSystem requires at least one vehicle asset");

    // --- build lanes from the baked roadway mask ------------------------
    const built = buildLaneRoutes(collision);
    this.laneStats = built.stats;
    this.bridgeFound = built.bridgeFound;

    // Structure routes first (the recycled bridge+highway cycle, then a bridge
    // loop, then elevated highways), then the longest city loops. The special
    // corridors are what make traffic circulate across the whole map instead of
    // staying in one district, so they must survive route selection. An open
    // route (`open`) recycles end -> start instead of wrapping as a loop.
    const rank = (r) => (r.recycle ? 3 : 0) + (r.bridge ? 2 : 0) + (r.elevated ? 1 : 0);
    const allRoutes = built.routes
      .map((r) => ({ ...r, path: new Path(r.points, { open: !!r.open }) }))
      .sort((a, b) => rank(b) - rank(a) || b.path.length - a.path.length);

    if (!allRoutes.length) throw new Error("no drivable traffic lanes could be built from the map");

    // Prefer structure loops, then the longest general loops; skip routes
    // that too closely overlap an already-chosen one so lanes do not
    // double up.
    const routes = selectDistinctRoutes(allRoutes, 0.45, Math.min(this.maxRoutes, allRoutes.length));
    if (!routes.length) throw new Error("no non-overlapping traffic routes");

    // Distribute the vehicle budget across routes. Each route gets a
    // proportional share (longer route -> more cars) with a floor of 1.
    const totalLength = routes.reduce((s, r) => s + r.path.length, 0);
    const plan = [];
    let remaining = maxVehicles;
    for (const route of routes) {
      if (remaining <= 0) break;
      // Structure routes (bridge / elevated) keep at least two cars so the
      // special corridors are always visibly in use, not just theoretically
      // reachable. The rest get a length-proportional share.
      const floor = route.recycle || route.bridge || route.elevated ? 2 : 1;
      const share = Math.max(floor, Math.round((route.path.length / totalLength) * maxVehicles));
      const count = Math.min(share, remaining);
      plan.push({ route, count });
      remaining -= count;
    }

    // --- spawn vehicles with spacing & variety -------------------------
    let spawnIndex = 0;
    for (const { route, count } of plan) {
      // Spacing along the loop: divide the loop length evenly, but enforce
      // a minimum spacing so cars do not bunch. If the loop is too short
      // to fit `count` cars at the minimum spacing, spawn whatever fits
      // instead of skipping the route outright (otherwise the budget is
      // silently lost and a district ends up empty).
      let fitCount = count;
      let spacing = route.path.length / fitCount;
      if (spacing < MIN_LANE_SPACING) {
        fitCount = Math.max(1, Math.floor(route.path.length / MIN_LANE_SPACING));
        spacing = route.path.length / fitCount;
      }

      for (let i = 0; i < fitCount; i++) {
        const asset = this._pickAsset(spawnIndex, route.id);
        const rig = this._spawnRig(asset, `traffic${spawnIndex}`);
        rig.setColor(TRAFFIC_COLORS[spawnIndex % TRAFFIC_COLORS.length]);

        // Spread cars all over the lane in both space and time: even slots
        // around the loop plus a golden-ratio phase per vehicle (so routes
        // do not line up with each other) plus a small deterministic jitter.
        // Speeds and lateral offsets also vary per car so sharing a lane does
        // not read as a convoy - cars drift apart and bunch up naturally.
        const phase = ((spawnIndex * 0.61803398875) % 1) * route.path.length;
        const jitter = ((spawnIndex * 37 + i * 23) % 31);
        const startDistance = ((i / fitCount) * route.path.length + phase + jitter) % route.path.length;
        // Cruise speed in m/s; roughly 29-72 km/h with a wider spread than
        // before so some cars cruise while others push on. Trucks stay slower.
        const isTruck = /truck|pickup|minivan|ambulance/i.test(asset.spec.label);
        const cruiseSpeed = isTruck
          ? 7 + ((spawnIndex * 5 + i * 3) % 7)
          : 8 + ((spawnIndex * 7 + i * 5) % 13);
        const laneOffset = (((spawnIndex + i) % 5) - 2) * 0.5;

        this.vehicles.push(
          new TrafficVehicle(rig, route, {
            startDistance,
            cruiseSpeed,
            laneOffset,
            collision: this.collision,
            player: this.player,
          }),
        );
        spawnIndex++;
      }
    }

    // Exposed for the headless probes and console poking.
    this.allRoutes = allRoutes;
    this.routes = routes;
    this.routeCount = routes.length;
    this.consideredRoutes = allRoutes.length;
    this.plan = plan.map((p) => ({
      recycle: !!p.route.recycle,
      bridge: !!p.route.bridge,
      elevated: !!p.route.elevated,
      count: p.count,
      length: Math.round(p.route.path.length),
      points: p.route.points.length,
    }));
  }

  /**
   * Pick a vehicle asset for the n-th spawn.
   *
   * The "no recent repeat" rule uses the last two asset indices that
   * were assigned on the same lane; the next pick is drawn from the
   * assets that are not those two. If only one model is available, the
   * rule degenerates to "always pick that model" - which is fine.
   */
  _pickAsset(spawnIndex, routeId) {
    // Lazy-init the per-route history.
    if (!this._recentPicks) this._recentPicks = new Map();
    if (!this._recentPicks.has(routeId)) this._recentPicks.set(routeId, []);
    const history = this._recentPicks.get(routeId);

    if (this.assets.length === 1) return this.assets[0];

    // Pick from the assets not in the recent history.
    const candidates = this.assets.filter((a) => !history.includes(a.index));
    const pool = candidates.length ? candidates : this.assets;
    // Use a deterministic permutation seeded by spawnIndex so the
    // variety is stable across reloads.
    const pick = pool[spawnIndex % pool.length];
    history.push(pick.index);
    if (history.length > 2) history.shift();
    return pick;
  }

  _spawnRig(asset, name) {
    return new TrafficRig(this.scene, asset, name);
  }

  /**
   * Update every vehicle. `playerPos` is passed in for the off-screen
   * recovery system - a vehicle that is far from the player is allowed
   * to teleport back onto its lane if it has been knocked off.
   */
  update(dt, playerPos = null) {
    // Distance-based scan throttling: cars near the player scan every
    // frame; cars far away scan every 4th. We update `_scanEvery` once
    // per update so the value is consistent across the frame.
    const px = playerPos?.x ?? 0;
    const pz = playerPos?.z ?? 0;
    for (const v of this.vehicles) {
      const dx = v.state.x - px;
      const dz = v.state.z - pz;
      const distSq = dx * dx + dz * dz;
      // Far cars: scan every 4th frame. Closer cars: every frame.
      v._scanEvery = distSq > 80 * 80 ? 4 : 1;
      v.update(dt, this, playerPos);
    }
  }

  /**
   * Collide the player against traffic vehicles.
   *
   * For each vehicle, check whether the player's swept motion this
   * frame would have crossed the vehicle's footprint. If so:
   *   - the player is bounced off and slowed,
   *   - the traffic vehicle receives an opposing shove (so it gets
   *     pushed/rotated by the impact),
   *   - the player's reported speed is reduced so its own controller
   *     does not just drive straight through.
   *
   * The brief asks for "natural" collisions: no flying cars, no physics
   * explosions, just believable contact. The implementation uses a
   * 2D oriented-rectangle intersection and an impulse model, which is
   * light enough to run for every vehicle every frame and still feels
   * solid.
   *
   * @returns an object { slowedSpeed, hitX, hitZ } describing the
   *          post-collision player state, or null if no collision
   *          happened this frame.
   */
  collideWithPlayer(playerState, prevX, prevZ) {
    return resolveVehicleCollision(this.player, this.vehicles, prevX, prevZ);
  }

  /** Kept for callers that referenced the SAT test directly. */
  _boxesOverlap(px, pz, pHeading, pHalfL, pHalfW, v) {
    return boxesOverlap(px, pz, pHeading, pHalfL, pHalfW, v);
  }

  /**
   * Move any traffic vehicle within `radius` of (x,z) further along its lane,
   * so the grid a race is about to be placed on is clear. Used at the start of
   * a race: without it a rival (or the player) can be teleported onto the grid
   * inside a parked traffic car and be stuck there from the lights.
   *
   * @returns the number of vehicles moved.
   */
  clearArea(x, z, radius = 26, ahead = 90) {
    let moved = 0;
    for (const v of this.vehicles) {
      const dx = v.state.x - x;
      const dz = v.state.z - z;
      if (dx * dx + dz * dz > radius * radius) continue;
      if (typeof v.relocateAhead !== "function") continue;
      if (v.relocateAhead(ahead)) moved++;
    }
    return moved;
  }

  /**
   * Take a circuit out of the ambient traffic for the duration of a race.
   *
   * Racing happens on a road the traffic fleet also drives, and a field of six
   * cars sharing a lane with ambient traffic cannot get round a lap: the
   * rivals spend the race braking behind a road car that is following the same
   * lane at a cruise. Real racing games close the course for the event, and so
   * does this - the vehicles whose route IS the circuit are hidden and stopped,
   * and returned to the road when the race is done.
   *
   * They are moved OUT of `vehicles` rather than flagged, so every existing
   * consumer stops seeing them with no change of its own.
   *
   * @returns the number of vehicles held.
   */
  holdCircuit(path) {
    if (!path) return 0;
    if (this._heldPath === path) return 0;
    if (this._heldPath) this.releaseCircuit();
    const kept = [];
    const held = [];
    for (const v of this.vehicles) {
      if (v.path === path) held.push(v);
      else kept.push(v);
    }
    for (const v of held) {
      v.rig?.setVisible?.(false);
      v.state.speed = 0;
      if (v.shove) v.shove.time = 0;
    }
    this.vehicles = kept;
    this.heldVehicles = held;
    this._heldPath = path;
    this._buildCircuitCells(path);
    return held.length;
  }

  /**
   * Coarse grid covering the held circuit, so "is this car on the course?" is a
   * set lookup rather than a walk down the path. Cells are 20 m and a 3x3
   * neighbourhood is marked, i.e. anything within roughly a road's width of the
   * circuit counts.
   */
  _buildCircuitCells(path) {
    const cells = new Set();
    const cell = 20;
    for (let d = 0; d < path.length; d += 6) {
      const p = path.sample(d);
      const cx = Math.floor(p.x / cell);
      const cz = Math.floor(p.z / cell);
      for (let ox = -1; ox <= 1; ox++) {
        for (let oz = -1; oz <= 1; oz++) cells.add(`${cx + ox},${cz + oz}`);
      }
    }
    this._heldCells = cells;
  }

  /**
   * Hide and stop any vehicle that has wandered onto the held circuit since the
   * last sweep. `holdCircuit` catches the cars whose route IS the circuit; this
   * catches the ones on OTHER routes that merely cross it - which otherwise sit
   * on the racing line and block the field, the very thing closing the course
   * is for. Called once per race frame.
   *
   * @returns the number of vehicles swept off the course.
   */
  sweepCircuit() {
    if (!this._heldPath || !this._heldCells) return 0;
    const vehicle = [];
    let moved = 0;
    for (const v of this.vehicles) {
      const key = `${Math.floor(v.state.x / 20)},${Math.floor(v.state.z / 20)}`;
      if (this._heldCells.has(key)) {
        v.rig?.setVisible?.(false);
        v.state.speed = 0;
        if (v.shove) v.shove.time = 0;
        this.heldVehicles.push(v);
        moved++;
      } else {
        vehicle.push(v);
      }
    }
    this.vehicles = vehicle;
    return moved;
  }

  /** Put the traffic that `holdCircuit` parked back on the road. */
  releaseCircuit() {
    if (!this._heldPath) return 0;
    const n = this.heldVehicles.length;
    for (const v of this.heldVehicles) {
      // Send it up its lane before it reappears, so a parked car does not pop
      // back into existence inside whatever is standing on the grid.
      if (typeof v.relocateAhead === "function") v.relocateAhead(60);
      v.rig?.setVisible?.(true);
    }
    this.vehicles = this.vehicles.concat(this.heldVehicles);
    this.heldVehicles = [];
    this._heldPath = null;
    this._heldCells = null;
    return n;
  }

  /** True while an ambient route is being held clear for a race. */
  get circuitHeld() {
    return this._heldPath !== null;
  }

  /** Nearest traffic vehicle to a point. */
  nearest(x, z) {
    let best = null;
    let bestDist = Infinity;
    for (const v of this.vehicles) {
      const d = (v.state.x - x) ** 2 + (v.state.z - z) ** 2;
      if (d < bestDist) {
        bestDist = d;
        best = v;
      }
    }
    return best ? { vehicle: best, distance: Math.sqrt(bestDist) } : null;
  }

  get count() {
    return this.vehicles.length;
  }
}

/**
 * Splits a route's centre line into a set of coarse grid cells, so two
 * routes covering the same stretch of road produce the same keys.
 */
function routeCells(route, cell = 8) {
  const cells = new Set();
  for (const p of route.path.points) {
    cells.add(`${Math.round(p.x / cell)},${Math.round(p.z / cell)}`);
  }
  return cells;
}

/** Fraction of the smaller route that lies on shared road. */
function overlapRatio(a, b) {
  const small = a.size <= b.size ? a : b;
  const large = a.size <= b.size ? b : a;
  let shared = 0;
  for (const key of small) if (large.has(key)) shared++;
  return shared / (small.size || 1);
}

/** Greedy selection: bridge + longest routes first, skipping near-duplicates. */
function selectDistinctRoutes(routes, maxOverlap, maxCount) {
  const chosen = [];
  const cells = [];
  for (const route of routes) {
    if (chosen.length >= maxCount) break;
    const candidate = routeCells(route);
    const clashes = cells.some((c) => overlapRatio(c, candidate) > maxOverlap);
    if (clashes) continue;
    chosen.push(route);
    cells.push(candidate);
  }
  return chosen;
}
