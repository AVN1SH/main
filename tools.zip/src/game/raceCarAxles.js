/**
 * Pure geometry/naming rules for the race cars, kept away from Babylon so they
 * can be checked offline against the real `.glb` files
 * (`tools/race-car-check.mjs`).
 *
 * The race field is authored in two different conventions and one of the models
 * (`car2.glb`) has a wheel whose NAME contradicts its POSITION, so every
 * decision here is made from measurements plus a name vote rather than from a
 * naming rule.
 */

/** A wheel mesh: `Tire` (race pack) or `wheel` (car1-style models). */
export const WHEEL_RE = /(tire|wheel)/i;

/**
 * Axle labels, as the part of a token left once the wheel word is removed.
 *
 * The one-letter forms are deliberately absent: `rFWheel.001` is "right FRONT
 * wheel", so its leading `r` is the side, not the axle - reading it as "rear"
 * is exactly the mistake this table exists to avoid. Removing the `Wheel`
 * suffix leaves `rf`, which is unambiguous.
 */
const FRONT_LABEL = new Set(["lf", "rf", "fl", "fr", "front"]);
const REAR_LABEL = new Set(["lr", "rr", "rl", "bl", "br", "lb", "rb", "rear", "back"]);

/**
 * Candidate tokens for a node name, in priority order.
 *
 * Two readings are offered because the two families write the axle differently:
 *
 *   `rFWheel.001`  -> [`rfwheel`, `001`]           (separators only) -> `rf`
 *   `leftFrontWheel` -> [`left`, `front`, `wheel`] (camelCase split) -> `front`
 *
 * The separator-only reading is tried first, so a camelCase split can never
 * turn `rFWheel` into a bare `r`.
 */
function* candidateTokens(name) {
  const raw = String(name ?? "");
  const split = (s) => s.split(/\s+/).filter(Boolean);
  yield* split(raw.replace(/[^a-zA-Z0-9]+/g, " ").trim().toLowerCase());
  yield* split(
    raw
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .toLowerCase(),
  );
}

/** The axle label inside one token, or null. */
function axleOfToken(token) {
  if (!token) return null;
  const bases = [token];
  const stripped = token.replace(/(wheel|tire|tyre)s?$/, "");
  if (stripped !== token && stripped) bases.push(stripped);
  const prefixed = token.replace(/^(wheel|tire|tyre)s?/, "");
  if (prefixed !== token && prefixed) bases.push(prefixed);
  for (const b of bases) {
    if (FRONT_LABEL.has(b)) return "front";
    if (REAR_LABEL.has(b)) return "rear";
  }
  return null;
}

/**
 * Which end of the car a wheel belongs to, from its name alone, or null.
 *
 * The label has to be the whole token (after the wheel word is removed):
 * `Classic Car_9 BL Tire` splits into [`classic`,`car`,`9`,`bl`,`tire`] and only
 * `bl` counts, so the "ack" in "Hatchback" or the "b" of a model name can never
 * be mistaken for an axle.
 */
export function wheelEndFromName(name) {
  for (const token of candidateTokens(name)) {
    const end = axleOfToken(token);
    if (end) return end;
  }
  return null;
}

/**
 * Work out the car's long axis and which axle is the front one.
 *
 * @param bodyBox     { min:{x,y,z}, max:{x,y,z} } of the body geometry
 * @param wheelCentres world-space centres, one per wheel
 * @param wheelNames   mesh names, same order
 * @returns {{ longAxis, lateralAxis, isFront: boolean[], votes: number[],
 *            ends: Array<{named:string|null, measured:string}> }}
 */
export function classifyAxles(bodyBox, wheelCentres, wheelNames) {
  const sizeX = bodyBox.max.x - bodyBox.min.x;
  const sizeZ = bodyBox.max.z - bodyBox.min.z;
  // The body is several times longer than it is wide in every one of these
  // models, so its own box settles the axis far more reliably than the wheels
  // do (a wide car's track can approach its wheelbase).
  const longAxis = sizeX >= sizeZ ? "x" : "z";
  const lateralAxis = longAxis === "x" ? "z" : "x";
  const centerLong = (bodyBox.min[longAxis] + bodyBox.max[longAxis]) / 2;

  let positiveVote = 0;
  let negativeVote = 0;
  const ends = [];
  for (let i = 0; i < wheelCentres.length; i++) {
    const named = wheelEndFromName(wheelNames[i]);
    const vote = named === "front" ? 1 : named === "rear" ? -1 : 0;
    const side = wheelCentres[i][longAxis] - centerLong >= 0;
    if (side) positiveVote += vote;
    else negativeVote += vote;
    ends.push({ named, measured: "" });
  }

  // `car2.glb` carries two wheels called `rfWheel`, one of them on the REAR
  // axle, which is why this is a vote rather than a lookup: the front side
  // still wins 2 to 0 there, and every other model agrees with itself. A tie
  // falls back to the negative side, which is the front end of the `car*`
  // family; the rig records the votes either way so a tie is visible in the
  // diagnostics rather than silent.
  const frontIsPositive = positiveVote === negativeVote ? false : positiveVote > negativeVote;

  const isFront = wheelCentres.map((c) => (c[longAxis] - centerLong >= 0) === frontIsPositive);
  for (let i = 0; i < ends.length; i++) ends[i].measured = isFront[i] ? "front" : "rear";
  return { longAxis, lateralAxis, isFront, votes: [positiveVote, negativeVote], ends };
}
