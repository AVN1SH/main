import { CAR, Path, clamp } from "./driving.js";
import { TerrainFollower } from "./terrain.js";

/**
 * Builds the race circuit for the one race the game ships, from the same baked
 * road mask the traffic lanes come from.
 *
 * There is no hand-authored track data. The lanes that `laneBuilder.js` already
 * validated (drivable surface, clear of the median, the car's footprint fits
 * with room to spare) are exactly what a race circuit needs, so the race reuses
 * one of them rather than inventing a second source of truth that could
 * disagree with the roads the cars actually drive on.
 *
 * Selection is deterministic and explainable:
 *
 *   1. keep the CLOSED loops (an open/recycling traffic route is not a circuit),
 *   2. of those, take the longest ones a car can clearly drive,
 *   3. prefer the ones that come near the paddock anchor - the player's own
 *      spawn - so the event is a short drive away rather than across the map.
 *
 * The start/finish line then sits at the point of that circuit nearest the
 * anchor, which is what makes the race discoverable: the player spawns looking
 * at it.
 */

/** A circuit shorter than this is not worth a race. */
const MIN_LENGTH = 600;
/** The event is preferred within this distance of the paddock anchor, metres. */
const NEAR_REACH = 170;
/** Lap count for the one race. */
export const DEFAULT_LAPS = 2;
/** Grid geometry, metres — wide enough that the field launches, not jams. */
const GRID_ROW_GAP = 9.5;
const GRID_COL_GAP = 3.4;
/** Longitudinal offset between the two grid columns (staggered grid). */
const GRID_COL_STAGGER = 4.5;
const GRID_ROWS_FIRST_OFFSET = 2.6;
/**
 * Metres past the start line the BACK row of an on-circuit grid sits.
 *
 * Must clear the intro's rollout: RaceSystem stages every car `ROLLOUT_BACK`
 * (8 m) behind its slot before rolling it in, so a tail any closer to the line
 * would be staged behind the start rather than on the course.
 */
const GRID_FIRST_S = 12;
/** How far past the line the grid will walk to find a straight to sit on. */
const GRID_STRAIGHT_REACH = 40;
/** Nominal distance between checkpoints, metres. */
const CHECKPOINT_SPACING = 130;
const MIN_GATES = 5;
const MAX_GATES = 28;
/** Bounds on a gate's measured half-width, metres. */
const GATE_MIN_HALF = 3.0;
const GATE_MAX_HALF = 8.0;

/** Minimal car geometry, matching laneBuilder's validator. */
function probeGeometry() {
  return {
    wheels: [
      { x: -0.95, z: 1.175 },
      { x: 0.95, z: 1.175 },
      { x: -0.95, z: -1.175 },
      { x: 0.95, z: -1.175 },
    ],
    wheelBase: CAR.wheelBase,
    track: CAR.width,
    halfLength: CAR.length / 2,
    halfWidth: CAR.width / 2,
    height: CAR.height,
    clearance: CAR.clearance,
  };
}

/**
 * @param collision baked MapCollision
 * @param routes    the built lane routes (TrafficSystem.allRoutes)
 * @param opts.anchor {x,z} - the paddock, i.e. where the player starts
 * @param opts.laps   lap count
 * @param opts.fieldSize   how many cars will be gridded (max 6)
 */
export function buildRaceTrack(collision, routes, { anchor = null, laps = DEFAULT_LAPS, fieldSize = 6 } = {}) {
  if (!collision) throw new Error("buildRaceTrack requires the collision model");
  const closed = (routes ?? []).filter((r) => r && r.points?.length > 8 && !r.open);
  if (!closed.length) throw new Error("buildRaceTrack: no closed lane loop is available to race on");

  const near = (route) => {
    if (!anchor) return 0;
    let best = Infinity;
    for (const p of route.points) {
      const d = Math.hypot(p.x - anchor.x, p.z - anchor.z);
      if (d < best) best = d;
    }
    return best;
  };

  // --- choose the circuit -------------------------------------------------
  const scored = closed.map((route) => ({
    route,
    length: route.path?.length ?? polylineLength(route.points),
    clearance: route.clearance ?? 0,
    near: near(route),
  }));
  const longEnough = scored.filter((s) => s.length >= MIN_LENGTH);
  const pool = longEnough.length ? longEnough : scored;
  const reachable = pool.filter((s) => s.near <= NEAR_REACH);
  const finalists = reachable.length ? reachable : pool;
  finalists.sort((a, b) => b.length - a.length || b.clearance - a.clearance || a.near - b.near);
  const winner = finalists[0];

  const points = winner.route.points.map((p) => ({ x: p.x, y: p.y, z: p.z }));
  const path = winner.route.path instanceof Path ? winner.route.path : new Path(points, { open: false });
  const length = path.length;

  // --- start/finish line: the circuit point nearest the paddock ----------
  let startDistance = 0;
  {
    let bestSq = Infinity;
    const step = Math.max(1, Math.round(length / 900));
    for (let s = 0; s < length; s += step) {
      const p = path.sample(s);
      const dx = p.x - (anchor?.x ?? p.x);
      const dz = p.z - (anchor?.z ?? p.z);
      const sq = dx * dx + dz * dz;
      if (sq < bestSq) {
        bestSq = sq;
        startDistance = s;
      }
    }
  }

  /** On-track pose at arc length `s` (``offset`` metres behind the line). */
  const poseAt = (s) => {
    const p = path.sample(s);
    const a = path.sample(s - 3);
    const b = path.sample(s + 3);
    const heading = Math.atan2(b.x - a.x, b.z - a.z);
    return { x: p.x, y: p.y, z: p.z, heading };
  };

  const probe = new TerrainFollower(collision, probeGeometry(), 6, null);
  const groundY = (x, z, ref) => {
    const g = collision.groundAt(x, z, ref ?? 6, { stepUp: 3, reach: 8 });
    return g.kind === "ground" ? g.y : null;
  };

  // --- checkpoint gates ---------------------------------------------------
  // Ensure checkpoint gates never land on corners; place them ahead or before on straights.
  const diffHeading = (h1, h2) => {
    let d = h1 - h2;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return Math.abs(d);
  };
  const curvatureAt = (s, span = 7) => diffHeading(poseAt(s + span).heading, poseAt(s - span).heading);
  const isStraight = (s) =>
    curvatureAt(s, 7) < 0.08 &&
    curvatureAt(s - 6, 6) < 0.09 &&
    curvatureAt(s + 6, 6) < 0.09;

  const straighten = (s0, minS, maxS) => {
    const s = ((s0 % length) + length) % length;
    if (s >= minS && s <= maxS && isStraight(s)) return s;
    let best = clamp(s, minS, maxS);
    let bestCurv = curvatureAt(best, 7);
    for (let off = 3; off <= 80; off += 3) {
      for (const cand of [((s0 - off) % length + length) % length, ((s0 + off) % length + length) % length]) {
        if (cand >= minS && cand <= maxS) {
          if (isStraight(cand)) return cand;
          const cv = curvatureAt(cand, 7);
          if (cv < bestCurv) {
            bestCurv = cv;
            best = cand;
          }
        }
      }
    }
    return best;
  };

  const gateCount = clamp(Math.round(length / CHECKPOINT_SPACING), MIN_GATES, MAX_GATES);
  const gates = [];
  let prevS = -Infinity;
  for (let k = 0; k < gateCount; k++) {
    const nominal = (startDistance + (k * length) / gateCount) % length;
    const minS = k === 0 ? 0 : prevS + 18;
    const maxS = length - 2;
    const s = k === 0 ? nominal : straighten(nominal, minS, maxS);
    prevS = s;
    const pose = poseAt(s);
    const rightX = Math.cos(pose.heading);
    const rightZ = -Math.sin(pose.heading);
    const y = groundY(pose.x, pose.z, pose.y) ?? pose.y;
    // Measure the drivable width either side and keep the narrower half, so a
    // gate never spans the kerb (or the median of a divided road).
    let pos = 0;
    let neg = 0;
    for (let d = 0.5; d <= 12; d += 0.5) {
      const g = collision.groundAt(pose.x + rightX * d, pose.z + rightZ * d, y + 1, { stepUp: 2, reach: 4 });
      if (g.kind !== "ground" || !collision.isRoadAt(pose.x + rightX * d, pose.z + rightZ * d)) break;
      pos = d;
    }
    for (let d = 0.5; d <= 12; d += 0.5) {
      const g = collision.groundAt(pose.x - rightX * d, pose.z - rightZ * d, y + 1, { stepUp: 2, reach: 4 });
      if (g.kind !== "ground" || !collision.isRoadAt(pose.x - rightX * d, pose.z - rightZ * d)) break;
      neg = d;
    }
    const halfWidth = clamp(Math.min(pos, neg) - 0.6, GATE_MIN_HALF, GATE_MAX_HALF);
    gates.push({
      index: k,
      s,
      x: pose.x,
      y,
      z: pose.z,
      heading: pose.heading,
      rightX,
      rightZ,
      halfWidth,
      isFinish: k === 0,
    });
  }

  // --- starting grid ------------------------------------------------------
  // Ordered pole-first, laid out two-wide and STAGGERED: the two columns are
  // offset along the circuit so that no three cars ever start abreast.
  //
  // That stagger is not decoration. A row-major grid puts a field of six three
  // abreast, and because every car then steers for the same racing line the
  // outer pair cut across the middle car within a second of the lights and the
  // whole field tangles on the grid. Staggering keeps each launch corridor
  // clear. Each slot is validated: a slot a car cannot sit in is pulled toward
  // the lane centre until it fits, and one that never fits is reported so a
  // broken circuit is visible instead of silently producing cars inside a
  // wall.
  const cols = fieldSize <= 1 ? 1 : 2;
  const stagger = cols === 1 ? 0 : GRID_COL_STAGGER;
  const grid = [];
  let shrinkWarnings = 0;
  for (let i = 0; i < fieldSize; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const s = startDistance - (GRID_ROWS_FIRST_OFFSET + row * GRID_ROW_GAP + col * stagger);
    const pose = poseAt(s);
    const rightX = Math.cos(pose.heading);
    const rightZ = -Math.sin(pose.heading);
    const baseLat = (col - (cols - 1) / 2) * GRID_COL_GAP;
    let placed = null;
    for (const shrink of [0, 0.4, 0.8, 1.2, 1.6, 2.0]) {
      const lat = Math.sign(baseLat) * Math.max(0, Math.abs(baseLat) - shrink);
      const x = pose.x + rightX * lat;
      const z = pose.z + rightZ * lat;
      const y = groundY(x, z, pose.y);
      if (y === null) continue;
      probe.teleport(y);
      if (probe.blocked(x, z, pose.heading)) continue;
      placed = { x, y, z, heading: pose.heading, slot: i, lat };
      break;
    }
    if (!placed) {
      shrinkWarnings++;
      const x = pose.x;
      const z = pose.z;
      placed = { x, y: groundY(x, z, pose.y) ?? pose.y, z, heading: pose.heading, slot: i, lat: 0 };
    }
    grid.push(placed);
  }

  return {
    id: winner.route.id,
    name: `${Math.round(length)} m circuit`,
    points,
    path,
    length,
    laps,
    startDistance,
    startPose: poseAt(startDistance),
    gates,
    gateCount,
    grid,
    fieldSize,
    clearance: winner.clearance,
    near: winner.near,
    warnings: { gridFallback: shrinkWarnings },
    stats: {
      id: winner.route.id,
      length: Math.round(length),
      gates: gateCount,
      clearance: winner.clearance,
      distanceFromPaddock: Math.round(winner.near),
      candidates: closed.length,
      nearEnough: reachable.length,
    },
  };
}

function polylineLength(points) {
  let d = 0;
  for (let i = 1; i < points.length; i++) {
    d += Math.hypot(points[i].x - points[i - 1].x, points[i].z - points[i - 1].z);
  }
  return d;
}

// ---------------------------------------------------------------------------
// Track from an explicit node path (the 30 race events).
//
// Unlike buildRaceTrack (which SELECTS a prebuilt closed lane loop), this
// BUILDS a track from an ordered list of road-mesh node centres - straight
// runs between collinear nodes, rounded at the corners - so an event can be
// authored as a sequence of road pieces. Supports OPEN sprints (finish != start)
// as well as CLOSED loops.
// ---------------------------------------------------------------------------

/**
 * Corner rounding: replace each vertex with a quadratic Bezier that is TANGENT
 * to both legs, with its tangent points a BOUNDED distance from the vertex.
 *
 * The bound is the whole point. The previous rounding (Chaikin) cut a fixed
 * FRACTION - 25% - off each of the two segments meeting at a vertex. That is a
 * reasonable sketch-level smooth, but these tracks are authored as junction
 * centres, and two junctions of a city loop sit 160-180 m apart. A 25% cut of
 * that is 45 m: on a 90 deg turn the "rounded" line left the carriageway 24 m
 * before the junction, crossed the block on the inside, and re-joined the road
 * a street later. Both symptoms followed from that one line - the rivals, which
 * only ever see this polyline, braked for a corner that was not on the road and
 * then aimed at a building, and the minimap drew the same shortcut.
 *
 * The cut is still a fraction of the legs it sits between - so a tight node
 * cluster is rounded as tightly as it always was - but it is now CAPPED in
 * metres: a 182 m leg can no longer drag the line 45 m across a block. The cap
 * applies to the shorter leg as well, so two tangent points can never meet in
 * the middle of a segment (consecutive corners keep their own stretch of road).
 */
const CORNER_CUT = 13; // most metres from the vertex to either tangent point
const CORNER_CUT_FRACTION = 0.25; // ... and never more than this of a leg
const CORNER_SAMPLE = 1.5; // metres between samples along a rounded corner
/** How much the cut is trimmed when the curve would leave the road, and how
 *  many times - the tightest corner the rounding ever falls back to is the
 *  plain vertex itself. */
const CORNER_SHRINK = 0.55;
const CORNER_TRIES = 4;

function roundCorners(collision, nodes, closed, maxCut = CORNER_CUT) {
  const n = nodes.length;
  if (n < 2) return nodes.map((p) => ({ ...p }));
  const at = (i) => nodes[closed ? (i + n) % n : Math.max(0, Math.min(n - 1, i))];
  const out = [];
  const emit = (p) => out.push({ x: p.x, y: p.y ?? 0, z: p.z });
  // Open tracks keep their two ends as ends; every vertex in between is a
  // corner. Closed tracks have no ends, so every vertex is one.
  const first = closed ? 0 : 1;
  const count = closed ? n : n - 2;
  if (!closed) emit(nodes[0]);
  for (let k = 0; k < count; k++) {
    const i = first + k;
    const prev = at(i - 1);
    const v = at(i);
    const next = at(i + 1);
    const inLen = Math.hypot(v.x - prev.x, v.z - prev.z);
    const outLen = Math.hypot(next.x - v.x, next.z - v.z);
    if (inLen < 1e-3 || outLen < 1e-3) {
      emit(v);
      continue;
    }
    const ux = (prev.x - v.x) / inLen;
    const uz = (prev.z - v.z) / inLen;
    const wx = (next.x - v.x) / outLen;
    const wz = (next.z - v.z) / outLen;
    // Deflection between the legs: ~0 means the vertex is on a straight run and
    // is left exactly where it is, so straights stay dead straight.
    const turn = Math.acos(clamp(ux * wx + uz * wz, -1, 1));
    if (turn < 0.02) {
      emit(v);
      continue;
    }
    // One cut for both legs, so the curve is turned about the vertex - the
    // corner of the road - rather than skewed toward the shorter leg. The cut
    // is then trimmed until the curve is on the road: on a wide junction a full
    // cut can still bow into the block on the inside of the turn, and a line
    // that leaves the carriageway on a corner is a rival aimed at a wall.
    // Trimming keeps the same corner, just turned tighter.
    const curveAt = (cut) => {
      const p0 = { x: v.x + ux * cut, y: v.y, z: v.z + uz * cut };
      const p2 = { x: v.x + wx * cut, y: v.y, z: v.z + wz * cut };
      const steps = clamp(Math.round(Math.hypot(p2.x - p0.x, p2.z - p0.z) / CORNER_SAMPLE), 2, 32);
      const pts = [];
      for (let s = 0; s <= steps; s++) {
        const t = s / steps;
        const w = 1 - t;
        pts.push({
          x: w * w * p0.x + 2 * w * t * v.x + t * t * p2.x,
          y: v.y,
          z: w * w * p0.z + 2 * w * t * v.z + t * t * p2.z,
        });
      }
      return pts;
    };
    let cut = Math.min(maxCut, inLen * CORNER_CUT_FRACTION, outLen * CORNER_CUT_FRACTION);
    let curve = curveAt(cut);
    for (let attempt = 1; collision && attempt < CORNER_TRIES; attempt++) {
      if (curve.every((p) => collision.isRoadAt(p.x, p.z))) break;
      cut *= CORNER_SHRINK;
      curve = curveAt(cut);
    }
    for (const p of curve) emit(p);
  }
  if (!closed) emit(nodes[n - 1]);
  return out;
}

/**
 * How far off the road a leg's middle may sit before the leg counts as a
 * missed junction rather than a drive along the road, and the grid the junction
 * is looked for on.
 */
const LEG_MISS = 2.5; // metres
const JUNCTION_REACH = 45; // metres searched beyond the leg's own box
const JUNCTION_STEP = 2; // metres, search resolution
/** A way round longer than this many times the straight leg is not a corner. */
const JUNCTION_DETOUR = 1.7;

/** Distance (m, capped) from a point to the nearest road. */
function roadDepth(collision, x, z, cap) {
  if (collision.isRoadAt(x, z)) return 0;
  for (let d = 0.5; d <= cap; d += 0.5) {
    for (let a = 0; a < 8; a++) {
      const th = (a * Math.PI) / 4;
      if (collision.isRoadAt(x + Math.cos(th) * d, z + Math.sin(th) * d)) return d;
    }
  }
  return cap;
}

/** Is the straight run from a to b entirely on the road? */
function runOnRoad(collision, a, b) {
  const len = Math.hypot(b.x - a.x, b.z - a.z);
  const steps = Math.max(1, Math.round(len / 4));
  for (let k = 0; k <= steps; k++) {
    const t = k / steps;
    if (!collision.isRoadAt(a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t)) return false;
  }
  return true;
}

/**
 * A leg of an authored track is a straight line between two node centres, and a
 * node centre is the middle of a road PIECE. When the two nodes sit on
 * different roads - the middle of a north-south street and the middle of a
 * piece 19 m along the east-west one - the straight leg between them is a
 * diagonal across the block in the corner, not the drive the author made.
 *
 * No amount of snapping fixes that gracefully: the line has to be dragged back
 * onto the roads sample by sample, which either leaves a step in the racing
 * line at the junction (an AI aiming across it, a minimap showing the shortcut)
 * or drags one sample across the block to catch up with its neighbours. Both
 * were visible on the Clean Line and Market Dash circuits.
 *
 * So the corner is put back where it belongs. A leg whose middle leaves the
 * road is replaced by the two-leg drive through the road point that makes the
 * way round both drivable and shortest - the junction the author actually
 * drove through - and the builder then rounds it like the ordinary corner it
 * always was. Nothing is inserted for a leg that is a road drive already, which
 * is every leg of the loop circuits.
 */
function missedJunction(collision, a, b) {
  const len = Math.hypot(b.x - a.x, b.z - a.z);
  if (len < 12) return null;
  const steps = clamp(Math.round(len / 8), 3, 10);
  let miss = 0;
  for (let k = 1; k < steps && miss < LEG_MISS; k++) {
    const t = k / steps;
    miss = Math.max(miss, roadDepth(collision, a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t, LEG_MISS));
  }
  if (miss < LEG_MISS) return null;

  // Nearest-first over a grid around the leg: the first candidate that is both
  // reachable on the road from each end and shorter than a plain detour wins.
  const x0 = Math.min(a.x, b.x) - JUNCTION_REACH;
  const x1 = Math.max(a.x, b.x) + JUNCTION_REACH;
  const z0 = Math.min(a.z, b.z) - JUNCTION_REACH;
  const z1 = Math.max(a.z, b.z) + JUNCTION_REACH;
  const mx = (a.x + b.x) / 2;
  const mz = (a.z + b.z) / 2;
  const cands = [];
  for (let x = x0; x <= x1; x += JUNCTION_STEP) {
    for (let z = z0; z <= z1; z += JUNCTION_STEP) {
      if (!collision.isRoadAt(x, z)) continue;
      const da = Math.hypot(x - a.x, z - a.z);
      const db = Math.hypot(b.x - x, b.z - z);
      // A "corner" hard against either node is not a corner: it would leave a
      // degenerate pair of legs for the rounding to trip over.
      if (da < 6 || db < 6) continue;
      cands.push({ x, z, cost: da + db, d: Math.hypot(x - mx, z - mz) });
    }
  }
  cands.sort((p, q) => p.cost - q.cost || p.d - q.d);
  const limit = len * JUNCTION_DETOUR;
  for (const c of cands) {
    if (c.cost >= limit) break;
    if (!runOnRoad(collision, a, c) || !runOnRoad(collision, c, b)) continue;
    return { x: c.x, y: a.y ?? 0, z: c.z };
  }
  return null;
}

/** Insert the junction every leg that leaves the road should have turned at. */
function insertRoadCorners(collision, nodes, closed) {
  const n = nodes.length;
  const legs = closed ? n : n - 1;
  const out = [];
  for (let i = 0; i < legs; i++) {
    const a = nodes[i];
    const b = nodes[(i + 1) % n];
    out.push(a);
    const c = missedJunction(collision, a, b);
    if (c) out.push(c);
  }
  if (!closed) out.push(nodes[n - 1]);
  return out;
}

/** Resample a polyline to roughly even spacing. */
function densify(pts, spacing, closed) {
  const out = [];
  const n = pts.length;
  const segs = closed ? n : n - 1;
  for (let i = 0; i < segs; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % n];
    const len = Math.hypot(b.x - a.x, b.z - a.z);
    const steps = Math.max(1, Math.round(len / spacing));
    for (let k = 0; k < steps; k++) {
      const t = k / steps;
      out.push({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t });
    }
  }
  if (!closed) out.push(pts[n - 1]);
  return out;
}

/**
 * Pull every centreline sample onto the middle of the drivable road span.
 * Fixes corner-cuts and U-turn overshoot (off-road samples are slid along the
 * local perpendicular until they find road) and keeps the line centred in its
 * lane span (so it won't sit on a divided road's median). Tangents are taken
 * from the ORIGINAL points so the recentre is not biased by itself.
 */
function recenterOnRoad(collision, pts, closed, R) {
  const n = pts.length;
  const onRoad = (x, z) => collision.isRoadAt(x, z);
  const snapped = pts.map((p) => ({ x: p.x, z: p.z }));
  for (let i = 0; i < n; i++) {
    const prev = pts[closed ? (i - 1 + n) % n : Math.max(0, i - 1)];
    const next = pts[closed ? (i + 1) % n : Math.min(n - 1, i + 1)];
    let tx = next.x - prev.x;
    let tz = next.z - prev.z;
    const tl = Math.hypot(tx, tz) || 1;
    tx /= tl;
    tz /= tl;
    const rx = tz;
    const rz = -tx; // a perpendicular to the local tangent
    const p = pts[i];
    let cx = p.x;
    let cz = p.z;
    if (!onRoad(cx, cz)) {
      let bestAbs = Infinity;
      let best = null;
      for (let d = -R; d <= R; d += 0.5) {
        const x = p.x + rx * d;
        const z = p.z + rz * d;
        if (onRoad(x, z) && Math.abs(d) < bestAbs) {
          best = { x, z };
          bestAbs = Math.abs(d);
        }
      }
      if (!best) continue; // nowhere nearby is road; leave the point
      cx = best.x;
      cz = best.z;
    }
    let pos = 0;
    let neg = 0;
    for (let d = 0.5; d <= R; d += 0.5) {
      if (!onRoad(cx + rx * d, cz + rz * d)) break;
      pos = d;
    }
    for (let d = 0.5; d <= R; d += 0.5) {
      if (!onRoad(cx - rx * d, cz - rz * d)) break;
      neg = d;
    }
    const shift = (pos - neg) / 2;
    snapped[i].x = cx + rx * shift;
    snapped[i].z = cz + rz * shift;
  }
  for (let i = 0; i < n; i++) {
    pts[i].x = snapped[i].x;
    pts[i].z = snapped[i].z;
  }
}

/** Width (m) above which a road is treated as DIVIDED (two carriageways round a
 *  median) rather than a plain 2-lane road. road_a pieces measure ~12 m; the
 *  road_b / road_c families measure ~20 m. */
const DIVIDED_SPAN = 15;

/**
 * Bias the racing line into the RIGHT-hand lane on divided roads, so the AI (and
 * the start grid, which is sampled off this line) sit in a lane instead of
 * straddling the median. Narrow roads (road_a: ~2 lanes, no divider) are left
 * centred. The player is unaffected and may still cross the divider freely.
 * The offset follows the local travel direction, so an out-and-back keeps the
 * correct side on each leg.
 */
function laneOffsetPass(collision, pts, closed) {
  const n = pts.length;
  const onRoad = (x, z) => collision.isRoadAt(x, z);
  const shifted = pts.map((p) => ({ x: p.x, z: p.z }));
  for (let i = 0; i < n; i++) {
    const prev = pts[closed ? (i - 1 + n) % n : Math.max(0, i - 1)];
    const next = pts[closed ? (i + 1) % n : Math.min(n - 1, i + 1)];
    let tx = next.x - prev.x;
    let tz = next.z - prev.z;
    const tl = Math.hypot(tx, tz) || 1;
    tx /= tl;
    tz /= tl;
    const rx = tz; // right-hand perpendicular to travel
    const rz = -tx;
    const p = pts[i];
    let pos = 0;
    let neg = 0;
    for (let d = 0.5; d <= 14; d += 0.5) {
      if (!onRoad(p.x + rx * d, p.z + rz * d)) break;
      pos = d;
    }
    for (let d = 0.5; d <= 14; d += 0.5) {
      if (!onRoad(p.x - rx * d, p.z - rz * d)) break;
      neg = d;
    }
    const span = pos + neg;
    if (span <= DIVIDED_SPAN) continue; // narrow road: keep centred
    // Sit in the right-hand lane but not hard against the kerb: a gentle offset
    // that clears the median yet leaves room for the grid and keeps the line
    // away from roadside objects on the right.
    const off = Math.min(span * 0.2, pos - 2.5);
    if (off > 0) {
      shifted[i].x = p.x + rx * off;
      shifted[i].z = p.z + rz * off;
    }
  }
  for (let i = 0; i < n; i++) {
    pts[i].x = shifted[i].x;
    pts[i].z = shifted[i].z;
  }
}

/**
 * Pull the racing line clear of SOLID obstacles (buildings, roadside props,
 * kerb furniture) - not just onto the road surface. The AI follows this line
 * blindly, so a line that clips a solid leaves a rival grinding into it and
 * wedging. Each sample that a car-sized box can't sit in is slid along the
 * local perpendicular to the nearest clear, on-road spot.
 */
function clearObstacles(collision, pts, closed) {
  const probe = new TerrainFollower(collision, probeGeometry(), 6, null);
  const n = pts.length;
  const snap = pts.map((p) => ({ x: p.x, z: p.z, y: p.y }));
  const blockedAt = (x, z, y, heading) => {
    const g = collision.groundAt(x, z, y ?? 6, { stepUp: 3, reach: 8 });
    if (g.kind !== "ground" || g.y == null) return true; // off the surface
    probe.teleport(g.y);
    return probe.blocked(x, z, heading) || !collision.isRoadAt(x, z);
  };
  for (let i = 0; i < n; i++) {
    const prev = pts[closed ? (i - 1 + n) % n : Math.max(0, i - 1)];
    const next = pts[closed ? (i + 1) % n : Math.min(n - 1, i + 1)];
    const heading = Math.atan2(next.x - prev.x, next.z - prev.z);
    const rx = Math.cos(heading); // right-hand perpendicular (matches gate right)
    const rz = -Math.sin(heading);
    const p = pts[i];
    if (!blockedAt(p.x, p.z, p.y, heading)) continue;
    let best = null;
    for (let d = 0.75; d <= 7; d += 0.75) {
      for (const s of [-1, 1]) {
        const x = p.x + rx * d * s;
        const z = p.z + rz * d * s;
        if (!blockedAt(x, z, p.y, heading)) {
          best = { x, z };
          break;
        }
      }
      if (best) break;
    }
    if (best) {
      snap[i].x = best.x;
      snap[i].z = best.z;
    }
  }
  for (let i = 0; i < n; i++) {
    pts[i].x = snap[i].x;
    pts[i].z = snap[i].z;
  }
}

/**
 * Hard guarantee that every sample of the racing line sits on the drivable
 * surface.
 *
 * The passes before this one each nudge the line for their own reason - the
 * span-centring slides a sample toward the middle of its road, the lane offset
 * pushes it into the right-hand lane - and a nudge that is correct in isolation
 * can put a sample over a kerb where two roads meet, which is how a line that
 * is everywhere "nearly" on the road ends up crossing a block corner at a
 * junction. Nothing after the last nudge would notice, so this pass is the last
 * word: whichever sample is still off the road is slid, along the local
 * perpendicular and nearest side first, onto the road.
 *
 * Only the sample's own point is tested, never a car-sized box as the obstacle
 * pass does - this is a racing line for pure pursuit to aim at, not a parking
 * space, and a box test would leave a point 0.2 m over a kerb exactly where the
 * line has to bend around it.
 *
 * Sideways only, deliberately. The lane offset is the pass that can put a
 * sample over a kerb, and its push is lateral, so the correction that matches
 * it is lateral too - the line stays a line. A sample that needs a search in
 * every direction is not a nudged sample but a wrong one (an authored node off
 * the road), and that is recenterOnRoad's job, upstream, where the recovered
 * point still gets centred in its lane and smoothed.
 */
function snapOnRoad(collision, pts, closed, R = 6) {
  const n = pts.length;
  for (let i = 0; i < n; i++) {
    const p = pts[i];
    if (collision.isRoadAt(p.x, p.z)) continue;
    const prev = pts[closed ? (i - 1 + n) % n : Math.max(0, i - 1)];
    const next = pts[closed ? (i + 1) % n : Math.min(n - 1, i + 1)];
    const tx = next.x - prev.x;
    const tz = next.z - prev.z;
    const tl = Math.hypot(tx, tz) || 1;
    const rx = tz / tl;
    const rz = -tx / tl;
    let best = null;
    for (let d = 0.5; d <= R && !best; d += 0.5) {
      for (const sgn of [1, -1]) {
        const x = p.x + rx * d * sgn;
        const z = p.z + rz * d * sgn;
        if (collision.isRoadAt(x, z)) {
          best = { x, z };
          break;
        }
      }
    }
    if (best) {
      p.x = best.x;
      p.z = best.z;
    }
  }
}

/**
 * Longitudinal smoothing pass over the centreline. Span-centering and
 * obstacle shoves are computed per sample, so a lone sample can jump sideways
 * relative to its neighbours - a visible kink on the minimap and a twitch for
 * the AI through corners. Averaging each sample with its ±2 neighbours keeps
 * straights exactly straight (collinear input is a fixed point) while ironing
 * those kinks. Any smoothed sample that leaves the road or its car box is
 * reverted, so this pass can only calm the line, never break it.
 */
function smoothLine(collision, pts, closed) {
  const n = pts.length;
  if (n < 5) return;
  const probe = new TerrainFollower(collision, probeGeometry(), 6, null);
  const at = (i) => pts[closed ? (i + n) % n : Math.max(0, Math.min(n - 1, i))];
  const blockedAt = (x, z, y, heading) => {
    const g = collision.groundAt(x, z, y ?? 6, { stepUp: 3, reach: 8 });
    if (g.kind !== "ground" || g.y == null) return true;
    probe.teleport(g.y);
    return probe.blocked(x, z, heading) || !collision.isRoadAt(x, z);
  };
  const sm = pts.map((p, i) => {
    let x = 0;
    let z = 0;
    for (let k = -2; k <= 2; k++) {
      const q = at(i + k);
      x += q.x;
      z += q.z;
    }
    return { x: x / 5, z: z / 5 };
  });
  for (let i = 0; i < n; i++) {
    const a = at(i - 1);
    const b = at(i + 1);
    const heading = Math.atan2(b.x - a.x, b.z - a.z);
    if (!blockedAt(sm[i].x, sm[i].z, pts[i].y, heading)) {
      pts[i].x = sm[i].x;
      pts[i].z = sm[i].z;
    }
  }
}

/**
 * Build a race track from an ordered list of resolved node centres.
 *
 * @param collision   baked MapCollision
 * @param nodePoints  [{x,y,z}, ...] world centres of the road pieces, in order
 * @param opts.open   true = point-to-point sprint (finish at the last point);
 *                    false = closed loop (first point is the start/finish line)
 * @param opts.laps   lap count (open sprints are always 1)
 * @param opts.fieldSize cars on the grid (including the player)
 * @param opts.id / opts.name  identifiers carried onto the track
 * @param opts.approachPoint kept for the events that author an `approach` node.
 *   The grid no longer needs it: the field lines up on the race road ITSELF
 *   (see the starting-grid section), so a start that joins at an angle, or one
 *   drawn across a junction, is solved without borrowing the side road the
 *   field used to arrive from.
 */
export function buildTrackFromNodes(
  collision,
  nodePoints,
  { open = false, laps = 1, fieldSize = 6, id = "event", name = "Race", approachPoint = null } = {},
) {
  if (!collision) throw new Error("buildTrackFromNodes requires the collision model");
  if (!nodePoints || nodePoints.length < 2) throw new Error("buildTrackFromNodes needs >= 2 nodes");

  // A closed loop whose first and last node coincide: drop the duplicate.
  let nodes = nodePoints.map((p) => ({ x: p.x, y: p.y ?? 0, z: p.z ?? 0 }));
  const closed = !open;
  if (closed && nodes.length > 2) {
    const a = nodes[0];
    const b = nodes[nodes.length - 1];
    if (Math.hypot(a.x - b.x, a.z - b.z) < 15) nodes = nodes.slice(0, -1);
  }

  // Centreline: round the corners lightly, resample evenly, then pull every
  // sample onto the middle of the drivable road span so corner-cuts and
  // U-turns don't stray onto the terrain, and finally drop it to the surface.
  const withCorners = insertRoadCorners(collision, nodes, closed);
  const cornersAdded = withCorners.length - nodes.length;
  const rounded = roundCorners(collision, withCorners, closed);
  const dense = densify(rounded, 4, closed);
  recenterOnRoad(collision, dense, closed, 11);
  laneOffsetPass(collision, dense, closed);
  snapOnRoad(collision, dense, closed);
  clearObstacles(collision, dense, closed);
  smoothLine(collision, dense, closed);
  let offRoad = 0;
  for (const p of dense) {
    const g = collision.groundAt(p.x, p.z, p.y ?? 6, { stepUp: 3, reach: 8 });
    if (g.kind === "ground" && g.y != null) p.y = g.y;
    if (!collision.isRoadAt(p.x, p.z)) offRoad++;
  }
  const path = new Path(dense, { open });
  const length = path.length;

  const poseAt = (s) => {
    const p = path.sample(s);
    const a = path.sample(s - 3);
    const b = path.sample(s + 3);
    const heading = Math.atan2(b.x - a.x, b.z - a.z);
    return { x: p.x, y: p.y, z: p.z, heading };
  };
  const groundY = (x, z, ref) => {
    const g = collision.groundAt(x, z, ref ?? 6, { stepUp: 3, reach: 8 });
    return g.kind === "ground" ? g.y : null;
  };
  const probe = new TerrainFollower(collision, probeGeometry(), 6, null);

  const startDistance = 0;
  // Outgoing (forward) heading at the start line, taken ONLY from the road
  // ahead - robust even when the start sits at a cusp (a loop that doubles back
  // through its start), where the symmetric reading is degenerate.
  const startFwd = (() => {
    const a = path.sample(startDistance);
    const b = path.sample(startDistance + 8);
    return Math.atan2(b.x - a.x, b.z - a.z);
  })();
  const startSample = path.sample(startDistance);
  const startX = startSample.x;
  const startZ = startSample.z;

  // The start line's own heading is the RACE direction - the way the circuit's
  // path leaves the line - and it is what every start pose is built from. Which
  // layout the grid itself uses (behind the line, or on the circuit just ahead
  // of it) is decided further down, once the path helpers exist: see the
  // "starting grid" section.
  const startPose = { x: startX, y: startSample.y, z: startZ, heading: startFwd };

  // Heading change around a point: high on a corner, ~0 on a straight.
  // Used to keep checkpoints strictly OFF turns and corners.
  const diffHeading = (h1, h2) => {
    let d = h1 - h2;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return Math.abs(d);
  };
  const curvatureAt = (s, span = 7) => diffHeading(poseAt(s + span).heading, poseAt(s - span).heading);

  // --- bridge exclusion ----------------------------------------------------
  // A gate must never stand on the bridge deck.
  //
  // Two things go wrong there. The path's height over a span is interpolated
  // from the authored NODES, and the bridge node is the whole structure's
  // centre, not its carriageway - it sits many metres above the deck - so a
  // gate placed on it resolves no ground within reach and falls back to that
  // height, leaving the arch hanging in mid-air above the bridge it should be
  // spanning. And the arch is drawn at a span wide enough to reach past a deck's
  // parapet, where its legs have nothing to stand on at all.
  //
  // Checkpoints therefore keep off the span entirely and are walked ahead of it
  // or before it, onto the road either side (`straighten` does the walking; see
  // the bridge term in `gateScore` for the no-straight fallback).
  //
  // `path.sample` is asked with a negative or past-the-end arc on purpose: it
  // wraps on a circuit and clamps on a sprint, which is exactly how the gate
  // search itself treats an out-of-range arc.
  const BRIDGE_LEG_REACH = 5; // metres from the gate's centre out to its legs
  const onBridge = (s) => {
    const p = path.sample(s);
    if (collision.isBridgeAt(p.x, p.z)) return true;
    // The plane is measured across the road, and the arch's legs stand out at
    // the gate's span either side of it, so a deck cell under either leg counts
    // as "on the bridge" just as much as one under the centre.
    const a = path.sample(s - 3);
    const b = path.sample(s + 3);
    const h = Math.atan2(b.x - a.x, b.z - a.z);
    const rx = Math.cos(h);
    const rz = -Math.sin(h);
    for (let d = -BRIDGE_LEG_REACH; d <= BRIDGE_LEG_REACH; d += BRIDGE_LEG_REACH) {
      if (d === 0) continue;
      if (collision.isBridgeAt(p.x + rx * d, p.z + rz * d)) return true;
    }
    return false;
  };

  // Strict straightness check: point s must be firmly on a straight segment,
  // not entering or exiting a turn, not inside a junction, and not on a bridge.
  const isStraight = (s) =>
    curvatureAt(s, 7) < 0.08 &&
    curvatureAt(s - 6, 6) < 0.09 &&
    curvatureAt(s + 6, 6) < 0.09 &&
    junctionAt(s) < 0.22 &&
    !onBridge(s);

  // --- junction detection --------------------------------------------------
  // A gate must also stay OUT of intersections: a straight crossroads has no
  // curvature, yet an arch across traffic lights, crossings and sidewalks
  // reads as a corner and drives like one. Junctions are read off the baked
  // road mask: the lateral road span balloons across an intersection mouth,
  // while a plain straight (even a wide divided one) holds a near-constant
  // span. So the variance of the span across a 20 m window is ~0 mid-block
  // and large at a junction - no Absolutebreite tuning needed.
  const JUNCTION_PROBE_R = 14; // lateral walk limit, metres
  const spanAt = (s) => {
    const p = path.sample(s);
    const a = path.sample(s - 3);
    const b = path.sample(s + 3);
    const h = Math.atan2(b.x - a.x, b.z - a.z);
    const rx = Math.cos(h);
    const rz = -Math.sin(h);
    let pos = 0;
    let neg = 0;
    for (let d = 0.5; d <= JUNCTION_PROBE_R; d += 0.5) {
      if (!collision.isRoadAt(p.x + rx * d, p.z + rz * d)) break;
      pos = d;
    }
    for (let d = 0.5; d <= JUNCTION_PROBE_R; d += 0.5) {
      if (!collision.isRoadAt(p.x - rx * d, p.z - rz * d)) break;
      neg = d;
    }
    return pos + neg;
  };
  const junctionAt = (s) => {
    const w0 = spanAt(fit(s - 10));
    const w1 = spanAt(fit(s));
    const w2 = spanAt(fit(s + 10));
    return clamp((Math.max(w0, w1, w2) - Math.min(w0, w1, w2)) / 12, 0, 1);
  };
  const JUNCTION_MAX = 0.25; // above this, the spot counts as a junction
  const gateScore = (s, s0) => {
    const dd = Math.abs(s - s0);
    const drift = Math.min(dd, length - dd) / 80;
    // A bridge is worse than any corner: the higher weight keeps the fallback -
    // the spot a gate settles on when no clean straight exists anywhere near -
    // off the deck even when every candidate there is bent.
    return (
      curvatureAt(s, 7) * 2.0 +
      1.2 * junctionAt(s) +
      0.2 * drift +
      (onBridge(s) ? 3.0 : 0)
    );
  };

  // Nudge an arc-length onto a straight road segment ahead or before a turn so
  // a checkpoint never lands on a corner/turning. Clamps (open) or wraps (closed).
  // Searches both before and ahead, immediately selecting clean straight sections.
  const fit = (s) => (open ? clamp(s, 2, length - 2) : ((s % length) + length) % length);
  const straighten = (s0, minS = 0, maxS = length - 2) => {
    const s = fit(s0);
    if (s >= minS && s <= maxS && isStraight(s)) return s;
    let best = clamp(s, minS, maxS);
    let bestScore = gateScore(best, s0);

    for (let off = 3; off <= 85; off += 3) {
      const candBefore = fit(s0 - off);
      const candAhead = fit(s0 + off);

      // Prioritize placing cleanly on straight before the turn
      if (candBefore >= minS && candBefore <= maxS && isStraight(candBefore)) {
        return candBefore;
      }
      // Or cleanly on straight ahead of the turn
      if (candAhead >= minS && candAhead <= maxS && isStraight(candAhead)) {
        return candAhead;
      }

      if (candBefore >= minS && candBefore <= maxS) {
        const sc = gateScore(candBefore, s0);
        if (sc < bestScore) {
          bestScore = sc;
          best = candBefore;
        }
      }
      if (candAhead >= minS && candAhead <= maxS) {
        const sc = gateScore(candAhead, s0);
        if (sc < bestScore) {
          bestScore = sc;
          best = candAhead;
        }
      }
    }
    return best;
  };

  // --- checkpoint gates ---------------------------------------------------
  const gateCount = clamp(Math.round(length / CHECKPOINT_SPACING), MIN_GATES, MAX_GATES);
  const gates = [];
  let prevS = -Infinity; // straightened gates keep their order (no leapfrogging)
  for (let k = 0; k < gateCount; k++) {
    // Closed: gate 0 is the start/finish at s=0, the rest spaced round the lap.
    // Open: gates sit AHEAD of the line (k+1), so the last one is the finish.
    const nominal = open
      ? Math.min(length - 3, ((k + 1) * length) / gateCount)
      : (startDistance + (k * length) / gateCount) % length;

    const fixed = open ? false : k === 0;
    const minS = k === 0 ? 0 : prevS + 18;
    const maxS = open ? length - 3 : length - 2;

    let s;
    if (fixed) {
      s = nominal;
    } else if (open && k === gateCount - 1) {
      s = straighten(Math.max(minS, length - 4), minS, length - 2);
    } else {
      s = straighten(nominal, minS, maxS);
    }
    prevS = s;
    const pose = poseAt(s);
    const rightX = Math.cos(pose.heading);
    const rightZ = -Math.sin(pose.heading);
    const y = groundY(pose.x, pose.z, pose.y) ?? pose.y;
    let pos = 0;
    let neg = 0;
    for (let d = 0.5; d <= 12; d += 0.5) {
      const gx = pose.x + rightX * d;
      const gz = pose.z + rightZ * d;
      const g = collision.groundAt(gx, gz, y + 1, { stepUp: 2, reach: 4 });
      if (g.kind !== "ground" || !collision.isRoadAt(gx, gz)) break;
      pos = d;
    }
    for (let d = 0.5; d <= 12; d += 0.5) {
      const gx = pose.x - rightX * d;
      const gz = pose.z - rightZ * d;
      const g = collision.groundAt(gx, gz, y + 1, { stepUp: 2, reach: 4 });
      if (g.kind !== "ground" || !collision.isRoadAt(gx, gz)) break;
      neg = d;
    }
    const halfWidth = clamp(Math.min(pos, neg) - 0.6, GATE_MIN_HALF, GATE_MAX_HALF);
    gates.push({
      index: k,
      s,
      x: pose.x,
      y,
      z: pose.z,
      heading: pose.heading,
      rightX,
      rightZ,
      halfWidth,
      isFinish: open ? k === gateCount - 1 : k === 0,
    });
  }

  // Every arch is ONE structure repeated: the gates are all drawn at the widest
  // span the circuit offers (see RaceSystem._buildMarkers, which takes the same
  // maximum), so the CROSSING test has to use that span too. `halfWidth` above
  // is the width of the road at that gate - the narrower half, so the arch never
  // spans a kerb or a median - and using it for the crossing test meant a car
  // that drove through the arch it could SEE, at the edge of a narrow road,
  // passed a checkpoint that was never marked as reached. The trigger is now
  // exactly the arch that stands there; see raceProgress for the body-width
  // margin that makes clipping a post a pass as well.
  const archHalf = gates.reduce((m, g) => Math.max(m, g.halfWidth), 0);
  for (const g of gates) g.halfWidth = archHalf;

  // --- starting grid ------------------------------------------------------
  // The field must launch STRAIGHT DOWN THE RACE ROAD, in the direction the
  // circuit's own path is defined at the start - not at whatever angle the side
  // street it was parked on happens to run, and not into the corner the line
  // itself may sit on. Two layouts, chosen from what the road does at the line:
  //
  //   - BEHIND the line, when the race road itself runs straight back from it:
  //     the classic grid - cars lined up on the road they are about to race,
  //     driving through the start arch. Slots march back along the line's own
  //     heading, which is exactly that straight.
  //   - else ON the circuit, one road ahead of the line: slots laid ON the path
  //     at the first straight stretch past the line, each facing the local
  //     racing direction. That is what a line drawn across a junction, a start
  //     that joins at an angle, and an open sprint (which has no road behind
  //     the line at all) all need - the field simply begins on the initial
  //     road, pointing the way the race goes.
  const fwx = Math.sin(startFwd);
  const fwz = Math.cos(startFwd);
  const offAxis = (h) => {
    let d = h - startFwd;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return Math.abs(d);
  };
  const cols = fieldSize <= 1 ? 1 : 2;
  const rows = Math.max(1, Math.ceil(fieldSize / cols));
  const stagger = cols === 1 ? 0 : GRID_COL_STAGGER;

  // Behind the line only when that road is a straight AND points the way the
  // race goes: a grid parked along a bend, or across the mouth of a side road,
  // launches the field at an angle it has to turn out of.
  const roadBehindStraight =
    !open &&
    isStraight(-8) &&
    isStraight(-24) &&
    offAxis(poseAt(-10).heading) < 0.14 &&
    offAxis(poseAt(-24).heading) < 0.14;

  const lateralOf = (col) => (col - (cols - 1) / 2) * GRID_COL_GAP;
  let slotPose;
  if (roadBehindStraight) {
    slotPose = (row, col) => {
      const back = GRID_ROWS_FIRST_OFFSET + row * GRID_ROW_GAP + col * stagger;
      return {
        x: startX - fwx * back,
        z: startZ - fwz * back,
        y: startSample.y,
        heading: startFwd,
        // Seeded at the line: the car starts behind it and drives onto it.
        s: startDistance,
        lat: lateralOf(col),
      };
    };
  } else {
    // First straight stretch of the initial road past the line, bounded so the
    // grid stays by the start: if the opening metres bend, the nearest clean
    // straight within GRID_STRAIGHT_REACH is used, else the nominal offset - a
    // slot on the path is already pointing the racing direction either way.
    const straight = straighten(
      GRID_FIRST_S,
      GRID_FIRST_S,
      Math.min(length - 4, GRID_FIRST_S + GRID_STRAIGHT_REACH),
    );
    const wanted = isStraight(straight) ? straight : GRID_FIRST_S;
    // Keep the whole grid on the course, and clear of the finish on a short one.
    const backS = clamp(
      wanted,
      GRID_FIRST_S,
      Math.max(GRID_FIRST_S, length - 6 - (rows - 1) * GRID_ROW_GAP - stagger),
    );
    slotPose = (row, col) => {
      // Rows run FORWARD from the tail: the row nearest the line is the back
      // row, the pole sits furthest down the road.
      const s = backS + (rows - 1 - row) * GRID_ROW_GAP - col * stagger;
      const pose = poseAt(s);
      return {
        x: pose.x,
        z: pose.z,
        y: pose.y,
        heading: pose.heading,
        // Seeded at the slot's own arc, so progress - and the AI's racing line -
        // start where the car actually is.
        s,
        lat: lateralOf(col),
      };
    };
  }

  const grid = [];
  let shrinkWarnings = 0;
  for (let i = 0; i < fieldSize; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const pose = slotPose(row, col);
    const rightX = Math.cos(pose.heading);
    const rightZ = -Math.sin(pose.heading);
    const baseLat = pose.lat;
    let placed = null;
    for (const shrink of [0, 0.4, 0.8, 1.2, 1.6, 2.0]) {
      const lat = Math.sign(baseLat) * Math.max(0, Math.abs(baseLat) - shrink);
      const x = pose.x + rightX * lat;
      const z = pose.z + rightZ * lat;
      const y = groundY(x, z, pose.y);
      if (y === null) continue;
      probe.teleport(y);
      if (probe.blocked(x, z, pose.heading)) continue;
      placed = { x, y, z, heading: pose.heading, slot: i, lat, s: pose.s };
      break;
    }
    if (!placed) {
      shrinkWarnings++;
      const x = pose.x;
      const z = pose.z;
      placed = { x, y: groundY(x, z, pose.y) ?? pose.y, z, heading: pose.heading, slot: i, lat: 0, s: pose.s };
    }
    grid.push(placed);
  }

  return {
    id,
    name,
    open,
    points: dense,
    path,
    length,
    laps: open ? 1 : laps,
    startDistance,
    startPose,
    gates,
    gateCount,
    grid,
    fieldSize,
    clearance: 0,
    near: 0,
    warnings: { gridFallback: shrinkWarnings, offRoad, cornersAdded },
    stats: {
      id,
      length: Math.round(length),
      gates: gateCount,
      open,
      offRoad,
      cornersAdded,
      points: dense.length,
    },
  };
}



