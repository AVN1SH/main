import { Ray, Vector3 } from "@babylonjs/core";

/**
 * Testing coordinate probe - REMOVAL: delete this file, the `.probe` CSS
 * block in src/styles/main.css, the `testing` wiring in src/main.js, and the
 * KeyX/KeyZ lines in src/game/input.js. Nothing else references it.
 *
 * Active only with `?testing=1` in the URL (see main.js).
 *
 *   X ............ toggle the readout chip (X / Y / Z / heading / speed)
 *   Z ............ capture the spot under the car: exact coordinates PLUS
 *                  the mesh name there, printed to the console AND copied to
 *                  the clipboard, ready to paste back for event placement.
 *
 * The capture raycasts straight down through the car, so the mesh reported
 * is what is actually under the wheels, not a nearby guess.
 */
export function createCoordProbe(scene) {
  const el = document.createElement("div");
  el.className = "probe";
  el.id = "coord-probe";
  el.setAttribute("aria-hidden", "true");
  const host = document.getElementById("app") ?? document.body;
  host.appendChild(el);

  let visible = true;
  const ray = new Ray(Vector3.Zero(), new Vector3(0, -1, 0), 80);
  el.classList.add("is-visible");
  el.setAttribute("aria-hidden", "false");
  let flashUntil = 0;

  const headingDeg = (h) => {
    const d = ((h * 180) / Math.PI) % 360;
    return (d + 360) % 360;
  };

  function render(state) {
    const hdg = headingDeg(state.heading);
    el.textContent =
      `X ${state.x.toFixed(1)}  Z ${state.z.toFixed(1)}  Y ${state.y.toFixed(2)}  ` +
      `HDG ${hdg.toFixed(0)}°  ${Math.abs(state.speed * 3.6).toFixed(0)} km/h`;
  }

  return {
    get isVisible() {
      return visible;
    },
    toggle() {
      visible = !visible;
      el.classList.toggle("is-visible", visible);
      el.setAttribute("aria-hidden", visible ? "false" : "true");
    },
    update(player) {
      if (!visible || !player?.state) return;
      // A fresh capture stays on screen briefly as its own confirmation.
      if (performance.now() < flashUntil) return;
      render(player.state);
    },
    /** Capture coordinates + mesh under the car; returns the line. */
    capture(player) {
      if (!player?.state) return "";
      const s = player.state;
      ray.origin.set(s.x, s.y + 30, s.z);
      const hit = scene.pickWithRay(ray, (m) => m.isVisible && m.isEnabled());
      const mesh = hit?.pickedMesh?.name ?? "(no mesh hit)";
      const line =
        `x: ${s.x.toFixed(1)}, z: ${s.z.toFixed(1)}, y: ${s.y.toFixed(2)}, ` +
        `headingDeg: ${headingDeg(s.heading).toFixed(0)}, mesh: ${mesh}`;
      console.log("[coord-probe]", line);
      if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(line).catch(() => {});
      }
      // Show the captured line in the chip as visible confirmation.
      el.textContent = "📋 " + line;
      flashUntil = performance.now() + 2500;
      return line;
    },
    dispose() {
      el.remove();
    },
  };
}
