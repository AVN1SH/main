import { CAR } from "./driving.js";

/**
 * Dynamic vehicle <-> vehicle collision, shared by the ambient traffic and the
 * race.
 *
 * The player's crash against an AI car, and a race car's crash against the
 * player or another race car, are the same physical event: an oriented
 * rectangle sweep, an impulse on the struck car, and a speed loss on the car
 * that hit it. It used to live inside `TrafficSystem` only, which meant the
 * race rivals would have had a second, subtly different copy. Both callers now
 * go through here, so a fix to one is a fix to both.
 *
 * `subject` is whatever car is doing the hitting - the player for traffic, a
 * race rival for the race, or a race rival against the player when the race
 * does the reciprocal check. It only has to expose `{ state, rig }`; a rival
 * also exposes `shoved` / `applyShove`, which is what makes the struck car
 * react instead of being an immovable post.
 */

/** Defaults for a car whose rig does not publish its own extents. */
const HALF_LENGTH = CAR.length / 2; // 2.15 m
const HALF_WIDTH = CAR.width / 2; // 0.95 m

/**
 * Sweep `subject`'s motion this frame and, if it crosses a vehicle's
 * footprint, return the resolved player state plus apply the opposing shove.
 *
 * @param subject  { state, rig } - state is mutated by the caller, not here
 * @param vehicles array of { state, rig, shoved, applyShove }
 * @param prevX,prevZ the subject's position at the start of the frame
 * @param options.spinScale scales the yaw impulse a hit imparts. Traffic takes
 *   the full value (a road car spun by a crash is the point); the race passes
 *   less, because two racers trading paint should not pirouette each other.
 * @param options.arcade when true this is racer-vs-racer contact (NFS/Forza
 *   style): the struck car is shoved AND driven forward by its own share of the
 *   closing speed (`pushForward`), the shove is damped, and the subject keeps
 *   far more of its speed than a traffic crash costs it - two cars at the same
 *   pace trade paint and carry on instead of welding shut.
 * @returns { v, slowedSpeed, hitX, hitZ, resolveX, resolveZ } or null
 */
export function resolveVehicleCollision(subject, vehicles, prevX, prevZ, { spinScale = 1, arcade = false } = {}) {
  if (!subject?.state || !vehicles || !vehicles.length) return null;
  const playerState = subject.state;
  const pHeading = playerState.heading;
  const pSpeed = playerState.speed;

  const pHalfL = subject.rig?.halfLength ?? HALF_LENGTH;
  const pHalfW = subject.rig?.halfWidth ?? HALF_WIDTH;

  // Sweep the subject's motion this frame instead of testing only the final
  // pose. A fast car moves metres between frames, so a single-sample test let
  // it straddle a vehicle on both sides without ever overlapping on the
  // sampled frame - that was the "merge straight through" bug. Walking the
  // segment in short substeps and taking the FIRST vehicle the box meets
  // catches the entry point, and backing the subject to the last clear
  // substep stops the chassis ending the frame buried in the car.
  const curX = playerState.x;
  const curZ = playerState.z;
  const segLen = Math.hypot(curX - prevX, curZ - prevZ);
  const steps = Math.max(1, Math.ceil(segLen / 0.4));

  let contact = null;
  for (let i = 1; i <= steps && !contact; i++) {
    const sx = prevX + (curX - prevX) * (i / steps);
    const sz = prevZ + (curZ - prevZ) * (i / steps);
    const backX = prevX + (curX - prevX) * ((i - 1) / steps);
    const backZ = prevZ + (curZ - prevZ) * ((i - 1) / steps);
    for (const v of vehicles) {
      if (!v || v === subject || !v.state) continue;
      const dx = v.state.x - sx;
      const dz = v.state.z - sz;
      if (dx * dx + dz * dz > 7 * 7) continue; // quick reject
      if (boxesOverlap(sx, sz, pHeading, pHalfL, pHalfW, v)) {
        contact = { v, sx, sz, backX, backZ };
        break;
      }
    }
  }
  if (!contact) return null;

  const { v, sx, sz, backX, backZ } = contact;
  const dx = v.state.x - sx;
  const dz = v.state.z - sz;
  const dist = Math.hypot(dx, dz) || 1e-3;
  const impactSpeed = Math.abs(pSpeed);

  // Require intent: a parked car just touching the subject must not fire a
  // collision every frame. Either the subject is moving with some speed, or it
  // is clearly driving into the vehicle.
  const dotToV = (dx * Math.sin(pHeading) + dz * Math.cos(pHeading)) * Math.sign(pSpeed || 1);
  if (impactSpeed < 1.5 && dotToV < 0.5) return null;

  const nx = dx / dist;
  const nz = dz / dist;
  const vHalfL = v.rig?.halfLength ?? 2.0;
  const vehicleMass = (v.rig?.halfLength ?? 2) * (v.rig?.halfWidth ?? 0.9) * 0.5;
  const impulseShare = 1.0 / (1.0 + vehicleMass);

  // How hard the two are actually closing.
  //
  // Traffic keeps the subject's own speed: it is a road car being hit, and the
  // shock of the hit is the point. A racer bumping a racer is a MOMENTUM
  // TRANSFER instead, so the figure that matters is the closing speed - how
  // much faster this car is than the one it is touching. Two rivals travelling
  // together at the same pace are then in contact with nothing to give: they
  // trade paint and carry on, where the full-figure impulse used to scrub ~9% of
  // the speed on EVERY contact frame (60 times a second, stopping both cars dead
  // inside a fifth of a second - the weld this exists to remove). It also bounds
  // the transfer: a racer can drive the car ahead up to its own speed, no more.
  const struckSpeed = Math.max(0, v.state.speed ?? 0);
  const closing = arcade ? Math.max(0, impactSpeed - struckSpeed) : impactSpeed;

  // Detect side-by-side flank contact (paint trading): cars travelling roughly parallel
  // and overlapping across their flanks.
  const pFx = Math.sin(pHeading);
  const pFz = Math.cos(pHeading);
  const pSideX = pFz;
  const pSideZ = -pFx;
  const fwdDist = dx * pFx + dz * pFz;
  const sideDist = dx * pSideX + dz * pSideZ;
  const vFx = Math.sin(v.state.heading);
  const vFz = Math.cos(v.state.heading);
  const headingDot = pFx * vFx + pFz * vFz;
  const isSide = Math.abs(fwdDist) < (pHalfL + vHalfL) * 0.72 && headingDot > 0.25;

  // Shove the vehicle on FIRST contact only. A car already mid-shove keeps
  // coasting from its first hit; re-applying every overlapping frame would
  // stack impulses and fling it. The subject is still blocked and slowed
  // below regardless, so it can never pass through a reacting car.
  // Arcade (racer vs racer): damped shove, no spin over-reaction - both cars
  // keep racing. Nothing to give means no shove at all: a pair at the same
  // speed are leaning on each other, not colliding.
  if (!v.shoved && typeof v.applyShove === "function" && closing > 0.05) {
    if (isSide) {
      // Side contact: gentle lateral shove only, zero spin so cars don't pirouette into each other
      const sideDir = sideDist >= 0 ? 1 : -1;
      const shoveSpeed = Math.min(closing, 3.5) * impulseShare * (arcade ? 0.35 : 0.75);
      v.applyShove(pSideX * sideDir * shoveSpeed, pSideZ * sideDir * shoveSpeed, 0, { arcade: true });
    } else {
      const arcadeDamp = arcade ? 0.45 : 1.0;
      const pushFigure = arcade ? closing : Math.max(impactSpeed, 3);
      const shoveSpeed = pushFigure * impulseShare * 1.6 * arcadeDamp;
      const tx = -nz;
      const tz = nx;
      const hitAlongV = dx * Math.sin(v.state.heading) + dz * Math.cos(v.state.heading);
      const spinSign = Math.sign(hitAlongV) || 1;
      const spinRate = Math.max(impactSpeed, 2) * 0.6 * Math.abs(hitAlongV) / Math.max(vHalfL, 0.5) * spinScale;
      let sx = nx * shoveSpeed + tx * shoveSpeed * 0.3;
      let sz = nz * shoveSpeed + tz * shoveSpeed * 0.3;
      if (arcade) {
        // A racer is never driven against the way it is going.
        const travel = (v.state.speed ?? 0) < 0 ? -1 : 1;
        const fx = Math.sin(v.state.heading) * travel;
        const fz = Math.cos(v.state.heading) * travel;
        if (sx * fx + sz * fz < 0) {
          sx *= 0.25;
          sz *= 0.25;
        }
      }
      v.applyShove(sx, sz, spinSign * spinRate, { arcade });
    }
  }

  // --- racers: momentum, into the struck car's own speed ------------------
  if (arcade && closing > 0.05 && typeof v.pushForward === "function") {
    v.pushForward(closing * impulseShare * 0.25);
  }

  if (isSide) {
    // Side contact: do NOT pull backward to backX/backZ!
    // Keep forward motion (curX, curZ) and resolve lateral overlap smoothly so cars slide.
    const targetSideGap = pHalfW + (v.rig?.halfWidth ?? 0.9) + 0.04;
    const currentSideGap = Math.abs(sideDist);
    const sideOverlap = Math.max(0, targetSideGap - currentSideGap);
    const pushSide = sideDist >= 0 ? -1 : 1;
    const sepDist = Math.min(sideOverlap * 0.45 + 0.015, 0.05);
    const resolvedX = curX + pSideX * (pushSide * sepDist);
    const resolvedZ = curZ + pSideZ * (pushSide * sepDist);
    const sideSlowdown = arcade ? Math.min(0.12, closing * 0.03) : Math.min(0.35, closing * 0.08);

    return {
      v,
      slowedSpeed: pSpeed - Math.sign(pSpeed) * sideSlowdown,
      hitX: v.state.x,
      hitZ: v.state.z,
      resolveX: resolvedX,
      resolveZ: resolvedZ,
      isSide: true,
    };
  }

  // Head-on or T-bone impact: standard full resolve and slowdown
  const rawSlowdown = closing * (1 - impulseShare) * (arcade ? 0.5 : 0.7);
  const slowdown = arcade ? Math.min(rawSlowdown, 2.5) : rawSlowdown;
  return {
    v,
    slowedSpeed: pSpeed - Math.sign(pSpeed) * slowdown,
    hitX: v.state.x,
    hitZ: v.state.z,
    resolveX: backX,
    resolveZ: backZ,
    isSide: false,
  };
}

/**
 * 2D oriented-rectangle (SAT) overlap test between a box at (px,pz,pHeading)
 * and another vehicle's box. Returns true on overlap.
 */
export function boxesOverlap(px, pz, pHeading, pHalfL, pHalfW, v) {
  const dx = v.state.x - px;
  const dz = v.state.z - pz;
  const vHalfL = v.rig?.halfLength ?? 2.0;
  const vHalfW = v.rig?.halfWidth ?? 0.9;
  const sinP = Math.sin(pHeading);
  const cosP = Math.cos(pHeading);
  const sinV = Math.sin(v.state.heading);
  const cosV = Math.cos(v.state.heading);

  // A POSITIVE `satOverlap` means the two projections are disjoint on that
  // axis, which proves no overlap - so the box test fails (`return false`).
  // The comparison used to be `<= 0`, i.e. inverted, which made the test
  // report an overlap only when the boxes were separated on every axis and so
  // let the player drive through nearly every traffic vehicle.
  if (satOverlap(dx, dz, sinP, cosP,
    pHalfL + vHalfL * Math.abs(sinV * sinP + cosV * cosP) + vHalfW * Math.abs(cosV * sinP - sinV * cosP)) > 0) return false;
  if (satOverlap(dx, dz, cosP, -sinP,
    pHalfW + vHalfL * Math.abs(sinV * cosP - cosV * sinP) + vHalfW * Math.abs(cosV * cosP + sinV * sinP)) > 0) return false;
  if (satOverlap(dx, dz, sinV, cosV,
    vHalfL + pHalfL * Math.abs(sinP * sinV + cosP * cosV) + pHalfW * Math.abs(cosP * sinV - sinP * cosV)) > 0) return false;
  if (satOverlap(dx, dz, cosV, -sinV,
    vHalfW + pHalfL * Math.abs(sinP * cosV - cosP * sinV) + pHalfW * Math.abs(cosP * cosV + sinP * sinV)) > 0) return false;
  return true;
}

/**
 * Project (dx, dz) onto axis (sinA, cosA) and return the absolute projection
 * minus the half-extent `extent`. Non-positive = the two projections overlap
 * on this axis; positive = a separating axis was found.
 */
function satOverlap(dx, dz, sinA, cosA, extent) {
  const proj = Math.abs(dx * sinA + dz * cosA);
  return proj - extent;
}

/** Distance ahead of a car (m) that `nearestBlocker` scans by default. */
export const OBSTACLE_SCAN = 22;
/** Safety gap the AI keeps to the car ahead, metres. */
export const SAFETY_GAP = 4;

/**
 * Nearest blocker ahead of `self`, from a list of candidate vehicles.
 *
 * A candidate counts when its footprint overlaps the corridor `self` is about
 * to drive down. The lateral test uses the candidate's half-width PROJECTED
 * ACROSS our forward axis rather than its raw width, so a vehicle crossing
 * ahead is caught by its length - the case that matters when the player cuts
 * across in front. The forward test counts from the candidate's nose, so a car
 * already in the corridor is seen even at the far edge of the scan.
 *
 * @returns { distance, gap, speed, closing } or null, where `closing` is the
 *   blocker's speed along THIS car's forward axis (negative = oncoming).
 */
export function nearestBlocker(self, candidates, { scan = OBSTACLE_SCAN } = {}) {
  if (!self?.state || !candidates) return null;
  const sin = Math.sin(self.state.heading);
  const cos = Math.cos(self.state.heading);
  const myHalfW = self.rig?.halfWidth ?? HALF_WIDTH;
  const myHalfL = self.rig?.halfLength ?? HALF_LENGTH;
  const margin = 0.5;
  let best = null;

  for (const v of candidates) {
    if (!v || v === self || !v.state) continue;
    const dx = v.state.x - self.state.x;
    const dz = v.state.z - self.state.z;
    const along = dx * sin + dz * cos;
    const vHalfL = v.rig?.halfLength ?? HALF_LENGTH;
    // Count from the candidate's nose so an already-entered corridor is not
    // missed at the tail of the scan window.
    if (along <= 0.3 || along > scan + vHalfL) continue;

    const side = Math.abs(dx * cos - dz * sin);
    const dh = (v.state.heading ?? self.state.heading) - self.state.heading;
    const vHalfW = v.rig?.halfWidth ?? HALF_WIDTH;
    const projHalfW = vHalfL * Math.abs(Math.sin(dh)) + vHalfW * Math.abs(Math.cos(dh));
    if (side > myHalfW + projHalfW + margin) continue;

    // Bumper-to-bumper gap along our forward axis, so "keep a gap" means a
    // real space between the cars rather than between their centres.
    const gap = along - myHalfL - vHalfL;
    const closing = (v.state.speed ?? 0) * Math.cos(dh);
    if (!best || gap < best.gap) {
      best = { vehicle: v, distance: along, gap, speed: v.state.speed ?? 0, closing };
    }
  }
  return best;
}
