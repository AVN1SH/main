import {
  Color3,
  DirectionalLight,
  DynamicTexture,
  Engine,
  HemisphericLight,
  LoadAssetContainerAsync,
  Mesh,
  MeshBuilder,
  Scene,
  StandardMaterial,
  TransformNode,
  UniversalCamera,
  Vector3,
} from "@babylonjs/core";
import "@babylonjs/loaders/glTF/2.0";
import { RACE_CAR_CATALOG } from "./VehicleAssets.js";

/**
 * Garage showroom: the NFS-style car grid plus a live 3D preview.
 *
 * Grid cards show name plates (thumbnail <img> slots are reserved in the
 * markup for user-supplied car images - see the `garage-thumb` comment in
 * index.html). Clicking a card loads that car - player car plus everything
 * in `public/assets/` that is NOT the player's car and NOT a `vehicles/`
 * traffic model - into a private showroom scene: deep-gray studio
 * (dark background melting into a lit gray floor via fog, gray podium
 * stage), blob contact shadow, level car stance, turntable with
 * horizontal-only drag (full 360 deg) and idle auto-spin.
 *
 * The showroom runs its own Engine on its own canvas and only renders while
 * open, so the main loop skips its own present in that window (see main.js).
 */

const SITE_ASSETS = "assets/";
const SHOW_LENGTH = 4.4; // every car normalised to this length, metres
const PLAYER_ENTRY = { file: "car1.glb", label: "Street Racer", price: 0 };

// Garage economy (owned by the showroom module, persisted across visits):
// the player's starter car is owned, everything else has a price tag. New
// drivers start broke: race winnings are the way up, and ~5-6 winning races
// earn the cheapest new car (Beetle, $9,500).
const START_BALANCE = 0;
const BALANCE_KEY = "streetracer_balance_v2";
const OWNED_KEY = "streetracer_garage_owned";
const EQUIPPED_KEY = "streetracer_equipped";

function loadBalance() {
  try {
    const raw = localStorage.getItem(BALANCE_KEY);
    // A MISSING key must mean "new player", not "no money": `Number(null)` is
    // 0, which would read as a spent-out balance and disable every BUY button
    // on the very first visit. Only a real stored number is trusted.
    if (raw !== null && raw !== "") {
      const n = Number(raw);
      if (Number.isFinite(n) && n >= 0) return Math.floor(n);
    }
  } catch {
    /* private mode: fall through to default */
  }
  return START_BALANCE;
}

function loadOwned() {
  try {
    const stored = localStorage.getItem(OWNED_KEY);
    // No key at all means a new player, who owns the starter car; only a real
    // stored list is trusted (parsing the absent key as "[]" would leave the
    // player owning nothing, including the car they are already driving).
    if (stored !== null) {
      const raw = JSON.parse(stored);
      if (Array.isArray(raw)) {
        const set = new Set(raw.filter((f) => typeof f === "string"));
        set.add(PLAYER_ENTRY.file); // the starter car can never be lost
        return set;
      }
    }
  } catch {
    /* corrupted save: fall through to default */
  }
  return new Set([PLAYER_ENTRY.file]);
}

/** The file the player is currently driving, or the starter car. */
function loadEquipped() {
  try {
    const raw = localStorage.getItem(EQUIPPED_KEY);
    if (typeof raw === "string" && raw) return raw;
  } catch {
    /* private mode: fall through to default */
  }
  return PLAYER_ENTRY.file;
}

function fmtCash(n) {
  return "$" + Math.floor(n).toLocaleString("en-US");
}
// All-gray studio: cyclorama sweep melts the backdrop into the floor seamlessly
// with a smooth continuous gradient across the entire canvas.
const PODIUM_R = 4.5;
const PODIUM_H = 0.22;
const PODIUM_TOP = PODIUM_H;
const STUDIO_BG = new Color3(0.063, 0.075, 0.094); // #101318

// Showroom order: cheapest to priciest. Owned and equipped
// cars keep their natural spot in that price-sorted line-up
// (the starter car, price 0, always leads it).
const priceTag = (entry) => {
  const p = Number(entry.price);
  return Number.isFinite(p) && p > 0 ? Math.floor(p) : 0;
};

export const GARAGE_CATALOG = [PLAYER_ENTRY, ...RACE_CAR_CATALOG].sort(
  (a, b) => priceTag(a) - priceTag(b),
);

export function createGarageScreen() {
  const screenEl = document.getElementById("garage-screen");
  const gridEl = document.getElementById("garage-grid");
  const countEl = document.getElementById("garage-count");
  const balanceEl = document.getElementById("garage-balance");
  const canvas = document.getElementById("garage-canvas");
  const nameEl = document.getElementById("garage-carname");

  let engine = null;
  let scene = null;
  let camera = null;
  let turntable = null;
  let tiltNode = null;
  let blob = null;
  let opened = false;
  let shown = false;
  let selected = 0;
  let yaw = 0.6;
  let tilt = 0;
  let lastInteract = 0;
  let dragging = false;
  let lastPX = 0;
  let lastPY = 0;
  const containers = new Map();
  let currentRoots = [];
  let balance = loadBalance();
  const owned = loadOwned();
  // File of the car currently sitting in the garage slot. Only set once the
  // game has actually swapped the model in (see `tryEquip`).
  //
  // The saved slot is honoured only if that car is genuinely owned: a save
  // written while the testing build had everything unlocked (or a hand-edited
  // one) must not leave a car the player never bought sitting in the slot.
  const savedEquipped = loadEquipped();
  let equipped = owned.has(savedEquipped) ? savedEquipped : PLAYER_ENTRY.file;
  if (equipped !== savedEquipped) saveEquipped();
  // Provided by main.js: builds the rig and swaps the player's car.
  let equipHandler = null;

  function saveEconomy() {
    try {
      localStorage.setItem(BALANCE_KEY, String(balance));
      localStorage.setItem(OWNED_KEY, JSON.stringify([...owned]));
    } catch {
      /* private mode: play session-only */
    }
  }

  function saveEquipped() {
    try {
      localStorage.setItem(EQUIPPED_KEY, equipped);
    } catch {
      /* private mode: play session-only */
    }
  }

  function isOwned(entry) {
    return owned.has(entry.file);
  }

  function isEquipped(entry) {
    return entry.file === equipped;
  }

  function carPrice(entry) {
    const p = Number(entry.price);
    return Number.isFinite(p) && p > 0 ? Math.floor(p) : 0;
  }

  if (countEl) countEl.textContent = `${GARAGE_CATALOG.length} CARS`;

  function renderBalance() {
    if (balanceEl) balanceEl.textContent = fmtCash(balance);
  }

  function buy(index) {
    const entry = GARAGE_CATALOG[index];
    if (!entry || isOwned(entry)) return false;
    const price = carPrice(entry);
    if (price <= 0 || balance < price) return false;
    balance -= price;
    owned.add(entry.file);
    saveEconomy();
    renderBalance();
    renderGrid();
    select(index);
    return true;
  }

  function renderGrid() {
    if (!gridEl) return;
    gridEl.textContent = "";
    GARAGE_CATALOG.forEach((entry, i) => {
      const card = document.createElement("div");
      card.className = "garage-card" + (i === selected ? " is-selected" : "");
      card.dataset.index = String(i);
      const thumb = document.createElement("div");
      thumb.className = "garage-thumb";
      // Thumbnail <img> slot: user-supplied car images drop in here later
      // (e.g. thumb.append(Object.assign(document.createElement('img'), { src }))).
      thumb.appendChild(
        document.createComment(" thumbnail <img> goes here (user assets) "),
      );
      const empty = document.createElement("div");
      empty.className = "garage-thumb__empty";
      empty.textContent = "IMAGE";
      thumb.appendChild(empty);
      const priceTag = document.createElement("div");
      priceTag.className = "garage-price";
      priceTag.textContent = isEquipped(entry)
        ? "IN GARAGE SLOT"
        : isOwned(entry)
          ? "OWNED"
          : fmtCash(carPrice(entry));
      thumb.appendChild(priceTag);
      const namebar = document.createElement("div");
      namebar.className = "garage-namebar";
      const name = document.createElement("span");
      name.textContent = entry.label;
      const tag = document.createElement("span");
      tag.className = "garage-tag";
      tag.textContent = isEquipped(entry) ? "EQUIPPED" : "SELECTED";
      namebar.append(name, tag);
      card.append(thumb, namebar);
      if (isEquipped(entry)) card.classList.add("is-equipped");
      const action = document.createElement("button");
      action.type = "button";
      if (isEquipped(entry)) {
        action.className = "garage-buy is-equipped";
        action.textContent = "EQUIPPED";
        action.disabled = true;
      } else if (isOwned(entry)) {
        action.className = "garage-buy is-owned";
        action.textContent = "EQUIP";
        action.addEventListener("click", (e) => {
          e.stopPropagation();
          tryEquip(i);
        });
      } else {
        const price = carPrice(entry);
        const afford = balance >= price;
        action.className = "garage-buy" + (afford ? "" : " is-disabled");
        action.textContent = `BUY ${fmtCash(price)}`;
        action.disabled = !afford;
        action.addEventListener("click", (e) => {
          e.stopPropagation();
          buy(i);
        });
      }
      card.append(action);
      card.addEventListener("click", () => select(i));
      gridEl.appendChild(card);
    });
  }

  /**
   * Hand the chosen car to the game. The swap is allowed to be asynchronous
   * (the model may still need loading), so the button only flips to EQUIPPED
   * once the handler resolves with a non-false result.
   */
  function tryEquip(index) {
    const entry = GARAGE_CATALOG[index];
    if (!entry || !isOwned(entry) || isEquipped(entry)) return false;
    if (!equipHandler) return false;
    let result;
    try {
      result = equipHandler(entry);
    } catch (err) {
      console.warn("Garage: equip failed", err);
      return false;
    }
    Promise.resolve(result).then(
      (ok) => {
        if (ok === false) return;
        equipped = entry.file;
        saveEquipped();
        select(index);
        renderGrid();
      },
      (err) => console.warn("Garage: equip failed", err),
    );
    return true;
  }

  function markSelected() {
    if (!gridEl) return;
    for (const card of gridEl.children) {
      card.classList.toggle(
        "is-selected",
        Number(card.dataset.index) === selected,
      );
    }
  }

  function paintStudioCycTexture(w = 512, h = 1024) {
    const tex = new DynamicTexture(
      "garage_cyc_tex",
      { width: w, height: h },
      scene,
      false,
    );
    const g = tex.getContext();

    // Smooth vertical studio backdrop gradient:
    // y = 0: top of back wall (reaches well past top of viewport)
    // y = h: front floor (foreground in front of vehicle)
    const vGrad = g.createLinearGradient(0, 0, 0, h);
    vGrad.addColorStop(0, "#101318");
    vGrad.addColorStop(0.2, "#13171e");
    vGrad.addColorStop(0.46, "#242a35");
    vGrad.addColorStop(0.6, "#2b3340");
    vGrad.addColorStop(0.72, "#232832");
    vGrad.addColorStop(0.85, "#191d24");
    vGrad.addColorStop(1.0, "#12151b");

    g.fillStyle = vGrad;
    g.fillRect(0, 0, w, h);

    // Wide, soft studio spotlight halo centered behind the vehicle
    const radGrad = g.createRadialGradient(
      w / 2,
      h * 0.54,
      20,
      w / 2,
      h * 0.54,
      w * 0.72,
    );
    radGrad.addColorStop(0, "rgba(62, 74, 94, 0.45)");
    radGrad.addColorStop(0.35, "rgba(44, 54, 68, 0.28)");
    radGrad.addColorStop(0.7, "rgba(24, 30, 40, 0.12)");
    radGrad.addColorStop(1, "rgba(0, 0, 0, 0)");

    g.fillStyle = radGrad;
    g.fillRect(0, 0, w, h);

    tex.update();
    return tex;
  }

  function buildStudioCyc() {
    // Continuous curved cyclorama sweep (floor -> cove curve -> tall back wall)
    // Covers the camera frustum completely from bottom to top with no horizon seam or black bar.
    const stepsD = 36;
    const stepsW = 24;
    const pathArray = [];

    // Direction vectors: camera looks toward negative X & negative Z
    const forward = new Vector3(-0.527, 0, -0.85);
    const right = new Vector3(0.85, 0, -0.527);

    for (let i = 0; i <= stepsD; i++) {
      const v = i / stepsD;
      // Depth from foreground (-14m) to deep behind the car (+26m)
      const d = -14 + v * 40;
      let y = 0;
      if (d > 4.6) {
        // Smooth curved cove
        const t = Math.min(1, (d - 4.6) / 13.4);
        y = 13.5 * (1 - Math.cos(t * Math.PI * 0.5));
        if (d > 18) {
          y += (d - 18) * 2.2;
        }
      }
      const path = [];
      for (let j = 0; j <= stepsW; j++) {
        const u = j / stepsW;
        const w = (u - 0.5) * 80;
        // Subtle bowl winging at wide edges for wrap-around feel
        const dish = d > 4.6 ? Math.pow(w / 40, 2) * 3 : 0;
        const pos = forward.scale(d).add(right.scale(w));
        pos.y = y + dish;
        path.push(pos);
      }
      pathArray.push(path);
    }

    const cyc = MeshBuilder.CreateRibbon(
      "garage_cyc",
      { pathArray, sideOrientation: Mesh.DOUBLESIDE },
      scene,
    );
    cyc.isPickable = false;

    const cycTex = paintStudioCycTexture(512, 1024);
    const cycMat = new StandardMaterial("garage_cyc_mat", scene);
    cycMat.diffuseTexture = cycTex;
    cycMat.emissiveTexture = cycTex;
    cycMat.emissiveColor = new Color3(0.92, 0.94, 0.98);
    cycMat.diffuseColor = new Color3(0.08, 0.08, 0.09);
    cycMat.specularColor = new Color3(0, 0, 0);
    cycMat.disableLighting = false;

    cyc.material = cycMat;
    cyc.freezeWorldMatrix();
  }

  function buildPodium() {
    // Circular stage elevated gently above the cyclorama floor.
    const capMat = new StandardMaterial("garage_podium_mat", scene);
    capMat.diffuseColor = new Color3(0.24, 0.26, 0.29);
    capMat.emissiveColor = new Color3(0.012, 0.014, 0.017);
    capMat.specularColor = new Color3(0.06, 0.06, 0.06);
    const podium = MeshBuilder.CreateCylinder(
      "garage_podium",
      {
        height: PODIUM_H,
        diameterTop: PODIUM_R * 2,
        diameterBottom: PODIUM_R * 2 + 0.4,
        tessellation: 64,
      },
      scene,
    );
    podium.position.y = PODIUM_H / 2;
    podium.material = capMat;
    podium.isPickable = false;
    podium.freezeWorldMatrix();

    blob = MeshBuilder.CreatePlane(
      "garage_blob",
      { width: 1, height: 1 },
      scene,
    );
    blob.rotation.x = -Math.PI / 2;
    blob.position.y = PODIUM_TOP + 0.006;
    blob.material = flatUnlit(
      paintRadial(256, "rgba(0,0,0,0.6)", "rgba(0,0,0,0)"),
    );
    blob.isPickable = false;
  }

  function paintRadial(size, inner, outer) {
    const tex = new DynamicTexture(
      `garage_radial_${size}`,
      { width: 256, height: 256 },
      scene,
      false,
    );
    tex.hasAlpha = true;
    const g = tex.getContext();
    g.clearRect(0, 0, 256, 256);
    const grad = g.createRadialGradient(128, 128, 8, 128, 128, 128);
    grad.addColorStop(0, inner);
    grad.addColorStop(1, outer);
    g.fillStyle = grad;
    g.fillRect(0, 0, 256, 256);
    tex.update();
    return tex;
  }

  function flatUnlit(tex) {
    const mat = new StandardMaterial(
      `garage_flat_${Math.random().toString(36).slice(2)}`,
      scene,
    );
    mat.emissiveTexture = tex;
    mat.emissiveColor = new Color3(1, 1, 1);
    mat.diffuseColor = new Color3(0, 0, 0);
    mat.specularColor = new Color3(0, 0, 0);
    mat.disableLighting = true;
    mat.useAlphaFromDiffuseTexture = true;
    return mat;
  }

  function buildShowroom() {
    engine = new Engine(canvas, true, {
      antialias: true,
      powerPreference: "high-performance",
      limitDeviceRatio: 1.5,
      stencil: true,
    });
    // Same as the main engine: Babylon's own loader UI must never paint
    // (the showroom has its own DOM); asset loading itself is untouched.
    engine.loadingScreen = {
      displayLoadingUI: () => {},
      hideLoadingUI: () => {},
    };
    scene = new Scene(engine);
    // Same gray as the fog: the floor fades exactly into this.
    scene.clearColor = STUDIO_BG.toColor4(1);

    camera = new UniversalCamera("garagecam", new Vector3(5, 3, 9), scene);
    camera.fov = 0.75;
    camera.minZ = 0.1;
    camera.maxZ = 200;
    camera.inputs.clear();
    scene.activeCamera = camera;

    const hemi = new HemisphericLight("ghemi", new Vector3(0, 1, 0), scene);
    hemi.intensity = 0.45;
    hemi.diffuse = new Color3(0.85, 0.89, 0.96);
    hemi.groundColor = new Color3(0.15, 0.16, 0.18);
    const key = new DirectionalLight("gkey", new Vector3(0.5, -1, 0.35), scene);
    key.intensity = 0.8;
    key.diffuse = new Color3(1.0, 0.97, 0.92);
    const rim = new DirectionalLight(
      "grim",
      new Vector3(-0.6, -0.4, -0.7),
      scene,
    );
    rim.intensity = 0.5;
    rim.diffuse = new Color3(0.62, 0.72, 1.0);

    buildStudioCyc();
    buildPodium();

    turntable = new TransformNode("garage_turntable", scene);
    tiltNode = new TransformNode("garage_tilt", scene);
    tiltNode.parent = turntable;

    canvas.addEventListener("pointerdown", (e) => {
      dragging = true;
      lastPX = e.clientX;
      lastPY = e.clientY;
      lastInteract = performance.now();
      try {
        canvas.setPointerCapture(e.pointerId);
      } catch {
        /* touch without capture support */
      }
    });
    const endDrag = () => {
      dragging = false;
      lastInteract = performance.now();
    };
    canvas.addEventListener("pointerup", endDrag);
    canvas.addEventListener("pointercancel", endDrag);
    canvas.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      // Horizontal-only spin: drag right rotates the car right
      // (clockwise from above), matching the pointer direction.
      yaw -= (e.clientX - lastPX) * 0.0085;
      lastPX = e.clientX;
      lastPY = e.clientY;
      lastInteract = performance.now();
    });

    window.addEventListener("resize", () => {
      if (opened && engine) engine.resize();
    });
  }

  function measureRoots(roots) {
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;
    for (const root of roots) {
      root.computeWorldMatrix(true);
      for (const m of root.getChildMeshes(false)) {
        m.computeWorldMatrix(true);
        const bb = m.getBoundingInfo().boundingBox;
        const wm = m.getWorldMatrix().m;
        for (let i = 0; i < 8; i++) {
          const x = i & 1 ? bb.maximum.x : bb.minimum.x;
          const y = i & 2 ? bb.maximum.y : bb.minimum.y;
          const z = i & 4 ? bb.maximum.z : bb.minimum.z;
          const wx = wm[0] * x + wm[4] * y + wm[8] * z + wm[12];
          const wy = wm[1] * x + wm[5] * y + wm[9] * z + wm[13];
          const wz = wm[2] * x + wm[6] * y + wm[10] * z + wm[14];
          if (wx < minX) minX = wx;
          if (wy < minY) minY = wy;
          if (wz < minZ) minZ = wz;
          if (wx > maxX) maxX = wx;
          if (wy > maxY) maxY = wy;
          if (wz > maxZ) maxZ = wz;
        }
      }
    }
    return { minX, minY, minZ, maxX, maxY, maxZ };
  }

  async function loadContainer(entry) {
    let container = containers.get(entry.file);
    if (container) return container;
    container = await LoadAssetContainerAsync(
      SITE_ASSETS + encodeURIComponent(entry.file),
      scene,
      {
        pluginExtension: ".glb",
      },
    );
    containers.set(entry.file, container);
    return container;
  }

  async function showCar(index) {
    selected = index;
    markSelected();
    const entry = GARAGE_CATALOG[index];
    if (nameEl) nameEl.textContent = entry.label.toUpperCase();
    if (!engine || !scene) return;
    for (const root of currentRoots) root.dispose();
    currentRoots = [];
    let container = null;
    try {
      container = await loadContainer(entry);
    } catch (err) {
      console.warn(`Garage: ${entry.file} failed to load`, err);
      if (nameEl)
        nameEl.textContent = `${entry.label.toUpperCase()} — FAILED TO LOAD`;
      return;
    }
    const inst = container.instantiateModelsToScene((n) => n, false);
    const roots = inst.rootNodes ?? [];
    if (!roots.length) return;
    const box = measureRoots(roots);
    if (!Number.isFinite(box.minX)) return;
    const dx = box.maxX - box.minX;
    const dz = box.maxZ - box.minZ;
    const s = SHOW_LENGTH / Math.max(dx, dz, 0.5);
    const carRoot = new TransformNode(`garage_car_${index}`, scene);
    carRoot.parent = tiltNode;
    // Centre the car on the podium disc and sit it level on the platform
    // top (no pitch: tilt stays 0 so all four wheels touch).
    carRoot.position.set(
      -((box.minX + box.maxX) / 2) * s,
      PODIUM_TOP - box.minY * s + 0.002,
      -((box.minZ + box.maxZ) / 2) * s,
    );
    carRoot.scaling.x = s;
    carRoot.scaling.y = s;
    carRoot.scaling.z = s;
    for (const r of roots) {
      r.parent = carRoot;
      currentRoots.push(r);
    }
    // Blob shadow follows the footprint.
    blob.scaling.x = dx * s * 1.5;
    blob.scaling.y = dz * s * 1.5;
    blob.scaling.z = 1;
    // Frame it: front three-quarter like the reference card.
    const dist = SHOW_LENGTH * 1.55 + 1.2;
    const dir = new Vector3(0.62, 0.34, 1.0).normalize();
    camera.position.set(dir.x * dist, 1.0 + dir.y * dist, dir.z * dist);
    camera.setTarget(new Vector3(0, 1.0, 0));
    lastInteract = performance.now();
  }

  function select(index) {
    if (index < 0 || index >= GARAGE_CATALOG.length) return;
    showCar(index).catch((err) => console.warn("Garage: show failed", err));
  }

  renderGrid();
  renderBalance();

  return {
    isOpen() {
      return opened;
    },
    isShown() {
      return shown;
    },
    /**
     * Register the game's car-swap callback: `(entry) => boolean | Promise`.
     * Returning false (or rejecting) leaves the equipped car unchanged.
     */
    setEquipHandler(fn) {
      equipHandler = typeof fn === "function" ? fn : null;
    },
    /** Catalog entry for the car currently equipped (defaults to the starter). */
    getEquipped() {
      return (
        GARAGE_CATALOG.find((e) => isEquipped(e)) ??
        GARAGE_CATALOG.find((e) => e.file === PLAYER_ENTRY.file)
      );
    },
    /** Current player balance (shown in the header, spent on cars). */
    getBalance() {
      return balance;
    },
    /** Add funds (race winnings, paid by main.js when results land). */
    addFunds(n) {
      if (!Number.isFinite(n) || n <= 0) return balance;
      balance += Math.floor(n);
      saveEconomy();
      renderBalance();
      renderGrid();
      return balance;
    },
    /**
     * Open the showroom. Pass `{ header: false }` to open it bare —
     * the lobby's garage section launches it that way, without the
     * header bar. The bare class is always cleared on close, so the
     * in-game opening screen keeps its header untouched.
     */
    open(opts = {}) {
      if (opened) return true;
      if (!engine) {
        try {
          buildShowroom();
        } catch (err) {
          console.warn("Garage: preview engine failed", err);
          return false;
        }
      }
      opened = true;
      shown = false;
      if (opts.header === false) screenEl?.classList.add("is-bare");
      engine.resize();
      yaw = 0.6;
      tilt = 0;
      lastInteract = 0; // auto-spin until first touch
      renderBalance();
      renderGrid();
      select(selected);
      return true;
    },
    close() {
      if (!opened) return;
      opened = false;
      shown = false;
      screenEl?.classList.remove("is-bare");
      screenEl?.classList.remove("is-visible");
      screenEl?.setAttribute("aria-hidden", "true");
    },
    /**
     * Reveal the overlay. Called by main.js once the top-view glide has
     * actually arrived (or its timeout trips) - never on a timer alone, so
     * the zoom-out always plays fully visible instead of behind the fade.
     */
    reveal() {
      if (shown) return;
      shown = true;
      screenEl?.classList.add("is-visible");
      screenEl?.setAttribute("aria-hidden", "false");
      engine.resize();
    },
    render(dt) {
      if (!opened || !engine || !scene) return;
      if (performance.now() - lastInteract > 3000) yaw += 0.12 * dt;
      turntable.rotation.y = yaw;
      tiltNode.rotation.x = 0;
      scene.render();
    },
  };
}
