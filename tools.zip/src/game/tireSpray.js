import { Color4, DynamicTexture, ParticleSystem, Vector3 } from "@babylonjs/core";

/**
 * Loose material thrown up by the player's rear tyres.
 *
 * Where `tireMarks` lays down the lasting smear, this is the airborne half of
 * the same event: dust, dirt, mud and sand flicked off the contact patch while
 * the car is driving. The look follows the ground under the wheel (the same
 * SURF families the marks use) so the two systems agree:
 *
 *   ROAD   - fine grey road dust, faint while cruising and thick on a burnout
 *            or a slide;
 *   DIRT   - mid-brown dust clouds, thrown on any normal driving;
 *   GRASS  - wet mud with green grass dragged through it;
 *   SAND   - pale sand grains, the loosest and most eager of the four.
 *
 * One pooled ParticleSystem per look (4 total). Each frame the player hands
 * over the rear-wheel contacts; the contacts are grouped by surface, and each
 * look's system emits from ALL of its wheels at once (the emitter box spans
 * them) at a rate scaled by speed and slip. Two tyres on the same surface
 * therefore spray together from both sides, and every uninvolved system decays
 * to zero. Nothing is allocated per frame, and the whole thing is inert until
 * the tyres are on the ground and moving.
 */

const LOOK_COUNT = 4;
const CAPACITY = 200;
// Base emission (particles/sec while moving) and how much slip adds on top.
// Road normally shows only a whisper of dust; the loose surfaces are eager.
const CFG = [
  // ROAD and GRASS spray rates are trimmed ~one third; grass a touch more
  // still ("specially on the grass surface"). DIRT and SAND are unchanged.
  { base: 8, slip: 113, size: [0.24, 0.62], life: [0.35, 0.8], power: [0.9, 2.3], gravity: -4.5 }, // ROAD
  { base: 26, slip: 175, size: [0.28, 0.85], life: [0.45, 1.05], power: [1.1, 2.8], gravity: -6.5 }, // DIRT
  { base: 16, slip: 105, size: [0.3, 0.95], life: [0.5, 1.15], power: [1.2, 3.0], gravity: -7.0 }, // GRASS
  { base: 44, slip: 195, size: [0.2, 0.68], life: [0.4, 0.9], power: [1.3, 3.2], gravity: -8.0 }, // SAND
];

function clamp01(v) {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

/** Soft round dust puff, colour baked in so tinting stays trivial. */
function makePuffTexture(scene, name, r, g, b) {
  const S = 64;
  const tex = new DynamicTexture(name, { width: S, height: S }, scene, true);
  tex.hasAlpha = true;
  const ctx = tex.getContext();
  ctx.clearRect(0, 0, S, S);
  const grad = ctx.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2);
  grad.addColorStop(0, `rgba(${r},${g},${b},0.95)`);
  grad.addColorStop(0.45, `rgba(${r},${g},${b},0.42)`);
  grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, S, S);
  tex.update();
  return tex;
}

/** Mud puff with green grass blades baked into it (GRASS look). */
function makeMudGrassTexture(scene, name) {
  const S = 64;
  const tex = new DynamicTexture(name, { width: S, height: S }, scene, true);
  tex.hasAlpha = true;
  const ctx = tex.getContext();
  ctx.clearRect(0, 0, S, S);
  // Mud base: dark and opaque at the centre, thinning out to the rim. This
  // has to dominate the texture or the spray reads as plain green grass
  // instead of the mud the tyres are actually digging up.
  const grad = ctx.createRadialGradient(S / 2, S / 2, 2, S / 2, S / 2, S / 2);
  grad.addColorStop(0, "rgba(92,63,33,0.98)");
  grad.addColorStop(0.4, "rgba(108,76,44,0.72)");
  grad.addColorStop(0.7, "rgba(86,60,34,0.32)");
  grad.addColorStop(1, "rgba(68,48,28,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, S, S);
  // Darker mud clods so the puff looks lumpy, not like a soft airbrush.
  for (let i = 0; i < 12; i++) {
    ctx.fillStyle = `rgba(56,38,22,${0.35 + Math.random() * 0.4})`;
    ctx.beginPath();
    ctx.arc(6 + Math.random() * (S - 12), 6 + Math.random() * (S - 12), 1 + Math.random() * 3, 0, Math.PI * 2);
    ctx.fill();
  }
  // A FEW grass blades dragged through the mud - accents, not the whole look.
  const blades = [
    [96, 130, 54],
    [118, 152, 66],
    [76, 106, 46],
  ];
  for (let i = 0; i < 10; i++) {
    const c = blades[i % blades.length];
    const x = 8 + Math.random() * (S - 16);
    const y = 8 + Math.random() * (S - 16);
    const len = 2 + Math.random() * 4;
    ctx.strokeStyle = `rgba(${c[0]},${c[1]},${c[2]},${0.5 + Math.random() * 0.4})`;
    ctx.lineWidth = 0.8 + Math.random() * 0.8;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (Math.random() - 0.5) * 3, y + len);
    ctx.stroke();
  }
  tex.update();
  return tex;
}

/** Bright, slightly grainy speck (SAND look). */
function makeGrainTexture(scene, name) {
  const S = 64;
  const tex = new DynamicTexture(name, { width: S, height: S }, scene, true);
  tex.hasAlpha = true;
  const ctx = tex.getContext();
  ctx.clearRect(0, 0, S, S);
  const grad = ctx.createRadialGradient(S / 2, S / 2, 1, S / 2, S / 2, S / 2);
  grad.addColorStop(0, "rgba(232,218,190,0.95)");
  grad.addColorStop(0.5, "rgba(214,196,160,0.45)");
  grad.addColorStop(1, "rgba(200,182,146,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, S, S);
  for (let i = 0; i < 22; i++) {
    const x = Math.random() * S;
    const y = Math.random() * S;
    const s = 1 + Math.random() * 2;
    ctx.fillStyle = `rgba(240,230,206,${0.5 + Math.random() * 0.4})`;
    ctx.fillRect(x, y, s, s);
  }
  tex.update();
  return tex;
}

function makeTexture(scene, look, tag) {
  if (look === 0) return makePuffTexture(scene, `tirespray_${tag}_0`, 196, 192, 186);
  if (look === 1) return makePuffTexture(scene, `tirespray_${tag}_1`, 168, 138, 98);
  if (look === 2) return makeMudGrassTexture(scene, `tirespray_${tag}_2`);
  return makeGrainTexture(scene, `tirespray_${tag}_3`);
}

function makeSystem(scene, look, tag) {
  const cfg = CFG[look];
  const ps = new ParticleSystem(`tirespray_${tag}_${look}`, CAPACITY, scene);
  ps.particleTexture = makeTexture(scene, look, tag);
  // Parked far below the world until the player points it at a wheel.
  ps.emitter = new Vector3(0, -1000, 0);
  ps.minEmitBox = new Vector3(-0.16, -0.03, -0.16);
  ps.maxEmitBox = new Vector3(0.16, 0.05, 0.16);
  ps.color1 = new Color4(1, 1, 1, 0.85);
  ps.color2 = new Color4(1, 1, 1, 0.5);
  ps.colorDead = new Color4(1, 1, 1, 0);
  ps.minSize = cfg.size[0];
  ps.maxSize = cfg.size[1];
  ps.minLifeTime = cfg.life[0];
  ps.maxLifeTime = cfg.life[1];
  ps.minEmitPower = cfg.power[0];
  ps.maxEmitPower = cfg.power[1];
  ps.gravity = new Vector3(0, cfg.gravity, 0);
  ps.blendMode = ParticleSystem.BLENDMODE_STANDARD;
  // A cloud grows as it rises and thins as it dies.
  ps.addSizeGradient(0, 0.55);
  ps.addSizeGradient(0.35, 1.0);
  ps.addSizeGradient(1, 1.7);
  ps.emitRate = 0;
  ps.start();
  return ps;
}

export class TireSpray {
  /**
   * @param scene Babylon scene
   * @param opts { tag }
   */
  constructor(scene, opts = {}) {
    this.scene = scene;
    this.tag = opts.tag ?? "world";
    this.systems = [];
    this.rates = new Float32Array(LOOK_COUNT);
    for (let look = 0; look < LOOK_COUNT; look++) {
      this.systems.push(makeSystem(scene, look, this.tag));
    }
  }

  /**
   * One frame of tyre spray.
   *
   * @param pose { heading, speed, slip, wheels: [{ x, y, z, look }] }
   *   `wheels` are the rear contact patches that are actually on the ground;
   *   `look` is a MARK_LOOK index (see surfaceLook). Passing none (or
   *   airborne/handbrake-parked frames) just decays the emitters.
   */
  update(dt, pose) {
    if (!pose || !pose.wheels || pose.wheels.length === 0) {
      this.idle(dt);
      return;
    }
    const speed = Math.abs(pose.speed ?? 0);
    const speedF = clamp01((speed - 2.5) / 14);
    const slip = clamp01(pose.slip ?? 0);

    // Group the contacting wheels by surface look. A single system per look
    // serves ALL of its wheels (usually both rear tyres), so a normal
    // same-surface drive sprays from both sides rather than one: the emitter
    // box is stretched across the wheels, and the requested rate is their sum.
    const target = [0, 0, 0, 0];
    const wheelsFor = [[], [], [], []];
    for (const w of pose.wheels) {
      const look = Math.max(0, Math.min(LOOK_COUNT - 1, w.look ?? 1));
      wheelsFor[look].push(w);
      const cfg = CFG[look];
      target[look] += (cfg.base * speedF + cfg.slip * slip) * speedF;
    }

    const fx = Math.sin(pose.heading ?? 0);
    const fz = Math.cos(pose.heading ?? 0);
    const k = 0.7 + speedF;
    const ease = Math.min(1, 7 * dt);
    for (let look = 0; look < LOOK_COUNT; look++) {
      const ps = this.systems[look];
      const ws = wheelsFor[look];
      const want = ws.length ? target[look] : 0;
      this.rates[look] += (want - this.rates[look]) * ease;
      const rate = this.rates[look];
      ps.emitRate = rate < 0.5 ? 0 : rate;
      if (!ws.length || ps.emitRate <= 0) continue;
      // Emitter box spanning every wheel on this surface. Axis-aligned but
      // built from the wheel spread, so it covers both tyres whatever the car
      // is yawed to; a single wheel degenerates to a small box at that wheel.
      let mx = 0;
      let my = 0;
      let mz = 0;
      for (const w of ws) {
        mx += w.x;
        my += w.y;
        mz += w.z;
      }
      mx /= ws.length;
      my /= ws.length;
      mz /= ws.length;
      let hx = 0.16;
      let hz = 0.16;
      for (const w of ws) {
        hx = Math.max(hx, Math.abs(w.x - mx) + 0.16);
        hz = Math.max(hz, Math.abs(w.z - mz) + 0.16);
      }
      ps.emitter.set(mx, my + 0.08, mz);
      ps.minEmitBox.set(-hx, -0.03, -hz);
      ps.maxEmitBox.set(hx, 0.05, hz);
      // Thrown backwards off the tread, slightly outward and up.
      ps.direction1.set(-fx * 1.3 * k - 0.45, 1.5 * k, -fz * 1.3 * k - 0.45);
      ps.direction2.set(-fx * 1.3 * k + 0.45, 2.5 * k, -fz * 1.3 * k + 0.45);
    }
  }

  /** Decay every emitter to zero (parked, airborne, or no ground contact). */
  idle(dt) {
    const ease = Math.min(1, 7 * dt);
    for (let look = 0; look < LOOK_COUNT; look++) {
      this.rates[look] += (0 - this.rates[look]) * ease;
      const ps = this.systems[look];
      if (ps.emitRate > 0 && this.rates[look] < 0.5) ps.emitRate = 0;
    }
  }

  dispose() {
    for (const ps of this.systems) {
      try {
        ps.stop();
        ps.particleTexture?.dispose();
        ps.dispose();
      } catch { /* noop */ }
    }
    this.systems = [];
  }
}
