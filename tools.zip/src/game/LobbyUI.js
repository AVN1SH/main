/**
 * Main Game Lobby UI Controller.
 *
 * Provides a high-end arcade racing lobby featuring:
 * - Electric Blue / Neon Cyan aesthetic.
 * - Top navigation bar: « HOME | GARAGE | SETTINGS » with sliding glow indicator.
 * - Home screen: 2-card slanted racing carousel matching the reference layout
 *   (Left: Quick Race / Play card; Right: Monochrome Head to Head card).
 * - Garage screen integration: seamless access to the 3D car showroom.
 * - Settings screen: audio, visual, and gameplay toggles + TODO notice for upcoming features.
 */

import { soundManager } from "./soundManager.js";

export class LobbyUI {
  constructor({
    onPlay = null,
    onOpenGarage = null,
    onCloseGarage = null,
    onSfxChange = null,
    onMusicChange = null,
    garageUI = null,
  } = {}) {
    this.onPlay = onPlay;
    this.onOpenGarage = onOpenGarage;
    this.onCloseGarage = onCloseGarage;
    this.onSfxChange = onSfxChange;
    this.onMusicChange = onMusicChange;
    this.garageUI = garageUI;

    this.screenEl = document.getElementById("lobby-screen");
    this.tabButtons = Array.from(document.querySelectorAll(".lobby__tab"));
    this.panels = {
      home: document.getElementById("lobby-panel-home"),
      garage: document.getElementById("lobby-panel-garage"),
      settings: document.getElementById("lobby-panel-settings"),
    };
    this.tabOrder = ["home", "garage", "settings"];
    this.activeTab = "home";
    this.opened = false;

    this._bindEvents();
    this._initSettings();
  }

  /** Wire up interactive clicks, navigation chevrons, and keyboard shortcuts. */
  _bindEvents() {
    // Tab buttons
    this.tabButtons.forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const tab = btn.dataset.tab;
        if (tab) this.setTab(tab);
      });
    });

    // Arrow chevrons
    document.getElementById("lobby-nav-prev")?.addEventListener("click", () => this.prevTab());
    document.getElementById("lobby-nav-next")?.addEventListener("click", () => this.nextTab());

    // Play button on the portrait card
    const playBtn = document.getElementById("lobby-play-btn");
    playBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.close();
    });

    // Whole portrait card click launches the race
    const playCard = document.getElementById("lobby-card-play");
    playCard?.addEventListener("click", (e) => {
      // Avoid double-firing if play button itself was clicked
      if (e.target.closest("#lobby-play-btn")) return;
      this.close();
    });

    // Garage Launcher Button inside Lobby
    document.getElementById("lobby-open-garage-btn")?.addEventListener("click", () => {
      this.setTab("garage");
    });

    // Keyboard navigation while in lobby
    window.addEventListener("keydown", (e) => {
      // If garage showroom overlay is open, let garage controller handle inputs
      if (document.getElementById("garage-screen")?.classList.contains("is-visible")) {
        return;
      }

      if (!this.opened) {
        // Pressing Escape while in-game opens the lobby
        if (e.code === "Escape") {
          e.preventDefault();
          this.open("home");
        }
        return;
      }

      if (e.code === "ArrowLeft") {
        e.preventDefault();
        this.prevTab();
      } else if (e.code === "ArrowRight") {
        e.preventDefault();
        this.nextTab();
      } else if (e.code === "Enter" || e.code === "Space") {
        if (this.activeTab === "home") {
          e.preventDefault();
          this.close();
        }
      } else if (e.code === "Escape") {
        e.preventDefault();
        this.close();
      }
    });
  }

  /** Initialize default settings state and live toggles. */
  _initSettings() {
    this.settings = {
      sfx: true,
      music: true,
      quality: "HIGH",
    };

    // Sound effects on/off
    const sfxToggle = document.getElementById("lobby-set-sfx");
    sfxToggle?.addEventListener("click", () => {
      this.settings.sfx = !this.settings.sfx;
      sfxToggle.classList.toggle("is-active", this.settings.sfx);
      sfxToggle.textContent = this.settings.sfx ? "ON" : "OFF";
      try {
        this.onSfxChange?.(this.settings.sfx);
      } catch {
        /* settings must never break the lobby */
      }
    });

    // Music on/off
    const musicToggle = document.getElementById("lobby-set-music");
    musicToggle?.addEventListener("click", () => {
      this.settings.music = !this.settings.music;
      musicToggle.classList.toggle("is-active", this.settings.music);
      musicToggle.textContent = this.settings.music ? "ON" : "OFF";
      try {
        this.onMusicChange?.(this.settings.music);
      } catch {
        /* settings must never break the lobby */
      }
    });

    // Rendering quality buttons
    const qualBtns = Array.from(document.querySelectorAll(".lobby-set-btn--qual"));
    qualBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        qualBtns.forEach((b) => b.classList.remove("is-active"));
        btn.classList.add("is-active");
        this.settings.quality = btn.dataset.val || "HIGH";
      });
    });

    // Reset settings button
    document.getElementById("lobby-set-reset")?.addEventListener("click", () => {
      this.settings.sfx = true;
      this.settings.music = true;
      this.settings.quality = "HIGH";
      if (sfxToggle) {
        sfxToggle.classList.add("is-active");
        sfxToggle.textContent = "ON";
      }
      if (musicToggle) {
        musicToggle.classList.add("is-active");
        musicToggle.textContent = "ON";
      }
      qualBtns.forEach((b) => b.classList.toggle("is-active", b.dataset.val === "HIGH"));
      try {
        this.onSfxChange?.(true);
      } catch {
        /* settings must never break the lobby */
      }
      try {
        this.onMusicChange?.(true);
      } catch {
        /* settings must never break the lobby */
      }
    });
  }

  /** Whether the lobby overlay is currently visible. */
  isOpen() {
    return this.opened;
  }

  /** Open the lobby overlay. */
  open(initialTab = "home") {
    if (this.opened && this.activeTab === initialTab) return;
    this.opened = true;
    this.screenEl?.classList.add("is-visible");
    this.screenEl?.setAttribute("aria-hidden", "false");

    // Hide minimap while inside lobby
    const minimap = document.getElementById("minimap");
    if (minimap) minimap.style.display = "none";

    this.setTab(initialTab);
  }

  /** Close the lobby overlay and launch into the drive. */
  close() {
    if (!this.opened) return;
    this.opened = false;

    // Clean up garage showroom if open
    if (this.activeTab === "garage") {
      this.garageUI?.close?.();
      this.onCloseGarage?.();
    }

    this.screenEl?.classList.remove("is-visible");
    this.screenEl?.setAttribute("aria-hidden", "true");

    // Reveal minimap when returning to driving
    const minimap = document.getElementById("minimap");
    if (minimap) minimap.style.display = "";

    this.onPlay?.();
  }

  /** Switch active lobby tab ('home' | 'garage' | 'settings'). */
  setTab(tab) {
    if (!this.tabOrder.includes(tab)) return;
    const prevTab = this.activeTab;
    // Race direction from tab order: forward (home -> garage -> settings)
    // slides in from the right, backward from the left. Same-tab re-selects
    // default to forward so they still get the racing entry.
    const dir = Math.sign(this.tabOrder.indexOf(tab) - this.tabOrder.indexOf(prevTab)) || 1;
    this.activeTab = tab;
    // Garage tab renders the bare showroom below the navbar;
    // the lobby's own panel area steps aside for it.
    this.screenEl?.classList.toggle("is-garage-tab", tab === "garage");

    // Update tab header buttons
    this.tabButtons.forEach((btn) => {
      const active = btn.dataset.tab === tab;
      btn.classList.toggle("is-active", active);
      btn.setAttribute("aria-selected", active ? "true" : "false");
    });

    // Update tab panels with a racing slide-in from the travel direction,
    // plus a speed-streak sweep across the whole screen — panels, navbar
    // and all (see lobby.css). The sweep lives on #lobby-screen so no region
    // sits the effect out.
    const screen = this.screenEl;
    if (screen) {
      screen.dataset.dir = dir >= 0 ? "fwd" : "back";
      // Restart the one-shot sweep even under rapid switching.
      screen.classList.remove("is-switching");
      void screen.offsetWidth;
      screen.classList.add("is-switching");
      window.clearTimeout(this._switchTimer);
      this._switchTimer = window.setTimeout(() => screen.classList.remove("is-switching"), 450);
    }
    Object.entries(this.panels).forEach(([name, panel]) => {
      if (!panel) return;
      const active = name === tab;
      panel.classList.toggle("is-active", active);
      panel.classList.toggle("from-fwd", active && dir >= 0);
      panel.classList.toggle("from-back", active && dir < 0);
      panel.setAttribute("aria-hidden", active ? "false" : "true");
    });
    // Racing swish over the global button click for every switch (keyboard
    // chevrons get no click sound, so this is their feedback too). Guarded:
    // pre-gesture calls stay silent instead of throwing.
    try {
      soundManager.playWhoosh("small");
    } catch {
      /* audio must never break tab switching */
    }

    // Handle Garage view lifecycle
    if (tab === "garage") {
      this.onOpenGarage?.();
      if (this.garageUI) {
        // Same showroom module as in-game, but launched bare (no header)
        this.garageUI.open({ header: false });
        this.garageUI.reveal();
      }
    } else if (prevTab === "garage") {
      this.garageUI?.close?.();
      this.onCloseGarage?.();
    }
  }

  /** Advance to next tab. */
  nextTab() {
    const idx = this.tabOrder.indexOf(this.activeTab);
    const next = this.tabOrder[(idx + 1) % this.tabOrder.length];
    this.setTab(next);
  }

  /** Regress to previous tab. */
  prevTab() {
    const idx = this.tabOrder.indexOf(this.activeTab);
    const prev = this.tabOrder[(idx - 1 + this.tabOrder.length) % this.tabOrder.length];
    this.setTab(prev);
  }
}
