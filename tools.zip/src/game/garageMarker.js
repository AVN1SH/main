import { Color3, DynamicTexture, MeshBuilder, StandardMaterial, TransformNode } from "@babylonjs/core";

/**
 * 3D garage marker: a small detailed totem spinning slowly on a base disc.
 * Reads from every direction, sits entirely on the baked surface it was
 * captured at.
 *
 * Pure decoration: not pickable, never baked into collision (built after
 * the bake), ignored by traffic/AI/probes.
 */

const SPIN_RATE = 0.55; // rad/s, slow collectible turntable
const HIDE_R = 4.5; // touch distance: shrink + sink below this (XZ metres)
const SHOW_R = 7; // reappear past this (hysteresis band: no flicker)
const SHRINK_RATE = 2.2; // visibility units per second (smooth ~0.8 s trips)
const SINK_DEPTH = 1.4; // metres sunk at fully hidden

export function createGarageMarker(scene, collision, { x, z } = {}) {
  let groundY = 0;
  try {
    const g = collision?.groundAt?.(x, z, 30, { stepUp: 5, reach: 40 });
    if (g && g.y !== null && g.y !== undefined) groundY = g.y;
  } catch {
    /* keep the fallback height */
  }

  const meshes = [];
  const mats = [];
  const mat = (name, setup) => {
    const m = new StandardMaterial(name, scene);
    setup(m);
    mats.push(m);
    return m;
  };
  const cream = mat("garage_marker_cream", (m) => {
    m.diffuseColor = new Color3(0.92, 0.88, 0.8);
  });
  const dark = mat("garage_marker_dark", (m) => {
    m.diffuseColor = new Color3(0.16, 0.17, 0.2);
  });
  const glow = mat("garage_marker_glow", (m) => {
    m.emissiveColor = new Color3(1.0, 0.55, 0.1);
    m.diffuseColor = Color3.Black();
    m.specularColor = Color3.Black();
    m.disableLighting = true;
  });
  const glass = mat("garage_marker_glass", (m) => {
    m.emissiveColor = new Color3(0.55, 0.8, 0.95);
    m.diffuseColor = Color3.Black();
    m.specularColor = Color3.Black();
    m.disableLighting = true;
  });

  const spinner = new TransformNode("garage_marker_spin", scene);
  spinner.position.set(x, groundY, z);

  // Base disc the totem stands on. Parented under the spinner (local pose)
  // so the whole marker - base included - shrinks and sinks as one. Never
  // frozen: it must follow its parent. (A frozen matrix would ignore the
  // parent and strand it mid-air while everything else hides.)
  const base = MeshBuilder.CreateCylinder("garage_marker_base", {
    height: 0.2,
    diameter: 2.0,
    tessellation: 24,
  }, scene);
  base.parent = spinner;
  base.position.set(0, 0.1, 0);
  base.material = dark;
  base.isPickable = false;
  meshes.push(base);
  const add = (mesh, material, px, py, pz) => {
    mesh.parent = spinner;
    mesh.position.set(px, py, pz);
    mesh.material = material;
    mesh.isPickable = false;
    meshes.push(mesh);
    return mesh;
  };

  // Foot molding, then the body.
  add(MeshBuilder.CreateBox("garage_marker_mold", { width: 1.7, height: 0.18, depth: 0.85 }, scene),
    dark, 0, 0.29, 0);
  add(MeshBuilder.CreateBox("garage_marker_body", { width: 1.5, height: 1.9, depth: 0.55 }, scene),
    cream, 0, 0.38 + 0.95, 0);

  // Corner pillars dressing the body edges.
  for (const sx of [1, -1]) {
    for (const sz of [1, -1]) {
      add(MeshBuilder.CreateBox("garage_marker_pillar", { width: 0.12, height: 1.9, depth: 0.12 }, scene),
        dark, sx * 0.75, 0.38 + 0.95, sz * 0.275);
    }
  }

  // Glowing shutter doors on both broad faces: dark frame, orange leaf,
  // three slat lines each so they read as roller shutters.
  for (const s of [1, -1]) {
    add(MeshBuilder.CreateBox("garage_marker_frame", { width: 1.24, height: 1.64, depth: 0.05 }, scene),
      dark, 0, 1.2, s * 0.28);
    add(MeshBuilder.CreateBox("garage_marker_door", { width: 1.1, height: 1.5, depth: 0.06 }, scene),
      glow, 0, 1.2, s * 0.3);
    for (let i = 0; i < 3; i++) {
      add(MeshBuilder.CreateBox("garage_marker_slat", { width: 1.1, height: 0.045, depth: 0.02 }, scene),
        dark, 0, 0.82 + i * 0.38, s * 0.34);
    }
  }

  // Narrow-side windows, lit pale blue.
  for (const s of [1, -1]) {
    add(MeshBuilder.CreateBox("garage_marker_window", { width: 0.02, height: 0.42, depth: 0.34 }, scene),
      glass, s * 0.76, 1.55, 0);
  }

  // Roof cap with an orange lip.
  add(MeshBuilder.CreateBox("garage_marker_cap", { width: 1.7, height: 0.2, depth: 0.75 }, scene),
    dark, 0, 0.38 + 1.9 + 0.1, 0);
  add(MeshBuilder.CreateBox("garage_marker_lip", { width: 1.74, height: 0.07, depth: 0.79 }, scene),
    glow, 0, 0.38 + 1.9 + 0.02, 0);

  // Name plates front + back.
  const plateTex = new DynamicTexture("garage_marker_plate_tex", { width: 256, height: 64 }, scene, true);
  plateTex.hasAlpha = true;
  paintPlate(plateTex.getContext(), 256, 64);
  plateTex.update();
  const plateMat = mat("garage_marker_plate_mat", (m) => {
    m.diffuseTexture = plateTex;
    m.emissiveTexture = plateTex;
    m.emissiveColor = new Color3(1, 1, 1);
    m.diffuseColor = new Color3(0, 0, 0);
    m.disableLighting = true;
    // Single-sided on purpose: a back face would read as mirrored text, so
    // reversed faces are culled instead of drawn. Front plate faces +z, the
    // back one is turned PI to face -z, and both sit proud of the doors.
    m.backFaceCulling = true;
  });
  for (const s of [1, -1]) {
    const plate = MeshBuilder.CreatePlane("garage_marker_plate", { width: 1.3, height: 0.32 }, scene);
    plate.parent = spinner;
    plate.position.set(0, 2.02, s * 0.37);
    if (s < 0) plate.rotation.y = Math.PI;
    plate.material = plateMat;
    plate.isPickable = false;
    meshes.push(plate);
  }

  // Proximity state: 1 = fully shown, 0 = sunk away. Eased every frame
  // toward its target, so hiding plays shrink+sink and showing plays the
  // exact reverse (rise+grow). Invisibility comes from near-zero scale plus
  // sinking under the asphalt - the render list is never touched (notably
  // NO setEnabled on the spinner: TransformNode has no such method in this
  // Babylon version, and calling it kills the frame loop).
  let vis = 1;
  let target = 1;

  return {
    mesh: spinner,
    /** True while the player is inside the marker (touching it). */
    inRange() {
      return target === 0;
    },
    update(dt, playerPos) {
      const step = Number.isFinite(dt) && dt > 0 ? Math.min(dt, 0.1) : 1 / 60;
      if (
        playerPos &&
        Number.isFinite(playerPos.x) &&
        Number.isFinite(playerPos.z)
      ) {
        const d = Math.hypot(playerPos.x - x, playerPos.z - z);
        if (d < HIDE_R) target = 0;
        else if (d > SHOW_R) target = 1;
        // Between the radii the last target holds: no flicker on the edge.
      }
      if (vis !== target) {
        const maxStep = SHRINK_RATE * step;
        vis += Math.max(-maxStep, Math.min(maxStep, target - vis));
        if (vis < 0) vis = 0;
        else if (vis > 1) vis = 1;
      }
      const e = vis * vis * (3 - 2 * vis);
      const s = e < 0.0001 ? 0.0001 : e;
      // NOTE: TransformNode exposes `scaling`, not `scale` - anything else
      // throws here and takes the whole frame loop down with it.
      spinner.scaling.x = s;
      spinner.scaling.y = s;
      spinner.scaling.z = s;
      spinner.position.y = groundY - (1 - e) * SINK_DEPTH;
      spinner.rotation.y += SPIN_RATE * step * e;
    },
    dispose() {
      for (const m of meshes) m.dispose(false, false);
      for (const m of mats) m.dispose();
      plateTex.dispose();
      spinner.dispose();
    },
  };
}

function paintPlate(g, W, H) {
  g.clearRect(0, 0, W, H);
  g.fillStyle = "rgba(8,12,16,0.92)";
  g.fillRect(0, 0, W, H);
  g.fillStyle = "#ff8c1a";
  g.fillRect(0, H - 8, W, 8);
  g.fillStyle = "#ffffff";
  g.font = "italic 800 40px Arial, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText("GARAGE", W / 2, H / 2 - 2);
}
