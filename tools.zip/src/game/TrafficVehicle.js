import { CAR, approach, clamp, smoothFactor } from "./driving.js";
import { TerrainFollower, describeVehicle } from "./terrain.js";
import { OBSTACLE_SCAN, SAFETY_GAP, nearestBlocker } from "./vehicleCollision.js";

/** Comfortable deceleration used to plan braking for corners, m/s^2. */
const DECEL = 4.5;
/** Fraction of the grip limit actually used through a corner. */
const CORNER_MARGIN = 0.7;
/** Top reverse speed used while unsticking, m/s. */
const REVERSE_CAP = 3;
/** Cross-track error (m) past which the lane target is re-derived. */
const LOST_OFF_LANE = 4;
/** Search window and step used when re-deriving the lane target, metres. */
const RESYNC_WINDOW = 45;
const RESYNC_STEP = 1.5;
/** Fruitless unsticking attempts before a car is re-seeded onto its lane. */
const WEDGE_LIMIT = 3;
/**
 * Half-window (m) and step (m) for the per-frame anchor glue. Small on
 * purpose: it only stops the anchor drifting off while the car falls behind,
 * it never teleports the car - the wide `RESYNC_WINDOW` still handles that.
 */
const NEAR_WINDOW = 8;
const NEAR_STEP = 0.5;
/** Rate limit for the AI wheel command, full-lock fractions per second. */
const AI_STEER_RATE = 3.0;

/**
 * Distance at which a traffic car is considered "off-screen" relative to the
 * player's camera. Off-screen cars are eligible for invisible recovery: a
 * car that has been knocked off its lane, rotated, or stuck will teleport
 * back onto a valid lane point rather than freeze in place. Doing it only
 * when the player cannot see keeps the world from popping.
 */
const OFFSCREEN_DISTANCE = 130;

/**
 * Time the AI stays paused after a heavy impact, seconds. While `shoveTime`
 * is positive the vehicle coasts under its residual velocity and friction
 * only - no lane-following, no obstacle avoidance. The AI resumes once the
 * shove has decayed and the car has slowed below the resume threshold.
 */
const SHOVE_DECAY_TIME = 2.5;
/** Speed (m/s) below which the AI resumes after a shove, on top of timer. */
const SHOVE_RESUME_SPEED = 2.5;

/**
 * The obstacle scan distance (`OBSTACLE_SCAN`, 22 m) and the gap kept to the
 * car ahead (`SAFETY_GAP`, 4 m) now live in `vehicleCollision.js` so the race
 * AI and the traffic AI brake by exactly the same rule.
 */

/**
 * One AI road user.
 *
 * The traffic model used to be a kinematic tracker on rails: lane points
 * were the position, so any bad point off the road put the car off the
 * road. The current model treats the lane as a TARGET only - motion is
 * swept against the real map collision (so a wall still stops the car),
 * and pure-pursuit steering keeps the car on its lane while it has grip.
 *
 * Behaviour the brief asks for:
 *
 *   - Low-density, naturally spaced spawning (handled by TrafficSystem)
 *   - Stay aligned with the road & follow lane direction (pure-pursuit +
 *     lateral correction term)
 *   - Maintain safe distance to vehicles ahead (obstacle scan with speed-
 *     matched following distance)
 *   - Stop for player and traffic ahead, then resume smoothly (targetSpeed
 *     drops to the blocker's speed + safety gap)
 *   - Do not get stuck on roadside props (TerrainFollower configured with
 *     `ignoreDestructibles` so signs and fences do not wedge AI cars)
 *   - Rigid-body collision with the player (`applyShove` injects an
 *     impulse; `update` integrates it under friction and lets the AI
 *     resume when it has decayed)
 *   - Off-screen recovery (when far from the player, snap back onto the
 *     lane if the car is in an invalid state)
 *   - Map edge / dead-end handling (the lanes themselves are closed loops,
 *     so cars naturally re-enter the loop; the rare non-loop tail is
 *     detected by reaching the path's end and triggers a respawn at the
 *     start of a chosen lane)
 */
export class TrafficVehicle {
  constructor(rig, route, {
    startDistance = 0,
    cruiseSpeed = 12,
    laneOffset = 0,
    collision = null,
    player = null,
  } = {}) {
    this.rig = rig;
    this.route = route;
    this.path = route.path;
    this.distance = startDistance % this.path.length;
    this.cruiseSpeed = cruiseSpeed;
    this.laneOffset = laneOffset;
    this.player = player; // player vehicle (so the AI can see the player)
    this.collided = false;
    this.stuckTime = 0;
    this.idleTime = 0;
    this.wedged = 0;

    // Rigid-body shove state - non-zero while the vehicle is recoiling
    // from an impact. While this is active the AI is paused and the body
    // moves under its own momentum + friction.
    this.shove = { vx: 0, vz: 0, vHeading: 0, time: 0, decay: 1.2 };
    // Whether the car is currently in the "shoved" state (AI paused).
    this.shoved = false;

    // Per-frame throttle on expensive checks - obstacles are scanned
    // every N frames for distant cars, every frame for close ones. Set
    // up in `update` based on distance to the player.
    this._scanEvery = 1;
    this._scanCounter = 0;

    const start = this.path.sample(this.distance);
    this.state = {
      x: start.x,
      y: start.y,
      z: start.z,
      heading: 0,
      speed: cruiseSpeed * 0.5,
    };
    this.steerAngle = 0;
    // Smoothed wheel command (see the steering block in `update`). Without
    // this every lane wiggle became an instant full-lock step - the zigzag.
    this._steerSm = 0;
    this.roll = 0;
    this.pitch = 0;
    this.recover = 0;

    // Build the terrain follower with destructible-bypass so street signs
    // and fences do not wedge the AI against the kerb. The collision cells
    // stay solid for the player, who smashes through them at speed.
    this.terrain = collision
      ? new TerrainFollower(collision, describeTrafficVehicle(rig), 0, {
          ignoreDestructibles: true,
        })
      : null;

    // Face along the lane from the outset, otherwise every car snaps round
    // on the first frame.
    const ahead = this.path.sample(this.distance + 6);
    this.state.heading = Math.atan2(ahead.x - start.x, ahead.z - start.z);

    if (this.terrain) {
      if (this.terrain.blocked(start.x, start.z, this.state.heading)) {
        const spot = this._findClearSpot(this.distance);
        if (spot) {
          this.distance = spot.distance;
          this.state.x = spot.x;
          this.state.y = spot.y;
          this.state.z = spot.z;
          const again = this.path.sample(this.distance + 6);
          this.state.heading = Math.atan2(again.x - spot.x, again.z - spot.z);
        }
      }
      this.terrain.teleport(this.state.y);
      this.terrain.apply(this.rig, this.state.x, this.state.z, this.state.heading);
    } else {
      this.rig.setPosition(start.x, this.state.y, start.z);
    }
    this.rig.setHeading(this.state.heading);
  }

  /**
   * Apply an external impulse to the vehicle - called when the player car
   * crashes into this AI car. The shove is in world-space units, and the
   * vehicle's AI is paused while the shove decays so it coasts naturally
   * instead of fighting the impact with its own throttle.
   *
   * The shove is integrated each frame under linear friction (so it slows
   * to a stop rather than sliding forever) and angular friction (so the
   * spin wobbles out rather than whipping round indefinitely). The
   * vehicle is NOT given physics-explosion behaviour: the speeds are
   * capped, the spin is bounded, and the resulting motion is the brief
   * shove + rotation the design asked for.
   */
  applyShove(vx, vz, yawRate) {
    // Cap the magnitudes so a very fast hit cannot fling the car across
    // the map - the design says "no extreme physics explosions".
    const speed = Math.hypot(vx, vz);
    const MAX_SHOVE = 14; // m/s
    if (speed > MAX_SHOVE) {
      const k = MAX_SHOVE / speed;
      vx *= k;
      vz *= k;
    }
    const MAX_SPIN = 4.5; // rad/s
    if (Math.abs(yawRate) > MAX_SPIN) yawRate = Math.sign(yawRate) * MAX_SPIN;

    // Add to (not replace) any existing shove - a second hit while the
    // first is still decaying stacks, which makes a multi-car pile-up
    // read as a single growing mess instead of a stop-start jitter.
    this.shove.vx += vx;
    this.shove.vz += vz;
    this.shove.vHeading += yawRate;
    this.shove.time = SHOVE_DECAY_TIME;
    this.shoved = true;
    // Cancel any in-progress wedge recovery; the car is now reacting to
    // a real impact, not stuck against a kerb.
    this.recover = 0;
    this.wedged = 0;
    this.stuckTime = 0;
    this.idleTime = 0;
  }

  /**
   * Nearest point along (or across) the lane where the car will fit.
   *
   * The height tested has to come from the surface at the candidate point,
   * not from the follower's current height: the follower is still sitting
   * at the height of wherever the car was, so reusing it tests the car
   * against the wrong slice of the world and picks a spot that only looks
   * clear.
   */
  _findClearSpot(fromDistance) {
    for (let ahead = 2; ahead <= 80; ahead += 2) {
      for (const across of [0, -2, 2, -4, 4]) {
        const d = fromDistance + ahead;
        const p = this.path.sample(d);
        const f = this.path.sample(d + 2);
        const heading = Math.atan2(f.x - p.x, f.z - p.z);
        const x = p.x + Math.cos(heading) * across;
        const z = p.z - Math.sin(heading) * across;
        const hit = this.terrain.collision.groundAt(x, z, p.y, { stepUp: 2, reach: 6 });
        if (hit.kind !== "ground") continue;
        this.terrain.teleport(hit.y);
        if (!this.terrain.blocked(x, z, heading)) return { distance: d, x, y: hit.y, z };
      }
    }
    return null;
  }

  /**
   * Put a hopelessly wedged car back on its lane, a little way behind where
   * it gave up so it has room to set off again. Real traffic AI does the
   * same thing: a car that cannot free itself is re-seeded onto its route
   * rather than left to occupy the road indefinitely.
   */
  _returnToLane() {
    for (let back = 4; back <= 48; back += 2) {
      const d = this.distance - back;
      const p = this.path.sample(d);
      const f = this.path.sample(d + 2);
      const heading = Math.atan2(f.x - p.x, f.z - p.z);
      const hit = this.terrain.collision.groundAt(p.x, p.z, p.y, { stepUp: 2, reach: 6 });
      if (hit.kind !== "ground") continue;
      this.terrain.teleport(hit.y);
      if (this.terrain.blocked(p.x, p.z, heading)) continue;
      this._snapToPose(d, p.x, hit.y, p.z, heading);
      return true;
    }
    return false;
  }

  /**
   * Re-seed this car further along its own lane. Used to clear a race grid of
   * parked traffic: the car keeps its route and direction, it just appears a
   * little way up the road instead of on the grid.
   */
  relocateAhead(distance = 90) {
    const d = this.distance + distance;
    const p = this.path.sample(this.path.open ? Math.min(d, this.path.length) : d);
    const f = this.path.sample(this.path.open ? Math.min(d + 2, this.path.length) : d + 2);
    const heading = Math.atan2(f.x - p.x, f.z - p.z);
    const hit = this.terrain?.collision.groundAt(p.x, p.z, p.y, { stepUp: 2, reach: 6 });
    const y = hit?.kind === "ground" ? hit.y : p.y;
    this._snapToPose(d, p.x, y, p.z, heading);
    return true;
  }

  /** Teleport the car to a pose, killing all velocity and AI state. */
  _snapToPose(distance, x, y, z, heading) {
    const wrapped = ((distance % this.path.length) + this.path.length) % this.path.length;
    this.distance = wrapped;
    this.state.x = x;
    this.state.y = y;
    this.state.z = z;
    this.state.heading = heading;
    this.state.speed = 0;
    this.stuckTime = 0;
    this.idleTime = 0;
    this.wedged = 0;
    this.recover = 0;
    // Kill any residual shove so the resumed AI starts clean.
    this.shove.vx = 0;
    this.shove.vz = 0;
    this.shove.vHeading = 0;
    this.shove.time = 0;
    this.shoved = false;
    if (this.terrain) {
      this.terrain.teleport(y);
      this.terrain.apply(this.rig, x, z, heading);
    }
    this.rig.setPosition(x, y, z);
    this.rig.setHeading(heading);
  }

  /**
   * Off-screen recovery: when the player is far enough away that they
   * cannot see this car, any invalid state (off-lane, spun round, stuck,
   * out of bounds, post-shove residue) is healed by snapping the car
   * back onto a clean lane point ahead of where it currently sits.
   *
   * Returning `true` from this means the caller should skip the rest of
   * the frame's update - the car has been teleported, the AI will pick
   * up from the new pose next frame.
   */
  _maybeRecoverOffscreen(playerPos) {
    if (!playerPos) return false;
    const dx = this.state.x - playerPos.x;
    const dz = this.state.z - playerPos.z;
    const distSq = dx * dx + dz * dz;
    if (distSq < OFFSCREEN_DISTANCE * OFFSCREEN_DISTANCE) return false;

    // Conditions that warrant a recovery snap:
    //   - heading badly off the lane direction (knocked sideways or round)
    //   - far from the lane centre line (shoved off the road)
    //   - out of bounds (e.g. flung across the map by an extreme hit)
    //   - stuck for a long time despite recovery attempts
    //   - shoved state lasting longer than the timer (residue)
    const here = this.path.sample(this.distance);
    const lateral = Math.hypot(here.x - this.state.x, here.z - this.state.z);
    const laneHeading = this._laneHeading(this.distance);
    let headingDiff = laneHeading - this.state.heading;
    while (headingDiff > Math.PI) headingDiff -= Math.PI * 2;
    while (headingDiff < -Math.PI) headingDiff += Math.PI * 2;
    const badHeading = Math.abs(headingDiff) > Math.PI * 0.5;
    const offLane = lateral > 4.5;
    const outOfBounds = !Number.isFinite(this.state.x) ||
      !Number.isFinite(this.state.z) ||
      Math.abs(this.state.x) > 2000 || Math.abs(this.state.z) > 2000;
    const stuckLong = this.stuckTime > 6 || this.idleTime > 8;
    const shoveResidue = this.shoved && this.shove.time <= 0;

    if (!(badHeading || offLane || outOfBounds || stuckLong || shoveResidue)) return false;

    // Re-derive the nearest lane point to snap back onto, scanning both
    // directions along the lane.
    let best = this.distance;
    let bestSq = Infinity;
    for (let d = -60; d <= 60; d += 2) {
      const p = this.path.sample(this.distance + d);
      const sq = (p.x - this.state.x) ** 2 + (p.z - this.state.z) ** 2;
      if (sq < bestSq) {
        bestSq = sq;
        best = this.distance + d;
      }
    }
    const p = this.path.sample(best);
    const f = this.path.sample(best + 2);
    const heading = Math.atan2(f.x - p.x, f.z - p.z);
    const hit = this.terrain?.collision.groundAt(p.x, p.z, p.y, { stepUp: 2, reach: 6 });
    const y = hit?.kind === "ground" ? hit.y : p.y;
    this._snapToPose(best, p.x, y, p.z, heading);
    return true;
  }

  /**
   * Respawn the car at the beginning of a lane. Used by the TrafficSystem
   * when a car reaches the end of a non-loop route (the lanes here are
   * closed loops, but a long-tail lane could in principle end; the system
   * also uses this for the very first spawn).
   */
  respawnAtStart() {
    this._snapToPose(0, this.path.points[0].x, this.path.points[0].y, this.path.points[0].z, this._laneHeading(0));
  }

  update(dt, traffic = null, playerPos = null) {
    // --- off-screen recovery ----------------------------------------------
    // Done first so a wedged/spun car heals at the top of the frame and
    // the rest of the update runs against a clean pose.
    if (this._maybeRecoverOffscreen(playerPos)) {
      return;
    }

    // --- rigid-body shove integration ------------------------------------
    // While the car is reacting to a player impact the AI is paused: the
    // body coasts under its residual velocity + friction, then the AI
    // resumes once the shove has decayed enough.
    if (this.shove.time > 0) {
      this.shove.time -= dt;
      // Integrate the shove velocity into position. Friction is exponential
      // so the car rolls to a stop rather than jerking to a halt.
      const friction = Math.exp(-this.shove.decay * dt);
      const prevX = this.state.x;
      const prevZ = this.state.z;
      this.state.x += this.shove.vx * dt;
      this.state.z += this.shove.vz * dt;
      this.state.heading += this.shove.vHeading * dt;
      this.shove.vx *= friction;
      this.shove.vz *= friction;
      this.shove.vHeading *= friction;
      // Wrap heading into [-pi, pi] for sanity.
      let h = this.state.heading;
      while (h > Math.PI) h -= Math.PI * 2;
      while (h < -Math.PI) h += Math.PI * 2;
      this.state.heading = h;

      // Swept collision so a shoved car does not pass through a wall -
      // the same logic the AI uses below, kept compact here so the
      // reaction is still physically believable without re-entering
      // the AI's planning.
      if (this.terrain) {
        const res = this.terrain.sweep(prevX, prevZ, this.state.x, this.state.z, this.state.heading);
        if (res.blocked) {
          // Pushed into a wall - kill the velocity along that axis and
          // accept the slide (or stop if even the slide is blocked).
          this.state.x = res.x;
          this.state.z = res.z;
          this.shove.vx *= 0.3;
          this.shove.vz *= 0.3;
        }
        this.terrain.follow(dt, this.state.x, this.state.z, this.state.heading);
        this.state.y = this.terrain.y;
      }
      this.rig.setPosition(this.state.x, this.state.y, this.state.z);
      this.rig.setHeading(this.state.heading);
      this.rig.setGroundTilt(this.terrain?.pitch ?? 0, this.terrain?.roll ?? 0);

      // Resume AI when the shove is small enough AND time has decayed, or
      // when the spin has slowed enough that continuing to coast looks
      // unrealistic. Either gate is enough - the design asks for "AI
      // resumes after the collision when appropriate".
      const shoveSpeed = Math.hypot(this.shove.vx, this.shove.vz);
      const shoveSpin = Math.abs(this.shove.vHeading);
      if ((this.shove.time <= 0 && shoveSpeed < SHOVE_RESUME_SPEED && shoveSpin < 0.5) ||
          (this.shove.time <= -1.5)) {
        // Hand control back to the AI. The lane target will re-sync to
        // wherever the car actually is, so a shoved car that landed
        // sideways on its lane does not need to teleport back.
        this.shoved = false;
        this.shove.vx = 0;
        this.shove.vz = 0;
        this.shove.vHeading = 0;
        this.state.speed = Math.max(0, this.state.speed * 0.3); // gentle re-entry
        this._resync();
      }
      return;
    }

    // The shove flag can stay true with zero time when the car was hit
    // hard enough to lock the resume gate. Reset it once we're here.
    if (this.shoved) this.shoved = false;

    // --- normal AI update ------------------------------------------------
    const path = this.path;

    // Throttle the obstacle scan for distant cars. Each car keeps a
    // private counter; when it ticks over, the scan runs.
    this._scanCounter++;
    const scanThisFrame = this._scanCounter >= this._scanEvery;
    if (scanThisFrame) this._scanCounter = 0;

    // --- target point on the lane ---------------------------------------
    // `this.distance` was re-glued to the lane at the end of last frame, so
    // the anchor cannot have run away while the car fell behind.
    const speed = Math.abs(this.state.speed);
    // Speed-proportional preview: ~0.8 s of travel. The old 3.5-7 m window
    // was ~0.4 s at cruise, so the car reacted to each lane wiggle instead
    // of averaging over it - the other half of the zigzag.
    const lookAhead = clamp(4 + speed * 0.45, 5, 12);
    const target = path.sample(this.distance + lookAhead);

    // --- steering: pure pursuit toward the lane + lateral correction ---
    const here = path.sample(this.distance);
    const dxh = here.x - this.state.x;
    const dzh = here.z - this.state.z;
    const lateral = dxh * Math.cos(this.state.heading) - dzh * Math.sin(this.state.heading);
    const desired = Math.atan2(target.x - this.state.x, target.z - this.state.z);
    let diff = desired - this.state.heading;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    // Gentle gains: a 0.3 m lane wiggle at full look-ahead is a ~2 deg angle
    // error, which deserves a nudge, not the old full-lock swerve.
    let steer = clamp(-diff * 1.4 - lateral * 0.25, -1, 1);

    // --- speed: corners, obstacles ahead, and box-in recovery -----------
    let targetSpeed = this._cornerSpeedLimit();
    const cornerFactor = 1 - clamp(Math.abs(diff) / Math.PI, 0, 1) * 0.4;
    targetSpeed *= cornerFactor;

    // Always check for the player; only the traffic-vs-traffic scan is
    // throttled. The player cutting in front must be seen on the frame it
    // happens, not up to three frames later.
    const blocker = this._obstacleAhead(traffic, scanThisFrame);
    if (blocker) {
      // `closing` is the blocker's speed ALONG our forward axis: positive for
      // a car we are catching up to or following, negative for an oncoming
      // one. Using the blocker's raw speed made an approaching car read as
      // "moving away", so the AI sped up into a head-on. Matching the closing
      // component instead drops the target to zero as the gap closes.
      //
      // The gap is BUMPER-TO-BUMPER (both half-lengths removed), not centre to
      // centre. Centre-to-centre, a 4 m "gap" is already metal-to-metal on two
      // 4 m cars, so the AI only asked for zero speed once it was touching the
      // thing it was supposed to stop for.
      const safeSpeed = blocker.closing + (blocker.gap - SAFETY_GAP) * 0.6;
      targetSpeed = Math.min(targetSpeed, Math.max(0, safeSpeed));
    }

    targetSpeed = Math.max(targetSpeed, 0);

    // --- stuck recovery -------------------------------------------------
    if ((this.stuckTime > 1.6 || this.idleTime > 2.5) && this.recover <= 0) {
      this.wedged += 1;
      if (this.wedged >= WEDGE_LIMIT) {
        this._returnToLane();
        this.wedged = 0;
        this.recover = 0;
      } else {
        this.recover = 1.2;
      }
    }
    let recovering = false;
    if (this.recover > 0) {
      this.recover -= dt;
      recovering = true;
      steer = clamp(-steer, -1, 1);
    }

    // Rate-limit the wheel command, exactly like the player's steering rate:
    // an instant step to full lock is what turned every lane wiggle and every
    // correction into a visible swerve. 3 full-lock sweeps per second still
    // leaves ample authority for real corners (see the yaw grip cap below).
    this._steerSm = approach(this._steerSm, steer, AI_STEER_RATE * dt);
    steer = this._steerSm;

    let input;
    if (recovering) {
      input = { steer, throttle: 0, brake: 1, handbrake: false };
    } else if (this.state.speed <= 0.2 && targetSpeed < 0.5) {
      input = { steer, throttle: 0, brake: 0, handbrake: false }; // hold
    } else {
      // Drive to the TARGET SPEED, not to a throttle figure with a floor. The
      // old `clamp(targetSpeed / 8, 0.2, 1)` kept at least 20% throttle on even
      // when the obstacle rule asked for a full stop, so the brake and the
      // throttle cancelled and a car "slowed down but never stopped", creeping
      // into whatever was in front of it. Below target we feed throttle; above
      // it we brake, so target zero is a genuine stop.
      const err = this.state.speed - targetSpeed;
      input = {
        steer,
        throttle: err < 0 ? clamp(-err / 4, 0, 1) : 0,
        brake: err > 0.3 ? clamp(err / 4, 0, 1) : 0,
        handbrake: false,
      };
    }

    const prevX = this.state.x;
    const prevZ = this.state.z;
    const speedBefore = this.state.speed;
    const yawRate = stepTraffic(this.state, dt, input, targetSpeed);
    const accel = (this.state.speed - speedBefore) / Math.max(dt, 1e-4);

    if (recovering && this.state.speed < -REVERSE_CAP) this.state.speed = -REVERSE_CAP;

    // --- collision: sweep the wanted motion, sliding along walls ------
    let moved = 0;
    let progress = 0;
    if (this.terrain) {
      const res = this.terrain.sweep(prevX, prevZ, this.state.x, this.state.z, this.state.heading);
      if (res.escaped) {
        this.collided = true;
        this.state.x = res.x;
        this.state.z = res.z;
        this.state.speed *= 0.5;
      } else if (res.blocked) {
        this.collided = true;
        const slideX = this.terrain.sweep(prevX, prevZ, this.state.x, prevZ, this.state.heading);
        const slideZ = this.terrain.sweep(prevX, prevZ, prevX, this.state.z, this.state.heading);
        const dx = Math.abs(slideX.x - prevX);
        const dz = Math.abs(slideZ.z - prevZ);
        if (!slideX.blocked && dx >= dz) {
          this.state.x = slideX.x;
          this.state.z = prevZ;
        } else if (!slideZ.blocked) {
          this.state.x = prevX;
          this.state.z = slideZ.z;
        } else {
          this.state.x = res.x;
          this.state.z = res.z;
          this.state.speed = 0;
        }
        if (this.state.speed !== 0) this.state.speed *= 0.7;
      } else {
        this.collided = false;
        this.state.x = res.x;
        this.state.z = res.z;
      }

      // --- surface following: height, pitch, roll, suspension ----------
      this.terrain.follow(dt, this.state.x, this.state.z, this.state.heading);
      this.state.y = this.terrain.y;

      const dx = this.state.x - prevX;
      const dz = this.state.z - prevZ;
      moved = Math.hypot(dx, dz);
      progress = dx * Math.sin(this.state.heading) + dz * Math.cos(this.state.heading);

      // --- stuck / boxed-in detection ----------------------------------
      const wanted = Math.max(targetSpeed, this.state.speed) * dt;
      if (wanted > 0.05 && moved < wanted * 0.35) {
        this.stuckTime += dt;
      } else {
        this.stuckTime = Math.max(0, this.stuckTime - dt * 2);
      }
      if (moved < 0.01 && targetSpeed > 1) this.idleTime += dt;
      else this.idleTime = Math.max(0, this.idleTime - dt * 2);
    }

    // --- lane bookkeeping ---------------------------------------------
    if (path.open) {
      // Open (recycling) route: the car drives to the end and is recycled to
      // the start. This is what lets a route that cannot close geometrically -
      // a one-way bridge crossing, an open-ended highway - still run a cycle.
      this.distance += progress;
      if (this.distance >= path.length) {
        this.respawnAtStart();
        return;
      }
      if (this.distance < 0) this.distance = 0;
    } else {
      this.distance = (this.distance + progress) % path.length;
    }

    // Re-glue the anchor to the closest lane point in a tight window: with
    // blind `distance += progress` the anchor ran away at full speed whenever
    // the car fell behind (slow corner, shove, reverse), and the car then cut
    // across to chase it. The wide `_resync` below still handles truly lost
    // cars; this just stops the drift that caused mid-road swerves.
    this.distance = this._nearAnchor(this.distance);

    if (Math.abs(lateral) > LOST_OFF_LANE || this.stuckTime > 1.2) this._resync();

    // --- presentation -------------------------------------------------
    const denom = Math.max(Math.abs(this.state.speed), 0.4) / CAR.wheelBase;
    const visSteer = clamp(-Math.atan(yawRate / denom), -CAR.maxSteer, CAR.maxSteer);
    this.steerAngle = approach(this.steerAngle, visSteer, CAR.steerRate * dt);

    const lateralAccel = this.state.speed * yawRate;
    this.roll += (clamp(-lateralAccel * 0.012, -0.07, 0.07) - this.roll) * smoothFactor(5, dt);
    this.pitch += (clamp(accel * 0.002, -0.03, 0.03) - this.pitch) * smoothFactor(4, dt);

    this.rig.setPosition(this.state.x, this.state.y, this.state.z);
    this.rig.setHeading(this.state.heading);
    if (this.rig.setSteer) this.rig.setSteer(this.steerAngle);
    if (this.rig.setTilt) this.rig.setTilt(this.roll, this.pitch);
    if (this.rig.setGroundTilt && this.terrain) {
      this.rig.setGroundTilt(this.terrain.pitch, this.terrain.roll);
    }
    if (this.rig.spinWheels) this.rig.spinWheels(this.state.speed * dt);
  }

  /**
   * Fastest speed the lane allows over the next stretch of road.
   *
   * Walks the lane ahead and, for every corner within braking distance,
   * works out both the speed the corner can physically be taken at (tyre
   * grip limit for the corner's radius) and whether there is room to shed
   * speed before reaching it. Taking the tightest of those gives a proper
   * velocity profile, so the car slows BEFORE the bend rather than once
   * it is already in it.
   */
  _cornerSpeedLimit() {
    const path = this.path;
    const step = 4;
    const scan = Math.min(path.length * 0.5, 8 + Math.abs(this.state.speed) * 3);
    let limit = this.cruiseSpeed;

    let prev = this._laneHeading(this.distance);
    for (let d = step; d <= scan; d += step) {
      const cur = this._laneHeading(this.distance + d);
      let turn = cur - prev;
      while (turn > Math.PI) turn -= Math.PI * 2;
      while (turn < -Math.PI) turn += Math.PI * 2;
      prev = cur;

      const radius = Math.abs(turn) > 1e-4 ? step / Math.abs(turn) : Infinity;
      const cornerSpeed = Math.sqrt(CAR.maxLateralAccel * radius) * CORNER_MARGIN;
      const reach = Math.sqrt(cornerSpeed * cornerSpeed + 2 * DECEL * d);
      limit = Math.min(limit, reach);
    }
    return clamp(limit, 2.5, this.cruiseSpeed);
  }

  /** Direction of travel of the lane centre line `ahead` metres past the car. */
  _laneHeading(ahead) {
    const a = this.path.sample(this.distance + ahead - 1);
    const b = this.path.sample(this.distance + ahead + 1);
    return Math.atan2(b.x - a.x, b.z - a.z);
  }

  /**
   * Closest lane point to the car within a tight window around `d`.
   *
   * Unlike `_resync` (wide window, for lost cars) this runs every frame and
   * only corrects drift: the anchor can move at most the window per frame,
   * so it tracks the car instead of escaping from it. Wrap/clamp matches the
   * route kind exactly like the bookkeeping above.
   */
  _nearAnchor(d) {
    let best = d;
    let bestSq = Infinity;
    for (let o = -NEAR_WINDOW; o <= NEAR_WINDOW; o += NEAR_STEP) {
      const p = this.path.sample(d + o);
      const sq = (p.x - this.state.x) ** 2 + (p.z - this.state.z) ** 2;
      if (sq < bestSq) {
        bestSq = sq;
        best = d + o;
      }
    }
    if (this.path.open) return clamp(best, 0, this.path.length);
    const L = this.path.length;
    return ((best % L) + L) % L;
  }

  /**
   * Re-derive `distance` from the car's ACTUAL position on the lane.
   */
  _resync() {
    let best = this.distance;
    let bestSq = Infinity;
    for (let d = -RESYNC_WINDOW; d <= RESYNC_WINDOW; d += RESYNC_STEP) {
      const p = this.path.sample(this.distance + d);
      const sq = (p.x - this.state.x) ** 2 + (p.z - this.state.z) ** 2;
      if (sq < bestSq) {
        bestSq = sq;
        best = this.distance + d;
      }
    }
    this.distance = ((best % this.path.length) + this.path.length) % this.path.length;
  }

  /**
   * Nearest blocker ahead of this car, combining other traffic vehicles (so AI
   * queues naturally), the race field (while a race is running) and the player
   * car (so AI yields to the player too).
   *
   * The geometry of the test - corridor overlap, the candidate's nose as the
   * reference, the closing speed along our own forward axis - lives in
   * `nearestBlocker` (`vehicleCollision.js`) because the race AI needs exactly
   * the same answer.
   *
   * @param scanTraffic when false only the player (and the race field) are
   *   checked; the caller throttles the traffic-vs-traffic scan for far cars.
   */
  _obstacleAhead(traffic, scanTraffic = true) {
    const candidates = [];
    if (scanTraffic && traffic) {
      for (const other of traffic.vehicles) {
        if (other === this) continue;
        if (other.shoved) continue; // a shoved car is not a clean blocker
        candidates.push(other);
      }
    }
    if (traffic?.extraVehicles) {
      for (const other of traffic.extraVehicles) {
        if (other === this || other.shoved || other.hidden) continue;
        candidates.push(other);
      }
    }
    if (this.player) candidates.push(this.player);
    return nearestBlocker(this, candidates);
  }

  get position() {
    return this.state;
  }
}

/**
 * Build a TerrainFollower geometry descriptor from a TrafficRig.
 *
 * The TrafficRig exposes the same shape VehicleRig does (wheels, wheelBase,
 * track, halfLength, halfWidth, height, clearance), so describeVehicle()
 * would work too - this is a thin alias so callers do not have to know
 * which rig class a car uses.
 */
function describeTrafficVehicle(rig) {
  const wheels = (rig.wheelOffsets ?? []).map((w) => ({
    x: w.x,
    z: w.z,
    radius: w.radius,
    front: w.front ?? (w.z > 0),
  }));
  return {
    wheels,
    wheelBase: rig.wheelBase ?? CAR.wheelBase,
    track: rig.track ?? CAR.width,
    halfLength: rig.halfLength ?? CAR.length / 2,
    halfWidth: rig.halfWidth ?? CAR.width / 2,
    height: rig.height ?? CAR.height,
    clearance: rig.clearance ?? CAR.clearance,
  };
}

/**
 * Longitudinal + yaw integration for a traffic car, mirroring stepVehicle()
 * but with a target speed instead of raw pedal inputs. Keeps AI cars
 * obeying the same speed limits as the player: engine power taper, brake
 * force, and the bicycle-model yaw.
 */
function stepTraffic(state, dt, { steer, throttle, brake }, targetSpeed) {
  const { speed } = state;

  let accel = 0;
  if (throttle > 0) {
    const power = CAR.enginePower * Math.max(0, 1 - Math.abs(speed) / CAR.maxSpeed);
    const headroom = clamp((targetSpeed - Math.abs(speed)) / 3, 0, 1);
    accel += throttle * power * headroom;
  }
  if (brake > 0) {
    if (speed > 0.4) accel -= brake * CAR.brakePower * 0.5;
    else accel -= brake * CAR.reversePower;
  }
  if (throttle === 0 && brake === 0) {
    accel -= Math.sign(speed) * CAR.rollResist;
  }
  accel -= CAR.dragK * speed * Math.abs(speed);

  let next = speed + accel * dt;
  if (throttle === 0 && brake === 0 && Math.sign(next) !== Math.sign(speed)) next = 0;
  state.speed = clamp(next, -CAR.maxReverse, CAR.maxSpeed);

  const steerAngle = steer * CAR.maxSteer;
  // Tire grip cap, mirroring the player's `stepVehicle`: cornering needs
  // v * yawRate of lateral acceleration, and the tyres refuse more than
  // `maxLateralAccel`. Without this a saturated steer command produced
  // 200+ deg/s fishtails at cruise speed - the zigzag. Near standstill the
  // limit is huge, so parking turns are unaffected.
  const desiredYawRate = -(state.speed / CAR.wheelBase) * Math.tan(steerAngle);
  const lateralLimit = CAR.maxLateralAccel / Math.max(Math.abs(state.speed), 1e-3);
  const yawRate = clamp(desiredYawRate, -lateralLimit, lateralLimit);
  state.heading += yawRate * dt;

  const forwardX = Math.sin(state.heading);
  const forwardZ = Math.cos(state.heading);
  state.x += forwardX * state.speed * dt;
  state.z += forwardZ * state.speed * dt;

  return yawRate;
}
