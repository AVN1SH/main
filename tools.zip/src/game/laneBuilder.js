/**
 * Builds traffic lanes from the BAKED collision model rather than from
 * offline data.
 *
 * Why: the offline lane builder (tools/build-routes.mjs) rasterises mesh
 * BOUNDING BOXES, because it cannot decode the map's Draco compression. On the
 * original map that was optimistic; on the current one whole corridors it
 * considers road are actually void or water (a physical raycast there hits
 * nothing drivable), so AI cars drove through empty space and buildings.
 *
 * The baked collision model, by contrast, is triangle-accurate: MapCollision
 * rasterises the real surface triangles and flags which cells are ROADWAY
 * (tarmac, the elevated deck, its ramps, parking). These builders turn that
 * mask into closed lane loops:
 *
 *   1. extract horizontal/vertical road BANDS from the roadway mask,
 *   2. find rectangles where two horizontal and two vertical bands cross,
 *   3. densify each rectangle into a ring, inset toward its centre so traffic
 *      keeps right,
 *   4. validate EVERY point against collision - drivable surface exists, it is
 *      roadway, and the car's footprint is not blocked - repairing points by
 *      shifting them across the road width, and dropping any loop that cannot
 *      be made fully clean,
 *   5. build one dedicated loop that crosses the elevated bridge, pairing the
 *      corridor band with a parallel ground road and two vertical connectors.
 *
 * Because the deck is just more roadway in the same mask, a loop edge that
 * crosses the corridor naturally rides up its ramps: every point's height is
 * read from the bake, and vehicles follow the surface from there.
 */
import { CAR, clamp } from "./driving.js";
import { TerrainFollower } from "./terrain.js";

const S = 2; // metres per band-grid cell
const MIN_RUN_CELLS = 15; // 30 m of continuous roadway makes a band
const LEN_SIMILARITY = 0.6; // row runs merge only if their lengths are similar
const MAX_ROAD_WIDTH = 60;
const MIN_SIDE = 80; // shortest side of a general loop
/**
 * Metres between lane points.
 *
 * Must stay below the car's length. Validation can only prove the lane is
 * drivable at the points it tests, so sampling a 4.3 m car with points 4 m apart
 * leaves its nose and tail reaching into stretches that were never checked -
 * a wall just past a sample point passes validation and the car drives into it.
 */
const DENSIFY = 1;
const LANE_HALF = 1.15; // half a car width plus margin
const LANE_MARGIN = 2.2; // clearance kept either side of the lane, metres
const LANE_MARGIN_RELAXED = 1.2; // floor for awkward loops, metres
/** Best-first: a lane takes the widest margin it can actually achieve. */
const LANE_MARGIN_LADDER = [2.2, 1.7, 1.2];
/** Elevated-loop search: roadway above this height is "up on the structure". */
const ELEV_MIN_Y = 1.8;
/** Shortest side of an elevated loop - the highway's carriageways are ~24 m apart. */
const ELEV_MIN_SIDE = 12;
const ELEV_MAX_SIDE = 70;
/**
 * Slack (m) allowed when a band must reach a corner. A highway connector often
 * stops just short of the carriageway centre it feeds; requiring an exact span
 * rejects a perfectly usable oval by a handful of metres. The lane is validated
 * against real collision afterwards, so a small overshoot cannot create a bad
 * route.
 */
const ELEV_SPAN_TOL = 22;
const FILLET = 12; // corner radius, metres - see buildLaneRing
const MAX_SHIFT = 8; // furthest a point may be nudged across its road, metres
const SHIFT_SMOOTH = 3; // half-width of the shift blur, in lane points

/**
 * Right-hand lane locking (see `lockLaneToRightHand`).
 *
 * The band builder places a loop on the CENTRE LINE of whatever roadway band it
 * found. On a divided road like the `road_b` family - one mesh holding both
 * directions with the median baked into the geometry - the centre line IS the
 * median, so a lane built down it makes every car straddle the divider, and on
 * a divided road it is also the boundary between the two directions. The fix is
 * a post-pass that re-places every lane point in the right-hand carriageway for
 * the direction it is actually travelling, measured from the real road extent.
 *
 * The offset is scaled to the road's own half-width: `width * 0.3` sits in the
 * middle of a carriageway on a divided road (past the median) and in the middle
 * of the near-side lane on an undivided one, instead of hugging the centre.
 */
const RIGHT_LANE_REACH = 16; // furthest the perpendicular probe looks for an edge, m
const RIGHT_LANE_MAX = 8; // cap on the lateral offset, metres
const RIGHT_LANE_SMOOTH = 4; // half-width of the offset blur, in lane points
const RIGHT_LANE_MIN_WIDTH = 5; // corridors narrower than this are left alone

/**
 * Recycled (open) route waypoints, world metres, in travel order.
 *
 * This is the flow the brief asks for, made possible by an OPEN path that
 * recycles end -> start instead of requiring a geometric loop. Every leg was
 * measured from the baked map:
 *
 *   - `road_c_03.019` (highway north, x 346..367 z 326..366) sits on the east
 *     carriageway, which runs unbroken x ~356 from z -76 to 364.
 *   - the z ~75 corridor is a single continuous road from `road_b_22.001`
 *     (x -165) east to the highway (x 366), carrying `road_c_02.004`, the
 *     `bridge_a` deck (x -104..-4), `road_c_02.003` and `road_b_06.003`.
 *   - `road_c_02.002` (x 306..346, z 65..86) is the highway's city ramp.
 *   - `road_c_03.012` (x 367..407, z -76..-55) is the highway's south exit.
 *
 * The cycle: spawn at the highway's north end, drive SOUTH down the east
 * carriageway, leave WEST along the z ~75 corridor across the bridge to
 * `road_b_22.001`, return through the city to the highway's south end, and
 * recycle back to the north end. The bridge is crossed exactly once, in one
 * direction, so no U-turn and no wrong-way leg is ever needed - which is why
 * this works where a closed loop could not.
 *
 * NOTE: these anchors are the proven working corridor - do not move them
 * off-road. Edge alignment / straight-tip / no-U-turn behaviour is handled
 * by post-processing (`lockLaneToRightHand` rescue + `straightenRecycleTips`)
 * so the A* corridor itself always stays valid and highway+bridge traffic
 * keeps flowing.
 */
const RECYCLE_ANCHORS = [
  { x: 356, z: 346 },  // road_c_03.019 - highway north (spawn)
  { x: 356, z: 200 },  // highway carriageway
  { x: 356, z: 80 },   // highway meets the city corridor
  // --- westbound along the corridor, across the bridge (road_b flow) -------
  { x: 320, z: 80 },   // road_c_02.002
  { x: 40, z: 80 },    // road_b_06.003
  { x: -4, z: 80 },    // road_c_02.003
  { x: -60, z: 80 },   // bridge_a deck
  { x: -110, z: 80 },  // road_c_02.004
  { x: -155, z: 80 },  // road_b_22.001
  // --- turnaround at road_b_22.001 (west tip, across the road width) ------
  { x: -160, z: 76 },
  { x: -155, z: 72 },
  // --- eastbound back along the corridor, across the bridge ---------------
  { x: -60, z: 72 },
  { x: 40, z: 72 },
  { x: 320, z: 72 },
  { x: 356, z: 74 },
  // --- south on the highway to the exit -----------------------------------
  { x: 387, z: -65 }, // road_c_03.012 - highway south end (despawn)
];

/** A minimal car geometry so the validator can test footprints. */
function probeGeometry() {
  const halfW = CAR.width / 2 - 0.15;
  const halfL = CAR.wheelBase / 2;
  return {
    wheels: [
      { x: -halfW, z: halfL },
      { x: halfW, z: halfL },
      { x: -halfW, z: -halfL },
      { x: halfW, z: -halfL },
    ],
    wheelBase: CAR.wheelBase,
    track: halfW * 2,
    halfLength: CAR.length / 2,
    halfWidth: CAR.width / 2,
    height: CAR.height,
    clearance: CAR.clearance,
  };
}

/**
 * @param collision a built MapCollision
 * @returns {{ routes: Array<object>, bridgeFound: boolean, stats: object }}
 *   routes: [{ id, points: [{x,y,z}], onRoadRatio, bridge }]
 */
export function buildLaneRoutes(collision) {
  const { minX, minZ, maxX, maxZ } = collision;
  const cols = Math.ceil((maxX - minX) / S);
  const rows = Math.ceil((maxZ - minZ) / S);
  const cellX = (c) => minX + (c + 0.5) * S;
  const cellZ = (r) => minZ + (r + 0.5) * S;
  const maskAt = (x, z) => {
    const c = Math.floor((x - minX) / S);
    const r = Math.floor((z - minZ) / S);
    return c >= 0 && r >= 0 && c < cols && r < rows ? mask[r * cols + c] : 0;
  };

  // --- roadway mask (both ground and deck levels) --------------------------
  const mask = new Uint8Array(cols * rows);
  let maskRoadCells = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (collision.isRoadAt(cellX(c), cellZ(r))) {
        mask[r * cols + c] = 1;
        maskRoadCells++;
      }
    }
  }

  // --- bands ---------------------------------------------------------------
  /** Runs of contiguous roadway per row (or column), merged into bands. */
  function extractBands(isRowPass, src = mask) {
    const runs = [];
    const outer = isRowPass ? rows : cols;
    const inner = isRowPass ? cols : rows;
    for (let o = 0; o < outer; o++) {
      let start = -1;
      for (let i = 0; i <= inner; i++) {
        const on = i < inner && src[isRowPass ? o * cols + i : i * cols + o] === 1;
        if (on && start < 0) start = i;
        if (!on && start >= 0) {
          if (i - start >= MIN_RUN_CELLS) runs.push({ o, start, end: i - 1 });
          start = -1;
        }
      }
    }

    const bands = [];
    for (const run of runs) {
      const len = run.end - run.start + 1;
      const cand = bands.find((b) => {
        if (run.o - b.lastO > 2) return false;
        const otherLen = b.end - b.start + 1;
        const overlap = Math.min(run.end, b.end) - Math.max(run.start, b.start) + 1;
        if (overlap < 0.5 * Math.min(len, otherLen)) return false;
        return Math.min(len, otherLen) / Math.max(len, otherLen) >= LEN_SIMILARITY;
      });
      if (cand) {
        cand.lastO = run.o;
        cand.os.push(run.o);
        cand.start = Math.min(cand.start, run.start);
        cand.end = Math.max(cand.end, run.end);
      } else {
        bands.push({ firstO: run.o, lastO: run.o, os: [run.o], start: run.start, end: run.end });
      }
    }

    return bands.map((b) => {
      const centerO = (Math.min(...b.os) + Math.max(...b.os) + 1) / 2;
      const spanMin = Math.min(...b.os);
      const spanMax = Math.max(...b.os) + 1;
      return {
        axis: isRowPass ? "z" : "x", // 'z' = runs along X at fixed Z
        center: isRowPass ? cellZ(centerO) : cellX(centerO),
        from: isRowPass ? cellX(b.start) : cellZ(b.start),
        to: isRowPass ? cellX(b.end) : cellZ(b.end),
        width: (spanMax - spanMin) * S,
      };
    });
  }

  const hBands = extractBands(true).filter((b) => b.width <= MAX_ROAD_WIDTH);
  const vBands = extractBands(false).filter((b) => b.width <= MAX_ROAD_WIDTH);

  // --- elevated-only roadway mask -----------------------------------------
  // Bands extracted from the full mask merge the highway with the ground roads
  // passing under it, so an elevated band is never cleanly elevated and the
  // highway loop is never found. This mask keeps only cells whose road surface
  // is well above ground, which isolates the viaducts and their connectors.
  const elevMask = new Uint8Array(cols * rows);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c;
      if (!mask[i]) continue;
      const g = collision.groundAt(cellX(c), cellZ(r), 8, { stepUp: 6, reach: 12 });
      if (g.kind === "ground" && g.y > ELEV_MIN_Y) elevMask[i] = 1;
    }
  }
  const elevAt = (x, z) => maskAt(x, z) > 0 && elevMask[
    Math.floor((z - minZ) / S) * cols + Math.floor((x - minX) / S)
  ] === 1;
  const elevHBands = extractBands(true, elevMask).filter((b) => b.width <= MAX_ROAD_WIDTH);
  const elevVBands = extractBands(false, elevMask).filter((b) => b.width <= MAX_ROAD_WIDTH);

  // --- general rectangles --------------------------------------------------
  const loops = [];
  const usedKey = new Set();
  for (let i = 0; i < hBands.length; i++) {
    for (let j = i + 1; j < hBands.length; j++) {
      const hA = hBands[i];
      const hB = hBands[j];
      if (Math.abs(hA.center - hB.center) < MIN_SIDE) continue;
      for (let k = 0; k < vBands.length; k++) {
        for (let l = k + 1; l < vBands.length; l++) {
          const vA = vBands[k];
          const vB = vBands[l];
          if (Math.abs(vA.center - vB.center) < MIN_SIDE) continue;
          const cornersOk = [
            [vA.center, hA.center],
            [vB.center, hA.center],
            [vB.center, hB.center],
            [vA.center, hB.center],
          ].every(([x, z]) => maskAt(x, z));
          if (!cornersOk) continue;
          const spanOk =
            hA.from <= Math.min(vA.center, vB.center) && hA.to >= Math.max(vA.center, vB.center) &&
            hB.from <= Math.min(vA.center, vB.center) && hB.to >= Math.max(vA.center, vB.center) &&
            vA.from <= Math.min(hA.center, hB.center) && vA.to >= Math.max(hA.center, hB.center) &&
            vB.from <= Math.min(hA.center, hB.center) && vB.to >= Math.max(hA.center, hB.center);
          if (!spanOk) continue;
          const key = [hA.center, hB.center, vA.center, vB.center].map((v) => Math.round(v)).join(",");
          if (usedKey.has(key)) continue;
          usedKey.add(key);
          loops.push({ hA, hB, vA, vB, bridge: false });
        }
      }
    }
  }

  // --- special corridors ---------------------------------------------------
  // The general rectangle search above only accepts wide blocks (MIN_SIDE). That
  // excludes the two structures the brief calls out by name: the elevated
  // highway, whose two carriageways are ~24 m apart, and the bridge, whose deck
  // sits on the same east-west corridor as the road it crosses. Both are found
  // here instead, and are pushed to the FRONT of the loop list so route
  // selection always keeps them.
  const specials = [];
  let bridgeFound = false;
  const bridgeLoop = findBridgeLoop({
    cols, rows, maskAt, hBands, vBands, collision,
  });
  if (bridgeLoop) {
    specials.push(bridgeLoop);
    bridgeFound = true;
  }
  const elevatedLoops = findElevatedLoops({
    hBands: elevHBands, vBands: elevVBands, elevAt,
  });
  for (const l of elevatedLoops) specials.push(l);
  if (specials.length) loops.unshift(...specials);
  const specialStats = {
    bridgeLoop: !!bridgeLoop,
    elevatedCandidates: elevatedLoops.length,
  };

  // --- validator -----------------------------------------------------------
  // A lane point only counts as clean if the car would fit there WITH ROOM TO
  // SPARE. Testing the bare footprint is not enough: the car is a tracker, not
  // a rail, and it runs a metre or so off the centre line through a bend. A lane
  // that merely fits gets scraped by its own tracking error - the car drifts
  // into the kerb-side props the lane was a hair away from, wedges, and stops.
  // Growing the footprint by the expected error makes the lane survivable.
  //
  // The margin is a PREFERENCE, not a gate. Demanding the full clearance on
  // every point rejects the majority of loops, which starves the traffic system
  // of routes and leaves every car on the same handful of streets. So each loop
  // is first tried at full margin and, only if that fails, again with a relaxed
  // one: wide clear roads win, awkward ones still contribute, hopeless ones drop.
  const probeGeo = probeGeometry();
  // Lane validation runs with `ignoreDestructibles: true` so a street sign
  // or barrel placed kerb-side does not invalidate an otherwise perfectly
  // drivable lane. Traffic will simply drive past (and the player smash
  // through) any such prop - the lane itself stays clean.
  const probe = new TerrainFollower(collision, probeGeo, 1, { ignoreDestructibles: true });
  // The car's footprint must not touch a baked road divider. `isRoadAt` is true
  // across a `road_b` median (it is part of the road mesh), so without this a
  // lane point sitting on the divider looks perfectly valid and the repair pass
  // will happily keep it there.
  const dividerClear = (x, z, heading) => {
    const s = Math.sin(heading);
    const c = Math.cos(heading);
    for (let a = -probeGeo.halfLength; a <= probeGeo.halfLength; a += 0.7) {
      for (let b = -probeGeo.halfWidth; b <= probeGeo.halfWidth; b += 0.6) {
        // footprint offset: `a` fore/aft, `b` left/right
        if (collision.isDividerAt(x + s * a + c * b, z + c * a - s * b)) return false;
      }
    }
    return true;
  };
  const makeClean = (margin) => (x, z, heading) => {
    const r = collision.groundAt(x, z, 6, { stepUp: 6, reach: 8 });
    if (r.kind !== "ground" || !collision.isRoadAt(x, z)) return null;
    if (!dividerClear(x, z, heading)) return null;
    const bottom = r.y + probeGeo.clearance;
    const top = r.y + probeGeo.height;
    const g = probeGeo.halfLength + margin;
    const w = probeGeo.halfWidth + margin;
    if (collision.blockedRect(x, z, heading, g, w, bottom, top, null, { ignoreDestructibles: true })) return null;
    probe.teleport(r.y);
    if (probe.blocked(x, z, heading)) return null;
    return r.y;
  };
  const clean = makeClean(LANE_MARGIN);
  // --- build + validate lanes ---------------------------------------------
  const routes = [];
  let dropped = 0;
  let repairedPoints = 0;
  let lockedRoutes = 0;
  const specialRoutes = { bridge: 0, elevated: 0 };
  for (const loop of loops) {
    const lane = buildLaneRing(loop, cellX, cellZ);
    // Take the best margin this particular loop can manage. A single hard
    // threshold would throw away streets that are perfectly drivable at a
    // smaller clearance just because they are narrower, and rank a tight lane
    // no better than one that genuinely has nowhere to spare.
    let validated = null;
    let clearance = 0;
    for (const margin of LANE_MARGIN_LADDER) {
      const tryClean = margin === LANE_MARGIN_LADDER[0] ? clean : makeClean(margin);
      validated = validateLane(lane, tryClean);
      if (validated) {
        clearance = margin;
        break;
      }
    }
    if (!validated) {
      dropped++;
      continue;
    }
    if (loop.bridge) specialRoutes.bridge++;
    if (loop.elevated) specialRoutes.elevated++;
    // Re-place the lane in the right-hand carriageway. The band builder puts
    // the loop on the road centre, which on the divided `road_b` streets is the
    // median itself - the source of the divider crossing. Only keep the locked
    // version if it still validates, so this can never make a healthy loop worse.
    const locked = lockLaneToRightHand(validated.points, clean, collision);
    if (locked) {
      const relock = validateLane(locked, clean);
      if (relock) {
        validated = relock;
        lockedRoutes++;
      }
    }
    repairedPoints += validated.repaired;
    // A route counts as elevated if it actually reaches the raised roadway,
    // whether by construction or by riding a ramp up onto it - which is the
    // only way the highway can be reached from the city here.
    let reach = -Infinity;
    for (const p of validated.points) if (p.y > reach) reach = p.y;
    routes.push({
      id: routes.length,
      points: validated.points,
      onRoadRatio: 1,
      bridge: !!loop.bridge,
      elevated: !!loop.elevated || reach > 2.5,
      // How much room the lane has to absorb the car's own tracking error.
      // Route selection prefers wide-clearance lanes so the relaxed ones are
      // only used when there is nothing better left.
      clearance,
    });
  }

  // --- recycled (open) bridge + highway cycle ------------------------------
  // The one route that cannot exist as a closed loop: it crosses the bridge
  // once, in one direction, and recycles from the highway's south end back to
  // its north end. No U-turn and no wrong-way leg is needed, which is exactly
  // why this works where the closed-loop searches could not.
  const recycle = buildRecycleRoute(collision, clean, makeClean);
  if (recycle) routes.push(recycle);

  // Structure routes are worth keeping whatever their clearance, so they are
  // never displaced by a prettier ground loop: recycle (bridge+highway) first,
  // then a genuine bridge loop, then elevated, then the widest clearances.
  const rank = (r) => (r.recycle ? 3 : 0) + (r.bridge ? 2 : 0) + (r.elevated ? 1 : 0);
  routes.sort((a, b) => rank(b) - rank(a) || b.clearance - a.clearance);
  routes.forEach((r, i) => {
    r.id = i;
  });

  return {
    routes,
    bridgeFound: bridgeFound && routes.some((r) => r.bridge),
    stats: {
      maskRoadCells,
      hBands: hBands.length,
      vBands: vBands.length,
      loops: loops.length,
      dropped,
      repairedPoints,
      lockedRoutes,
      ...specialStats,
      recycleRoute: !!recycle,
      bridgeRoutes: specialRoutes.bridge,
      elevatedRoutes: specialRoutes.elevated,
    },
  };
}

/**
 * How far drivable roadway continues from (x,z) along the unit direction
 * (dx,dz), up to `max` metres. Stops at the first non-road sample.
 */
function roadRun(collision, x, z, dx, dz, max) {
  let d = 0;
  for (let s = 0.5; s <= max; s += 0.5) {
    if (!collision.isRoadAt(x + dx * s, z + dz * s)) break;
    d = s;
  }
  return d;
}

/**
 * Re-place a validated lane in its right-hand carriageway, or null.
 *
 * For each lane point the road is measured perpendicular to travel (the real
 * `isRoadAt` extent, so it is bounded by the actual carriageway), its centre is
 * located, and the point is moved to `width * 0.3` to the RIGHT of that centre:
 *
 *   - on a divided road the centre is the median, so the offset lands in the
 *     correct directional carriageway and a car can no longer straddle the
 *     divider or sit in the oncoming lane;
 *   - on an undivided road it is the middle of the right-hand lane, matching
 *     the player's keep-right convention.
 *
 * Offsets are found per point but applied through a blurred field, exactly like
 * the validator's sideways repair, so neighbouring points move together and the
 * lane stays smooth instead of kinking. A locked point that would fall off the
 * roadway keeps its original position, and the caller re-validates the whole
 * lane, so this pass is safe by construction.
 *
 * @returns Array<{x,y,z}> or null when the lane is too short to work on.
 */
function lockLaneToRightHand(points, clean, collision, open = false) {
  const n = points.length;
  if (n < 8) return null;
  const hasDivider = typeof collision.isDividerAt === "function";
  // Closed loops turn around at the ends (modulo); open paths clamp.
  const at = (i) => (open ? Math.min(Math.max(i, 0), n - 1) : ((i % n) + n) % n);

  const headingAt = (i) => {
    const a = points[at(i - 1)];
    const b = points[at(i + 1)];
    return Math.atan2(b.x - a.x, b.z - a.z);
  };

  const delta = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const p = points[i];
    const heading = headingAt(i);
    // Right of heading h is (cos h, -sin h).
    const rx = Math.cos(heading);
    const rz = -Math.sin(heading);
    const pos = roadRun(collision, p.x, p.z, rx, rz, RIGHT_LANE_REACH);
    const neg = roadRun(collision, p.x, p.z, -rx, -rz, RIGHT_LANE_REACH);
    const width = pos + neg;
    if (width < RIGHT_LANE_MIN_WIDTH) {
      // Divided highway case: the point sits on (or in the gap of) a median,
      // so both runs read ~0 and the lane would be left straddling the
      // divider. Probe sideways for the nearest real carriageway instead -
      // bias to the RIGHT so southbound stays in its own carriageway - and
      // snap there when it is on roadway and clear of a divider.
      let rescue = 0;
      for (let d = 0.5; d <= RIGHT_LANE_REACH; d += 0.5) {
        for (const s of [1, -1]) {
          const tx = p.x + rx * d * s;
          const tz = p.z + rz * d * s;
          if (!collision.isRoadAt(tx, tz)) continue;
          if (hasDivider && collision.isDividerAt(tx, tz)) continue;
          // Prefer the right-hand side; take the first right hit, else the
          // first left hit as a fallback.
          if (s === 1) { rescue = d; break; }
          if (rescue === 0) rescue = -d;
        }
        if (rescue !== 0 && rescue > 0) break;
        if (rescue !== 0 && d > 4) break;
      }
      delta[i] = rescue;
      continue;
    }
    const offset = Math.min(width * 0.3, width / 2 - 1.0, RIGHT_LANE_MAX);
    const want = (pos - neg) / 2 + offset;
    // Shrink toward the original position until the target is on roadway AND
    // clear of a divider. The shrink can also be pushed OUTWARD past a divider
    // the point currently sits on, so a median-centred lane lands in the
    // carriageway instead of being nudged just off the fin.
    let chosen = null;
    for (let t = 0; t < 8; t++) {
      const d = want * (1 - t / 8);
      const tx = p.x + rx * d;
      const tz = p.z + rz * d;
      if (!collision.isRoadAt(tx, tz)) continue;
      if (hasDivider && collision.isDividerAt(tx, tz)) continue;
      chosen = d;
      break;
    }
    delta[i] = chosen === null ? 0 : chosen;
  }

  // Blur the offset field around the loop (same idea as the validator's
  // repair): a point that must move several metres sits beside one that must
  // not, and applying both unchanged would put a kink in the lane.
  const smooth = new Float64Array(n);
  if (open) {
    let span = 0;
    for (let k = -RIGHT_LANE_SMOOTH; k <= RIGHT_LANE_SMOOTH; k++) span++;
    for (let i = 0; i < n; i++) {
      let s = 0;
      for (let k = -RIGHT_LANE_SMOOTH; k <= RIGHT_LANE_SMOOTH; k++) s += delta[at(i + k)];
      smooth[i] = s / span;
    }
  } else {
    let span = 0;
    for (let i = -RIGHT_LANE_SMOOTH; i <= RIGHT_LANE_SMOOTH; i++) {
      smooth[((i % n) + n) % n] += delta[((i % n) + n) % n];
      span++;
    }
    for (let i = 1; i < n; i++) {
      smooth[i] += delta[(i + RIGHT_LANE_SMOOTH) % n] -
        delta[(((i - RIGHT_LANE_SMOOTH - 1) % n) + n) % n];
    }
    for (let i = 0; i < n; i++) smooth[i] /= span;
  }

  const out = [];
  for (let i = 0; i < n; i++) {
    const p = points[i];
    const heading = headingAt(i);
    const rx = Math.cos(heading);
    const rz = -Math.sin(heading);
    const d = smooth[i];
    const x = p.x + rx * d;
    const z = p.z + rz * d;
    // Never leave the roadway; if the smoothed offset does, keep the point.
    if (Math.abs(d) > 0.05 && !collision.isRoadAt(x, z)) {
      out.push({ x: p.x, y: p.y, z: p.z });
      continue;
    }
    out.push({ x, y: p.y, z });
  }
  return out;
}

/**
 * Passable roadway grid for the recycle-route search: 1 m cells that are
 * roadway AND not a road divider, so the connector never crosses a median.
 */
function buildRecycleGrid(collision) {
  const { cols, rows, minX, minZ, cell } = collision;
  const pass = new Uint8Array(cols * rows);
  let cells = 0;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = minX + (c + 0.5) * cell;
      const z = minZ + (r + 0.5) * cell;
      if (collision.isRoadAt(x, z) && !collision.isDividerAt(x, z)) {
        pass[r * cols + c] = 1;
        cells++;
      }
    }
  }
  return { pass, cells, cols, rows, minX, minZ, cell };
}

/** Nearest passable cell to (x,z), or null. Snaps anchors onto real roadway. */
function nearestPassable(grid, x, z, maxR = 16) {
  const { pass, cols, rows, minX, minZ, cell } = grid;
  const c0 = Math.floor((x - minX) / cell);
  const r0 = Math.floor((z - minZ) / cell);
  for (let d = 0; d <= maxR; d++) {
    for (let dr = -d; dr <= d; dr++) {
      for (let dc = -d; dc <= d; dc++) {
        if (Math.max(Math.abs(dr), Math.abs(dc)) !== d) continue;
        const c = c0 + dc;
        const r = r0 + dr;
        if (c >= 0 && r >= 0 && c < cols && r < rows && pass[r * cols + c]) {
          return { x: minX + (c + 0.5) * cell, z: minZ + (r + 0.5) * cell };
        }
      }
    }
  }
  return null;
}

/**
 * A* over the roadway grid between two world points, 8-connected with no
 * diagonal corner-cutting. Returns a point chain or null when the two are not
 * connected (which is the honest answer for a genuine cut, e.g. the bridge
 * before the deck cells are included).
 */
function astarPath(grid, ax, az, bx, bz) {
  const { pass, cols, rows, minX, minZ, cell } = grid;
  const a = nearestPassable(grid, ax, az);
  const b = nearestPassable(grid, bx, bz);
  if (!a || !b) return null;
  const start = Math.floor((a.z - minZ) / cell) * cols + Math.floor((a.x - minX) / cell);
  const goal = Math.floor((b.z - minZ) / cell) * cols + Math.floor((b.x - minX) / cell);
  if (start === goal) return [a];

  const N = cols * rows;
  const g = new Float64Array(N).fill(Infinity);
  const came = new Int32Array(N).fill(-1);
  const closed = new Uint8Array(N);
  const f = new Float64Array(N).fill(Infinity);
  const wx = (i) => minX + ((i % cols) + 0.5) * cell;
  const wz = (i) => minZ + (((i / cols) | 0) + 0.5) * cell;
  const h = (i) => Math.hypot(wx(i) - b.x, wz(i) - b.z);

  const heap = [start];
  g[start] = 0;
  f[start] = h(start);
  const push = (i) => {
    heap.push(i);
    let c = heap.length - 1;
    while (c > 0) {
      const p = (c - 1) >> 1;
      if (f[heap[p]] <= f[heap[c]]) break;
      const t = heap[p]; heap[p] = heap[c]; heap[c] = t; c = p;
    }
  };

  while (heap.length) {
    const top = heap[0];
    const last = heap.pop();
    if (heap.length) {
      heap[0] = last;
      let c = 0;
      for (;;) {
        const l = c * 2 + 1;
        const r = l + 1;
        let m = c;
        if (l < heap.length && f[heap[l]] < f[heap[m]]) m = l;
        if (r < heap.length && f[heap[r]] < f[heap[m]]) m = r;
        if (m === c) break;
        const t = heap[m]; heap[m] = heap[c]; heap[c] = t; c = m;
      }
    }
    if (top === goal) break;
    if (closed[top]) continue;
    closed[top] = 1;
    const tc = top % cols;
    const tr = (top / cols) | 0;
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (!dr && !dc) continue;
        const nc = tc + dc;
        const nr = tr + dr;
        if (nc < 0 || nr < 0 || nc >= cols || nr >= rows) continue;
        const ni = nr * cols + nc;
        if (!pass[ni] || closed[ni]) continue;
        if (dr && dc && (!pass[tr * cols + nc] || !pass[nr * cols + tc])) continue;
        const step = dr && dc ? Math.SQRT2 : 1;
        const ng = g[top] + step;
        if (ng < g[ni]) {
          g[ni] = ng;
          came[ni] = top;
          const nf = ng + h(ni);
          if (nf < f[ni]) { f[ni] = nf; push(ni); }
        }
      }
    }
  }
  if (goal !== start && came[goal] < 0) return null;
  const out = [];
  for (let i = goal; i >= 0; i = came[i]) {
    out.push({ x: wx(i), z: wz(i) });
    if (i === start) break;
  }
  out.reverse();
  return out;
}

/** True when every cell along the straight segment a->b is passable. */
function lineClear(grid, a, b) {
  const { pass, cols, rows, minX, minZ, cell } = grid;
  const d = Math.hypot(b.x - a.x, b.z - a.z);
  const steps = Math.max(1, Math.ceil(d / (cell * 0.5)));
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = a.x + (b.x - a.x) * t;
    const z = a.z + (b.z - a.z) * t;
    const c = Math.floor((x - minX) / cell);
    const r = Math.floor((z - minZ) / cell);
    if (c < 0 || r < 0 || c >= cols || r >= rows || !pass[r * cols + c]) return false;
  }
  return true;
}

/** Greedy string-pull: keep only the waypoints needed to stay on roadway. */
function stringPull(grid, pts) {
  if (pts.length <= 2) return pts.slice();
  const out = [pts[0]];
  let i = 0;
  while (i < pts.length - 1) {
    let j = pts.length - 1;
    for (; j > i + 1; j--) if (lineClear(grid, pts[i], pts[j])) break;
    out.push(pts[j]);
    i = j;
  }
  return out;
}

/** Resample an open polyline at `spacing` metres. */
function densifyOpen(pts, spacing) {
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i];
    const b = pts[i + 1];
    const d = Math.hypot(b.x - a.x, b.z - a.z);
    const steps = Math.max(1, Math.round(d / spacing));
    for (let k = 0; k < steps; k++) {
      out.push({ x: a.x + ((b.x - a.x) * k) / steps, z: a.z + ((b.z - a.z) * k) / steps });
    }
  }
  const last = pts[pts.length - 1];
  out.push({ x: last.x, z: last.z });
  return out;
}

/**
 * Builds the recycled (open) bridge+highway route, or null.
 *
 * Connects the anchors in `RECYCLE_ANCHORS` with A* over the roadway, then
 * makes it a real lane: simplified, densified, right-hand locked and validated
 * exactly like a closed loop. The result is flagged `open`/`recycle` so the
 * traffic system treats the end as a recycle point rather than a wrap.
 */
function buildRecycleRoute(collision, clean, makeClean) {
  if (typeof collision.isDividerAt !== "function") return null;
  const grid = buildRecycleGrid(collision);
  if (grid.cells < 100) return null;

  // 1. A* between successive anchors. Each segment is simplified on its own -
  //    pulling strings across the WHOLE path would run a clear straight line
  //    down the highway and silently discard the bridge detour between the
  //    anchors, since string-pulling only preserves the two end points.
  const raw = [];
  let prev = null;
  for (let i = 0; i < RECYCLE_ANCHORS.length - 1; i++) {
    const a = RECYCLE_ANCHORS[i];
    const b = RECYCLE_ANCHORS[i + 1];
    const seg = astarPath(grid, a.x, a.z, b.x, b.z);
    if (!seg) return null;
    for (const p of stringPull(grid, seg)) {
      if (prev && Math.hypot(p.x - prev.x, p.z - prev.z) < 0.5) continue;
      raw.push(p);
      prev = p;
    }
  }

  // 2. densify, read heights from the bake.
  const dense = densifyOpen(raw, DENSIFY);
  const ring = [];
  for (const p of dense) {
    const g = collision.groundAt(p.x, p.z, 6, { stepUp: 6, reach: 8 });
    ring.push({ x: p.x, z: p.z, y: g.kind === "ground" ? g.y : 0 });
  }
  if (ring.length < 8) return null;

  // 3. validate, then right-hand lock, then re-validate (mirrors closed loops).
  let validated = null;
  let clearance = 0;
  for (const margin of LANE_MARGIN_LADDER) {
    const tryClean = margin === LANE_MARGIN_LADDER[0] ? clean : makeClean(margin);
    validated = validateLane(ring, tryClean, true);
    if (validated) { clearance = margin; break; }
  }
  if (!validated) return null;

  const locked = lockLaneToRightHand(validated.points, clean, collision, true);
  if (locked) {
    const relock = validateLane(locked, clean, true);
    if (relock) validated = relock;
  }

  // Straight tips, safely: collapse any turnaround kink at either end into a
  // straight run and extend both tips to the road edge so cars appear /
  // disappear at the edge heading straight (no U-turn, no mid-road median
  // spawn). Only kept when the straightened lane still validates - otherwise
  // the pre-straighten lane is kept so highway+bridge traffic never drops.
  {
    const before = validated;
    const straight = straightenRecycleTips(validated.points, clean);
    const check = validateLane(straight, clean, true);
    if (check) validated = check;
    else validated = before;
  }

  return {
    id: -1,
    points: validated.points,
    onRoadRatio: 1,
    bridge: false,
    elevated: false,
    open: true,
    recycle: true,
    clearance,
  };
}

/**
 * Collapse any kink/U-turn at the two tips of an open recycle lane into a
 * straight edge-to-edge run.
 *
 * The first/last ~18 m are rewritten as a straight lerp (which turns a
 * turnaround loop into a straight line by construction), then the start is
 * pulled BACK to the road edge and the end is pushed FORWARD to the road
 * edge along the same heading - so the spawn sits at the north edge of
 * `road_c_03.019` in its right-hand lane and the despawn sits at the east
 * edge of `road_c_03.012`, both heading straight along the road. Every moved
 * point is re-checked with `clean` (roadway + divider + footprint), so a
 * tip can never end up on the median or off the road.
 */
function straightenRecycleTips(points, clean) {
  const n = points.length;
  if (n < 30) return points;
  const K = Math.min(18, Math.floor(n / 12));
  const out = points.map((p) => ({ ...p }));

  const headingOf = (a, b) => Math.atan2(b.x - a.x, b.z - a.z);

  // --- collapse kinks into straight runs ---------------------------------
  {
    const a = out[0];
    const b = out[K];
    for (let k = 0; k <= K; k++) {
      const t = k / K;
      const x = a.x + (b.x - a.x) * t;
      const z = a.z + (b.z - a.z) * t;
      const h = headingOf(a, b);
      const y = clean(x, z, h);
      if (y !== null) out[k] = { x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) };
    }
  }
  {
    const a = out[n - K - 1];
    const b = out[n - 1];
    for (let k = 0; k <= K; k++) {
      const t = k / K;
      const x = a.x + (b.x - a.x) * t;
      const z = a.z + (b.z - a.z) * t;
      const h = headingOf(a, b);
      const y = clean(x, z, h);
      if (y !== null) out[n - K - 1 + k] = { x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) };
    }
  }

  // --- push start BACK to the north edge ----------------------------------
  {
    const b = out[K];
    let a = out[0];
    let h = headingOf(a, b);
    let best = a;
    for (let d = 0.5; d <= 10; d += 0.5) {
      const x = a.x - Math.sin(h) * d;
      const z = a.z - Math.cos(h) * d;
      const y = clean(x, z, h);
      if (y === null) break;
      best = { x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) };
    }
    out[0] = best;
    a = best;
    h = headingOf(a, b);
    for (let k = 1; k < K; k++) {
      const t = k / K;
      const x = a.x + (b.x - a.x) * t;
      const z = a.z + (b.z - a.z) * t;
      const y = clean(x, z, h);
      if (y !== null) out[k] = { x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) };
    }
  }

  // --- push end FORWARD to the exit edge (straight, no turn) ---------------
  {
    const a = out[n - K - 1];
    let b = out[n - 1];
    let h = headingOf(a, b);
    let best = b;
    for (let d = 0.5; d <= 12; d += 0.5) {
      const x = b.x + Math.sin(h) * d;
      const z = b.z + Math.cos(h) * d;
      const y = clean(x, z, h);
      if (y === null) break;
      best = { x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) };
    }
    out[n - 1] = best;
    b = best;
    h = headingOf(a, b);
    for (let k = 1; k < K; k++) {
      const t = k / K;
      const x = a.x + (b.x - a.x) * t;
      const z = a.z + (b.z - a.z) * t;
      const y = clean(x, z, h);
      if (y !== null) out[n - K - 1 + k] = { x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) };
    }
  }

  return out;
}

/**
 * Closed loops on the ELEVATED roadway - the highway/viaduct sections.
 *
 * The general rectangle pass requires a block side of `MIN_SIDE` (80 m), which
 * is right for city blocks but wrong for a divided highway: its two carriageways
 * are only a couple of dozen metres apart, and its connector at the end of a run
 * is a short cross piece. So the highway was never built at all and traffic
 * never left the ground.
 *
 * This pass reuses the same rectangle construction with a smaller minimum side,
 * but only for bands that are genuinely elevated: every sample along the band
 * must sit on roadway more than `ELEV_MIN_Y` above ground. That yields the
 * classic highway oval - up one carriageway, across a connector, back down the
 * other - as a legitimate loop, with the turnaround happening at a real
 * connector rather than a U-turn on the carriageway.
 */
function findElevatedLoops({ hBands, vBands, elevAt }) {
  const ev = vBands;
  const eh = hBands;
  const loops = [];
  const seen = new Set();
  for (let i = 0; i < eh.length; i++) {
    for (let j = i + 1; j < eh.length; j++) {
      const hA = eh[i];
      const hB = eh[j];
      const hd = Math.abs(hA.center - hB.center);
      if (hd < ELEV_MIN_SIDE || hd > ELEV_MAX_SIDE) continue;
      for (let k = 0; k < ev.length; k++) {
        for (let l = k + 1; l < ev.length; l++) {
          const vA = ev[k];
          const vB = ev[l];
          const vd = Math.abs(vA.center - vB.center);
          if (vd < ELEV_MIN_SIDE || vd > ELEV_MAX_SIDE) continue;
          const cornersOk = [
            [vA.center, hA.center],
            [vB.center, hA.center],
            [vB.center, hB.center],
            [vA.center, hB.center],
          ].every(([x, z]) => elevAt(x, z));
          if (!cornersOk) continue;
          const lo = Math.min(vA.center, vB.center) - ELEV_SPAN_TOL;
          const hi = Math.max(vA.center, vB.center) + ELEV_SPAN_TOL;
          const loZ = Math.min(hA.center, hB.center) - ELEV_SPAN_TOL;
          const hiZ = Math.max(hA.center, hB.center) + ELEV_SPAN_TOL;
          const spanOk =
            hA.from <= lo && hA.to >= hi &&
            hB.from <= lo && hB.to >= hi &&
            vA.from <= loZ && vA.to >= hiZ &&
            vB.from <= loZ && vB.to >= hiZ;
          if (!spanOk) continue;
          const key = [hA.center, hB.center, vA.center, vB.center].map((v) => Math.round(v)).join(",");
          if (seen.has(key)) continue;
          seen.add(key);
          loops.push({ hA, hB, vA, vB, bridge: false, elevated: true });
        }
      }
    }
  }
  return loops;
}

/**
 * Finds a closed traffic loop that uses the elevated roadway, or null.
 *
 * A loop needs the deck to be reachable from the street network, which means it
 * has to have ramps: corridor eastbound (up a ramp, over the deck, down the
 * other), a connector, a parallel ground road back, and a second connector.
 *
 * On THIS map no such loop exists, and the search correctly returns null. The
 * bridge deck is continuous with the boulevard it carries, so a car CAN drive
 * across it - but the only roads that reach the deck's two ends are the deck
 * itself and the boulevard, and the two banks of the channel are not otherwise
 * linked at any z a rectangle could return along. A closed loop would therefore
 * have to cross the deck twice in opposite directions and turn around on each
 * bank - legal only with a turnaround block on each side, which this kit does
 * not have. The version of this builder that ignored connectivity produced a
 * collapsed sliver whose cars immediately wedged; the corner/span checks below
 * are what reject that.
 *
 * The deck itself is flat and drivable, so on a map where a return road does
 * reach both ends this builder produces a proper crossing loop.
 */
function findBridgeLoop({ cols, rows, maskAt, hBands, vBands, collision }) {
  const { minX, minZ } = collision;

  // 1. locate the deck from the bake's own bridge mask. A height threshold
  //    cannot do it: the deck over the channel sits only just above the water,
  //    so an "is it elevated" test sees nothing and the search always gave up.
  let bMinX = Infinity;
  let bMaxX = -Infinity;
  let bMinZ = Infinity;
  let bMaxZ = -Infinity;
  // The bridge mask lives on the collision's own 1 m grid, NOT the coarse band
  // grid this module works on, so it has to be walked with the collision's
  // dimensions (indexing it with band-grid rows finds nothing).
  let cells = 0;
  const cc = collision.cols;
  const cr = collision.rows;
  const cminX = collision.minX;
  const cminZ = collision.minZ;
  const cs = collision.cell;
  for (let r = 0; r < cr; r++) {
    for (let c = 0; c < cc; c++) {
      if (!collision.bridgeMask[r * cc + c]) continue;
      cells++;
      const x = cminX + (c + 0.5) * cs;
      const z = cminZ + (r + 0.5) * cs;
      if (x < bMinX) bMinX = x;
      if (x > bMaxX) bMaxX = x;
      if (z < bMinZ) bMinZ = z;
      if (z > bMaxZ) bMaxZ = z;
    }
  }
  void minX;
  void minZ;
  if (cells < 20) return null;
  // 2. the deck is a corridor along its long axis; only the east-west case is
  //    built here (the connectors pair it with a parallel road).
  if (bMaxX - bMinX < bMaxZ - bMinZ) return null;
  const deckZ = (bMinZ + bMaxZ) / 2;
  const d0 = bMinX;
  const d1 = bMaxX;

  // 3. corridor extent at deck level Z: full roadway run containing the deck
  let w0 = null;
  let w1 = null;
  {
    let start = -1;
    for (let c = 0; c <= cols; c++) {
      const on = c < cols && maskAt(minX + (c + 0.5) * S, deckZ);
      if (on && start < 0) start = c;
      if (!on && start >= 0) {
        const from = minX + start * S;
        const to = minX + c * S;
        if (from - 4 <= d0 && to + 4 >= d1) {
          w0 = from;
          w1 = to;
          break;
        }
        start = -1;
      }
    }
  }
  if (w0 === null) {
    w0 = d0 - 30;
    w1 = d1 + 30;
  }

  // 4. return band: a horizontal band 12..45 m to the north or south whose
  //    span reaches both connector zones
  const retCands = hBands.filter(
    (b) => b.axis === "z" && Math.abs(b.center - deckZ) >= 12 && Math.abs(b.center - deckZ) <= 45,
  );
  if (!retCands.length) return null;

  // 5. connectors: vertical bands crossing deckZ and the return band, one near
  //    each end of the deck
  const connectors = (xLo, xHi, retZ) =>
    vBands
      .filter((v) => v.center >= xLo && v.center <= xHi)
      .filter((v) => v.from <= Math.min(deckZ, retZ) && v.to >= Math.max(deckZ, retZ))
      .sort((a, b) => Math.abs(a.center - xLo) - Math.abs(b.center - xLo));

  for (const ret of retCands.sort((a, b) => Math.abs(a.center - deckZ) - Math.abs(b.center - deckZ))) {
    const west = connectors(w0 - 20, d0 + 5, ret.center)[0];
    const east = connectors(d1 - 5, w1 + 20, ret.center)[0];
    if (!west || !east || east.center - west.center < 40) continue;
    // The rectangle has to actually close: all four corners on roadway, and
    // the two sides must physically reach each other. Without this the ring
    // was built across a return road that does not connect, and validation
    // then dragged the far side back onto the deck - a collapsed sliver.
    const cornersOk = [
      [west.center, deckZ], [east.center, deckZ],
      [east.center, ret.center], [west.center, ret.center],
    ].every(([x, z]) => maskAt(x, z));
    if (!cornersOk) continue;
    const loX = Math.min(west.center, east.center);
    const hiX = Math.max(west.center, east.center);
    const loZ = Math.min(deckZ, ret.center);
    const hiZ = Math.max(deckZ, ret.center);
    const spanOk =
      ret.from <= loX && ret.to >= hiX &&
      west.from <= loZ && west.to >= hiZ &&
      east.from <= loZ && east.to >= hiZ;
    if (!spanOk) continue;

    // Ring the standard builder understands. hNear carries the bridge deck;
    // its span is widened to the connectors so the ring crosses the deck.
    const hNear = {
      center: deckZ, width: 21,
      from: Math.min(west.center, d0), to: Math.max(east.center, d1),
    };
    const hFar = { center: ret.center, width: ret.width, from: ret.from, to: ret.to };
    const vA = { center: west.center, width: west.width, from: west.from, to: west.to };
    const vB = { center: east.center, width: east.width, from: east.from, to: east.to };
    return { hA: hNear, hB: hFar, vA, vB, bridge: true };
  }
  return null;
}

/**
 * Densified ring for a rectangle loop, inset toward its centre and with every
 * corner rounded.
 *
 * The rounding matters: a raw rectangle gives the lane four exact 90 deg steps,
 * and a car tracking such a lane arrives at a step with a huge heading error,
 * cuts the corner and drives into whatever sits on the inside of the bend.
 * Replacing each corner with a tangent arc means the lane has a finite radius
 * that matches the car's own turning circle, so the vehicle can follow it.
 */
function buildLaneRing(loop, cellX, cellZ) {
  void cellX;
  void cellZ;
  const { hA, hB, vA, vB } = loop;

  // Order the two vertical and two horizontal bands by position so every loop
  // is built with the SAME winding - interior on the car's RIGHT. The band
  // extractor emits bands in scan order rather than sorted, so a loop handed a
  // reversed pair traversed the other way round and put traffic on the wrong
  // side of the road.
  const vLo = vA.center <= vB.center ? vA : vB;
  const vHi = vA.center <= vB.center ? vB : vA;
  const hLo = hA.center <= hB.center ? hA : hB;
  const hHi = hA.center <= hB.center ? hB : hA;

  const cx = (vLo.center + vHi.center) / 2;
  const cz = (hLo.center + hHi.center) / 2;

  // Keep the lane near the CENTRE OF THE CAR'S HALF of the road rather than a
  // fixed number of metres off the centre line. The old fixed inset (capped at
  // 4.5 m) put traffic down the middle of wide roads - a 4.5 m offset is a small
  // fraction of a 30 m carriageway - and hard against the kerb on narrow ones,
  // where half the road is less than 4.5 m. Scaling it to each road's own width
  // puts every car in a real lane.
  const laneInset = (width) =>
    clamp(width / 4, LANE_HALF + 0.3, Math.max(width / 2 - LANE_HALF, LANE_HALF + 0.3));

  // Keep-right winding: with this corner order the rectangle's interior lies to
  // the car's right on every edge, so insetting toward the centre IS keeping
  // right - matching the player, who also drives on the right.
  const corners = [
    { v: vLo, h: hLo },
    { v: vLo, h: hHi },
    { v: vHi, h: hHi },
    { v: vHi, h: hLo },
  ].map(({ v, h }) => {
    const ix = laneInset(v.width);
    const iz = laneInset(h.width);
    return {
      x: v.center + (v.center < cx ? ix : -ix),
      z: h.center + (h.center < cz ? iz : -iz),
    };
  });

  // --- turn each corner into {entry, arc[], exit} --------------------------
  const nodes = corners.map((p, s) => {
    const prev = corners[(s - 1 + corners.length) % corners.length];
    const next = corners[(s + 1) % corners.length];
    const inLen = Math.max(Math.hypot(p.x - prev.x, p.z - prev.z), 0.001);
    const outLen = Math.max(Math.hypot(next.x - p.x, next.z - p.z), 0.001);

    // Unit vectors from the corner along each of its two edges.
    const ix = (prev.x - p.x) / inLen;
    const iz = (prev.z - p.z) / inLen;
    const ox = (next.x - p.x) / outLen;
    const oz = (next.z - p.z) / outLen;

    // Never round away more than half of either adjoining edge.
    const r = Math.max(0.5, Math.min(FILLET, inLen * 0.4, outLen * 0.4));
    const entry = { x: p.x + ix * r, z: p.z + iz * r };
    const exit = { x: p.x + ox * r, z: p.z + oz * r };

    // Every loop corner is 90 deg (the bands are axis aligned), so the arc
    // centre sits on the corner bisector, r/sin(45 deg) = r*sqrt2 away, which
    // is exactly p + (in + out) * r.
    const cenX = p.x + (ix + ox) * r;
    const cenZ = p.z + (iz + oz) * r;
    const a0 = Math.atan2(entry.z - cenZ, entry.x - cenX);
    const a1 = Math.atan2(exit.z - cenZ, exit.x - cenX);
    let sweep = a1 - a0;
    while (sweep > Math.PI) sweep -= Math.PI * 2;
    while (sweep < -Math.PI) sweep += Math.PI * 2;

    const steps = Math.max(1, Math.round((Math.abs(sweep) * r) / DENSIFY));
    const arc = [];
    for (let k = 0; k <= steps; k++) {
      const a = a0 + (sweep * k) / steps;
      arc.push({ x: cenX + Math.cos(a) * r, z: cenZ + Math.sin(a) * r, y: 0 });
    }
    return { entry, exit, arc };
  });

  // --- stitch: corner arc, straight run, corner arc, ... -------------------
  // Traversal order is entry(s) -> arc(s) -> exit(s) -> straight -> entry(s+1).
  const ring = [];
  for (let s = 0; s < nodes.length; s++) {
    const cur = nodes[s];
    const nxt = nodes[(s + 1) % nodes.length];

    for (const p of cur.arc) ring.push({ x: p.x, z: p.z, y: 0 });

    // Start at t=1: the arc already contributed cur.exit as its final point, so
    // emitting t=0 here would put two identical points in a row. A zero-length
    // segment makes every heading the car derives from the lane degenerate.
    const len = Math.hypot(nxt.entry.x - cur.exit.x, nxt.entry.z - cur.exit.z);
    const steps = Math.max(1, Math.round(len / DENSIFY));
    for (let t = 1; t < steps; t++) {
      ring.push({
        x: cur.exit.x + ((nxt.entry.x - cur.exit.x) * t) / steps,
        z: cur.exit.z + ((nxt.entry.z - cur.exit.z) * t) / steps,
        y: 0,
      });
    }
  }
  return ring;
}

/**
 * Validates every lane point against collision and repairs what it can.
 *
 * A point is clean when the bake has drivable ROADWAY under it and the car's
 * footprint is not blocked there. Dirty points are shifted sideways ACROSS the
 * road (never off it) until they are clean, and a loop with any point that
 * cannot be made clean is rejected outright, so no traffic route ever contains
 * a bad spot.
 *
 * The shifts are found per point but applied through a blurred field. Repairing
 * each point independently produces a zigzag: a point that needs 5 m of shift
 * sits next to one that needs none, giving a kink the car cannot follow and
 * which the corner-speed scan reads as a near-180 deg corner. Smoothing the
 * offset field makes neighbouring points move together, so the lane stays
 * continuous and every shift is still applied across the road.
 *
 * @returns {{ points: Array<{x,y,z}>, repaired: number }} or null
 */
function validateLane(ring, clean, open = false) {
  const n = ring.length;
  if (n < 8) return null;
  const at = (i) => (open ? Math.min(Math.max(i, 0), n - 1) : ((i % n) + n) % n);

  const headingAt = (i) => {
    const p = ring[i];
    const nxt = ring[at(i + 1)];
    const prv = ring[at(i - 1)];
    return Math.atan2(nxt.x - prv.x, nxt.z - prv.z);
  };

  // --- pass 1: smallest signed lateral shift that cleans each point --------
  const raw = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const p = ring[i];
    const heading = headingAt(i);
    if (clean(p.x, p.z, heading) !== null) continue;
    const found = searchShift(p.x, p.z, heading, clean);
    if (found === null) return null; // unrepairable - reject the whole loop
    raw[i] = found;
  }

  // --- pass 2: blur the shift field around the ring ------------------------
  const smooth = new Float64Array(n);
  if (open) {
    let span = 0;
    for (let k = -SHIFT_SMOOTH; k <= SHIFT_SMOOTH; k++) span++;
    for (let i = 0; i < n; i++) {
      let s = 0;
      for (let k = -SHIFT_SMOOTH; k <= SHIFT_SMOOTH; k++) s += raw[at(i + k)];
      smooth[i] = s / span;
    }
  } else {
    let span = 0;
    for (let i = -SHIFT_SMOOTH; i <= SHIFT_SMOOTH; i++) {
      const idx = ((i % n) + n) % n;
      smooth[idx] += raw[idx];
      span++;
    }
    for (let i = 1; i < n; i++) {
      const add = raw[(i + SHIFT_SMOOTH) % n];
      const drop = raw[(((i - SHIFT_SMOOTH - 1) % n) + n) % n];
      smooth[i] += add - drop;
    }
    for (let i = 0; i < n; i++) smooth[i] /= span;
  }

  // --- pass 3: apply, then fall back per point to the unsmoothed shift -----
  const points = [];
  let repaired = 0;
  for (let i = 0; i < n; i++) {
    const p = ring[i];
    const heading = headingAt(i);
    const cos = Math.cos(heading);
    const sin = Math.sin(heading);

    let x = p.x + cos * smooth[i];
    let z = p.z - sin * smooth[i];
    let y = clean(x, z, heading);

    if (y === null && Math.abs(smooth[i] - raw[i]) > 0.01) {
      x = p.x + cos * raw[i];
      z = p.z - sin * raw[i];
      y = clean(x, z, heading);
    }
    if (y === null) {
      // Smoothing pushed it somewhere invalid: try any nearby clean spot.
      const spot = searchAnyShift(x, z, heading, clean);
      if (!spot) return null;
      x = spot.x;
      z = spot.z;
      y = clean(x, z, heading);
      if (y === null) return null;
    }
    if (y === null) return null;

    if (Math.abs(raw[i]) > 0.01 || Math.abs(smooth[i]) > 0.01) repaired++;
    points.push({ x: +x.toFixed(2), y: +y.toFixed(3), z: +z.toFixed(2) });
  }
  return { points, repaired };
}

/**
 * Smallest signed sideways offset that makes (x,z) clean, or null.
 * Offsets are taken positive to the car's right, matching the lane's travel
 * direction, and are capped so a repair can never leave the road it started on.
 */
function searchShift(x, z, heading, clean) {
  const cos = Math.cos(heading);
  const sin = Math.sin(heading);
  for (let d = 0.5; d <= MAX_SHIFT; d += 0.5) {
    for (const s of [1, -1]) {
      if (clean(x + cos * d * s, z - sin * d * s, heading) !== null) return d * s;
    }
  }
  return null;
}

/**
 * Like searchShift but searching a full ring of directions. Used as a last
 * resort where smoothing dropped a point onto the kerb: the lane may still be
 * salvaged by moving that one point sideways at any angle.
 *
 * @returns the offset to apply at (x,z), or null
 */
function searchAnyShift(x, z, heading, clean) {
  for (let d = 0.5; d <= MAX_SHIFT; d += 0.5) {
    for (let a = 0; a < 8; a++) {
      const th = (a / 8) * Math.PI * 2;
      const nx = x + Math.cos(th) * d;
      const nz = z - Math.sin(th) * d;
      if (clean(nx, nz, heading) !== null) return { x: nx, z: nz };
    }
  }
  return null;
}
