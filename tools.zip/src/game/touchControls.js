/**
 * On-screen touch controls: steering (bottom-left) and pedals
 * (bottom-right), merged into the keyboard input by createInput.
 *
 * The buttons are plain DOM (styled by the `.touch-ui` rules in
 * main.css) and only ever read - they hold no game logic. They are
 * built once and stay mounted for the whole session so every driving
 * state (free roam, countdown, race, finish cinematic) sees them;
 * the full-screen overlays (loading / lobby / garage / pause) simply
 * paint on top, which keeps menu taps from reaching the buttons.
 *
 * Mounted on EVERY device - there is no phone/tablet/desktop
 * detection (?touch=0 hides them for keyboard play). A `touch`
 * class is added to the body so CSS can hook the mounted state.
 */
const ACTION_MAP = {
  up: "throttle",
  down: "brake",
  left: "left",
  right: "right",
  handbrake: "handbrake",
};

export class TouchControls {
  constructor() {
    // Per-button pressed state, mirrored into the input getters.
    this._left = false;
    this._right = false;
    this._throttle = false;
    this._brake = false;
    this._handbrake = false;
    /** button element -> set of pointerIds currently holding it. */
    this._holders = new Map();
    /** action -> button element */
    this._buttons = new Map();
    /** actions currently held via keyboard */
    this._keyHolders = new Set();

    // Always on: the controls are part of the HUD on every
    // device. ?touch=0 hides them (keyboard-only play).
    this.enabled = new URLSearchParams(location.search).get("touch") !== "0";

    this.root = null;
    if (this.enabled) {
      this.root = this._build();
      document.body.classList.add("touch");
    }
  }

  /** Merged pedal/steer state, consumed by createInput(). */
  get steer() {
    // The driving model is steer +1 = left, -1 = right
    // (see input.js), so LEFT presses must read positive.
    return (this._left ? 1 : 0) - (this._right ? 1 : 0);
  }

  get throttle() {
    return this._throttle ? 1 : 0;
  }

  get brake() {
    return this._brake ? 1 : 0;
  }

  get handbrake() {
    return this._handbrake;
  }

  _build() {
    const root = document.createElement("div");
    root.className = "touch-ui";
    root.innerHTML = `
      <div class="touch-ui__cluster touch-ui__cluster--left">
        <button type="button" class="touch-btn touch-btn--steer touch-btn--steer-left" data-touch="left" aria-label="Steer left">
          <svg class="touch-steer-svg" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <circle cx="32" cy="32" r="30" class="touch-steer-halo" />
            <circle cx="32" cy="32" r="25" class="touch-steer-disc" />
            <g class="touch-steer-chevron">
              <polygon points="21,31.5 37,19 37,25.5 28,31.5" />
              <polygon points="21,32.5 28,32.5 37,38.5 37,45" />
            </g>
          </svg>
        </button>
        <button type="button" class="touch-btn touch-btn--steer touch-btn--steer-right" data-touch="right" aria-label="Steer right">
          <svg class="touch-steer-svg" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <circle cx="32" cy="32" r="30" class="touch-steer-halo" />
            <circle cx="32" cy="32" r="25" class="touch-steer-disc" />
            <g class="touch-steer-chevron">
              <polygon points="43,31.5 27,19 27,25.5 36,31.5" />
              <polygon points="43,32.5 36,32.5 27,38.5 27,45" />
            </g>
          </svg>
        </button>
      </div>
      <div class="touch-ui__cluster touch-ui__cluster--right">
        <button type="button" class="touch-btn touch-btn--hb" data-touch="handbrake" aria-label="Handbrake">
          <svg class="touch-hb-svg" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <circle cx="32" cy="32" r="30" class="touch-steer-halo" />
            <circle cx="32" cy="32" r="25" class="touch-steer-disc" />
          </svg>
          <span class="touch-hb-text">HB</span>
        </button>
        <div class="touch-ui__pedals">
          <button type="button" class="touch-btn touch-btn--pedal touch-btn--brake" data-touch="brake" aria-label="Brake">
            <svg class="touch-pedal-svg" viewBox="0 0 64 88" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <path class="touch-pedal-halo" d="M 16,4 L 48,4 Q 60,4 60,16 L 60,72 Q 60,84 48,84 L 24,84 Q 16,84 13,79 L 7,68 Q 4,62 4,54 L 4,16 Q 4,4 16,4 Z" />
              <path class="touch-pedal-plate" d="M 16,4 L 48,4 Q 60,4 60,16 L 60,72 Q 60,84 48,84 L 24,84 Q 16,84 13,79 L 7,68 Q 4,62 4,54 L 4,16 Q 4,4 16,4 Z" />
              <g class="touch-pedal-holes">
                <circle cx="20" cy="18" r="4.5" />
                <circle cx="44" cy="18" r="4.5" />
                <circle cx="32" cy="29" r="4.5" />
                <circle cx="20" cy="40" r="4.5" />
                <circle cx="44" cy="40" r="4.5" />
                <circle cx="32" cy="51" r="4.5" />
                <circle cx="20" cy="62" r="4.5" />
                <circle cx="44" cy="62" r="4.5" />
                <circle cx="32" cy="73" r="4.5" />
              </g>
            </svg>
          </button>
          <button type="button" class="touch-btn touch-btn--pedal touch-btn--throttle" data-touch="throttle" aria-label="Throttle">
            <svg class="touch-pedal-svg" viewBox="0 0 64 88" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <path class="touch-pedal-halo" d="M 16,4 L 48,4 Q 60,4 60,16 L 60,72 Q 60,84 48,84 L 24,84 Q 16,84 13,79 L 7,68 Q 4,62 4,54 L 4,16 Q 4,4 16,4 Z" />
              <path class="touch-pedal-plate" d="M 16,4 L 48,4 Q 60,4 60,16 L 60,72 Q 60,84 48,84 L 24,84 Q 16,84 13,79 L 7,68 Q 4,62 4,54 L 4,16 Q 4,4 16,4 Z" />
              <g class="touch-pedal-holes">
                <circle cx="20" cy="18" r="4.5" />
                <circle cx="44" cy="18" r="4.5" />
                <circle cx="32" cy="29" r="4.5" />
                <circle cx="20" cy="40" r="4.5" />
                <circle cx="44" cy="40" r="4.5" />
                <circle cx="32" cy="51" r="4.5" />
                <circle cx="20" cy="62" r="4.5" />
                <circle cx="44" cy="62" r="4.5" />
                <circle cx="32" cy="73" r="4.5" />
              </g>
            </svg>
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(root);

    for (const btn of root.querySelectorAll("[data-touch]")) {
      this._buttons.set(btn.dataset.touch, btn);
      this._bind(btn);
      // Long-press on mobile Safari/Chrome would otherwise pop the
      // context menu / callout over the controls.
      btn.addEventListener("contextmenu", (e) => e.preventDefault());
    }
    return root;
  }

  /**
   * One press-set per button, tracked by pointerId, so any number of
   * fingers across different buttons work at once (true multi-touch)
   * and a stray release can never leave a pedal stuck on.
   */
  _bind(btn) {
    const action = btn.dataset.touch;
    const press = () => {
      this["_" + action] = true;
      btn.classList.add("is-active");
    };
    const release = () => {
      this["_" + action] = false;
      if (!this._keyHolders.has(action)) {
        btn.classList.remove("is-active");
      }
    };

    btn.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      let holders = this._holders.get(btn);
      if (!holders) {
        holders = new Set();
        this._holders.set(btn, holders);
      }
      if (holders.size === 0) press();
      holders.add(e.pointerId);
      // Keep the finger's events coming to this button even if it
      // slides off the edge (capture is a no-op where unsupported).
      try {
        btn.setPointerCapture(e.pointerId);
      } catch {
        /* older engines: pointerleave fallback below */
      }
    });

    const end = (e) => {
      const holders = this._holders.get(btn);
      if (!holders || !holders.has(e.pointerId)) return;
      holders.delete(e.pointerId);
      if (holders.size === 0) release();
    };
    btn.addEventListener("pointerup", end);
    btn.addEventListener("pointercancel", end);
    // Capture lost (browser gesture, system UI) must also clear.
    btn.addEventListener("lostpointercapture", () => {
      const holders = this._holders.get(btn);
      if (holders && holders.size > 0) {
        holders.clear();
        release();
      }
    });
    // Engines without pointer capture: sliding off the button ends
    // the press instead of keeping it stuck.
    btn.addEventListener("pointerleave", (e) => {
      if (btn.hasPointerCapture?.(e.pointerId)) return;
      end(e);
    });
  }

  /**
   * Activates/deactivates the on-screen button UI when user drives with keyboard.
   * Matches up/down/left/right/handbrake actions to their respective controls.
   */
  setKeyActive(action, isActive) {
    const touchAction = ACTION_MAP[action] || action;
    const btn = this._buttons.get(touchAction);
    if (!btn) return;

    if (isActive) {
      this._keyHolders.add(touchAction);
      btn.classList.add("is-active");
    } else {
      this._keyHolders.delete(touchAction);
      const holders = this._holders.get(btn);
      if (!holders || holders.size === 0) {
        btn.classList.remove("is-active");
      }
    }
  }

  /** Clears all keyboard-driven activations on blur/focus loss. */
  clearKeys() {
    this._keyHolders.clear();
    for (const [, btn] of this._buttons) {
      const holders = this._holders.get(btn);
      if (!holders || holders.size === 0) {
        btn.classList.remove("is-active");
      }
    }
  }
}
