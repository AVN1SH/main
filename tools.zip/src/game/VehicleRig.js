import { Quaternion, TransformNode, Vector3 } from "@babylonjs/core";
import { WHEEL_RE, classifyAxles } from "./raceCarAxles.js";

/**
 * Wraps one instance of the car model and makes its wheels controllable.
 *
 * The source asset needs surgery before the wheels can move correctly:
 *
 *  1. The wheel NODES are not centred on their meshes. `rFWheel.001` and
 *     `rrWheel` have their origin on the OPPOSITE side of the car from the
 *     wheel itself (off by ~1.72 units), so rotating those nodes to steer
 *     would swing the wheel around the chassis instead of pivoting it.
 *  2. The real body frame is the wheel meshes' PARENT, which in Babylon's
 *     import is a TransformNode named "amg Gt body". The visible body geometry
 *     is a set of sibling children called "amg Gt body_primitive0..2" whose own
 *     local transforms are IDENTITY - the 0.387 scale and the 180 degree yaw
 *     live on the parent. Looking the body up by mesh name therefore finds a
 *     node with no transform at all, which silently misplaces every pivot.
 *
 * Resulting structure:
 *
 *   root                     <- game drives this (position, rotation.y = heading)
 *    +- model                <- one-time rotation so the car's forward is +Z
 *        +- gltfRoot  (__root__, carries a mirrored scale from the glTF import)
 *            +- wheelHub      <- rigid copy of the body frame
 *            |    +- steerPivot (rotation.y = steering)
 *            |         +- spinPivot (rolling; axis measured per model)
 *            |              +- wheelMesh
 *            +- bodyTilt      <- roll/pitch, body geometry only
 *                 +- bodyNode  (the original "amg Gt body" node)
 *
 * The wheels are pulled out of `bodyNode` into `wheelHub` so body tilt does not
 * lift them off the road. Heading convention matches driving.js:
 * forward = (sin h, 0, cos h), root.rotation.y = h.
 *
 * Which local axis steers and which one rolls is MEASURED per model rather
 * than assumed: `car1.glb` rolls about the body frame's Z, but the
 * `<Car> FL Tire` models put the axle along X, and rolling the wrong axis
 * tumbles the wheel instead of turning it.
 */


export class VehicleRig {
  constructor(scene, loadedRoot, label = "car", calibration = null) {
    this.scene = scene;
    this.label = label;
    this.diagnostics = {};

    // --- collect nodes ---------------------------------------------------
    const meshes = [...loadedRoot.getChildMeshes(false)];
    if (loadedRoot.getClassName() === "Mesh") meshes.push(loadedRoot);

    const wheelMeshes = meshes.filter((m) => WHEEL_RE.test(m.name));
    if (wheelMeshes.length !== 4) {
      throw new Error(`${label}: expected 4 wheel meshes, found ${wheelMeshes.length}`);
    }
    // Which axle is FRONT cannot be read from the names: the models come from
    // two authoring conventions (`lfWheel`/`rrWheel` vs `<Car> FL Tire`) and
    // `car2.glb` carries a wheel whose name contradicts its position. Measure
    // the long axis from the body and vote the names, exactly as RaceRig does,
    // so this rig works unchanged on every model in the garage catalogue.
    const bodyMeshes = meshes.filter((m) => !wheelMeshes.includes(m));
    if (!bodyMeshes.length) throw new Error(`${label}: no body mesh found`);
    const bodyBox = unionBounds(bodyMeshes);
    const axles = classifyAxles(
      bodyBox,
      wheelMeshes.map((m) => this._meshWorldCentre(m)),
      wheelMeshes.map((m) => m.name),
    );
    const isFront = axles.isFront;
    this.diagnostics.longAxis = axles.longAxis;
    this.diagnostics.axleVotes = axles.votes;
    this.diagnostics.wheelEnds = wheelMeshes.map((m, i) => ({
      name: m.name,
      named: axles.ends[i].named,
      measured: axles.ends[i].measured,
    }));

    // The wheels' parent IS the body frame. Trust the graph, not the names.
    const bodyNode = wheelMeshes[0].parent;
    if (!bodyNode) throw new Error(`${label}: wheel meshes have no parent to use as the body frame`);
    const strayWheel = wheelMeshes.find((w) => w.parent !== bodyNode);
    if (strayWheel) {
      throw new Error(`${label}: wheel ${strayWheel.name} is not parented to the body frame`);
    }
    this.bodyNode = bodyNode;
    this.diagnostics.bodyNode = { name: bodyNode.name, className: bodyNode.getClassName() };

    // --- skeleton --------------------------------------------------------
    this.root = new TransformNode(`${label}_root`, scene);
    // `ground` carries the terrain pitch/roll so the whole car (wheels
    // included) lies along the surface. Body-only lean/pitch stays on
    // `bodyTilt` further down.
    this.ground = new TransformNode(`${label}_ground`, scene);
    this.ground.parent = this.root;
    this.model = new TransformNode(`${label}_model`, scene);
    this.model.parent = this.ground;

    let gltfRoot = loadedRoot;
    if (loadedRoot === bodyNode) {
      gltfRoot = new TransformNode(`${label}_gltfroot`, scene);
      gltfRoot.parent = this.model;
      const saved = captureTransform(loadedRoot);
      loadedRoot.parent = gltfRoot;
      restoreTransform(loadedRoot, saved);
    } else {
      gltfRoot.parent = this.model;
    }
    this.gltfRoot = gltfRoot;

    this._forceUpdate();
    for (const m of meshes) m.computeWorldMatrix(true);

    // --- align the model so its forward is +Z ----------------------------
    // The asset's forward is baked along another axis, so measure it from the
    // axles and rotate once; a wrong guess here makes the car drive sideways.
    const frontMid = average(
      wheelMeshes.filter((_, i) => isFront[i]).map((w) => this._worldToSpace(this._meshWorldCentre(w), this.model)),
    );
    const rearMid = average(
      wheelMeshes.filter((_, i) => !isFront[i]).map((w) => this._worldToSpace(this._meshWorldCentre(w), this.model)),
    );
    const forward = frontMid.subtract(rearMid);
    forward.y = 0;
    if (forward.lengthSquared() < 1e-6) {
      throw new Error(`${label}: could not determine the car's forward direction`);
    }
    forward.normalize();

    const yawFix = -Math.atan2(forward.x, forward.z);
    this.model.rotation.y = yawFix;
    this.diagnostics.forwardInModelSpace = [round(forward.x, 3), 0, round(forward.z, 3)];
    this.diagnostics.modelYawFixDeg = round((yawFix * 180) / Math.PI, 1);
    this._forceUpdate();

    // --- hub: a sibling of the body sharing its exact frame --------------
    // Built BEFORE the body is reparented, so bodyNode.parent is still gltfRoot.
    this.wheelHub = new TransformNode(`${label}_wheelhub`, scene);
    this.wheelHub.parent = bodyNode.parent;
    copyTransform(bodyNode, this.wheelHub);
    this._forceUpdate();

    const hubWorldInv = this.wheelHub.getWorldMatrix().clone().invert();

    // --- rebuild the wheels on centred pivots ----------------------------
    this.wheels = [];
    for (let wi = 0; wi < wheelMeshes.length; wi++) {
      const wheel = wheelMeshes[wi];
      wheel.computeWorldMatrix(true);
      const centerWorld = this._meshWorldCentre(wheel);
      const centerHub = Vector3.TransformCoordinates(centerWorld, hubWorldInv);
      const sizeWorld = wheel.getBoundingInfo().boundingBox.extendSizeWorld.scale(2);
      const saved = captureTransform(wheel);

      const steerPivot = new TransformNode(`${label}_steer_${wheel.name}`, scene);
      steerPivot.parent = this.wheelHub;
      steerPivot.position.copyFrom(centerHub);
      steerPivot.rotationQuaternion = null;
      steerPivot.rotation.setAll(0);

      const spinPivot = new TransformNode(`${label}_spin_${wheel.name}`, scene);
      spinPivot.parent = steerPivot;
      spinPivot.position.setAll(0);
      spinPivot.rotationQuaternion = null;
      spinPivot.rotation.setAll(0);

      // Reparent, then re-express the position so the baked geometry offset
      // still lands the wheel where it belongs. Rotation and scale are restored
      // explicitly instead of trusting setParent's decompose.
      wheel.parent = spinPivot;
      wheel.position.copyFrom(saved.position.subtract(centerHub));
      wheel.scaling.copyFrom(saved.scaling);
      if (saved.rotationQuaternion) {
        wheel.rotationQuaternion = saved.rotationQuaternion.clone();
      } else {
        wheel.rotationQuaternion = null;
        wheel.rotation.copyFrom(saved.rotation);
      }

      // Which local axis steers and which one rolls is NOT the same in every
      // model: `car1.glb` puts the axle along the body frame's Z, while the
      // `<Car> FL Tire` family puts it along X (its long axis is Z). Spinning
      // the wrong one tumbles the wheel instead of rolling it, which is why
      // these are measured per wheel rather than assumed:
      //   - steer axis: whichever pivot axis points most nearly at world up,
      //   - spin axis:  whichever points most nearly along the wheel's own
      //                 axle - the thinnest box axis of the mesh itself.
      const upInHub = Vector3.TransformNormal(new Vector3(0, 1, 0), hubWorldInv);
      const axleWorld = Vector3.TransformNormal(this._axleAxisLocal(wheel), wheel.getWorldMatrix());
      const axleInHub = Vector3.TransformNormal(axleWorld, hubWorldInv);
      const steerAxis = dominantAxis(upInHub);
      const spinAxis = dominantAxis(axleInHub);

      this.wheels.push({
        name: wheel.name,
        mesh: wheel,
        steerPivot,
        spinPivot,
        steerAxis,
        spinAxis,
        isFront: isFront[wi],
        // Side is taken from the measured lateral axis, so it is consistent
        // across both naming conventions (the names disagree about which
        // letter means which side).
        isLeft: centerHub[axles.lateralAxis] >= 0,
        centerHub: centerHub.clone(),
        radius: Math.max(sizeWorld.x, sizeWorld.y, sizeWorld.z) / 2,
      });
    }
    this._forceUpdate();

    // --- body tilt: geometry only, wheels are no longer its children -----
    this.bodyTilt = new TransformNode(`${label}_bodytilt`, scene);
    this.bodyTilt.parent = bodyNode.parent;
    const savedBody = captureTransform(bodyNode);
    bodyNode.parent = this.bodyTilt;
    restoreTransform(bodyNode, savedBody);
    this._forceUpdate();

    // --- measurements + sanity ------------------------------------------
    this.diagnostics.wheels = this.wheels.map((w) => ({
      name: w.name,
      front: w.isFront,
      left: w.isLeft,
      steerAxis: w.steerAxis,
      spinAxis: w.spinAxis,
      radius: round(w.radius, 3),
      centreHub: v3(w.centerHub),
      pivotError: round(
        Vector3.Distance(w.steerPivot.getAbsolutePosition(), this._meshWorldCentre(w.mesh)),
        4,
      ),
      distanceFromRoot: round(
        Vector3.Distance(this._meshWorldCentre(w.mesh), this.root.getAbsolutePosition()),
        3,
      ),
    }));

    // Measure in WORLD space, not hub space. Hub coordinates are in body units,
    // and this body frame carries a 0.387 scale, so a hub-space distance is
    // ~2.6x too large and would feed a wrong wheelbase into the bicycle model.
    const fm = average(this.wheels.filter((w) => w.isFront).map((w) => this._meshWorldCentre(w.mesh)));
    const rm = average(this.wheels.filter((w) => !w.isFront).map((w) => this._meshWorldCentre(w.mesh)));
    this.wheelBase = Vector3.Distance(fm, rm);
    this.wheelRadius = this.wheels.reduce((s, w) => s + w.radius, 0) / this.wheels.length;
    this.diagnostics.wheelBase = round(this.wheelBase, 3);
    this.diagnostics.wheelRadius = round(this.wheelRadius, 3);
    this.diagnostics.bodyWorldDeterminant = round(bodyNode.getWorldMatrix().determinant(), 5);
    this.diagnostics.maxWheelDistanceFromRoot = round(
      Math.max(...this.wheels.map((w) => this.diagnostics.wheels.find((d) => d.name === w.name).distanceFromRoot)),
      3,
    );

    // With the pivots re-centred, steering must rotate a wheel in place rather
    // than translate it. Before the fix this measured ~1.7 m.
    this.diagnostics.pivotSwing = this._measurePivotSwing();

    // Wheel positions in ROOT space, used by the terrain sampler. Measured here
    // (at rest, ground tilt zero) so the sampler knows where each tyre is
    // without re-deriving it from the node graph every frame.
    this.wheelOffsets = this.wheels.map((w) => {
      const p = this._worldToSpace(w.steerPivot.getAbsolutePosition(), this.root);
      return { name: w.name, x: p.x, z: p.z, radius: w.radius };
    });
    this.diagnostics.wheelOffsets = this.wheelOffsets.map((w) => ({
      name: w.name,
      x: round(w.x, 3),
      z: round(w.z, 3),
    }));

    // Hub-space direction that points up in world space. The imported asset is
    // mirrored, so this is measured rather than assumed.
    const hub = this.wheelHub.getWorldMatrix().clone().invert();
    const up = Vector3.TransformNormal(new Vector3(0, 1, 0), hub);
    this._suspensionUp = up.lengthSquared() > 1e-9 ? up.normalize() : new Vector3(0, 1, 0);

    // Suspension must start at its rest pose, not the last probe rotation.
    this.setSuspension(this.wheels.map(() => 0));

    if (calibration) {
      this.steerSign = calibration.steerSign;
      this.spinSign = calibration.spinSign;
      this.tiltSign = calibration.tiltSign;
      this.diagnostics.calibration = "reused";
    } else {
      this._calibrate();
      this._calibrateTilt();
    }

    this.steerAngle = 0;
    this.setSteer(0);
    this.spinWheels(0);
  }

  get calibration() {
    return { steerSign: this.steerSign, spinSign: this.spinSign, tiltSign: this.tiltSign };
  }

  /**
   * Measures which way a positive tilt actually leans the body.
   *
   * The imported hierarchy carries a mirrored scale (see the class comment), so
   * a positive rotation about Z can visually lean the car either way - and a
   * car that leans INTO corners instead of out of them looks obviously wrong.
   *
   * A rotation about the car's forward axis moves any point above that axis
   * sideways by roughly (height x angle), so one probe point and two dot
   * products settle both signs.
   */
  _calibrateTilt() {
    const eps = 0.06;

    // a point well above the tilt pivot, in the tilt node's own space
    let lo = new Vector3(Infinity, Infinity, Infinity);
    let hi = new Vector3(-Infinity, -Infinity, -Infinity);
    for (const mesh of this.bodyTilt.getChildMeshes(false)) {
      mesh.computeWorldMatrix(true);
      const bb = mesh.getBoundingInfo().boundingBox;
      for (let i = 0; i < 8; i++) {
        const corner = new Vector3(
          i & 1 ? bb.maximum.x : bb.minimum.x,
          i & 2 ? bb.maximum.y : bb.minimum.y,
          i & 4 ? bb.maximum.z : bb.minimum.z,
        );
        const w = Vector3.TransformCoordinates(corner, mesh.getWorldMatrix());
        lo = Vector3.Minimize(lo, w);
        hi = Vector3.Maximize(hi, w);
      }
    }
    if (!Number.isFinite(lo.x)) {
      this.tiltSign = { lean: 1, pitch: 1 };
      return;
    }
    const probeWorld = new Vector3((lo.x + hi.x) / 2, hi.y, (lo.z + hi.z) / 2);

    this.bodyTilt.rotationQuaternion = Quaternion.Identity();
    this._forceUpdate();
    const probeLocal = Vector3.TransformCoordinates(
      probeWorld,
      this.bodyTilt.getWorldMatrix().clone().invert(),
    );

    const rightW = Vector3.TransformNormal(new Vector3(1, 0, 0), this.root.getWorldMatrix());
    rightW.y = 0;
    rightW.normalize();
    const forwardW = this._forwardWorld();

    const measure = (quat) => {
      this.bodyTilt.rotationQuaternion = quat;
      this._forceUpdate();
      const p = Vector3.TransformCoordinates(probeLocal, this.bodyTilt.getWorldMatrix());
      return {
        lateral: (p.x - probeWorld.x) * rightW.x + (p.z - probeWorld.z) * rightW.z,
        along: (p.x - probeWorld.x) * forwardW.x + (p.z - probeWorld.z) * forwardW.z,
      };
    };

    const moveFor = (qx, qz) => measure(Quaternion.FromEulerAngles(qx, 0, qz));

    /** Applies a tilt using the same mapping setTilt will use. */
    const moveForNamed = (leanRight, noseUp) => {
      const s = this.tiltSign;
      const lean = leanRight * s.leanSign;
      const pitch = noseUp * s.pitchSign;
      return measure(
        s.leanAxis === "x"
          ? Quaternion.FromEulerAngles(lean, 0, pitch)
          : Quaternion.FromEulerAngles(pitch, 0, lean),
      );
    };

    const aboutX = moveFor(eps, 0);
    const aboutZ = moveFor(0, eps);
    this.bodyTilt.rotationQuaternion = Quaternion.Identity();
    this._forceUpdate();

    // Which local axis does what is NOT fixed: in this asset the tilt node's
    // local X is the car's forward and local Z is its lateral axis, so a
    // rotation about Z is pitch rather than the roll you would expect.
    // Classify by what each rotation actually does to the probe point: the one
    // that shifts it sideways is the lean, the other is pitch.
    const xIsLean = Math.abs(aboutX.lateral) >= Math.abs(aboutX.along);
    const leanMove = xIsLean ? aboutX : aboutZ;
    const pitchMove = xIsLean ? aboutZ : aboutX;

    this.tiltSign = {
      // rolling right means the top of the car drifts toward its right
      leanSign: leanMove.lateral > 0 ? 1 : -1,
      // raising the nose pushes a point above the pivot backwards
      pitchSign: pitchMove.along < 0 ? 1 : -1,
      leanAxis: xIsLean ? "x" : "z",
      pitchAxis: xIsLean ? "z" : "x",
    };

    // Verify the mapping end to end, rather than trusting the classification.
    const checkLean = moveForNamed(0.1, 0);
    const checkPitch = moveForNamed(0, 0.1);
    this.bodyTilt.rotationQuaternion = Quaternion.Identity();
    this._forceUpdate();

    this.diagnostics.tilt = {
      probeWorld: v3(probeWorld),
      probeLocal: v3(probeLocal),
      bodyMeshCount: this.bodyTilt.getChildMeshes(false).length,
      aboutXLateral: round(aboutX.lateral, 5),
      aboutXAlong: round(aboutX.along, 5),
      aboutZLateral: round(aboutZ.lateral, 5),
      aboutZAlong: round(aboutZ.along, 5),
      ...this.tiltSign,
      // these two must have opposite signs to the intent check below
      leanTestLateral: round(checkLean.lateral, 5),
      pitchTestAlong: round(checkPitch.along, 5),
    };
  }

  /**
   * Measures (rather than derives) the two signs that decide whether the car
   * looks broken. This is necessary, not paranoia: the imported hierarchy
   * carries a mirrored scale (`__root__` has absScale (1,-1,1)), so the sense
   * of a rotation is not recoverable by reasoning about the maths alone.
   *
   * 1. steerSign - nudge a front pivot and watch its axle turn in the car's
   *    frame, to find how many radians of wheel yaw one radian of pivot
   *    rotation produces.
   * 2. spinSign - nudge a spin pivot and watch the TOP of the wheel (not the
   *    contact patch, which is the instantaneous centre of rotation and barely
   *    moves). Rolling forward carries the top of the wheel forwards.
   */
  _calibrate() {
    const wheel = this.wheels.find((w) => w.isFront) ?? this.wheels[0];
    const eps = 0.05;

    wheel.steerPivot.rotation[wheel.steerAxis] = 0;
    this._forceUpdate();
    const axleBefore = this._axleDirInRoot(wheel);
    wheel.steerPivot.rotation[wheel.steerAxis] = eps;
    this._forceUpdate();
    const axleAfter = this._axleDirInRoot(wheel);
    wheel.steerPivot.rotation[wheel.steerAxis] = 0;
    this._forceUpdate();

    const cross = axleBefore.x * axleAfter.z - axleBefore.z * axleAfter.x;
    const dot = axleBefore.x * axleAfter.x + axleBefore.z * axleAfter.z;
    const turned = Math.atan2(cross, dot);
    this.steerSign = Math.abs(turned) < 1e-6 ? -1 : turned / eps;

    // The invariant that matters: rolling FORWARD drags the TOP of the wheel
    // forwards, so measure exactly that point.
    //
    // Testing an arbitrary rim point (e.g. a bounding-box corner) does not
    // work - every corner of the box travels the same distance, so "pick the
    // biggest mover" selects nothing, and a corner's forward component depends
    // on where it sits on the circle and can be either sign. The top point has
    // an unambiguous answer.
    const spin = wheel.spinPivot;
    const centreWorld = this._meshWorldCentre(wheel.mesh);
    const topWorld = centreWorld.add(new Vector3(0, wheel.radius, 0));

    spin.rotation[wheel.spinAxis] = 0;
    this._forceUpdate();
    const topLocal = Vector3.TransformCoordinates(
      topWorld,
      wheel.mesh.getWorldMatrix().clone().invert(),
    );
    const p0 = Vector3.TransformCoordinates(topLocal, wheel.mesh.getWorldMatrix());
    spin.rotation[wheel.spinAxis] = eps;
    this._forceUpdate();
    const p1 = Vector3.TransformCoordinates(topLocal, wheel.mesh.getWorldMatrix());
    spin.rotation[wheel.spinAxis] = 0;
    this._forceUpdate();

    const moved = p1.subtract(p0);
    const forwardWorld = this._forwardWorld();
    const alongTravel = moved.x * forwardWorld.x + moved.z * forwardWorld.z;
    this.spinSign = Math.abs(alongTravel) < 1e-9 ? -1 : Math.sign(alongTravel);

    this.diagnostics.calibration = {
      probeWheel: wheel.name,
      steerAxis: wheel.steerAxis,
      spinAxis: wheel.spinAxis,
      axleTurnPerRadian: round(turned / eps, 3),
      steerSign: round(this.steerSign, 3),
      topMovedTotal: round(moved.length(), 5),
      topMovedAlongTravel: round(alongTravel, 5),
      expectedFromRadius: round(wheel.radius * eps, 5),
      spinSign: this.spinSign,
    };
  }

  _measurePivotSwing() {
    const wheel = this.wheels.find((w) => w.isFront) ?? this.wheels[0];
    const before = this._worldToSpace(this._meshWorldCentre(wheel.mesh), this.root);
    wheel.steerPivot.rotation[wheel.steerAxis] = 0.6;
    this._forceUpdate();
    const after = this._worldToSpace(this._meshWorldCentre(wheel.mesh), this.root);
    wheel.steerPivot.rotation[wheel.steerAxis] = 0;
    this._forceUpdate();
    return round(Vector3.Distance(before, after), 4);
  }

  /**
   * World-space centre of a mesh from its LOCAL bounding box pushed through its
   * world matrix. Deliberately avoids boundingBox.centerWorld, which relies on
   * Babylon's cached bounding info being in sync.
   */
  _meshWorldCentre(mesh) {
    mesh.computeWorldMatrix(true);
    return Vector3.TransformCoordinates(mesh.getBoundingInfo().boundingBox.center, mesh.getWorldMatrix());
  }

  _axleDirInRoot(wheel) {
    const world = Vector3.TransformNormal(this._axleAxisLocal(wheel.mesh), wheel.mesh.getWorldMatrix());
    const inRoot = Vector3.TransformNormal(world, this.root.getWorldMatrix().clone().invert());
    inRoot.y = 0;
    return inRoot.normalize();
  }

  /** Mesh-local unit vector along the axle (the wheel's thinnest box axis). */
  _axleAxisLocal(mesh) {
    const e = mesh.getBoundingInfo().boundingBox.extendSize;
    if (e.y <= e.x && e.y <= e.z) return new Vector3(0, 1, 0);
    if (e.x <= e.y && e.x <= e.z) return new Vector3(1, 0, 0);
    return new Vector3(0, 0, 1);
  }

  _forwardWorld() {
    const f = Vector3.TransformNormal(new Vector3(0, 0, 1), this.root.getWorldMatrix());
    f.y = 0;
    return f.normalize();
  }

  _worldToSpace(worldPoint, space) {
    space.computeWorldMatrix(true);
    return Vector3.TransformCoordinates(worldPoint, space.getWorldMatrix().clone().invert());
  }

  /** Force world matrices down the chain; nothing has rendered yet. */
  _forceUpdate() {
    this.root.computeWorldMatrix(true);
    this.ground?.computeWorldMatrix(true);
    this.model.computeWorldMatrix(true);
    this.gltfRoot?.computeWorldMatrix(true);
    this.wheelHub?.computeWorldMatrix(true);
    this.bodyTilt?.computeWorldMatrix(true);
    this.bodyNode?.computeWorldMatrix(true);
    for (const w of this.wheels ?? []) {
      w.steerPivot.computeWorldMatrix(true);
      w.spinPivot.computeWorldMatrix(true);
      w.mesh.computeWorldMatrix(true);
    }
  }

  /**
   * @param angle steering angle in radians. Positive steers LEFT, matching the
   *   sign the bicycle model in driving.js expects.
   */
  setSteer(angle) {
    this.steerAngle = angle;
    // steerSign is the measured wheel yaw per unit of pivot rotation, so
    // dividing converts the desired yaw into the pivot rotation that produces it.
    const y = Math.abs(this.steerSign) < 1e-6 ? -angle : angle / this.steerSign;
    for (const w of this.wheels) {
      if (w.isFront) w.steerPivot.rotation[w.steerAxis] = y;
    }
  }

  /** @param distance signed distance rolled this frame, in metres. */
  spinWheels(distance) {
    if (!distance) return;
    const delta = (distance / this.wheelRadius) * this.spinSign;
    for (const w of this.wheels) {
      let a = w.spinPivot.rotation[w.spinAxis] + delta;
      if (a > Math.PI) a -= Math.PI * 2;
      else if (a < -Math.PI) a += Math.PI * 2;
      w.spinPivot.rotation[w.spinAxis] = a;
    }
  }

  /**
   * Body-only lean and pitch, so the wheels stay planted on the road.
   * @param leanRight positive leans the car to its right (out of a left turn)
   * @param noseUp    positive raises the nose (squat under acceleration)
   */
  setTilt(leanRight, noseUp) {
    const s = this.tiltSign ?? { leanSign: 1, pitchSign: -1, leanAxis: "x", pitchAxis: "z" };
    const lean = leanRight * s.leanSign;
    const pitch = noseUp * s.pitchSign;
    this.bodyTilt.rotationQuaternion =
      s.leanAxis === "x"
        ? Quaternion.FromEulerAngles(lean, 0, pitch)
        : Quaternion.FromEulerAngles(pitch, 0, lean);
  }

  setPosition(x, y, z) {
    this.root.position.set(x, y, z);
  }

  /**
   * Fade the whole car for the race-intro reveal (1 = fully visible).
   * Per-mesh `visibility` works regardless of material sharing, and the
   * per-frame pose sync never touches it, so fading and driving compose.
   */
  setFade(v) {
    const f = Math.max(0, Math.min(1, v));
    const meshes = this.root?.getChildMeshes?.(false) ?? [];
    for (const m of meshes) m.visibility = f;
  }

  setHeading(heading) {
    this.root.rotation.y = heading;
  }

  /**
   * Terrain pitch/roll applied to the WHOLE car so it lies along the slope.
   * @param pitch rotation about the car's right axis (negative = nose up)
   * @param roll  rotation about the car's forward axis
   */
  setGroundTilt(pitch, roll) {
    this.ground.rotationQuaternion = null;
    this.ground.rotation.set(pitch ?? 0, 0, roll ?? 0);
  }

  /**
   * Vertical suspension offset per wheel (index matches `this.wheels`), in
   * metres. Positive lifts the wheel toward the body (compression), negative
   * lets it droop. Zero restores the wheel to its modelled position.
   */
  setSuspension(travels) {
    const up = this._suspensionUp ?? new Vector3(0, 1, 0);
    for (let i = 0; i < this.wheels.length; i++) {
      const w = this.wheels[i];
      const t = travels?.[i] ?? 0;
      w.steerPivot.position.set(
        w.centerHub.x + up.x * t,
        w.centerHub.y + up.y * t,
        w.centerHub.z + up.z * t,
      );
    }
  }

  /** Tint the body so traffic is not a fleet of identical cars. */
  setColor(color) {
    for (const mesh of this.wheelHub.parent.getChildMeshes(false)) {
      if (!/body/i.test(mesh.name) || mesh === this.root) continue;
      if (this.wheels.some((w) => w.mesh === mesh)) continue;
      const src = mesh.material;
      if (!src) continue;
      // Clone first: instantiated meshes share the asset container's
      // materials, so tinting in place would permanently recolour the
      // container and every car equipped from that model afterwards.
      let mat = null;
      try {
        mat = src.clone(`${this.label}_tint_${mesh.name}`);
      } catch {
        continue;
      }
      if (!mat) continue;
      if (mat.albedoColor) mat.albedoColor.copyFrom(color);
      else if (mat.diffuseColor) mat.diffuseColor.copyFrom(color);
      else continue;
      mat.markAsDirty?.();
      mesh.material = mat;
    }
  }

  dispose() {
    this.root.dispose(false, false);
  }
}

// ---------------------------------------------------------------- helpers

/** The dominant axis of a (possibly scaled) direction, as "x" | "y" | "z". */
function dominantAxis(v) {
  const ax = Math.abs(v.x);
  const ay = Math.abs(v.y);
  const az = Math.abs(v.z);
  if (ay >= ax && ay >= az) return "y";
  if (ax >= az) return "x";
  return "z";
}

function average(list) {
  const out = new Vector3(0, 0, 0);
  for (const p of list) out.addInPlace(p);
  return out.scaleInPlace(1 / (list.length || 1));
}

/** World AABB covering every mesh in `list` (used to find the body's long axis). */
function unionBounds(list) {
  const min = new Vector3(Infinity, Infinity, Infinity);
  const max = new Vector3(-Infinity, -Infinity, -Infinity);
  for (const mesh of list) {
    mesh.computeWorldMatrix(true);
    const bb = mesh.getBoundingInfo().boundingBox;
    min.minimizeInPlace(bb.minimumWorld);
    max.maximizeInPlace(bb.maximumWorld);
  }
  return { min, max };
}

function captureTransform(node) {
  return {
    position: node.position.clone(),
    rotation: node.rotation.clone(),
    rotationQuaternion: node.rotationQuaternion ? node.rotationQuaternion.clone() : null,
    scaling: node.scaling.clone(),
  };
}

/** Writes a captured transform back, so a reparent cannot alter it. */
function restoreTransform(node, t) {
  node.position.copyFrom(t.position);
  node.rotation.copyFrom(t.rotation);
  if (t.rotationQuaternion) {
    node.rotationQuaternion = t.rotationQuaternion.clone();
  } else {
    node.rotationQuaternion = null;
  }
  node.scaling.copyFrom(t.scaling);
}

function copyTransform(from, to) {
  to.position.copyFrom(from.position);
  to.rotation.copyFrom(from.rotation);
  if (from.rotationQuaternion) {
    to.rotationQuaternion = from.rotationQuaternion.clone();
  } else {
    to.rotationQuaternion = null;
  }
  to.scaling.copyFrom(from.scaling);
}

const round = (v, d = 2) => Math.round(v * 10 ** d) / 10 ** d;
const v3 = (v) => [round(v.x, 3), round(v.y, 3), round(v.z, 3)];
