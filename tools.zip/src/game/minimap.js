/**
 * Minimap module — all minimap logic lives here, nothing anywhere else.
 *
 * - Top-left overlay canvas (`#minimap`, created here if missing).
 * - Collapsed: small circle, heading-up follow view (map rotates, the
 *   player arrow always points UP — Far Cry / GTA style). The race circuit
 *   draws as a REVEAL WINDOW around the car (a short upcoming stretch fully
 *   lit, the passed stretch fading out behind it) instead of the whole
 *   track at once, so overlapping loops never confuse the read.
 * - Expanded: bigger square, static full-map view (north-up, fixed —
 *   it does not move or rotate with the player) showing the WHOLE circuit.
 * - Click (or `M` key) toggles between the two.
 *
 * The road + building layers are pre-rendered ONCE from the baked
 * `MapCollision` grids (roadway mask + tall obstacle cells) at 2x
 * supersampling with a dark casing, so the per-frame cost is a single
 * `drawImage` plus a handful of dots/arrow.
 *
 * Usage (in main.js):
 *   import { Minimap } from "./game/minimap.js";
 *   const minimap = new Minimap(collision);
 *   // per frame:
 *   minimap.update(player, traffic, dt);
 */

const SMALL_PX = 168;
const LARGE_PX = 420;
/** Half-size of the collapsed follow window, in world metres. */
const SMALL_HALF_RANGE = 110;
/** Offscreen supersampling: static road pixels per collision cell. */
const STATIC_SS = 2;
/** Collapsed race-track reveal: metres of upcoming track fully lit. */
const TRACK_AHEAD_M = 150;
/** Metres of passed track kept behind the car, fading out with age. */
const TRACK_BEHIND_M = 60;
/** Sampling step (m) for the reveal-window polyline. */
const TRACK_WINDOW_STEP = 2;
/** Passed-track fade: [max metres behind, alpha] bands, nearest first. */
const TRACK_FADE_BANDS = [
  [15, 0.9],
  [30, 0.65],
  [45, 0.4],
  [60, 0.18],
];

const COLORS = {
  bgTop: "#171b21",
  bgBottom: "#0e1116",
  building: "#2b3138",
  roadCasing: "#20242a",
  road: "#6b7280",
  player: "#ff2d55",
  playerOutline: "#ffffff",
  traffic: "#ffd60a",
  trafficOutline: "rgba(0,0,0,0.75)",
  ring: "rgba(255,255,255,0.07)",
  // --- race overlay -----------------------------------------------------
  track: "#19d3ff",
  trackCasing: "rgba(4,10,18,0.85)",
  start: "#ff2d55",
  gate: "#2b8fa8",
  gateNext: "#ffd60a",
  gatePassed: "#3c4a58",
  racer: "#3ddc97",
  racerOutline: "rgba(0,0,0,0.75)",
  // --- race event icon (pre-race): the event is an icon, not cars ------------
  eventDiamond: "#35ff69",
  // Completed-but-not-mastered events: grayed out, like the repair wrench, and
  // culled when outside the dial (not edge-pinned).
  eventDone: "#8893a0",
  // --- garage house icon (always shown): same green family as the event ---
  garage: "#35ff69",
  garageOutline: "rgba(0,0,0,0.75)",
  // --- repair wrench icons (gas stations): same green, culled in the dial --
  repair: "#35ff69",
  repairOutline: "rgba(0,0,0,0.75)",
};

export class Minimap {
  /**
   * @param {import("../engine/MapCollision.js").MapCollision} collision baked map model
   * @param {object} opts
   * @param {string} opts.canvasId DOM id to use (default "minimap")
   */
  constructor(collision, { canvasId = "minimap" } = {}) {
    if (!collision) throw new Error("Minimap requires a collision model");
    this.collision = collision;
    this.expanded = false;
    /** Smoothed heading used for the map rotation (radians). */
    this.displayHeading = null;

    // Find or create the canvas. It lives as a direct child of #app so it
    // sits above the WebGL canvas but below the loading overlay.
    let canvas = document.getElementById(canvasId);
    if (!canvas) {
      canvas = document.createElement("canvas");
      canvas.id = canvasId;
      const host = document.getElementById("app") ?? document.body;
      host.appendChild(canvas);
    }
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");

    this._buildStaticLayer();
    this._applySize();

    // Click toggles small <-> big. Stop propagation so the game canvas
    // never sees the click (it ignores clicks anyway).
    this._onClick = (e) => {
      e.stopPropagation();
      this.toggle();
    };
    canvas.addEventListener("click", this._onClick);

    // The CSS size animates (transition); re-sync the backing store once
    // it lands so the expanded map isn't left stretched/blurry.
    this._onTransitionEnd = (e) => {
      if (e.propertyName === "width" || e.propertyName === "height") this._applySize();
    };
    canvas.addEventListener("transitionend", this._onTransitionEnd);
    this._onKey = (e) => {
      if (e.code === "KeyM") this.toggle();
    };
    window.addEventListener("keydown", this._onKey);

    // Keep the backing store in sync with layout (DPR / viewport changes).
    this._onResize = () => this._applySize();
    window.addEventListener("resize", this._onResize);
  }

  /**
   * Attach the race so the guided track, its checkpoints and the rivals are
   * drawn on both views. `race` only has to answer `getMinimapData()`.
   */
  setRace(race) {
    this.race = race ?? null;
  }

  /**
   * The discoverable race-event markers (owned by RaceEventManager): a list of
   * `{ x, z, state }` where state is "active" (green, edge-pinned in the dial so
   * the player can always drive to it) or "completed" (gray, culled when outside
   * the dial - like the repair wrenches). Mastered events are simply absent.
   */
  setEvents(events) {
    this.events = (events ?? []).map((e) => ({ x: e.x, z: e.z, state: e.state }));
  }

  /**
   * Garage world position for the green house icon. Wired from main.js so
   * the icon always matches the 3D marker spot.
   */
  setGarage(x, z) {
    this.garage = { x, z };
  }

  /**
   * Repair-shop spots for the green wrench icons. Unlike the event/garage
   * marks these are NOT edge-pinned in the follow view: a wrench only
   * appears once its area is actually inside the dial circle (pro-game
   * style). The expanded map always shows all of them.
   */
  setRepairSpots(spots) {
    this.repairSpots = (spots ?? []).map((s) => ({ x: s.x, z: s.z }));
  }

  /**
   * Whether an active race run is currently in progress (intro/countdown/racing).
   * While active, all non-race world POI symbols (garage, repair shops, event
   * diamonds) are hidden so the minimap is uncluttered and focused on the race.
   * Once finished (or idle/armed), the symbols reappear.
   */
  isRaceActive(race = null) {
    const st = race?.state ?? this.race?.state ?? null;
    return st === "intro" || st === "countdown" || st === "racing";
  }

  get isExpanded() {
    return this.expanded;
  }

  toggle() {
    this.expanded = !this.expanded;
    this._applySize();
  }

  setExpanded(v) {
    this.expanded = !!v;
    this._applySize();
  }

  dispose() {
    this.canvas.removeEventListener("click", this._onClick);
    this.canvas.removeEventListener("transitionend", this._onTransitionEnd);
    window.removeEventListener("keydown", this._onKey);
    window.removeEventListener("resize", this._onResize);
  }

  // ------------------------------------------------------------ internals

  /**
   * Pre-render the map into an offscreen canvas.
   *
   * Three passes, bottom to top: building blocks, road casing, street
   * surface. Each collision cell becomes a STATIC_SS x STATIC_SS block, so
   * the per-frame cost stays a single `drawImage` plus dots/arrow.
   * Row 0 is minZ (the north edge) so it maps straight to the top.
   */
  _buildStaticLayer() {
    const c = this.collision;
    const cols = c.cols;
    const rows = c.rows;
    const off = document.createElement("canvas");
    off.width = cols * STATIC_SS;
    off.height = rows * STATIC_SS;
    const g = off.getContext("2d");
    g.clearRect(0, 0, off.width, off.height);
    // Pass 0: buildings (under everything else).
    this._paintBuildings(g);
    // Pass 1: casing (dilated by ~1px so every street gets an outline).
    g.fillStyle = COLORS.roadCasing;
    for (let r = 0; r < rows; r++) {
      for (let col = 0; col < cols; col++) {
        if (c.roadMask[r * cols + col] === 1) {
          g.fillRect(col * STATIC_SS - 1, r * STATIC_SS - 1, STATIC_SS + 2, STATIC_SS + 2);
        }
      }
    }
    // Pass 2: street surface.
    g.fillStyle = COLORS.road;
    for (let r = 0; r < rows; r++) {
      for (let col = 0; col < cols; col++) {
        if (c.roadMask[r * cols + col] === 1) {
          g.fillRect(col * STATIC_SS, r * STATIC_SS, STATIC_SS, STATIC_SS);
        }
      }
    }
    this.staticLayer = off;
  }

  /**
   * City blocks from the baked obstacle grid: any ground cell whose obstacle
   * columns rise 2 m or more reads as a building. Houses, shops and towers
   * clear that bar; fences, kerbs and median fins don't — and thin leftovers
   * like sign poles are single sub-pixel cells, so they vanish at map scale.
   * Painted pixel-wise into one ImageData blit (one pass, no per-block
   * draw calls), sitting under the road casing pass.
   */
  _paintBuildings(g) {
    const c = this.collision;
    const mask = c.obstacleMask;
    const bot = c.obstacleBottom;
    const top = c.obstacleTop;
    if (!mask || !bot || !top) return;
    const cols = c.cols;
    const rows = c.rows;
    const oCols = c.oCols;
    const oRows = c.oRows;
    const MIN_SPAN = 2.0;
    const W = cols * STATIC_SS;
    const H = rows * STATIC_SS;
    const img = g.createImageData(W, H);
    const d = img.data;
    // Parsed once: COLORS.building "#2b3138".
    const br = 0x2b;
    const bg = 0x31;
    const bb = 0x38;
    for (let r = 0; r < rows; r++) {
      const or0 = r * 2;
      for (let col = 0; col < cols; col++) {
        // The grids share an origin and 1.0 m ground = 2 x 0.5 m obstacle
        // cells, so each ground cell owns exactly a 2x2 obstacle block.
        const oc0 = col * 2;
        let solid = false;
        for (let or = or0; or < or0 + 2 && !solid; or++) {
          if (or < 0 || or >= oRows) continue;
          const base = or * oCols;
          for (let oc = oc0; oc < oc0 + 2; oc++) {
            if (oc < 0 || oc >= oCols) continue;
            const i = base + oc;
            if (mask[i] && top[i] - bot[i] >= MIN_SPAN) {
              solid = true;
              break;
            }
          }
        }
        if (!solid) continue;
        for (let py = r * STATIC_SS; py < (r + 1) * STATIC_SS; py++) {
          for (let px = col * STATIC_SS; px < (col + 1) * STATIC_SS; px++) {
            const o = (py * W + px) * 4;
            d[o] = br;
            d[o + 1] = bg;
            d[o + 2] = bb;
            d[o + 3] = 255;
          }
        }
      }
    }
    g.putImageData(img, 0, 0);
  }

  /** Size the backing store for DPR and reflect expanded/collapsed CSS. */
  _applySize() {
    this.canvas.classList.toggle("expanded", this.expanded);
    // Read the real layout size (the stylesheet clamps the expanded size
    // with min(), so a fixed constant would stretch on small screens).
    const fallback = this.expanded ? LARGE_PX : SMALL_PX;
    const w = this.canvas.clientWidth || fallback;
    const h = this.canvas.clientHeight || fallback;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.canvas.title = this.expanded ? "Click to shrink minimap" : "Click to expand map";
    this.canvas.setAttribute("aria-label", this.expanded ? "Shrink map" : "Expand map");
  }

  /** Shortest-arc smoothing so the map rotation never snaps or spins. */
  _smoothHeading(target, dt) {
    if (this.displayHeading === null || this.displayHeading === undefined) {
      this.displayHeading = target;
      return this.displayHeading;
    }
    let d = target - this.displayHeading;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    const t = dt && dt > 0 ? 1 - Math.exp(-8 * dt) : 0.2;
    this.displayHeading += d * Math.min(1, t);
    return this.displayHeading;
  }

  /**
   * Draw one frame.
   * - Collapsed: heading-up rotating follow view (map rotates, player arrow
   *   always points UP — Far Cry / GTA style).
   * - Expanded: static full-map view, north-up, fixed (does not move or
   *   rotate with the player — only the dots move).
   * @param player PlayerVehicle (uses .state {x,z,heading})
   * @param traffic TrafficSystem (uses .vehicles[].state {x,z}) — optional
   * @param dt frame delta seconds (for rotation smoothing) — optional
   */
  update(player, traffic = null, dt = 0) {
    const ctx = this.ctx;
    if (!ctx || !player?.state) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = this.canvas.width / dpr;
    const H = this.canvas.height / dpr;
    if (!W || !H) return;

    ctx.save();
    ctx.scale(dpr, dpr);

    // Clip to the visible shape: the CSS already rounds the element, but the
    // canvas bitmap itself is square, so clip here too to keep dots/arrows
    // from painting into the transparent corners of the small circle.
    ctx.clearRect(0, 0, W, H);
    ctx.beginPath();
    if (this.expanded) {
      if (typeof ctx.roundRect === "function") ctx.roundRect(0, 0, W, H, 14);
      else ctx.rect(0, 0, W, H);
    } else {
      ctx.arc(W / 2, H / 2, Math.min(W, H) / 2, 0, Math.PI * 2);
    }
    ctx.clip();

    // Background: subtle vertical gradient.
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, COLORS.bgTop);
    bg.addColorStop(1, COLORS.bgBottom);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    const race = this.race?.getMinimapData?.() ?? null;
    const hideSymbols = this.isRaceActive(race);

    if (this.expanded) {
      this._drawFullMap(ctx, W, H, player, traffic, race, hideSymbols);
    } else {
      const heading = this._smoothHeading(player.state.heading, dt);
      this._drawRotatingWorld(ctx, W, H, player, traffic, SMALL_HALF_RANGE, heading, race);
      if (!hideSymbols) {
        this._drawGarageCollapsed(ctx, W, H, player, heading);
        this._drawRepairCollapsed(ctx, W, H, player, heading);
        this._drawEventsCollapsed(ctx, W, H, player, heading);
      }
      this._drawChrome(ctx, W, H, heading);

      // Player arrow fixed at the centre, always pointing UP.
      this._drawPlayerArrowUp(ctx, W / 2, H / 2, 8);

      // Rotating "N" pill showing where world north currently is.
      this._drawNorthPill(ctx, W, H, heading);
    }

    ctx.restore();
  }

  /**
   * Expanded square: static full-map view, north-up and fixed.
   * The map never moves or rotates — only the player/traffic dots move.
   */
  _drawFullMap(ctx, W, H, player, traffic, race = null, hideSymbols = false) {
    const c = this.collision;
    const worldW = c.maxX - c.minX;
    const worldH = c.maxZ - c.minZ;
    const scale = Math.min(W / worldW, H / worldH);
    const dw = worldW * scale;
    const dh = worldH * scale;
    const dx = (W - dw) / 2;
    const dy = (H - dh) / 2;

    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(
      this.staticLayer,
      0, 0, this.staticLayer.width, this.staticLayer.height,
      dx, dy, dw, dh,
    );

    const toMap = (x, z) => [dx + (x - c.minX) * scale, dy + (z - c.minZ) * scale];

    if (race) this._drawRaceFull(ctx, race, toMap);

    if (traffic?.vehicles?.length) {
      for (const v of traffic.vehicles) {
        const s = v.state;
        if (!s) continue;
        const [mx, my] = toMap(s.x, s.z);
        if (mx < 0 || my < 0 || mx > W || my > H) continue;
        ctx.beginPath();
        ctx.arc(mx, my, 3.2, 0, Math.PI * 2);
        ctx.fillStyle = COLORS.traffic;
        ctx.fill();
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = COLORS.trafficOutline;
        ctx.stroke();
      }
    }

    if (!hideSymbols) {
      // Garage house icon (under the player arrow so the car stays on top).
      if (this.garage) {
        const [gx, gy] = toMap(this.garage.x, this.garage.z);
        if (gx >= -12 && gy >= -12 && gx <= W + 12 && gy <= H + 12) {
          this._drawGarageHouse(ctx, gx, gy, 9);
        }
      }

      // Repair wrenches: the full map always shows every spot.
      if (this.repairSpots?.length) {
        for (const s of this.repairSpots) {
          const [rx, ry] = toMap(s.x, s.z);
          if (rx >= -12 && ry >= -12 && rx <= W + 12 && ry <= H + 12) {
            this._drawRepairWrench(ctx, rx, ry, 9);
          }
        }
      }

      // Discoverable race-event markers (active green / completed gray).
      this._drawEventsFull(ctx, toMap);
    }

    // Player arrow rotates with the car on the static map.
    const [px, py] = toMap(player.state.x, player.state.z);
    this._drawPlayerArrowHeading(ctx, px, py, player.state.heading, 8);

    // Static north label.
    ctx.fillStyle = "rgba(255,255,255,0.65)";
    ctx.font = "600 11px system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillText("N ↑", 10, 8);
  }

  /**
   * Draw roads + traffic in the rotated frame: translate to the player,
   * rotate so the heading points up, then paint the world around them.
   */
  _drawRotatingWorld(ctx, W, H, player, traffic, half, heading, race = null) {
    const c = this.collision;
    const px = player.state.x;
    const pz = player.state.z;
    const s = Math.min(W, H) / (half * 2); // canvas px per world metre

    ctx.save();
    ctx.translate(W / 2, H / 2);
    // Heading-up frame WITHOUT mirroring: rotate() by h + PI alone puts
    // forward on screen-up but lands the vehicle's own right on screen-LEFT
    // (a reflection, not a rotation - left/right come out swapped). Flipping
    // Y inside the frame restores the chirality, so forward is up AND right
    // is right. Everything in this frame (roads, track, dots, arrows,
    // diamond) is corrected together.
    ctx.rotate(-heading);
    ctx.scale(1, -1);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(
      this.staticLayer,
      0, 0, this.staticLayer.width, this.staticLayer.height,
      (c.minX - px) * s,
      (c.minZ - pz) * s,
      c.cols * c.cell * s,
      c.rows * c.cell * s,
    );

    if (race) this._drawRaceRotating(ctx, race, px, pz, s, half);

    // Traffic dots live in the same rotated frame so they track the roads.
    if (traffic?.vehicles?.length) {
      const cull = half * 1.5;
      for (const v of traffic.vehicles) {
        const st = v.state;
        if (!st) continue;
        const dxw = st.x - px;
        const dzw = st.z - pz;
        if (dxw * dxw + dzw * dzw > cull * cull) continue;
        const mx = dxw * s;
        const my = dzw * s;
        ctx.beginPath();
        ctx.arc(mx, my, 2.8, 0, Math.PI * 2);
        ctx.fillStyle = COLORS.traffic;
        ctx.fill();
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = COLORS.trafficOutline;
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  // ------------------------------------------------------------- race layer

  /**
   * The guided race track on the static (expanded) map: the circuit as a line,
   * every checkpoint as a tick, the next checkpoint highlighted, the start line
   * marked, the event icon, and the rivals as arrows (race only).
   */
  _drawRaceFull(ctx, race, toMap) {
    ctx.save();
    this._strokePath(ctx, race.points, (x, z) => toMap(x, z), 3.4, COLORS.trackCasing);
    this._strokePath(ctx, race.points, (x, z) => toMap(x, z), 1.8, COLORS.track);

    for (const g of race.gates) {
      const [gx, gy] = toMap(g.x, g.z);
      const isNext = g.index === race.nextGate && !g.isFinish;
      const r = isNext ? 4.4 : 2.6;
      ctx.beginPath();
      ctx.arc(gx, gy, r, 0, Math.PI * 2);
      ctx.fillStyle = g.isFinish ? COLORS.start : isNext ? COLORS.gateNext : COLORS.gate;
      ctx.fill();
      ctx.lineWidth = 1.2;
      ctx.strokeStyle = "rgba(0,0,0,0.7)";
      ctx.stroke();
    }

    this._drawRaceRacers(ctx, race, (x, z) => toMap(x, z), 5);
    // Event diamonds are drawn by the events layer (setEvents), not here.
    ctx.restore();
  }

  /**
   * The same layer inside the rotated follow view. Everything is drawn in the
   * already-rotated frame, in world-relative metres scaled by `s`, so the track
   * rotates with the roads under it. The event icon gets an edge arrow when
   * the start line is off-screen, so the player can always drive to it.
   *
   * The circuit itself draws as a REVEAL WINDOW around the car (the upcoming
   * stretch fully lit, the passed stretch fading out behind it) instead of
   * the whole track at once, so a road the race crosses twice never reads as
   * two live routes. The expanded map still shows the full circuit.
   */
  _drawRaceRotating(ctx, race, px, pz, s, half) {
    const cull = half * 1.6;
    const win = this._trackWindow(race);
    ctx.save();
    if (win) {
      this._strokeWindowedTrack(ctx, win, px, pz, s, cull);
    } else {
      const visible = [];
      for (const p of race.points) {
        const dx = p.x - px;
        const dz = p.z - pz;
        // Cull hard here: this view shows ~220 m, so most of a 1 km circuit is
        // off-screen and there is no point building its path each frame.
        if (dx * dx + dz * dz > cull * cull) {
          visible.push(null);
          continue;
        }
        visible.push([dx * s, dz * s]);
      }
      this._strokeSegments(ctx, visible, 5, COLORS.trackCasing);
      this._strokeSegments(ctx, visible, 2.4, COLORS.track);
    }

    this._drawRaceGatesRotating(ctx, race, win, px, pz, s);

    this._drawRaceRacers(ctx, race, (x, z) => [(x - px) * s, (z - pz) * s], 5);
    // Event diamonds are drawn by the events layer (setEvents), not here.
    ctx.restore();
  }

  /**
   * Reveal-window descriptor for the collapsed follow view, or null when the
   * window cannot be built (no track showing, no path data, or a circuit so
   * short the window would cover all of it — then the legacy full draw
   * applies). The window anchors on the player's AUTHORITATIVE along-track
   * distance (RaceProgress, branch-correct on overlapping roads), so a
   * parallel/overlapping stretch never leaks into view.
   */
  _trackWindow(race) {
    if (!race?.points?.length) return null;
    const path = race.trackPath;
    const L = race.trackLength;
    const playerS = race.playerS;
    if (!path || !(L > TRACK_AHEAD_M + TRACK_BEHIND_M)) return null;
    if (playerS == null || !Number.isFinite(playerS)) return null;
    return {
      path,
      length: L,
      playerS,
      open: !!race.trackOpen,
      finished: !!race.finished,
      isLastLap: !!race.isLastLap,
      laps: race.laps ?? 1,
    };
  }

  /** Fade band index (1-based) for `behindM` metres behind the car, or -1 when older than the window. */
  _fadeBand(behindM) {
    for (let i = 0; i < TRACK_FADE_BANDS.length; i++) {
      if (behindM <= TRACK_FADE_BANDS[i][0]) return i + 1;
    }
    return -1;
  }

  /** Alpha for a band: 0 is the upcoming stretch (full brightness). */
  _fadeAlpha(band) {
    return band <= 0 ? 1 : TRACK_FADE_BANDS[band - 1][1];
  }

  /** Stroke one continuous run of already-projected points. */
  _strokeRun(ctx, pts, width, color) {
    if (pts.length < 2) return;
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    ctx.stroke();
  }

  /**
   * Draw the reveal window: the upcoming stretch fully lit, the passed
   * stretch fading band by band, everything else hidden. Samples the
   * track's arclength path directly (exact offsets, uniform spacing), so
   * only the road the player is actually on ever paints.
   */
  _strokeWindowedTrack(ctx, win, px, pz, s, cull) {
    // Project the window, splitting it into per-band runs (band 0 =
    // upcoming, 1..N = history). View culling breaks runs like the legacy
    // path used to.
    const bands = Array.from({ length: 1 + TRACK_FADE_BANDS.length }, () => []);
    let cur = null;
    // For open (point-to-point) tracks or on the final lap, clamp the sampling range so we never
    // reveal track beyond the finish line, or if the race has finished, don't reveal any upcoming track.
    let minO = -TRACK_BEHIND_M;
    let maxO = TRACK_AHEAD_M;
    if (win.finished) {
      maxO = 0;
    } else if (win.open || win.isLastLap) {
      maxO = Math.max(0, Math.min(TRACK_AHEAD_M, win.length - win.playerS));
    }
    if (win.open) {
      minO = Math.max(-TRACK_BEHIND_M, -win.playerS);
    }
    for (let o = minO; o <= maxO; o += TRACK_WINDOW_STEP) {
      const sampleS = (win.open || win.isLastLap)
        ? Math.max(0, Math.min(win.playerS + o, win.length))
        : win.playerS + o;
      const p = win.path.sample(sampleS);
      const dx = p.x - px;
      const dz = p.z - pz;
      let band = -1;
      if (dx * dx + dz * dz <= cull * cull) {
        band = o >= 0 ? 0 : this._fadeBand(-o);
      }
      if (band < 0) {
        cur = null;
        continue;
      }
      if (!cur || cur.band !== band) {
        cur = { band, pts: [] };
        bands[band].push(cur.pts);
      }
      cur.pts.push([dx * s, dz * s]);
    }
    ctx.save();
    for (let b = 0; b < bands.length; b++) {
      const runs = bands[b];
      if (!runs.length) continue;
      ctx.globalAlpha = this._fadeAlpha(b);
      for (const run of runs) {
        this._strokeRun(ctx, run, 5, COLORS.trackCasing);
        this._strokeRun(ctx, run, 2.4, COLORS.track);
      }
    }
    ctx.restore();
  }

  /**
   * Checkpoint dots in the follow view. With a reveal window, only gates
   * inside it draw (upcoming full, passed fading); the NEXT gate always
   * draws while in view so the target never vanishes. Without a window,
   * every gate draws (legacy).
   */
  _drawRaceGatesRotating(ctx, race, win, px, pz, s) {
    for (const g of race.gates) {
      let alpha = 1;
      if (win) {
        if (win.finished) {
          const behind = (win.open || win.isLastLap)
            ? win.playerS - g.s
            : (((win.playerS - g.s) % win.length) + win.length) % win.length;
          if (behind > 0 && behind <= TRACK_BEHIND_M) {
            alpha = this._fadeAlpha(this._fadeBand(behind));
          } else {
            continue;
          }
        } else {
          const L = win.length;
          let ahead;
          let behind;
          if (win.open || win.isLastLap) {
            ahead = g.s - win.playerS;
            behind = win.playerS - g.s;
          } else {
            ahead = (((g.s - win.playerS) % L) + L) % L;
            behind = (((win.playerS - g.s) % L) + L) % L;
          }
          if (g.index !== race.nextGate) {
            if (ahead >= 0 && ahead <= TRACK_AHEAD_M) alpha = 1;
            else if (behind > 0 && behind <= TRACK_BEHIND_M) alpha = this._fadeAlpha(this._fadeBand(behind));
            else continue;
          }
        }
      }
      const dx = (g.x - px) * s;
      const dz = (g.z - pz) * s;
      const isNext = g.index === race.nextGate && !g.isFinish && !win?.finished;
      const r = isNext ? 6 : 3.6;
      ctx.save();
      if (alpha !== 1) ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.arc(dx, dz, r, 0, Math.PI * 2);
      ctx.fillStyle = g.isFinish ? COLORS.start : isNext ? COLORS.gateNext : COLORS.gate;
      ctx.fill();
      ctx.lineWidth = 1.3;
      ctx.strokeStyle = "rgba(0,0,0,0.75)";
      ctx.stroke();
      ctx.restore();
    }
  }

  /**
   * Garage house in the follow view, drawn in screen space (always upright
   * like the player arrow). The position replays the rotated frame's
   * transform — rotate(-heading) then Y-flip — so the icon sits exactly
   * where the roads put it, with edge pinning when the garage is
   * off-screen (same treatment as the event diamond).
   */
  _drawGarageCollapsed(ctx, W, H, player, heading) {
    if (!this.garage) return;
    const half = SMALL_HALF_RANGE;
    const s = Math.min(W, H) / (half * 2);
    const dxw = this.garage.x - player.state.x;
    const dzw = this.garage.z - player.state.z;
    const ch = Math.cos(heading);
    const sh = Math.sin(heading);
    let mx = (dxw * ch - dzw * sh) * s;
    let my = (-dxw * sh - dzw * ch) * s;
    const dist = Math.hypot(mx, my);
    const R = Math.min(half * s * 0.92, 78);
    if (dist > R + 12) {
      const k = R / (dist || 1);
      mx *= k;
      my *= k;
    }
    this._drawGarageHouse(ctx, W / 2 + mx, H / 2 + my, 8);
  }

  /**
   * Garage marker: a small filled green house (body + roof + door) with a
   * soft glow and dark outline, so it reads on any road color.
   */
  _drawGarageHouse(ctx, x, y, size) {
    ctx.save();
    // Soft glow so the mark reads on any road color.
    ctx.beginPath();
    ctx.arc(x, y, size + 5, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(53,255,105,0.12)";
    ctx.fill();
    // Body.
    const bw = size * 0.58;
    const top = y - size * 0.12;
    const bot = y + size * 0.85;
    ctx.beginPath();
    ctx.rect(x - bw, top, bw * 2, bot - top);
    ctx.fillStyle = COLORS.garage;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = COLORS.garageOutline;
    ctx.stroke();
    // Roof.
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x + size * 0.8, top);
    ctx.lineTo(x - size * 0.8, top);
    ctx.closePath();
    ctx.fillStyle = COLORS.garage;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.lineJoin = "round";
    ctx.strokeStyle = COLORS.garageOutline;
    ctx.stroke();
    // Door cutout.
    const dw = size * 0.22;
    ctx.fillStyle = COLORS.garageOutline;
    ctx.fillRect(x - dw / 2, bot - size * 0.3, dw, size * 0.3);
    ctx.restore();
  }

  /**
   * Repair wrenches in the follow view. Same screen-space projection as the
   * garage mark, but strictly culled: a wrench draws ONLY while its spot is
   * inside the dial circle - never pinned to the edge.
   */
  _drawRepairCollapsed(ctx, W, H, player, heading) {
    if (!this.repairSpots?.length) return;
    const half = SMALL_HALF_RANGE;
    const s = Math.min(W, H) / (half * 2);
    const ch = Math.cos(heading);
    const sh = Math.sin(heading);
    const R = Math.min(half * s * 0.92, 78);
    for (const spot of this.repairSpots) {
      const dxw = spot.x - player.state.x;
      const dzw = spot.z - player.state.z;
      const mx = (dxw * ch - dzw * sh) * s;
      const my = (-dxw * sh - dzw * ch) * s;
      if (Math.hypot(mx, my) > R + 6) continue;
      this._drawRepairWrench(ctx, W / 2 + mx, H / 2 + my, 8);
    }
  }

  /**
   * Discoverable race-event markers in the follow view (screen space). Active
   * events are green and edge-pinned to the dial so the player can always head
   * to them; completed events are gray and culled when outside the dial (like
   * the repair wrenches). Mastered events were removed from the list upstream.
   */
  _drawEventsCollapsed(ctx, W, H, player, heading) {
    if (!this.events?.length) return;
    const half = SMALL_HALF_RANGE;
    const s = Math.min(W, H) / (half * 2);
    const ch = Math.cos(heading);
    const sh = Math.sin(heading);
    const R = Math.min(half * s * 0.92, 78);
    for (const ev of this.events) {
      const dxw = ev.x - player.state.x;
      const dzw = ev.z - player.state.z;
      let mx = (dxw * ch - dzw * sh) * s;
      let my = (-dxw * sh - dzw * ch) * s;
      const dist = Math.hypot(mx, my);
      const active = ev.state === "active";
      if (dist > R + 6) {
        if (!active) continue; // completed: cull when off the dial
        mx = (mx / (dist || 1)) * R; // active: pin to the dial edge
        my = (my / (dist || 1)) * R;
      }
      const color = active ? COLORS.eventDiamond : COLORS.eventDone;
      const glow = active ? "rgba(53,255,105,0.12)" : "rgba(136,147,160,0.12)";
      this._drawEventDiamond(ctx, W / 2 + mx, H / 2 + my, active ? 8 : 7, color, glow);
    }
  }

  /** Discoverable race-event markers on the expanded map. */
  _drawEventsFull(ctx, toMap) {
    if (!this.events?.length) return;
    for (const ev of this.events) {
      const [x, y] = toMap(ev.x, ev.z);
      const active = ev.state === "active";
      this._drawEventDiamond(
        ctx,
        x,
        y,
        active ? 8 : 7,
        active ? COLORS.eventDiamond : COLORS.eventDone,
        active ? "rgba(53,255,105,0.12)" : "rgba(136,147,160,0.12)",
      );
    }
  }

  /**
   * Repair marker: a small diagonal wrench (open-end head + handle + end
   * hole) with a soft glow and dark outline, so it reads on any road color.
   */
  _drawRepairWrench(ctx, x, y, size) {
    const s = size;
    // Recentre the glyph on the anchor: the diagonal wrench reads heavy
    // toward the head (top-right), so shift it back down-left.
    const ox = x - 0.1 * s;
    const oy = y + 0.07 * s;
    // Handle end -> head base; head centre sits past the handle top-right.
    const hx0 = ox - 0.42 * s;
    const hy0 = oy + 0.55 * s;
    const hx1 = ox + 0.28 * s;
    const hy1 = oy - 0.32 * s;
    const cx = ox + 0.44 * s;
    const cy = oy - 0.5 * s;
    const cr = 0.33 * s;
    // Jaw gap faces away from the handle (up-right).
    const gap = Math.atan2(cy - hy1, cx - hx1);
    const spread = 0.65;
    const trace = (style, width) => {
      ctx.strokeStyle = style;
      ctx.lineWidth = width;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.beginPath();
      ctx.moveTo(hx0, hy0);
      ctx.lineTo(hx1, hy1);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, cr, gap + spread, gap - spread + Math.PI * 2);
      ctx.stroke();
    };
    ctx.save();
    // Soft glow so the mark reads on any road color.
    ctx.beginPath();
    ctx.arc(x, y, s + 5, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(53,255,105,0.12)";
    ctx.fill();
    // Dark outline pass, then the green pass on top.
    trace(COLORS.repairOutline, 0.3 * s + 2.4);
    trace(COLORS.repair, 0.3 * s);
    // Handle-end hole.
    ctx.beginPath();
    ctx.arc(hx0, hy0, 0.09 * s, 0, Math.PI * 2);
    ctx.fillStyle = COLORS.repairOutline;
    ctx.fill();
    ctx.restore();
  }

  /**
   * Event marker: a green hollow diamond, drawn still — no pulse, no
   * breathing. One steady mark for the event.
   */
  _drawEventDiamond(ctx, x, y, size, color = COLORS.eventDiamond, glow = "rgba(53,255,105,0.12)") {
    ctx.save();
    // Soft glow so the hollow mark reads on any road color.
    ctx.beginPath();
    ctx.arc(x, y, size + 4, 0, Math.PI * 2);
    ctx.fillStyle = glow;
    ctx.fill();
    // Hollow diamond: stroke only, no fill.
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x + size, y);
    ctx.lineTo(x, y + size);
    ctx.lineTo(x - size, y);
    ctx.closePath();
    ctx.lineWidth = 1.8;
    ctx.strokeStyle = color;
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Rival markers: small green arrows (same wedge as the player arrow, but
   * smaller), rotated to each car's heading. The angle is world-space in both
   * views — the follow view's frame rotation carries arrows and roads together,
   * exactly like the player arrowHeading helper.
   */
  _drawRaceRacers(ctx, race, project, size) {
    if (!race.racers?.length) return;
    for (const r of race.racers) {
      const [x, y] = project(r.x, r.z);
      this._drawRacerArrow(ctx, x, y, Math.atan2(Math.sin(r.heading), -Math.cos(r.heading)), size, !!r.finished);
    }
  }

  /** One rival wedge: player-arrow shape at racer scale. */
  _drawRacerArrow(ctx, x, y, angle, size, finished = false) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.shadowColor = "rgba(0,0,0,0.6)";
    ctx.shadowBlur = 4;
    ctx.beginPath();
    ctx.moveTo(0, -size - 1);
    ctx.lineTo(size * 0.72, size * 0.75);
    ctx.lineTo(0, size * 0.38);
    ctx.lineTo(-size * 0.72, size * 0.75);
    ctx.closePath();
    ctx.fillStyle = finished ? COLORS.gatePassed : COLORS.racer;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 0.9;
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
  }

  /** Stroke a closed polyline given a world->canvas projection. */
  _strokePath(ctx, points, project, width, color) {
    if (!points?.length) return;
    ctx.beginPath();
    for (let i = 0; i < points.length; i++) {
      const [x, y] = project(points[i].x, points[i].z);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.strokeStyle = color;
    ctx.stroke();
  }

  /** Stroke the visible runs of an already-projected point list. */
  _strokeSegments(ctx, projected, width, color) {
    ctx.lineWidth = width;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.strokeStyle = color;
    ctx.beginPath();
    let drawing = false;
    for (const p of projected) {
      if (!p) {
        drawing = false;
        continue;
      }
      if (!drawing) ctx.moveTo(p[0], p[1]);
      else ctx.lineTo(p[0], p[1]);
      drawing = true;
    }
    ctx.stroke();
  }

  /** Static chrome for the small dial: range rings + edge vignette. */
  _drawChrome(ctx, W, H, heading) {
    void heading;
    const cx = W / 2;
    const cy = H / 2;
    const R = Math.min(W, H) / 2;
    ctx.save();
    ctx.strokeStyle = COLORS.ring;
    ctx.lineWidth = 1;
    for (const f of [0.45, 0.8]) {
      ctx.beginPath();
      ctx.arc(cx, cy, R * f, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Vignette to seat the map inside the glass.
    const vg = ctx.createRadialGradient(cx, cy, R * 0.55, cx, cy, R);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.38)");
    ctx.fillStyle = vg;
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  /** Player wedge, fixed pointing up (the map rotates beneath it). */
  _drawPlayerArrowUp(ctx, x, y, size) {
    ctx.save();
    ctx.translate(x, y);
    ctx.shadowColor = "rgba(0,0,0,0.6)";
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.moveTo(0, -size - 1);
    ctx.lineTo(size * 0.72, size * 0.75);
    ctx.lineTo(0, size * 0.38);
    ctx.lineTo(-size * 0.72, size * 0.75);
    ctx.closePath();
    ctx.fillStyle = COLORS.player;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1.8;
    ctx.strokeStyle = COLORS.playerOutline;
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
  }

  /** Player wedge on the static map, rotated to the car's heading. */
  _drawPlayerArrowHeading(ctx, x, y, heading, size) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.PI - heading);
    ctx.shadowColor = "rgba(0,0,0,0.6)";
    ctx.shadowBlur = 6;
    ctx.beginPath();
    ctx.moveTo(0, -size - 1);
    ctx.lineTo(size * 0.72, size * 0.75);
    ctx.lineTo(0, size * 0.38);
    ctx.lineTo(-size * 0.72, size * 0.75);
    ctx.closePath();
    ctx.fillStyle = COLORS.player;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = 1.8;
    ctx.strokeStyle = COLORS.playerOutline;
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Compass pill: world north (-Z) lands on screen direction
   * (sin h, cos h) in the unmirrored heading-up frame — it orbits the dial
   * as the car turns, exactly like a Far Cry compass.
   */
  _drawNorthPill(ctx, W, H, heading) {
    const nx = Math.sin(heading);
    const ny = Math.cos(heading);
    const R = Math.min(W, H) / 2;
    const rad = Math.min(11, R * 0.11) + 3;
    const x = W / 2 + nx * (R - rad - 7);
    const y = H / 2 + ny * (R - rad - 7);
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, rad, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(4,8,14,0.72)";
    ctx.fill();
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.stroke();
    ctx.fillStyle = "#ff4d5e";
    ctx.font = `800 ${Math.round(rad * 1.05)}px system-ui, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("N", x, y + 0.5);
    ctx.restore();
  }
}
