import { Color3, MeshBuilder, StandardMaterial, Vector3 } from "@babylonjs/core";
import { OBSTACLE_SOURCE } from "../engine/MapCollision.js";

/**
 * Debug overlay that marks WHERE collision is being detected.
 *
 * This is instrumentation, not a fix. It exists to answer one question by eye:
 * is every block caused by a car touching real geometry, or is the car being
 * stopped by empty space?
 *
 * The collision bake is a rasterisation, and two of its shortcuts can produce
 * cells that are not on anything the player can see:
 *
 *   - a mesh smaller than 25 m2 with no side over 8 m is baked as its world
 *     AABB, so a rotated or diagonal mesh gets a rectangular footprint larger
 *     than the mesh itself;
 *   - large meshes contribute only their steep wall triangles, so roofs and
 *     floors are not solid and a car can pass under an overhang.
 *
 * Both are legitimate design choices, but both can look like a phantom wall, so
 * the overlay draws them differently:
 *
 *   GREEN  block backed by a real triangle of a solid mesh - expected
 *   RED    block that is only inside a mesh's bounding box - the mesh is not
 *          actually here, and the box is what the car is hitting
 *   BLUE   block from the height field (an unclimbable step / wall)
 *
 * Enabling it with `?hits=1` turns on provenance tracking in the bake, which
 * costs about 3 bytes per 0.5 m cell, so it is off for normal play.
 */

/** How long a freshly-recorded contact stays on screen, seconds. */
const LIVE_LIFE = 2.5;
/** Contacts older than this are forgotten, keeping the marker pool bounded. */
const HISTORY_LIFE = 45;
/** Ceiling on remembered contacts, so a long session cannot grow without end. */
const MAX_HITS = 900;
/** Ceiling on source-mesh boxes drawn at once. */
const MAX_BOXES = 60;

const COLOR_FROM = {
  [OBSTACLE_SOURCE.TRIANGLE]: new Color3(0.15, 1, 0.35),
  [OBSTACLE_SOURCE.AABB]: new Color3(1, 0.12, 0.12),
  3: new Color3(0.2, 0.5, 1), // height field: an unclimbable step
};

export class CollisionDebug {
  constructor(scene, { trail = true } = {}) {
    this.scene = scene;
    this.trail = trail;
    this.hits = [];
    this.time = 0;
    this.enabled = true;

    // --- markers: one sphere, many thin instances --------------------------
    // Thin instances rather than a mesh per contact: a busy junction produces
    // hundreds of hits a second and individual meshes would choke the scene.
    this.marker = MeshBuilder.CreateSphere("hitMarker", { diameter: 0.42, segments: 6 }, scene);
    const mat = new StandardMaterial("hitMarkerMat", scene);
    mat.emissiveColor = Color3.White();
    mat.diffuseColor = Color3.Black();
    mat.specularColor = Color3.Black();
    mat.disableLighting = true;
    this.marker.material = mat;
    this.marker.isPickable = false;
    this.marker.alwaysSelectAsActiveMesh = true;
    this.marker.renderingGroupId = 1;
    this.marker.thinInstanceEnablePicking = false;
    this.markerMatrices = new Float32Array(MAX_HITS * 16);
    this.markerColors = new Float32Array(MAX_HITS * 4);
    this.marker.thinInstanceSetBuffer("matrix", this.markerMatrices, 16, false);
    this.marker.thinInstanceSetBuffer("color", this.markerColors, 4, false);
    this.marker.thinInstanceCount = 0;

    // --- source-mesh boxes: where a block is "box only" --------------------
    this.boxMat = new StandardMaterial("hitBoxMat", scene);
    this.boxMat.wireframe = true;
    this.boxMat.emissiveColor = new Color3(1, 0.15, 0.15);
    this.boxMat.disableLighting = true;
    this.boxMat.backFaceCulling = false;
    this.boxes = [];
    for (let i = 0; i < MAX_BOXES; i++) {
      const b = MeshBuilder.CreateBox(`hitBox${i}`, { size: 1 }, scene);
      b.material = this.boxMat;
      b.isPickable = false;
      b.renderingGroupId = 1;
      b.setEnabled(false);
      b.alwaysSelectAsActiveMesh = true;
      this.boxes.push(b);
    }

    this.highlighted = new Set();
    this.tally = { triangle: 0, aabb: 0, step: 0, wheel: 0 };
    // Unmerged log of recent contacts, so analysis tools can sample hundreds of
    // real contacts instead of the handful that survive position-merging.
    this.raw = [];
    this.rawCap = 4000;
    this.boxList = document.createElement("div");
    this.boxList.className = "hit-list";
    this.boxList.style.cssText =
      "position:fixed;left:8px;bottom:8px;z-index:20;max-width:46ch;font:11px/1.45 ui-monospace," +
      "monospace;color:#dfe6ee;background:rgba(8,10,14,.82);border:1px solid #2a3340;" +
      "border-radius:6px;padding:6px 8px;pointer-events:none;white-space:pre-wrap";
    document.body.appendChild(this.boxList);
  }

  /**
   * Called with the contact records a vehicle's `blocked()` produced this frame.
   * Records at the same spot are merged so a car grinding along a wall does not
   * fill the whole budget with one point.
   */
  record(contacts, who = "traffic") {
    if (!this.enabled || !contacts || !contacts.length) return;
    for (const c of contacts) {
      const bucket =
        c.kind === "step" ? "step" : c.kind === "wheel" ? "wheel" : c.from === OBSTACLE_SOURCE.AABB ? "aabb" : "triangle";
      this.tally[bucket]++;
      const h = {
        x: c.x,
        z: c.z,
        y: c.y,
        born: this.time,
        who,
        kind: c.kind,
        mesh: c.mesh ?? null,
        from: c.from,
        box: c.box ?? null,
        meshRef: c.meshRef ?? null,
        bucket,
      };
      this.raw.push(h);
      if (this.raw.length > this.rawCap) this.raw.splice(0, this.raw.length - this.rawCap);
      this.hits.push(h);
    }
    // Merge records that land on the same cell: a car resting against a wall
    // reports the same contact every frame, and 60 copies of it would push
    // every other hit out of the pool.
    this.hits.sort((a, b) => a.born - b.born);
    const merged = [];
    for (const h of this.hits) {
      const dup = merged.find((m) => Math.abs(m.x - h.x) < 0.6 && Math.abs(m.z - h.z) < 0.6);
      if (dup) dup.born = h.born;
      else merged.push(h);
    }
    if (merged.length > MAX_HITS) merged.splice(0, merged.length - MAX_HITS);
    this.hits = merged;
  }

  update(dt) {
    this.time += dt;
    this.hits = this.hits.filter((h) => this.time - h.born < HISTORY_LIFE);
    this._drawMarkers();
    this._drawBoxes();
    this._drawList();
  }

  _drawMarkers() {
    let n = 0;
    const now = this.time;
    for (const h of this.hits) {
      if (n >= MAX_HITS) break;
      const age = now - h.born;
      // Fresh contacts are full size and solid; older ones shrink and dim, so
      // "what is hitting me right now" reads apart from "where has this
      // happened".
      const fade = age < LIVE_LIFE ? 1 : Math.max(0.12, 1 - (age - LIVE_LIFE) / (HISTORY_LIFE - LIVE_LIFE));
      const s = (h.kind === "column" ? 0.42 : 0.3) * (0.5 + 0.5 * fade);
      const o = n * 16;
      // column-major 4x4: scale on the diagonal, translation in the last row
      this.markerMatrices[o + 0] = s;
      this.markerMatrices[o + 5] = s;
      this.markerMatrices[o + 10] = s;
      this.markerMatrices[o + 15] = 1;
      this.markerMatrices[o + 12] = h.x;
      this.markerMatrices[o + 13] = h.y;
      this.markerMatrices[o + 14] = h.z;
      const col = COLOR_FROM[h.from] ?? Color3.White();
      const c = n * 4;
      this.markerColors[c + 0] = col.r;
      this.markerColors[c + 1] = col.g;
      this.markerColors[c + 2] = col.b;
      this.markerColors[c + 3] = fade;
      n++;
    }
    this.marker.thinInstanceCount = n;
    if (n > 0) {
      this.marker.thinInstanceBufferUpdated("matrix");
      this.marker.thinInstanceBufferUpdated("color");
      this.marker.setEnabled(true);
    } else {
      this.marker.setEnabled(false);
    }
  }

  /** Wireframe boxes around the meshes that caused AABB-only blocks. */
  _drawBoxes() {
    const recent = this.hits.filter((h) => h.box && this.time - h.born < 12);
    this.boxes.forEach((b, i) => {
      const h = recent[i];
      if (!h) {
        b.setEnabled(false);
        return;
      }
      const k = h.box;
      b.setEnabled(true);
      b.position.set((k.minX + k.maxX) / 2, (k.minY + k.maxY) / 2, (k.minZ + k.maxZ) / 2);
      b.scaling.set(Math.max(k.maxX - k.minX, 0.05), Math.max(k.maxY - k.minY, 0.05), Math.max(k.maxZ - k.minZ, 0.05));
    });
  }

  _drawList() {
    const t = this.tally;
    const worst = this.hits
      .filter((h) => h.bucket === "aabb")
      .slice(-6)
      .map((h) => `  ${h.mesh ?? "?"} @ ${h.x.toFixed(0)},${h.z.toFixed(0)}`)
      .join("\n");
    this.boxList.textContent =
      `collision hits  tri ${t.triangle}  AABB-only ${t.aabb}  step ${t.step}  wheel ${t.wheel}\n` +
      `red = blocked by a mesh's bounding box, not its geometry` +
      (worst ? `\nbox-only sources:\n${worst}` : "");
  }

  dispose() {
    this.marker.dispose();
    for (const b of this.boxes) b.dispose();
    this.boxList.remove();
  }
}

/**
 * Attaches a follower to the debug overlay.
 *
 * `follow` is called with (x, z, heading) each time the follower is asked
 * whether it is blocked; when it is, the contact records land in the overlay.
 * The collector is only allocated while a block actually happens, so the
 * no-collision path costs nothing.
 */
export function instrumentFollower(follower, debug, who) {
  const original = follower.blocked.bind(follower);
  follower.blocked = (x, z, heading, hits) => {
    if (!debug.enabled) return original(x, z, heading, hits);
    const collected = hits ?? [];
    const blocked = original(x, z, heading, collected);
    if (blocked) debug.record(collected, who);
    return blocked;
  };
}
