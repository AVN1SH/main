/**
 * Race-event progression: which events are finished/mastered, and which show
 * on the map right now. Pure logic + localStorage; no engine or DOM deps, so it
 * can be unit-driven and reused by the RaceEventManager.
 *
 * Lifecycle per event (see the plan):
 *   not finished            -> a "new" event (green, edge-followed), startable
 *   completed (2nd/3rd)     -> gray, cull-if-outside, still startable to win 1st
 *   mastered (1st)          -> removed from the map entirely
 *
 * At most `MAX_ACTIVE` *new* (not-yet-finished) events are revealed at once;
 * finishing one (any podium place) reveals the next by `order`. Completed
 * (not mastered) events stay visible until mastered.
 */

const STORAGE_KEY = "streetracer_events";
export const MAX_ACTIVE = 3;

/** @returns { [id]: { completed, mastered, bestPlace, bestTimeMs, bestHits } } */
export function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const obj = JSON.parse(raw);
      if (obj && typeof obj === "object") return obj;
    }
  } catch {
    /* private mode / corrupt: start fresh */
  }
  return {};
}

export function saveProgress(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* private mode: session-only */
  }
}

/** Has this event been finished at least once (podium)? */
export function isFinished(state, id) {
  const s = state[id];
  return !!(s && (s.completed || s.mastered));
}

export function isMastered(state, id) {
  return !!state[id]?.mastered;
}

/**
 * Record a finish. `place` is 1/2/3 for a podium result, 0 (or >3) for a miss.
 * `extra` carries best-time / best-hits for TIME / NOCOLLIDE events. Returns the
 * mutated state (same object) for chaining; caller persists.
 */
export function recordFinish(state, id, place, extra = {}) {
  const s = (state[id] ??= { completed: false, mastered: false, bestPlace: 0 });
  if (place >= 1) {
    if (place <= 3) s.completed = true;
    if (place === 1) s.mastered = true;
    // bestPlace: 1 is best, so keep the smallest non-zero.
    s.bestPlace = s.bestPlace ? Math.min(s.bestPlace, place) : place;
  }
  if (extra.timeMs != null && (s.bestTimeMs == null || extra.timeMs < s.bestTimeMs)) {
    s.bestTimeMs = extra.timeMs;
  }
  if (extra.hits != null && (s.bestHits == null || extra.hits < s.bestHits)) {
    s.bestHits = extra.hits;
  }
  return state;
}

/**
 * Which events are on the map, and in what visual state.
 *
 * @returns {{
 *   active: Event[],      // "new" (not finished) - green, edge-followed, max 3
 *   completed: Event[],   // finished but not mastered - gray, cull-if-outside
 *   startable: Set<id>,   // events the player may begin a race on
 * }}
 */
export function selectEvents(events, state, maxActive = MAX_ACTIVE) {
  const byOrder = [...events].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  const active = [];
  const completed = [];
  for (const ev of byOrder) {
    if (isMastered(state, ev.id)) continue; // gone
    if (isFinished(state, ev.id)) {
      completed.push(ev); // completed (2nd/3rd), replayable, gray
    } else if (active.length < maxActive) {
      active.push(ev); // a revealed "new" event, green
    }
    // else: still locked (not yet revealed) — omitted
  }
  const startable = new Set([...active, ...completed].map((e) => e.id));
  return { active, completed, startable };
}
