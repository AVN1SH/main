import { Quaternion, TransformNode, Vector3 } from "@babylonjs/core";

/**
 * Lightweight rig for traffic vehicles.
 *
 * VehicleRig is the player's rig - it is built around `car1.glb` whose
 * wheel nodes are named `lFWheel`, `rFWheel` etc. and whose pivots need
 * surgery to be steerable. The traffic catalogue lives in
 * `public/assets/vehicles/` and uses a completely different convention:
 *
 *   root  (the body mesh, e.g. "Ambulance-Truck")
 *    +- _TireFL / _TireFR / _TireBL / _TireBR
 *
 * The wheel nodes ARE centred on the wheel geometry (unlike `car1.glb`),
 * so a steer + spin pivot can be dropped straight onto each hub with no
 * pivot surgery. Each wheel therefore steers (front axle) and rolls just
 * like the player's car - cheap enough even across twenty cars because
 * it is two node rotations per wheel and no per-frame measurement.
 *
 * One trap the body node sets: it carries a baked +90deg X rotation (the
 * Blender Z-up -> Y-up fix) and a uniform 0.01 scale. In a wheel's LOCAL
 * frame that makes local Y the AXLE (lateral) axis and local Z the
 * vertical axis - NOT the other way round. Steering and suspension act on
 * Z, spin acts on Y. The earlier rig assumed local Y was "up" and so
 * `setSuspension` shoved every wheel onto the car's centre line, hiding
 * them inside the body.
 *
 * What the rig does provide:
 *
 *   - normalised scale, so a `mini-car` is the same on-screen size as a
 *     `pickup` would be in real life (each catalogue entry has a
 *     `targetLength` and the rig scales uniformly to hit it),
 *   - a one-time yaw fix so the model's forward reads as +Z, matching the
 *     rest of the game (`heading = atan2(fwd.x, fwd.z)` etc.),
 *   - per-instance body tinting so two `muscle-car`s do not look like the
 *     same car,
 *   - the wheel offsets and the half-extents the terrain follower needs.
 *
 * The rig does NOT mutate the asset container - every traffic vehicle
 * gets a fresh `instantiateModelsToScene` so they share geometry but
 * carry their own transforms and their own (cloned) materials for the
 * tint.
 */
const WHEEL_RE = /_Tire([FB])([LR])\d*$/i;

export class TrafficRig {
  /**
   * @param scene        Babylon scene
   * @param asset        one entry from `loadVehicleAssets`
   * @param label        name for the rig's nodes (debug only)
   */
  constructor(scene, asset, label = "traffic") {
    this.scene = scene;
    this.asset = asset;
    this.label = label;
    this.diagnostics = {};

    // --- instantiate --------------------------------------------------
    const entries = asset.container.instantiateModelsToScene((n) => n, false);
    const loadedRoot = entries.rootNodes[0];
    if (!loadedRoot) throw new Error(`${label}: vehicle asset produced no root node`);

    // --- wrap in our own root so we can scale and yaw-fix without
    // touching the shared container graph --------------------------------
    this.root = new TransformNode(`${label}_root`, scene);
    this.ground = new TransformNode(`${label}_ground`, scene);
    this.ground.parent = this.root;
    this.model = new TransformNode(`${label}_model`, scene);
    this.model.parent = this.ground;

    loadedRoot.parent = this.model;
    // The loaded root carries its own transform (some authors pre-bake a
    // 90deg turn). Preserve whatever it was, then add the yaw fix on top.
    loadedRoot.computeWorldMatrix(true);

    // --- collect meshes & wheels --------------------------------------
    const meshes = [...loadedRoot.getChildMeshes(false)];
    if (loadedRoot.getClassName && loadedRoot.getClassName() === "Mesh") meshes.push(loadedRoot);

    const wheels = [];
    let bodyMesh = null;
    for (const m of meshes) {
      const match = WHEEL_RE.exec(m.name);
      if (match) {
        wheels.push({
          mesh: m,
          name: m.name,
          front: match[1].toUpperCase() === "F",
          left: match[2].toUpperCase() === "L",
        });
      } else if (!bodyMesh) {
        // The body is the first non-wheel, non-tyre mesh; the catalogue
        // only ships one body mesh per file so this is unambiguous.
        bodyMesh = m;
      }
    }
    if (wheels.length < 4) {
      throw new Error(`${label}: ${wheels.length} wheels found, need at least 4`);
    }
    this.wheels = wheels;
    this.bodyMesh = bodyMesh;

    // --- apply scale to the model node (whole vehicle, wheels included)
    this.model.scaling.setAll(asset.scale);

    // Force the world matrix chain down so the measures below are real.
    this._forceUpdate();

    // --- yaw fix: forward = +Z ----------------------------------------
    // The assets are authored with X as the long axis, so we rotate the
    // model so its measured forward reads as +Z. We measure rather than
    // trust the asset's stored rotation because some files carry a baked
    // 90deg turn and a measured forward is immune to that.
    const fwd = this._measureForward();
    if (fwd) {
      const yawFix = -Math.atan2(fwd.x, fwd.z);
      this.model.rotation.y += yawFix;
      this.diagnostics.yawFixDeg = Math.round((yawFix * 180) / Math.PI, 1);
    }
    this._forceUpdate();

    // --- measure wheel positions in ROOT space (post-scale, post-yaw) --
    this.wheelOffsets = this.wheels.map((w) => {
      const p = this._worldToRoot(w.mesh.getAbsolutePosition(), this.root);
      // `extendSizeWorld` is computed AFTER the model's scaling is
      // applied, so it already includes the asset scale - do not
      // multiply it again. The largest of the box's three half-extents
      // is the wheel's diameter/2.
      const ext = w.mesh.getBoundingInfo().boundingBox.extendSizeWorld;
      const radius = Math.max(ext.x, ext.y, ext.z);
      return {
        name: w.name,
        x: p.x,
        z: p.z,
        radius,
        front: w.front,
        left: w.left,
      };
    });

    const fronts = this.wheelOffsets.filter((w) => w.front);
    const rears = this.wheelOffsets.filter((w) => !w.front);
    const posX = this.wheelOffsets.filter((w) => w.x > 0);
    const negX = this.wheelOffsets.filter((w) => w.x < 0);
    const avg = (list, key) => list.reduce((s, w) => s + w[key], 0) / (list.length || 1);

    this.wheelBase = Math.max(avg(fronts, "z") - avg(rears, "z"), 0.5);
    this.track = Math.max(avg(posX, "x") - avg(negX, "x"), 0.5);
    this.wheelRadius = avg(this.wheelOffsets, "radius");

    // --- body half-extents in ROOT space (for terrain collision) -------
    // Measure the body mesh's world bounds and re-express as half-length
    // (along forward = +Z) and half-width (across = +X), so the terrain
    // follower's oriented rectangle is the body's actual footprint.
    if (bodyMesh) {
      const bb = bodyMesh.getBoundingInfo().boundingBox;
      const lo = bb.minimumWorld;
      const hi = bb.maximumWorld;
      const halfX = (hi.x - lo.x) / 2;
      const halfZ = (hi.z - lo.z) / 2;
      const halfY = (hi.y - lo.y) / 2;
      this.halfLength = Math.max(halfX, halfZ);
      this.halfWidth = Math.min(halfX, halfZ);
      this.height = Math.max(halfY * 2, 0.6);
      this.bodyCenter = new Vector3((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, (lo.z + hi.z) / 2);
    } else {
      // Fallback: derive from scaled raw dimensions.
      const s = asset.scale;
      this.halfLength = (asset.raw.length * s) / 2;
      this.halfWidth = (asset.raw.width * s) / 2;
      this.height = Math.max(asset.raw.height * s, 0.6);
      this.bodyCenter = Vector3.Zero();
    }
    this.clearance = 0.26;

    // --- make the wheels steerable + rollable --------------------------
    // Each wheel gets a steer pivot (rotates about the vertical) and a spin
    // pivot (rotates about the axle), parented into the SAME node the wheel
    // already lives under - the body, which carries the baked +90deg X
    // rotation and the 0.01 scale. In that frame local Y is the axle
    // (lateral) and local Z is vertical, so steering/suspension act on Z and
    // spin on Y. Attaching the pivots any higher (e.g. the glTF __root__)
    // drops the body's 0.01 scale and flings the wheels metres into the sky.
    this._forceUpdate();
    const wheelFrame = this.wheels[0].mesh.parent;
    // World-up expressed in the body's local frame. Left un-normalised so its
    // length (1/scale) turns a metre of suspension travel into a metre of
    // world movement.
    this._suspensionUp = Vector3.TransformNormal(
      new Vector3(0, 1, 0), wheelFrame.getWorldMatrix().clone().invert());

    for (const w of this.wheels) {
      const parent = w.mesh.parent;
      const centerWorld = this._meshWorldCentre(w.mesh);
      const centerLocal = this._worldToRoot(centerWorld, parent);
      const saved = {
        position: w.mesh.position.clone(),
        rotation: w.mesh.rotation.clone(),
        rotationQuaternion: w.mesh.rotationQuaternion ? w.mesh.rotationQuaternion.clone() : null,
        scaling: w.mesh.scaling.clone(),
      };

      const steerPivot = new TransformNode(`${this.label}_steer_${w.name}`, this.scene);
      steerPivot.parent = parent;
      steerPivot.position.copyFrom(centerLocal);
      steerPivot.rotationQuaternion = null;
      steerPivot.rotation.setAll(0);

      const spinPivot = new TransformNode(`${this.label}_spin_${w.name}`, this.scene);
      spinPivot.parent = steerPivot;
      spinPivot.position.setAll(0);
      spinPivot.rotationQuaternion = null;
      spinPivot.rotation.setAll(0);

      // Reparent, then re-express the mesh's offset so the geometry stays put
      // (handles the few assets whose node pivot is a hair off the hub).
      w.mesh.parent = spinPivot;
      w.mesh.position.copyFrom(saved.position.subtract(centerLocal));
      w.mesh.scaling.copyFrom(saved.scaling);
      if (saved.rotationQuaternion) {
        w.mesh.rotationQuaternion = saved.rotationQuaternion;
      } else {
        w.mesh.rotationQuaternion = null;
        w.mesh.rotation.copyFrom(saved.rotation);
      }

      w.steerPivot = steerPivot;
      w.spinPivot = spinPivot;
      w.restPos = centerLocal.clone();
    }
    this._forceUpdate();

    // --- seat the car on its wheels, not its belly ---------------------
    // The terrain follower drops the rig's ROOT onto the road surface, so the
    // wheel-contact plane has to sit at the root origin or the car rides high
    // or low. These assets place their origin at the body with the tyres
    // hanging below it (worst on the trucks), which sank the wheels into the
    // tarmac. Measure the mean wheel-bottom height at rest and lift the whole
    // model by it, so the tyres - not the chassis floor - meet the road.
    let sumCenterY = 0;
    for (const w of this.wheels) sumCenterY += w.steerPivot.getAbsolutePosition().y;
    const contactY = sumCenterY / this.wheels.length - this.wheelRadius;
    this.model.position.y -= contactY;
    this.diagnostics.wheelSeatY = Math.round(contactY * 1000) / 1000;
    this._forceUpdate();

    // The asset is not mirrored (uniform +scale everywhere), so one probe
    // wheel settles the steer and spin signs for every wheel on this rig.
    this.steerAngle = 0;
    this._calibrateWheels();

    // Rest pose - now a true no-op that leaves each wheel on its hub rather
    // than collapsing it onto the centre line.
    this.setSuspension(this.wheels.map(() => 0));
    this.setSteer(0);
    this.spinWheels(0);
  }

  /** World-space centre of a wheel mesh from its local bounding box. */
  _meshWorldCentre(mesh) {
    mesh.computeWorldMatrix(true);
    return Vector3.TransformCoordinates(
      mesh.getBoundingInfo().boundingBox.center,
      mesh.getWorldMatrix(),
    );
  }

  /** The wheel's axle direction, flattened into the root's horizontal plane. */
  _axleDirInRoot(w) {
    const world = Vector3.TransformNormal(new Vector3(0, 1, 0), w.spinPivot.getWorldMatrix());
    const inRoot = Vector3.TransformNormal(world, this.root.getWorldMatrix().clone().invert());
    inRoot.y = 0;
    if (inRoot.lengthSquared() < 1e-9) return new Vector3(1, 0, 0);
    return inRoot.normalize();
  }

  /**
   * Measure the two signs that decide whether the wheels animate the right
   * way. There is no mirror in these assets, so a single probe is enough.
   *
   *   spinSign  - +eps about the axle must carry the TOP of the wheel forward
   *               (the contact patch barely moves, so the top is the honest
   *               point to watch).
   *   steerSign - radians of axle yaw produced per radian of pivot rotation;
   *               setSteer divides by it so a desired wheel angle comes out
   *               the correct way, matching VehicleRig.
   */
  _calibrateWheels() {
    const probe = this.wheels.find((w) => w.front) ?? this.wheels[0];
    const eps = 0.05;

    this._forceUpdate();
    const centerRoot = this._worldToRoot(probe.mesh.getAbsolutePosition(), this.root);
    const topRoot = new Vector3(centerRoot.x, centerRoot.y + this.wheelRadius, centerRoot.z);
    const topWorld = Vector3.TransformCoordinates(topRoot, this.root.getWorldMatrix());
    const topInSpin = Vector3.TransformCoordinates(
      topWorld, probe.spinPivot.getWorldMatrix().clone().invert());
    probe.spinPivot.rotation.y = eps;
    this._forceUpdate();
    const movedWorld = Vector3.TransformCoordinates(topInSpin, probe.spinPivot.getWorldMatrix());
    probe.spinPivot.rotation.y = 0;
    this._forceUpdate();
    const movedRoot = this._worldToRoot(movedWorld, this.root);
    this.spinSign = movedRoot.z - topRoot.z >= 0 ? 1 : -1;

    const axle0 = this._axleDirInRoot(probe);
    probe.steerPivot.rotation.z = eps;
    this._forceUpdate();
    const axle1 = this._axleDirInRoot(probe);
    probe.steerPivot.rotation.z = 0;
    this._forceUpdate();
    const cross = axle0.x * axle1.z - axle0.z * axle1.x;
    const dot = axle0.x * axle1.x + axle0.z * axle1.z;
    const turned = Math.atan2(cross, dot);
    this.steerSign = Math.abs(turned) < 1e-6 ? -1 : turned / eps;

    this.diagnostics.spinSign = this.spinSign;
    this.diagnostics.steerSign = Math.round(this.steerSign * 100) / 100;
  }

  /** Forward unit vector measured from front vs rear wheel positions. */
  _measureForward() {
    this._forceUpdate();
    const fronts = this.wheels.filter((w) => w.front);
    const rears = this.wheels.filter((w) => !w.front);
    if (!fronts.length || !rears.length) return null;

    const fm = new Vector3(0, 0, 0);
    for (const w of fronts) fm.addInPlace(w.mesh.getAbsolutePosition());
    fm.scaleInPlace(1 / fronts.length);
    const rm = new Vector3(0, 0, 0);
    for (const w of rears) rm.addInPlace(w.mesh.getAbsolutePosition());
    rm.scaleInPlace(1 / rears.length);

    const fwd = fm.subtract(rm);
    fwd.y = 0;
    if (fwd.lengthSquared() < 1e-6) return null;
    return fwd.normalize();
  }

  _worldToRoot(worldPoint, space) {
    space.computeWorldMatrix(true);
    return Vector3.TransformCoordinates(worldPoint, space.getWorldMatrix().clone().invert());
  }

  _forceUpdate() {
    this.root.computeWorldMatrix(true);
    this.ground.computeWorldMatrix(true);
    this.model.computeWorldMatrix(true);
    for (const w of this.wheels) {
      w.steerPivot?.computeWorldMatrix(true);
      w.spinPivot?.computeWorldMatrix(true);
      w.mesh.computeWorldMatrix(true);
    }
    if (this.bodyMesh) this.bodyMesh.computeWorldMatrix(true);
  }

  setPosition(x, y, z) {
    this.root.position.set(x, y, z);
  }

  setHeading(heading) {
    this.root.rotation.y = heading;
  }

  /**
   * Terrain pitch/roll applied to the whole vehicle so it lies along the
   * road's surface. Mirrors VehicleRig.setGroundTilt.
   * @param pitch rotation about the car's right axis (negative = nose up)
   * @param roll  rotation about the car's forward axis
   */
  setGroundTilt(pitch, roll) {
    this.ground.rotationQuaternion = null;
    this.ground.rotation.set(pitch ?? 0, 0, roll ?? 0);
  }

  /**
   * Vertical suspension offset per wheel. Positive lifts the wheel toward
   * the body (compression), negative lets it droop; zero restores the rest
   * pose. The offset is applied along the measured world-up axis from each
   * wheel's hub rest position, so it never disturbs the wheel's placement
   * across the car (the bug that previously hid the wheels).
   */
  setSuspension(travels) {
    const up = this._suspensionUp;
    if (!up) return;
    for (let i = 0; i < this.wheels.length; i++) {
      const w = this.wheels[i];
      const t = travels?.[i] ?? 0;
      w.steerPivot.position.set(
        w.restPos.x + up.x * t,
        w.restPos.y + up.y * t,
        w.restPos.z + up.z * t,
      );
    }
  }

  /**
   * Steer the front wheels. @param angle radians; positive steers LEFT, the
   * same convention the bicycle model in driving.js uses, so the visible
   * wheels turn the way the car is actually turning.
   */
  setSteer(angle) {
    this.steerAngle = angle;
    if (this.steerSign === undefined) return;
    const z = Math.abs(this.steerSign) < 1e-6 ? -angle : angle / this.steerSign;
    for (const w of this.wheels) {
      if (w.front) w.steerPivot.rotation.z = z;
    }
  }

  /** Roll every wheel. @param distance signed metres travelled this frame. */
  spinWheels(distance) {
    if (!distance || !this.spinSign) return;
    const delta = (distance / this.wheelRadius) * this.spinSign;
    for (const w of this.wheels) {
      let a = w.spinPivot.rotation.y + delta;
      if (a > Math.PI) a -= Math.PI * 2;
      else if (a < -Math.PI) a += Math.PI * 2;
      w.spinPivot.rotation.y = a;
    }
  }

  /**
   * Tint the body so two vehicles of the same model do not look identical.
   * Clones the body's material so the asset container is untouched.
   */
  setColor(color) {
    if (!this.bodyMesh) return;
    const mat = this.bodyMesh.material;
    if (!mat) return;
    // Clone per-instance so other traffic vehicles using the same asset
    // container keep their own colour.
    const clone = mat.clone(`${this.label}_bodyMat`);
    if (clone.albedoColor) clone.albedoColor = color.clone();
    else if (clone.diffuseColor) clone.diffuseColor = color.clone();
    else return;
    clone.markAsDirty?.();
    this.bodyMesh.material = clone;
  }

  /** Toggle visibility, used when a vehicle is being recycled off-screen. */
  setVisible(visible) {
    this.root.setEnabled(visible);
  }

  dispose() {
    this.root.dispose(false, false);
  }
}
