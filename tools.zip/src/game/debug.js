/**
 * Diagnostics and self-tests.
 *
 * The assertions here exist because the things most likely to be wrong in this
 * project are not visible in a screenshot: the wheel pivots came out of the
 * asset off-centre, and the steering/spin signs depend on Babylon's handedness
 * after a right-to-left conversion. Both are checked numerically at runtime
 * and reported as PASS/FAIL, so a regression shows up as data rather than as a
 * car that quietly looks wrong.
 */

/**
 * Builds a point-on-road test from the BAKED roadway mask.
 *
 * This used to test against the road-band rectangles in routes.json, but those
 * were derived from mesh bounding boxes and do not match the actual drivable
 * surface - the mask is the same data the cars physically drive on, so a pass
 * here means the car is really on road geometry.
 */
export function createRoadTest(routeData, collision = null) {
  if (collision) {
    return function isOnRoad(x, z) {
      return collision.isRoadAt(x, z);
    };
  }
  const { horizontal, vertical } = routeData.roads;
  return function isOnRoad(x, z, margin = 1.0) {
    for (const r of horizontal) {
      if (x >= r.from - margin && x <= r.to + margin) {
        if (Math.abs(z - r.center) <= r.width / 2 + margin) return true;
      }
    }
    for (const r of vertical) {
      if (z >= r.from - margin && z <= r.to + margin) {
        if (Math.abs(x - r.center) <= r.width / 2 + margin) return true;
      }
    }
    return false;
  };
}

export function runSelfTest({ rig, player, traffic, isOnRoad, routeData, mapStats, collision }) {
  const results = [];
  const check = (name, pass, detail) => results.push({ name, pass: !!pass, detail });

  const d = rig.diagnostics;

  // 1. The wheel pivots must be re-centred: steering must not translate the
  //    wheel. Before the fix this measured ~1.7 for the right-hand wheels.
  check(
    "wheel pivots re-centred",
    d.pivotSwing !== undefined && d.pivotSwing < 0.02,
    `wheel centre drift when steering 0.6rad = ${d.pivotSwing} m (want < 0.02)`,
  );

  // 2. Calibration must actually have run and produced a usable sign.
  const cal = d.calibration;
  const calOk = cal && typeof cal === "object" && Math.abs(d.calibration.steerSign) > 1e-3;
  check(
    "steer/spin signs calibrated",
    calOk,
    cal ? `steerSign=${cal.steerSign} spinSign=${cal.spinSign}` : "no calibration recorded",
  );

  // 3. Forward alignment: the model's forward is measured from the axles and
  //    the model node is rotated once to make it +Z. This records what that
  //    measurement produced, so a wrong sign is visible in the report.
  const f = d.forwardInModelSpace;
  check(
    "model forward measured",
    !!f && Math.abs(Math.hypot(f[0], f[2]) - 1) < 0.05,
    `forward in model space = ${JSON.stringify(f)}, yaw fix ${d.modelYawFixDeg} deg`,
  );

  // 4. Measured dimensions must be plausible for a car (catches a unit-scale
  //    mistake in the rig, e.g. forgetting the asset's 0.387 scale).
  check(
    "wheelbase plausible",
    d.wheelBase > 1.5 && d.wheelBase < 4.5,
    `wheelBase = ${d.wheelBase} m (want 1.5..4.5)`,
  );
  check(
    "wheel radius plausible",
    d.wheelRadius > 0.15 && d.wheelRadius < 0.8,
    `wheelRadius = ${d.wheelRadius} m (want 0.15..0.8)`,
  );

  // 5. Every pivot must sit exactly ON its wheel's centre. This is the
  //    assertion that catches an off-centre wheel node in the asset, and the
  //    one that would have caught the body-frame lookup bug.
  const maxPivotError = Math.max(...(d.wheels ?? []).map((w) => w.pivotError ?? 999));
  check(
    "pivots sit on wheel centres",
    maxPivotError < 0.01,
    `max pivot error = ${maxPivotError} m (want < 0.01)`,
  );

  // 5b. Wheels must actually be attached to the car. A broken pivot frame
  //     displaces them off the chassis, which is invisible to a numeric check
  //     on the pivots alone.
  const maxWheelDist = d.maxWheelDistanceFromRoot ?? 999;
  check(
    "wheels attached to the car",
    maxWheelDist > 0.5 && maxWheelDist < 3,
    `furthest wheel centre = ${maxWheelDist} m from the car origin (want 0.5..3)`,
  );

  // 5c. The body frame must be the transform node the wheels hang off, not a
  //     body mesh primitive (whose local transform is identity).
  check(
    "body frame is the wheels' parent",
    d.bodyNode?.className === "TransformNode",
    `bodyNode = ${JSON.stringify(d.bodyNode)}`,
  );

  // 5d. Body lean must go the right way: leaning "right" has to tip the car's
  //     top toward its right, and "nose up" must not pitch it nose-down. Both
  //     were calibrated rather than derived, so assert the result.
  const leanTest = d.tilt?.leanTestLateral;
  const pitchTest = d.tilt?.pitchTestAlong;
  check(
    "body leans the right way",
    typeof leanTest === "number" && leanTest > 0,
    `leaning right moved the top ${leanTest} m toward the car's right (want > 0); axis=${d.tilt?.leanAxis}`,
  );
  check(
    "nose-up pitch the right way",
    typeof pitchTest === "number" && pitchTest < 0,
    `nose-up moved the top ${pitchTest} m along travel (want < 0 = top goes back); axis=${d.tilt?.pitchAxis}`,
  );

  // 6. Traffic must exist and every vehicle must be sitting on real road.
  check(
    "traffic spawned",
    traffic.count > 0,
    `${traffic.count} vehicles across ${traffic.routeCount} routes`,
  );
  const offRoad = traffic.vehicles.filter((v) => !isOnRoad(v.state.x, v.state.z));
  check(
    "all traffic on road",
    offRoad.length === 0,
    offRoad.length
      ? `${offRoad.length} off road, e.g. ${offRoad
          .slice(0, 3)
          .map((v) => `(${v.state.x.toFixed(1)}, ${v.state.z.toFixed(1)})`)
          .join(" ")}`
      : `checked ${traffic.count} vehicles`,
  );

  // 7. The player must start on a road too.
  check(
    "player spawn on road",
    isOnRoad(player.state.x, player.state.z),
    `player at (${player.state.x.toFixed(1)}, ${player.state.z.toFixed(1)})`,
  );

  // 8. Everything must be inside the collision model's baked area, or the car
  //    is driving in the void.
  const inBounds = (p) =>
    p.x >= collision.minX && p.x <= collision.maxX && p.z >= collision.minZ && p.z <= collision.maxZ;
  const strays = traffic.vehicles.filter((v) => !inBounds(v.state));
  check(
    "traffic inside map bounds",
    strays.length === 0,
    strays.length ? `${strays.length} outside the baked area` : "ok",
  );

  // 9. Map actually loaded.
  check(
    "map loaded",
    mapStats.meshes > 500,
    `${mapStats.meshes} meshes, ${mapStats.vertices.toLocaleString()} vertices`,
  );

  // 9b. Collision geometry baked: real surfaces and real obstacles found, and
  //     the map genuinely has elevation (a flat field would mean the bake failed
  //     and the car was back on a constant ground plane).
  if (collision) {
    const s = collision.stats;
    check(
      "collision geometry baked",
      s.groundCells > 1000 && s.obstacleCells > 1000,
      `${s.groundCells} ground / ${s.obstacleCells} obstacle cells from ${s.triangles} surface triangles in ${s.buildMs} ms`,
    );
    check(
      "map has elevation (not a flat plane)",
      s.minGroundY !== null && s.maxGroundY - s.minGroundY > 1.5,
      `baked surface heights span ${s.minGroundY}..${s.maxGroundY} m`,
    );

    // 9c. The car must actually be standing on the baked surface, whichever
    //     that is, rather than at a stored constant.
    const under = collision.groundAt(player.state.x, player.state.z, player.state.y + 1, {
      stepUp: 8,
      reach: 8,
    });
    check(
      "player on the baked surface",
      under.y !== null && Math.abs(player.state.y - under.y) < 1.0,
      `player y=${player.state.y.toFixed(2)}, surface y=${under.y === null ? "none" : under.y.toFixed(2)}`,
    );
    check(
      "player spawn is not inside geometry",
      player.terrain ? !player.terrain.blocked(player.state.x, player.state.z, player.state.heading) : false,
      player.terrain ? "spawn footprint is clear" : "no terrain follower",
    );

    // 9d. Traffic must be sitting on the same baked surface as its lane, not
    //     floating at the lane polyline's stored height.
    const strayTraffic = traffic.vehicles.filter((v) => {
      const lane = v.path.sample(v.distance).y;
      return !Number.isFinite(v.state.y) || Math.abs(v.state.y - lane) > 0.8;
    });
    check(
      "traffic follows the baked surface",
      strayTraffic.length === 0,
      strayTraffic.length
        ? `${strayTraffic.length} vehicles more than 0.8 m off their lane height`
        : `checked ${traffic.count} vehicles`,
    );
  } else {
    check("collision geometry baked", false, "no collision model was built");
  }

  // 10. Vehicles sharing a route are evenly spaced by construction, so any pair
  //     closer than a car length means the spacing maths is wrong. Vehicles on
  //     DIFFERENT routes may legitimately meet where loops cross, so that is
  //     only reported, not asserted.
  let minSameRoute = Infinity;
  let minAnyPair = Infinity;
  const vs = traffic.vehicles;
  for (let i = 0; i < vs.length; i++) {
    for (let j = i + 1; j < vs.length; j++) {
      const dist = Math.hypot(vs[i].state.x - vs[j].state.x, vs[i].state.z - vs[j].state.z);
      minAnyPair = Math.min(minAnyPair, dist);
      if (vs[i].route === vs[j].route) minSameRoute = Math.min(minSameRoute, dist);
    }
  }
  check(
    "traffic spaced within each route",
    minSameRoute > 3,
    `closest same-route pair = ${Number.isFinite(minSameRoute) ? minSameRoute.toFixed(1) : "n/a"} m (want > 3)`,
  );
  results.push({
    name: "closest pair overall (informational)",
    pass: true,
    detail: `closest of any two vehicles = ${minAnyPair.toFixed(1)} m; loops crossing may meet here`,
  });

  return results;
}

/** Writes the report into the DOM so a headless run can read it back. */
export function publish(payload, enabled) {
  const el = document.getElementById("debug-out");
  if (!el) return;
  el.textContent = JSON.stringify(payload, null, 1);
  el.dataset.ready = "1";
  void enabled;
}
