/**
 * Per-car race progress: which checkpoint is next, which lap, and how far
 * around the circuit the car has actually got.
 *
 * This is shared by the player and the rivals on purpose. A race is only fair
 * if everyone's lap is counted the same way, and the two obvious shortcuts both
 * break that:
 *
 *   - counting laps by "distance travelled along the path" lets a car cut
 *     across the infield (or simply drive backwards) and rack laps up without
 *     visiting the circuit;
 *   - counting laps by "crossed the finish line" lets a car sit on the line and
 *     ping-pong over it.
 *
 * So a lap only counts when the car has passed EVERY checkpoint of that lap in
 * order and then crossed the start/finish gate. Checkpoints are gates placed on
 * the circuit, and passing one is a real plane crossing (sign change of the
 * along-track distance) inside the gate's width, which cannot be tunnelled
 * through at any speed the cars can reach.
 *
 * The circuit distance is a separate, cosmetic number: it is what the live
 * position readout and the "metres behind" figure are computed from. It is
 * re-derived from the car's own position each frame inside a window around the
 * last known distance, so it cannot run away when a car is shoved off the road.
 */

/** Half-window (m) searched around the last known distance. */
const WINDOW = 60;
/** Step (m) used for that search, then refined. */
const STEP = 2;
/**
 * Body half-width (m) added to a gate's span when testing a crossing.
 *
 * `gate.halfWidth` is the span the arch actually stands across, and a car is not
 * a point: a car threading the gate at the very edge - body clipping the post,
 * centre a few centimetres outside the span - has driven through the checkpoint
 * and must count. Without the margin those edge crossings were dropped, and
 * because a crossing that fails the width test still flips the plane test's side
 * the checkpoint was skipped for the rest of the lap, so the driver had to turn
 * round and take it again.
 */
const GATE_TOUCH = 1.0;

export class RaceProgress {
  /** @param track the object returned by buildRaceTrack */
  constructor(track) {
    this.track = track;
    this.gateCount = track.gateCount;
    this.reset(track.startDistance);
  }

  /** Put the tracker on the grid: no checkpoint passed, lap 0, nobody finished. */
  reset(distance = this.track.startDistance, { x = null, z = null } = {}) {
    this.distance = wrap(distance, this.track.length);
    // Gate 0 is the start/finish line, which the grid sits behind. The first
    // thing a car has to do is visit checkpoint 1, so crossing the line on the
    // way out of the grid cannot count as a lap.
    //
    // OPEN sprints have no start/finish line to re-cross: gate 0 is the first
    // real checkpoint ahead of the grid and the LAST gate is the finish, so the
    // tracker expects gate 0 first and never wraps.
    this.gate = this.track.open ? 0 : this.gateCount > 1 ? 1 : 0;
    this.lap = 0;
    this.finished = false;
    this.finishTime = 0;
    this.laps = this.track.laps;
    this._prevAlong = null;
    if (x !== null && z !== null) this._seed(x, z);
  }

  /** Total distance travelled along the circuit, laps included, metres. */
  get total() {
    return this.lap * this.track.length + this.distance;
  }

  /** Checkpoints passed so far, within the current lap. */
  get checkpointsPassed() {
    const n = this.gateCount;
    if (!n) return 0;
    // Open sprint: gates run 0..n-1, so the count is simply the next-gate index.
    if (this.track.open) return this.gate;
    // Lap sequence is 1..n-1 then 0, so the count ticked over mirrors `gate`.
    return this.gate === 0 ? n - 1 : this.gate - 1;
  }

  /** 0..1 fraction of the current lap completed, for the HUD bar. */
  get lapFraction() {
    return this.track.length ? this.distance / this.track.length : 0;
  }

  /**
   * Feed one frame of car position.
   *
   * @returns {{ gatePassed:number|null, lapCompleted:boolean, finished:boolean }}
   */
  update(x, z, { time = 0 } = {}) {
    this._advance(x, z);
    const events = { gatePassed: null, lapCompleted: false, finished: false };
    if (this.finished) return events;

    const gate = this.track.gates[this.gate];
    if (!gate) return events;

    const dx = x - gate.x;
    const dz = z - gate.z;
    // Forward is the circuit tangent at the gate; `heading` comes straight from
    // the lane, so (sin h, cos h) is the direction of travel through it.
    const fx = Math.sin(gate.heading);
    const fz = Math.cos(gate.heading);
    const along = dx * fx + dz * fz;
    const lateral = Math.abs(dx * gate.rightX + dz * gate.rightZ);

    if (this._prevAlong === null) {
      this._prevAlong = along;
      return events;
    }
    const crossed = this._prevAlong < 0 && along >= 0 && lateral <= gate.halfWidth + GATE_TOUCH;
    this._prevAlong = along;
    if (!crossed) return events;

    events.gatePassed = this.gate;
    if (gate.isFinish) {
      this.lap++;
      events.lapCompleted = true;
      if (this.lap >= this.laps) {
        this.finished = true;
        this.finishTime = time;
        events.finished = true;
      }
    }
    // Lap sequence: 1, 2, ... n-1, then 0 (the finish line), then 1 again.
    this.gate = (this.gate + 1) % this.gateCount;
    this._prevAlong = null; // the next gate has its own plane
    // Re-seed the distance from the car rather than trusting the increment: the
    // car has just crossed a gate, which is a known point on the circuit.
    this.distance = wrap(gate.s + 0.5, this.track.length);
    return events;
  }

  /** Re-seed after a teleport (grid alignment, recovery snap). */
  resync(x, z) {
    this._seed(x, z);
    this._prevAlong = null;
  }

  /**
   * Re-seed the along-track distance to a KNOWN arc position (no nearest-point
   * search), keeping the current lap / gate state. Used by the recovery reseat
   * so a track that doubles back on itself can't re-seed onto the wrong branch
   * and send the car off the wrong way.
   */
  seedDistance(distance) {
    this.distance = wrap(distance, this.track.length);
    this._prevAlong = null;
  }

  _seed(x, z) {
    // Nearest sample over the WHOLE circuit: after a teleport the car can be
    // anywhere, so the tight window is not usable.
    let best = 0;
    let bestSq = Infinity;
    const step = Math.max(1, Math.round(this.track.length / 400));
    for (let s = 0; s < this.track.length; s += step) {
      const p = this.track.path.sample(s);
      const sq = (p.x - x) ** 2 + (p.z - z) ** 2;
      if (sq < bestSq) {
        bestSq = sq;
        best = s;
      }
    }
    this.distance = best;
  }

  _advance(x, z) {
    const path = this.track.path;
    const L = this.track.length;
    let best = this.distance;
    let bestSq = Infinity;
    for (let o = -WINDOW; o <= WINDOW; o += STEP) {
      const p = path.sample(this.distance + o);
      const sq = (p.x - x) ** 2 + (p.z - z) ** 2;
      if (sq < bestSq) {
        bestSq = sq;
        best = this.distance + o;
      }
    }
    // Refine to 0.5 m so the distance figure does not quantise.
    for (let o = -STEP; o <= STEP; o += 0.5) {
      const p = path.sample(best + o);
      const sq = (p.x - x) ** 2 + (p.z - z) ** 2;
      if (sq < bestSq) {
        bestSq = sq;
        best = best + o;
      }
    }
    this.distance = wrap(best, L);
  }
}

function wrap(v, L) {
  if (!L) return 0;
  return ((v % L) + L) % L;
}
