import {
  Color3,
  DynamicTexture,
  Mesh,
  StandardMaterial,
  VertexBuffer,
} from "@babylonjs/core";

/**
 * Tire tracks, pooled per surface look.
 *
 * One mesh per look (road / dirt / grass-mud / sand), each a preallocated
 * ring buffer of quads - so the whole system costs 4 draw calls no matter
 * how many marks are down. Marks fade out over their life through per-vertex
 * alpha; nothing is ever allocated per stamp.
 *
 * Realism notes: the old look painted ONE texture and stamped every quad with
 * the exact same UVs, so a long slide read as obvious wallpaper - the same
 * blotch repeated. The look is now an ATLAS of 8 hand-painted variants, and
 * every stamp picks a random cell (with a random U/V flip) so no two
 * neighbouring marks are identical. Each variant is painted per-pixel (not in
 * 2 px blocks) with a ragged, wandering edge, a length-wise break-up, a fine
 * grain, cross-sipes for road rubber and scattered clods / grass flecks for
 * the loose surfaces, and a soft shoulder that is lighter than the core, which
 * is what sells "smeared material" rather than "drawn line".
 *
 * Looks differ by surface (see SURF in MapCollision): asphalt gets dark
 * rubber streaks with a tread pattern, grass gets wet mud with green flecks,
 * sand gets pale soft smears with bright grains, dirt/unknown gets mid-brown.
 */

export const MARK_LOOK = {
  ROAD: 0,
  DIRT: 1,
  GRASS: 2,
  SAND: 3,
};
const LOOK_COUNT = 4;

/** Map a SURF surface type (0..4) onto a mark pool. Unknown reads as dirt. */
export function surfaceLook(surf) {
  if (surf === 4) return MARK_LOOK.ROAD;
  if (surf === 3) return MARK_LOOK.SAND;
  if (surf === 2) return MARK_LOOK.GRASS;
  return MARK_LOOK.DIRT;
}

const DEFAULT_MAX = 384;
const DEFAULT_LIFE = 26; // seconds a mark stays down
const FULL_ALPHA_UNTIL = 0.55; // fraction of life at full strength, then fade

// Atlas: ATLAS_COLS x ATLAS_ROWS independently-painted variants in one texture.
const TEX_SIZE = 256;
const ATLAS_COLS = 4;
const ATLAS_ROWS = 2;
const VARIANTS = ATLAS_COLS * ATLAS_ROWS;

/** Deterministic 0..1 hash. Used for the texture grain so it never flickers. */
function hash2(x, y) {
  const s = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
  return s - Math.floor(s);
}

/**
 * Painting recipe per look. `core` is the centre colour, `edge` the lighter
 * shoulder the smear fades into (compare: a real tyre mark is darkest where
 * the rubber is thickest and lighter where the surface shows through).
 * `clods` are scattered lumps of displaced material, `flecks` are the sharp
 * bits - grass blades on mud, bright grains on sand.
 */
const LOOK_PAINT = [
  {
    // ROAD - burnt rubber, dark core, faint grey shoulder, cross-siped tread.
    core: [8, 8, 11],
    edge: [38, 37, 41],
    band: 0.5,
    soft: 0.34,
    alpha: 0.94,
    groove: { period: 11, width: 0.42, depth: 0.42 },
    grain: 0.17,
    clods: { count: 26, color: [30, 30, 35], size: [0.7, 1.6], alpha: 0.5, spread: 0.62 },
    flecks: null,
  },
  {
    // DIRT - mid brown, cloddy, ragged.
    core: [102, 72, 44],
    edge: [142, 108, 68],
    band: 0.64,
    soft: 0.44,
    alpha: 0.74,
    groove: null,
    grain: 0.22,
    clods: { count: 150, color: [78, 53, 30], size: [0.8, 2.2], alpha: 0.6, spread: 1.0 },
    flecks: null,
  },
  {
    // GRASS - wet mud with green grass dragged through it.
    core: [72, 48, 28],
    edge: [116, 88, 52],
    band: 0.68,
    soft: 0.46,
    alpha: 0.78,
    groove: null,
    grain: 0.24,
    clods: { count: 170, color: [54, 36, 20], size: [0.9, 2.4], alpha: 0.65, spread: 1.0 },
    flecks: {
      count: 30,
      colors: [[88, 122, 50], [112, 148, 62], [70, 102, 44]],
      size: [0.7, 1.5],
      alpha: 0.9,
      spread: 1.0,
    },
  },
  {
    // SAND - pale soft smear, barely there, bright grains.
    core: [204, 184, 148],
    edge: [228, 212, 180],
    band: 0.74,
    soft: 0.52,
    alpha: 0.62,
    groove: null,
    grain: 0.2,
    clods: { count: 150, color: [192, 172, 136], size: [0.7, 1.8], alpha: 0.55, spread: 1.0 },
    flecks: {
      count: 44,
      colors: [[236, 224, 196], [214, 196, 160]],
      size: [0.6, 1.2],
      alpha: 0.85,
      spread: 1.0,
    },
  },
];

/** Small LCG so a variant paints identically every run. */
function makeRand(seed) {
  let s = (seed >>> 0) || 1;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/** Alpha-over splat of one soft blob (or, stretched, a grass blade). */
function splat(data, w, h, cx, cy, r, color, alpha, stretchX, stretchY) {
  const sx = r * stretchX;
  const sy = r * stretchY;
  const x0 = Math.max(0, Math.floor(cx - sx));
  const x1 = Math.min(w - 1, Math.ceil(cx + sx));
  const y0 = Math.max(0, Math.floor(cy - sy));
  const y1 = Math.min(h - 1, Math.ceil(cy + sy));
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const dx = (x - cx) / sx;
      const dy = (y - cy) / sy;
      const dd = dx * dx + dy * dy;
      if (dd > 1) continue;
      const a = alpha * (1 - dd) * (1 - dd);
      if (a <= 0.004) continue;
      const i = (y * w + x) * 4;
      const ia = 1 - a;
      data[i] = color[0] * a + data[i] * ia;
      data[i + 1] = color[1] * a + data[i + 1] * ia;
      data[i + 2] = color[2] * a + data[i + 2] * ia;
      data[i + 3] = Math.min(255, a * 255 + data[i + 3] * ia);
    }
  }
}

/**
 * Paint one atlas cell. The streak runs down the cell (V = length), so width
 * lives on X and length on Y. Every layer is per-pixel: no blocky stamps.
 */
function paintVariant(data, w, h, cfg, seed) {
  const rand = makeRand(seed * 2654435761 + 1);
  const half = cfg.band * 0.5;
  const soft = Math.max(cfg.soft * half, 1 / w);
  const [cr, cg, cb] = cfg.core;
  const [er, eg, eb] = cfg.edge;

  for (let y = 0; y < h; y++) {
    const t = y / (h - 1);
    // The streak's half-width wanders along its length so it is never a ruler.
    const wob =
      Math.sin(t * 6.9 + seed * 1.7) * 0.07 + Math.sin(t * 17.3 + seed * 3.1) * 0.035;
    const hw = Math.max(0.04, half * (1 + wob));
    // Longitudinal break-up: the rubber/mud thins and thickens in patches.
    const breakup =
      0.6 +
      0.4 * (0.5 + 0.5 * Math.sin(t * 21.7 + seed * 2.3)) * (0.6 + 0.4 * hash2(seed, Math.floor(t * 37)));
    for (let x = 0; x < w; x++) {
      const d = Math.abs(x / (w - 1) - 0.5) * 2; // 0 centre -> 1 cell edge
      // Ragged boundary: the fade starts a random little before the edge.
      const edgeN = (hash2(x * 0.53 + seed * 3.1, y * 0.41) - 0.5) * soft * 0.9;
      let a = 1 - Math.max(0, (d - (hw + edgeN - soft)) / soft);
      a = a < 0 ? 0 : a > 1 ? 1 : a;
      a = a * a * (3 - 2 * a); // smoothstep
      a *= breakup;
      a *= 1 - cfg.grain * (1 - hash2(x * 1.13 + seed * 7, y * 0.91));
      if (cfg.groove) {
        const ph = (y % cfg.groove.period) / cfg.groove.period;
        if (ph < cfg.groove.width) a *= 1 - cfg.groove.depth;
      }
      a *= cfg.alpha;
      if (a <= 0.004) continue;
      // Dark core bleeding into a lighter shoulder.
      const m = Math.min(1, d / Math.max(hw + edgeN, 1e-3));
      const mm = m * m;
      const i = (y * w + x) * 4;
      data[i] = cr + (er - cr) * mm;
      data[i + 1] = cg + (eg - cg) * mm;
      data[i + 2] = cb + (eb - cb) * mm;
      data[i + 3] = a * 255;
    }
  }

  // Displaced material thrown around the tread.
  if (cfg.clods) {
    const c = cfg.clods;
    for (let k = 0; k < c.count; k++) {
      const cx = rand() * w;
      const cy = rand() * h;
      if (Math.abs(cx / (w - 1) - 0.5) * 2 > c.spread) continue;
      const r = c.size[0] + rand() * (c.size[1] - c.size[0]);
      splat(data, w, h, cx, cy, r, c.color, (0.35 + rand() * 0.65) * c.alpha, 1, 1);
    }
  }

  // Sharp bits: grass blades, bright sand grains.
  if (cfg.flecks) {
    const f = cfg.flecks;
    for (let k = 0; k < f.count; k++) {
      const cx = rand() * w;
      const cy = rand() * h;
      if (Math.abs(cx / (w - 1) - 0.5) * 2 > f.spread) continue;
      const col = f.colors[Math.floor(rand() * f.colors.length)];
      const r = f.size[0] + rand() * (f.size[1] - f.size[0]);
      splat(data, w, h, cx, cy, r, col, (0.55 + rand() * 0.45) * f.alpha, 0.7, 2.1);
    }
  }
}

function makeTrackTexture(look, scene, tag) {
  const S = TEX_SIZE;
  // No mipmaps: the atlas cells must not bleed into one another at distance,
  // and marks are small on screen anyway.
  const tex = new DynamicTexture(`tiremark_${tag}_${look}`, { width: S, height: S }, scene, false);
  tex.hasAlpha = true;
  const g = tex.getContext();
  g.clearRect(0, 0, S, S);
  const cw = S / ATLAS_COLS;
  const ch = S / ATLAS_ROWS;
  const cfg = LOOK_PAINT[look];
  for (let v = 0; v < VARIANTS; v++) {
    const cx = (v % ATLAS_COLS) * cw;
    const cy = Math.floor(v / ATLAS_COLS) * ch;
    const img = g.createImageData(cw, ch);
    paintVariant(img.data, cw, ch, cfg, v + 1 + look * 17);
    g.putImageData(img, cx, cy);
  }
  tex.update();
  return tex;
}

class MarkPool {
  constructor(scene, look, tag, max, life) {
    this.look = look;
    this.max = max;
    this.life = life;
    this.head = 0;
    this.ages = new Float32Array(max).fill(-1);
    this.baseA = new Float32Array(max);
    this.alive = 0;

    const n = max * 4;
    this.positions = new Float32Array(n * 3);
    this.colors = new Float32Array(n * 4);
    this.uvs = new Float32Array(n * 2);
    const normals = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) normals[i * 3 + 1] = 1;
    const indices = new Uint32Array(max * 6);
    for (let i = 0; i < max; i++) {
      const v = i * 4;
      const o = i * 6;
      indices[o] = v; indices[o + 1] = v + 1; indices[o + 2] = v + 2;
      indices[o + 3] = v; indices[o + 4] = v + 2; indices[o + 5] = v + 3;
    }

    const mesh = new Mesh(`tiremarks_${tag}_${look}`, scene);
    mesh.setVerticesData(VertexBuffer.PositionKind, this.positions, true);
    mesh.setVerticesData(VertexBuffer.NormalKind, normals, true);
    mesh.setVerticesData(VertexBuffer.UVKind, this.uvs, true);
    mesh.setVerticesData(VertexBuffer.ColorKind, this.colors, true, 4);
    mesh.setIndices(indices);
    mesh.useVertexColors = true;
    mesh.hasVertexAlpha = true;
    mesh.isPickable = false;
    mesh.alwaysSelectAsActiveMesh = true;
    mesh.doNotSyncBoundingInfo = true;
    mesh.freezeWorldMatrix();

    const mat = new StandardMaterial(`tiremarks_mat_${tag}_${look}`, scene);
    mat.diffuseTexture = makeTrackTexture(look, scene, tag);
    mat.useAlphaFromDiffuseTexture = true;
    mat.specularColor = new Color3(0, 0, 0);
    mat.disableDepthWrite = true;
    mat.backFaceCulling = false;
    mesh.material = mat;

    this.mesh = mesh;
    this.dirtyColors = false;
  }

  emit(x, y, z, yaw, w, l, alpha) {
    const i = this.head;
    this.head = (this.head + 1) % this.max;
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    const sx = fz;
    const sz = -fx;
    const hl = l / 2;
    const hw = w / 2;
    const o = i * 12;
    const P = this.positions;
    // p0..p3: back-left, back-right, front-right, front-left.
    P[o] = x - fx * hl - sx * hw; P[o + 1] = y; P[o + 2] = z - fz * hl - sz * hw;
    P[o + 3] = x - fx * hl + sx * hw; P[o + 4] = y; P[o + 5] = z - fz * hl + sz * hw;
    P[o + 6] = x + fx * hl + sx * hw; P[o + 7] = y; P[o + 8] = z + fz * hl + sz * hw;
    P[o + 9] = x + fx * hl - sx * hw; P[o + 10] = y; P[o + 11] = z - fz * hl - sz * hw;
    this.mesh.updateVerticesData(VertexBuffer.PositionKind, P, false);

    // Pick a variant and a random mirror so consecutive stamps never tile.
    const v = (Math.random() * VARIANTS) | 0;
    const col = v % ATLAS_COLS;
    const row = (v / ATLAS_COLS) | 0;
    const inset = 0.35 / TEX_SIZE;
    let u0 = col / ATLAS_COLS + inset;
    let u1 = (col + 1) / ATLAS_COLS - inset;
    let v0 = row / ATLAS_ROWS + inset;
    let v1 = (row + 1) / ATLAS_ROWS - inset;
    if (Math.random() < 0.5) { const t = u0; u0 = u1; u1 = t; }
    if (Math.random() < 0.5) { const t = v0; v0 = v1; v1 = t; }
    const U = this.uvs;
    const uo = i * 8;
    U[uo] = u0; U[uo + 1] = v0;
    U[uo + 2] = u1; U[uo + 3] = v0;
    U[uo + 4] = u1; U[uo + 5] = v1;
    U[uo + 6] = u0; U[uo + 7] = v1;
    this.mesh.updateVerticesData(VertexBuffer.UVKind, U, false);

    if (this.ages[i] < 0) this.alive++;
    this.ages[i] = 0;
    this.baseA[i] = alpha;
    const C = this.colors;
    const co = i * 16;
    for (let k = 0; k < 4; k++) {
      C[co + k * 4] = 1;
      C[co + k * 4 + 1] = 1;
      C[co + k * 4 + 2] = 1;
      C[co + k * 4 + 3] = alpha;
    }
    this.dirtyColors = true;
    return i;
  }

  update(dt) {
    if (this.alive <= 0) return 0;
    let dirty = this.dirtyColors;
    const C = this.colors;
    for (let i = 0; i < this.max; i++) {
      if (this.ages[i] < 0) continue;
      this.ages[i] += dt;
      const t = this.ages[i] / this.life;
      const co = i * 16;
      if (t >= 1) {
        this.ages[i] = -1;
        this.alive--;
        C[co + 3] = 0; C[co + 7] = 0; C[co + 11] = 0; C[co + 15] = 0;
        dirty = true;
      } else {
        const fade = t < FULL_ALPHA_UNTIL ? 1 : 1 - (t - FULL_ALPHA_UNTIL) / (1 - FULL_ALPHA_UNTIL);
        const a = this.baseA[i] * fade;
        if (Math.abs(C[co + 3] - a) > 0.004) {
          C[co + 3] = a; C[co + 7] = a; C[co + 11] = a; C[co + 15] = a;
          dirty = true;
        }
      }
    }
    if (dirty) {
      this.mesh.updateVerticesData(VertexBuffer.ColorKind, C, false);
      this.dirtyColors = false;
    }
    return this.alive;
  }

  clear() {
    this.ages.fill(-1);
    this.baseA.fill(0);
    // Zero the whole color buffer (rgb included): dead quads stay
    // transparent, and emit() rewrites rgb back to 1 on reuse.
    this.colors.fill(0);
    this.alive = 0;
    this.head = 0;
    this.mesh.updateVerticesData(VertexBuffer.ColorKind, this.colors, false);
  }

  dispose() {
    try {
      this.mesh.material?.diffuseTexture?.dispose();
    } catch { /* noop */ }
    try {
      this.mesh.material?.dispose();
    } catch { /* noop */ }
    try {
      this.mesh.dispose();
    } catch { /* noop */ }
  }
}

export class TireMarks {
  /**
   * @param scene Babylon scene
   * @param opts { maxPerType, life, tag }
   */
  constructor(scene, opts = {}) {
    this.scene = scene;
    this.max = opts.maxPerType ?? DEFAULT_MAX;
    this.life = opts.life ?? DEFAULT_LIFE;
    const tag = opts.tag ?? "world";
    this.pools = [];
    for (let look = 0; look < LOOK_COUNT; look++) {
      this.pools.push(new MarkPool(scene, look, tag, this.max, this.life));
    }
  }

  emit(x, y, z, yaw, w, l, alpha, look) {
    const pool = this.pools[look] ?? this.pools[MARK_LOOK.DIRT];
    return pool.emit(x, y, z, yaw, w, l, Math.max(0, Math.min(1, alpha)));
  }

  update(dt) {
    let alive = 0;
    for (const pool of this.pools) alive += pool.update(dt);
    return alive;
  }

  aliveCount() {
    let n = 0;
    for (const pool of this.pools) n += pool.alive;
    return n;
  }

  clear() {
    for (const pool of this.pools) pool.clear();
  }

  dispose() {
    for (const pool of this.pools) pool.dispose();
    this.pools = [];
  }
}
