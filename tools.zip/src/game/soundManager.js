/**
 * Central sound-effects manager (HTMLAudio-based file SFX).
 *
 * All game FILE sounds go through here so tuning is a one-file change:
 *   - file paths  -> `SOUND_FILES` below
 *   - mix levels  -> `SOUND_CONFIG.volumes`
 *   - pool sizes  -> `SOUND_CONFIG.pool`
 *   - spam guards -> `SOUND_CONFIG.cooldownMs`
 *
 * The synthesised engine/skid/brake/wind mix stays in `carAudio.js` (it is a
 * live AudioWorklet graph, not files). This module owns everything that plays
 * from `public/assets/audio/`:
 *
 *   - UI click            (button_click.mp3)            -> every <button>
 *   - repair jingle       (repair.mp3)                  -> gas-station pads
 *   - whooshes            (woosh_sound_small/long.mp3)  -> race/UI transitions
 *   - crash impacts       (car_impact_sound_*.mp3)      -> walls / cars / props
 *   - lobby music         (bg.mp3, looped)              -> lobby only
 *
 * Usage:
 *   import { soundManager } from "./soundManager.js";
 *   soundManager.preload();          // at boot (never rejects)
 *   soundManager.bindGlobalClickSound(); // once: click on every button
 *   soundManager.playClick();
 *   soundManager.playRepair();
 *   soundManager.playWhoosh("ui");   // "ui"|"camera"|"result"|"passby"|"small"|"long"
 *   soundManager.playImpact("metal", { intensity: 0.8 });
 *   soundManager.playPropBreak("sign");
 *   soundManager.setMuted(true);     // user pref (lobby / pause / M key)
 *   soundManager.setEnabled(false);  // menu/garage silencing
 *   soundManager.startMusic();       // lobby open (looped bg.mp3)
 *   soundManager.stopMusic();        // lobby close
 *   soundManager.setMusicMuted(true); // lobby/pause music toggle + M key
 *
 * Every play is promise-guarded and never throws, so audio can never break
 * driving. With no Web Audio / no files it degrades to a silent no-op.
 */

// ---------------------------------------------------------------------------
// SINGLE SOURCE OF TRUTH — edit paths here and preload.js picks them up too.
// ---------------------------------------------------------------------------
export const SOUND_FILES = {
  /** UI click (all buttons). */
  click: ["assets/audio/button_click.mp3"],
  /** Gas-station repair + paint jingle. */
  repair: ["assets/audio/repair.mp3"],
  /** Short UI swish (prompt / intro card). */
  whooshSmall: ["assets/audio/woosh_sound_small.mp3"],
  /** Long sweep (results board / finish pass-by / camera moves). */
  whooshLong: ["assets/audio/woosh_sound_long.mp3"],
  /** Wall / building / concrete hits (3 round-robin variants). */
  impactBrick: [
    "assets/audio/car_impact_sound_brick.mp3",
    "assets/audio/car_impact_sound_brick2.mp3",
    "assets/audio/car_impact_sound_brick3.mp3",
  ],
  /** Car-vs-car + metal prop hits (3 round-robin variants). */
  impactMetal: [
    "assets/audio/car_impact_sound_metal.mp3",
    "assets/audio/car_impact_sound_metal2.mp3",
    "assets/audio/car_impact_sound_metal3.mp3",
  ],
  /** Tree / wooden-prop hits. */
  impactTree: ["assets/audio/car_impact_sound_tree.mp3"],
  /** Lobby background music (looped, played only while the lobby is open). */
  music: ["assets/audio/bg.mp3"],
};

/** Flat list of every file above — used by preload.js (`PRELOAD_AUDIO`). */
export const ALL_SOUND_URLS = Object.values(SOUND_FILES).flat();

/**
 * Mix + behaviour tuning. One object so balance changes never touch logic.
 * volumes are per-category base gains (0..1); intensity scales them further.
 */
export const SOUND_CONFIG = {
  volumes: {
    click: 0.5,
    repair: 0.45,
    whooshSmall: 0.4,
    whooshLong: 0.45,
    impact: 0.75,
    /** Looped lobby music bed — kept low so SFX/clicks stay on top. */
    music: 0.28,
  },
  /** Pooled <audio> per category so overlaps never cut each other off. */
  pool: {
    click: 3,
    repair: 2,
    whooshSmall: 2,
    whooshLong: 2,
    impactBrick: 4,
    impactMetal: 4,
    impactTree: 2,
  },
  /** Minimum gap between two plays of the same category (spam guard), ms. */
  cooldownMs: {
    click: 60,
    repair: 600,
    whooshSmall: 120,
    whooshLong: 250,
    impact: 150,
  },
};

/** Destructible family id -> impact flavour (see destructibles.js). */
const PROP_SOUND = {
  sign: "metal",
  mailbox: "metal",
  barrel: "metal",
  cart: "metal",
  mower: "metal",
  bench: "metal",
  fence: "tree",
  gate: "tree",
  crate: "tree",
  timber: "tree",
  log: "tree",
};

/** RaceHud/CarAudio transition variant -> file pool. */
const WHOOSH_ROUTE = {
  ui: "whooshSmall",
  small: "whooshSmall",
  camera: "whooshLong",
  result: "whooshLong",
  passby: "whooshLong",
  long: "whooshLong",
};

const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

export class SoundManager {
  constructor({ volumes = {}, pool = {}, cooldownMs = {} } = {}) {
    this.volumes = { ...SOUND_CONFIG.volumes, ...volumes };
    this.poolSizes = { ...SOUND_CONFIG.pool, ...pool };
    this.cooldowns = { ...SOUND_CONFIG.cooldownMs, ...cooldownMs };
    /** poolKey -> HTMLAudioElement[] */
    this.pools = new Map();
    /** poolKey -> round-robin cursor */
    this.cursors = new Map();
    /** cooldownKey -> last play timestamp */
    this.lastPlay = new Map();
    this.muted = false;
    this.enabled = true;
    this._preloaded = false;
    this._boundClicks = false;
    // --- lobby music (single looped element, not pooled) -------------------
    this.musicMuted = false;
    this._music = null;
    /** True between startMusic() and stopMusic() — the intent to play. */
    this._musicWanted = false;
    this._musicFadeTimer = null;
    /** Active music fade: null | "in" | "out" (guards per-frame re-entry). */
    this._musicFade = null;
  }

  // ------------------------------------------------------------ lifecycle

  /**
   * Build the pooled <audio> elements and warm them. Safe to call twice;
   * never rejects, so a bad file can never stall the boot.
   * @returns {Promise<{loaded:number,total:number}>}
   */
  async preload() {
    if (this._preloaded) return { loaded: this.pools.size, total: this.pools.size };
    if (typeof window === "undefined" || typeof Audio === "undefined") return { loaded: 0, total: 0 };
    // Music gets its own looped element (see _initMusic), not a one-shot pool.
    const entries = Object.entries(SOUND_FILES).filter(([key]) => key !== "music");
    let loaded = 0;
    await Promise.all(
      entries.map(async ([key, urls]) => {
        const size = Math.max(1, this.poolSizes[key] ?? 2);
        const pool = [];
        for (let i = 0; i < size; i++) {
          // Round-robin across variants: element i plays urls[i % urls.length],
          // so the brick/metal triples cycle instead of repeating one file.
          const url = urls[i % urls.length];
          try {
            const el = new Audio(url);
            el.preload = "auto";
            el.volume = this._baseVolume(key);
            try {
              el.load();
            } catch {
              /* some browsers throw on load() with no source yet */
            }
            pool.push(el);
          } catch {
            /* a broken file just leaves a smaller pool */
          }
        }
        if (pool.length) {
          this.pools.set(key, pool);
          this.cursors.set(key, 0);
          loaded += 1;
        }
        // Wait for at least one element per pool to be playable (or time out),
        // so the first in-game play is instant like the other preloaded assets.
        await this._awaitReady(pool[0]).catch(() => {});
      }),
    );
    // Lobby music bed: one looped element, warmed alongside the SFX pools.
    try {
      await this._initMusic();
      loaded += 1;
    } catch {
      /* a bad music file just leaves the lobby silent */
    }
    this._preloaded = true;
    return { loaded, total: entries.length + 1 };
  }

  /** Resolve once the element can play through (or after a short timeout). */
  _awaitReady(el, timeoutMs = 4000) {
    return new Promise((resolve) => {
      if (!el) return resolve(false);
      try {
        if (el.readyState >= 3) return resolve(true);
      } catch {
        return resolve(false);
      }
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        resolve(ok);
      };
      const timer = window.setTimeout(() => finish(false), timeoutMs);
      const ok = () => {
        window.clearTimeout(timer);
        finish(true);
      };
      el.addEventListener("canplaythrough", ok, { once: true });
      el.addEventListener("loadeddata", ok, { once: true });
      el.addEventListener("error", () => {
        window.clearTimeout(timer);
        finish(false);
      }, { once: true });
    });
  }

  /**
   * Prime playback after a user gesture (browsers gate audio until one).
   * HTMLAudio usually needs no explicit resume, but re-issuing load() here
   * guarantees the pools are warm the moment input is allowed. If the lobby
   * music was wanted but blocked, it is retried here.
   */
  unlock() {
    try {
      for (const pool of this.pools.values()) {
        for (const el of pool) {
          try {
            if (el.readyState === 0) el.load();
          } catch {
            /* ignore */
          }
        }
      }
    } catch {
      /* audio must never interrupt the game */
    }
    // Retry a blocked lobby-music play now that a gesture has happened.
    try {
      if (this._musicWanted && !this.musicMuted && this._music && this._music.paused) {
        this._applyMusicState();
      }
    } catch {
      /* ignore */
    }
  }

  /** User preference mute (lobby / pause settings / M key). */
  setMuted(on) {
    this.muted = !!on;
  }

  /** Menu/garage silencing (mirrors CarAudio.setEnabled). */
  setEnabled(on) {
    this.enabled = !!on;
  }

  /** @returns the new muted state. */
  toggleMute() {
    this.muted = !this.muted;
    return this.muted;
  }

  get audible() {
    return !this.muted && this.enabled;
  }

  // ------------------------------------------------------- lobby music bed

  /** Build the single looped music element (called once from preload()). */
  async _initMusic() {
    if (this._music || typeof Audio === "undefined") return;
    const url = (SOUND_FILES.music ?? [])[0];
    if (!url) return;
    try {
      const el = new Audio(url);
      el.preload = "auto";
      el.loop = true;
      el.volume = this.volumes.music ?? 0.28;
      try {
        el.load();
      } catch {
        /* some browsers throw on load() with no source yet */
      }
      this._music = el;
      await this._awaitReady(el).catch(() => {});
      // If startMusic() was already called before preload finished, apply it.
      this._applyMusicState();
    } catch {
      this._music = null;
    }
  }

  /** (Re)apply wanted+muted state to the music element. Never throws. */
  _applyMusicState() {
    try {
      const el = this._music;
      // Not preloaded yet: one-shot fallback so an early lobby open still
      // gets music instead of staying silent until preload finishes.
      if (!el) {
        if (this._musicWanted && !this.musicMuted) this._musicOneShot();
        return;
      }
      if (this._musicWanted && !this.musicMuted) {
        // (Re)start unless already playing — including mid-fade-out, which
        // flips back to a fade-in instead of fighting it.
        if (el.paused || this._musicFade === "out") {
          this._fadeMusicIn(el);
        } else {
          try {
            el.volume = this.volumes.music ?? 0.28;
          } catch {
            /* read-only volume */
          }
        }
      } else if (!el.paused || this._musicFade === "in") {
        this._fadeMusicOut(el);
      }
    } catch {
      /* music must never interrupt the game */
    }
  }

  /** Fallback when the loop element is not ready yet (early lobby open). */
  _musicOneShot() {
    try {
      if (this._music || typeof Audio === "undefined") return;
      const url = (SOUND_FILES.music ?? [])[0];
      if (!url) return;
      const el = new Audio(url);
      el.preload = "auto";
      el.loop = true;
      el.volume = 0;
      this._music = el;
      const p = el.play();
      if (p && typeof p.catch === "function") {
        p.catch(() => {});
        p.then?.(() => this._fadeMusicIn(el)).catch(() => {});
      } else {
        this._fadeMusicIn(el);
      }
    } catch {
      /* silent */
    }
  }

  /** Clear any running music fade without touching playback. */
  _clearMusicFade() {
    try {
      if (this._musicFadeTimer) window.clearInterval(this._musicFadeTimer);
    } catch {
      /* ignore */
    }
    this._musicFadeTimer = null;
    this._musicFade = null;
  }

  /** Ramp the bed up to its target volume (~0.8 s). */
  _fadeMusicIn(el) {
    try {
      // startMusic() runs every frame while the lobby is open: never restart
      // a fade that is already running, or it would never finish.
      if (this._musicFade === "in") return;
      this._clearMusicFade();
      this._musicFade = "in";
      const target = this.volumes.music ?? 0.28;
      let p = null;
      try {
        p = el.play();
      } catch {
        this._musicFade = null;
        return;
      }
      const begin = () => {
        // A stop/mute may have landed while play() was pending.
        if (this._musicFade !== "in") return;
        try {
          el.volume = 0;
          const steps = 12;
          let i = 0;
          this._musicFadeTimer = window.setInterval(() => {
            try {
              if (this._musicFade !== "in") {
                this._clearMusicFade();
                return;
              }
              i += 1;
              el.volume = clamp01(target * (i / steps));
              if (i >= steps) this._clearMusicFade();
            } catch {
              this._clearMusicFade();
            }
          }, 65);
        } catch {
          this._musicFade = null;
          /* keep playing at whatever volume stuck */
        }
      };
      if (p && typeof p.then === "function") p.then(begin, () => {
        if (this._musicFade === "in") this._musicFade = null;
      });
      else begin();
      if (p && typeof p.catch === "function") p.catch(() => {});
    } catch {
      /* music must never interrupt the game */
    }
  }

  /** Ramp the bed down, then pause. */
  _fadeMusicOut(el) {
    try {
      // stopMusic() / mute run every frame: never restart a fade that is
      // already running, or pause() would never fire and the bed would sit
      // at ~zero volume forever instead of stopping.
      if (this._musicFade === "out") return;
      this._clearMusicFade();
      this._musicFade = "out";
      const startVol = (() => {
        try {
          return el.volume;
        } catch {
          return 0;
        }
      })();
      const steps = 10;
      let i = 0;
      this._musicFadeTimer = window.setInterval(() => {
        try {
          if (this._musicFade !== "out") {
            this._clearMusicFade();
            return;
          }
          i += 1;
          el.volume = clamp01(startVol * (1 - i / steps));
          if (i >= steps) {
            this._clearMusicFade();
            try {
              el.pause();
            } catch {
              /* was not playing */
            }
          }
        } catch {
          this._clearMusicFade();
          try {
            el.pause();
          } catch {
            /* ignore */
          }
        }
      }, 60);
    } catch {
      try {
        el.pause();
      } catch {
        /* ignore */
      }
    }
  }

  /**
   * Start the looped lobby bed. Idempotent — call every frame if convenient.
   * The lobby calls this while open; main.js stops it when driving.
   */
  startMusic() {
    this._musicWanted = true;
    this._applyMusicState();
  }

  /** Stop the lobby bed (keeps the element warm for the next open). */
  stopMusic() {
    this._musicWanted = false;
    this._applyMusicState();
  }

  /** Lobby/pause music toggle (true = muted). Independent of the SFX mute. */
  setMusicMuted(on) {
    this.musicMuted = !!on;
    this._applyMusicState();
  }

  /** @returns the new music-muted state. */
  toggleMusicMute() {
    this.musicMuted = !this.musicMuted;
    this._applyMusicState();
    return this.musicMuted;
  }

  /** True while the bed is actually audible. */
  isMusicPlaying() {
    try {
      return !!this._music && !this._music.paused && !this.musicMuted && this._musicWanted;
    } catch {
      return false;
    }
  }

  // ------------------------------------------------------------- internals

  _baseVolume(poolKey) {
    if (poolKey === "whooshSmall") return this.volumes.whooshSmall ?? 0.4;
    if (poolKey === "whooshLong") return this.volumes.whooshLong ?? 0.45;
    if (poolKey === "click") return this.volumes.click ?? 0.5;
    if (poolKey === "repair") return this.volumes.repair ?? 0.45;
    if (poolKey === "music") return this.volumes.music ?? 0.28;
    return this.volumes.impact ?? 0.75;
  }

  _cooldownOk(key) {
    const wait = this.cooldowns[key] ?? 0;
    if (wait <= 0) return true;
    const now = (typeof performance !== "undefined" ? performance.now() : Date.now());
    const last = this.lastPlay.get(key) ?? -Infinity;
    if (now - last < wait) return false;
    this.lastPlay.set(key, now);
    return true;
  }

  /**
   * Low-level pooled play. Never throws, never rejects outwards.
   * @param {string} poolKey one of SOUND_FILES keys
   * @param {object} [opts] { volume 0..1 multiplier, rate playbackRate }
   * @returns {boolean} true when a play was attempted
   */
  play(poolKey, { volume = 1, rate = 1 } = {}) {
    try {
      if (!this.audible) return false;
      // Music never goes through the one-shot pool — use startMusic/stopMusic.
      if (poolKey === "music") return false;
      const pool = this.pools.get(poolKey);
      if (!pool?.length) {
        // Not preloaded yet (or preload failed): fall back to a one-shot so
        // early clicks still sound instead of staying silent until preload.
        this._oneShot(poolKey, volume, rate);
        return true;
      }
      const cursor = this.cursors.get(poolKey) ?? 0;
      const el = pool[cursor % pool.length];
      this.cursors.set(poolKey, cursor + 1);
      try {
        el.pause();
      } catch {
        /* was not playing */
      }
      try {
        el.currentTime = 0;
      } catch {
        /* not seekable yet */
      }
      try {
        el.volume = clamp01(this._baseVolume(poolKey) * volume);
      } catch {
        /* read-only volume */
      }
      try {
        el.playbackRate = rate;
      } catch {
        /* ignore */
      }
      let p = null;
      try {
        p = el.play();
      } catch {
        return false;
      }
      if (p && typeof p.catch === "function") p.catch(() => {});
      return true;
    } catch {
      return false;
    }
  }

  /** Fallback path when the pool is empty: a throwaway element per play. */
  _oneShot(poolKey, volume = 1, rate = 1) {
    try {
      const urls = SOUND_FILES[poolKey];
      if (!urls?.length) return;
      const url = urls[Math.floor(Math.random() * urls.length)];
      const el = new Audio(url);
      el.preload = "auto";
      el.volume = clamp01(this._baseVolume(poolKey) * volume);
      try {
        el.playbackRate = rate;
      } catch {
        /* ignore */
      }
      const p = el.play();
      if (p && typeof p.catch === "function") p.catch(() => {});
    } catch {
      /* silent */
    }
  }

  // ------------------------------------------------------------ game SFX

  /** UI click — wired globally to every <button> (see bindGlobalClickSound). */
  playClick() {
    if (!this._cooldownOk("click")) return false;
    return this.play("click", { volume: 1, rate: 0.96 + Math.random() * 0.08 });
  }

  /** Gas-station repair + paint jingle. */
  playRepair() {
    if (!this._cooldownOk("repair")) return false;
    return this.play("repair", { volume: 1, rate: 1 });
  }

  /**
   * Race/UI transition sweep. Accepts the CarAudio variant names so this can
   * stand in for `raceHud.sfx.whoosh` directly:
   * "ui"/"small" -> short file, "camera"/"result"/"passby"/"long" -> long file.
   */
  playWhoosh(variant = "ui") {
    const poolKey = WHOOSH_ROUTE[variant] ?? WHOOSH_ROUTE.small;
    const cdKey = poolKey === "whooshLong" ? "whooshLong" : "whooshSmall";
    if (!this._cooldownOk(cdKey)) return false;
    return this.play(poolKey, { volume: 1, rate: 0.97 + Math.random() * 0.06 });
  }

  /** CarAudio-compatible alias (raceHud calls `sfx.whoosh(variant)`). */
  whoosh(variant = "ui") {
    return this.playWhoosh(variant);
  }

  /**
   * Crash impact.
   * @param {"brick"|"metal"|"tree"|"auto"} kind surface flavour
   * @param {object} [opts] { intensity 0..1 (scales volume), volume extra gain }
   */
  playImpact(kind = "auto", { intensity = 0.7, volume = 1 } = {}) {
    if (!this._cooldownOk("impact")) return false;
    let poolKey = "impactBrick";
    const k = String(kind ?? "auto").toLowerCase();
    if (k === "metal") poolKey = "impactMetal";
    else if (k === "tree") poolKey = "impactTree";
    else if (k === "brick") poolKey = "impactBrick";
    else {
      // "auto": lean metallic for car shapes, brick otherwise — randomised so
      // repeated hits never sound identical.
      poolKey = Math.random() < 0.5 ? "impactMetal" : "impactBrick";
    }
    const hard = clamp01(intensity);
    // Soft taps stay quiet; full hits play at full base gain.
    const gain = (0.35 + 0.65 * hard) * volume;
    const rate = 0.9 + Math.random() * 0.2 - hard * 0.05;
    return this.play(poolKey, { volume: gain, rate });
  }

  /**
   * Crash volume from speed. Below ~15 km/h stays silent (parking touches).
   * @param {number} speedKmh impact speed in km/h
   * @param {"brick"|"metal"|"tree"|"auto"} kind
   */
  playImpactForSpeed(speedKmh, kind = "auto") {
    const v = Math.abs(Number(speedKmh) || 0);
    if (v < 15) return false;
    return this.playImpact(kind, { intensity: clamp01((v - 15) / 85) });
  }

  /**
   * Destructible prop break (fence / sign / crate / ...). Picks the flavour
   * from the family id so wood reads woody and signs read metallic.
   */
  playPropBreak(familyId = "", { intensity = 0.75 } = {}) {
    const kind = PROP_SOUND[String(familyId ?? "").toLowerCase()] ?? "auto";
    return this.playImpact(kind, { intensity });
  }

  // ------------------------------------------------------------- UI wiring

  /**
   * Play the click on EVERY button, present and future. Uses a single
   * delegated listener (no per-button wiring to maintain) plus a
   * MutationObserver-free design: delegation sees dynamically created garage
   * BUY/EQUIP buttons automatically. Safe to call twice.
   */
  bindGlobalClickSound() {
    try {
      if (this._boundClicks) return;
      if (typeof document === "undefined") return;
      this._boundClicks = true;
      document.addEventListener(
        "click",
        (e) => {
          try {
            const t = e.target?.closest?.("button");
            if (!t || t.disabled) return;
            this.playClick();
          } catch {
            /* hit-testing must never break clicks */
          }
        },
        true,
      );
    } catch {
      /* non-DOM environment (tests): stay silent */
    }
  }
}

/**
 * Shared game-wide instance. Import this everywhere instead of constructing
 * new managers, so mute/preload state stays in one place.
 */
export const soundManager = new SoundManager();
