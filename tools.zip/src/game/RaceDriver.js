import { CAR, approach, clamp, playerLateralAccelAt, stepVehicle } from "./driving.js";
import { TerrainFollower, describeVehicle } from "./terrain.js";
import { RaceProgress } from "./raceProgress.js";
import { createCarDamage, impactSeverity } from "./carDamage.js";
import { paintAt } from "./carPaint.js";

/**
 * One AI rival.
 *
 * It is a racer, not a road user, which is why it is not a `TrafficVehicle`:
 *
 *   - it drives the circuit as fast as its grip allows rather than at a
 *     comfortable cruise, braking for corners from a proper velocity profile,
 *   - it is allowed (and expected) to fight for position, so it follows the car
 *     ahead closely and pulls out to pass instead of queueing politely,
 *   - it never recycles, and its recovery puts it back on ITS OWN circuit point
 *     rather than anywhere along a shared lane,
 *   - it carries a `RaceProgress`, so laps and checkpoints are counted for it
 *     by exactly the same code that counts them for the player.
 *
 * The physics is the shared one (`stepVehicle`), so a rival's car turns, grips
 * and stalls under the same model as the player's, and its tyres are swept
 * against the map on every frame by the same `TerrainFollower`. What differs is
 * only the driving: lane following by pure pursuit, a corner-speed limit, and a
 * `pace` that scales how fast it is willing to go.
 */

/** Comfortable deceleration used to plan braking for corners, m/s^2. */
const DECEL = 12.0;
/**
 * Braking assumed when planning car-following gaps, m/s^2. Deliberately below
 * the true brake authority (~26) so the planned gap always has margin: the
 * field brakes early and together instead of piling into braking zones.
 */
const RACE_BRAKE = 12.0;
/** Fraction of the grip limit used through a corner - kept back from the edge
 *  so a car on the limit still has tyre left for a bump or a slide. */
const CORNER_MARGIN = 0.72;
/** Hard minimum gap to the car ahead, bumper to bumper, metres. */
const RACE_MIN_GAP = 1.2;
/** Rate limit for the wheel command, full-lock fractions per second. */
const STEER_RATE = 3.2;
/** How hard a rival pulls out of line to pass a slower car (steer units). */
const PASS_BIAS = 0.30;
/** Committed-pass steer authority once an overtake is latched (steer units). */
const OVERTAKE_BIAS = 0.55;
/** Steering pursuit gain: firm but smooth — no snap turns. */
const PURSUIT_GAIN = 1.35;
/** Lateral correction gain: eases back onto the line instead of yanking. */
const LATERAL_GAIN = 0.16;
/**
 * Over-lock past the feasible steer angle, as a ratio. The command is clamped
 * to what the tyres can hold at the current speed (see the handling clamp),
 * plus this margin so the wheels still visibly crank a little at the limit —
 * like the player's own over-lock, but small so the tyres never saturate deep
 * and plow the car into the outside wall.
 */
const STEER_OVERLOCK = 1.25;
/** Angle (rad) past which the AI emergency-brakes for the corner. */
const SHARP_DIFF = 0.7;
/** Angle (rad) past which the corner is a hairpin: crawl, then turn. */
const HAIRPIN_DIFF = 1.0;
/**
 * "Stuck" is measured as NET CIRCUIT PROGRESS over a window, not as speed and
 * not as distance travelled.
 *
 * The obvious measure - "did I move as far as I wanted this frame" - silently
 * fails exactly when it matters: the car ahead rule zeroes the wanted speed
 * when the gap is tight, and then any micro-jitter counts as progress, so a
 * field jammed nose-to-tail into itself is never detected as stuck. Measuring
 * distance travelled fails differently: a car pinned by the contact resolver
 * is nudged back and forth every frame, and a car spun broadside is still
 * "moving" while getting nowhere.
 *
 * What is actually true of a stuck car is that its distance ROUND THE CIRCUIT
 * stops increasing. So each window remembers the circuit distance it started
 * at, and if less than `STUCK_MIN_ADVANCE` metres of net progress was made by
 * the time the window closes, the car is stuck - whatever its speed readout or
 * its frame-to-frame displacement says.
 */
const STUCK_WINDOW = 1.2;
const STUCK_MIN_ADVANCE = 1.2;
/** Seconds of (effectively) no progress before a rival tries to reverse out. */
const STUCK_TRIGGER = 0.6;
/** Grace period after GO during which no progress is expected yet, seconds. */
const LAUNCH_GRACE = 3.5;
/**
 * Slowest a racer is ever asked to go, m/s, while the race is on.
 *
 * The car-ahead rule can legitimately ask for a stop, and the obvious
 * implementation - target zero, so no throttle - leaves a car that has been
 * stopped behind another one with no way to ever start again: zero target plus
 * zero speed is zero throttle for ever, and the field behind it jams. A floor
 * keeps every car creeping, so a jam pushes itself apart instead of locking.
 */
const MIN_CREEP_SPEED = 4.0;
/** Degrees off the circuit direction that counts as facing the wrong way. */
const WRONG_WAY_ANGLE = 1.25; // ~72 deg
/** How long a racer may sit facing the wrong way before it is re-seated, s. */
const WRONG_WAY_TIME = 1.4;
/** Recovery attempts before it concedes and is re-seated on the circuit. */
const WEDGE_LIMIT = 1;
/** Top reverse speed while unsticking, m/s. */
const REVERSE_CAP = 5;
/** Time a rival coasts after an impact before the AI takes over again. */
const SHOVE_DECAY_TIME = 0.35;
const SHOVE_RESUME_SPEED = 1.0;
/**
 * Most forward momentum one racer-to-racer bump may add to the struck car, m/s.
 * The caller already bounds what it hands over by the closing speed; this is
 * the second, blunter guard, so however a contact is classified a single frame
 * can never shunt a car further than a nudge.
 */
const PUSH_GAIN = 2.5;

export class RaceDriver {
  /**
   * @param rig      RaceRig for this rival
   * @param track    the circuit from buildRaceTrack
   * @param opts.name    display name (leaderboard)
   * @param opts.pace    0..1 - how hard it drives (see `cruiseSpeed`)
   * @param opts.collision  baked MapCollision
   * @param opts.player  the player vehicle, so rivals can see it
   */
  constructor(rig, track, { name = "Rival", pace = 0.9, cruiseSpeed = 26, collision = null, player = null, label = null } = {}) {
    this.rig = rig;
    this.track = track;
    this.path = track.path;
    this.name = name;
    this.label = label ?? name;
    this.pace = clamp(pace, 0.2, 1);
    this.cruiseSpeed = cruiseSpeed;
    this.player = player;
    this.stats = { impacts: 0, recoveries: 0, reseats: 0 };

    this.state = { x: 0, y: 0, z: 0, heading: 0, speed: 0 };
    /** Pose swept from this frame, for the contact resolver. */
    this.prevX = 0;
    this.prevZ = 0;
    this.debugTarget = undefined;
    this.debugBlocker = null;
    this.steerAngle = 0;
    this._steerSm = 0;
    this.roll = 0;
    this.pitch = 0;
    this.collided = false;
    this.stuckTime = 0;
    this.idleTime = 0;
    this.recover = 0;
    this.wedged = 0;
    /** Circuit distance at the start of the current stuck window. */
    this._stuckRef = null;
    /** Seconds elapsed in the current stuck window. */
    this._stuckWindow = 0;
    /** Net circuit progress measured over the last closed window (diagnostics). */
    this._lastNet = 0;
    this.wrongWayTime = 0;
    /** Set while the launch grace is running (see LAUNCH_GRACE). */
    this.stuckGrace = 0;
    this._wasLocked = false;
    /** True while the grid is held for the countdown: the car does not move. */
    this.locked = false;
    this.finished = false;
    /** True while the event is in icon-only state: invisible, non-collidable. */
    this.hidden = false;
    /** Latched pass side (-1 | 0 | +1) once an overtake commits. */
    this._overtakeSide = 0;
    /** Seconds the current overtake situation has held. */
    this._overtakeTime = 0;
    /** Seconds of extra following gap after contact (anti-grind caution). */
    this._bumpCooldown = 0;
    /**
     * Roadside-prop hook, wired by RaceSystem to the destructible system. It is
     * handed the pose the car could not reach (see update) and returns true when
     * a prop actually broke - the same contract the player's car uses.
     */
    this.onImpact = null;

    this.shove = { vx: 0, vz: 0, vHeading: 0, time: 0, decay: 1.4, arcade: false };
    this.shoved = false;

    this.progress = new RaceProgress(track);
    // NOTE: unlike traffic, a rival does NOT ignore the destructible families:
    // a roadside sign is solid to it exactly as it is to the player, which is
    // what makes the break a real HIT (proved by the sweep) rather than a
    // proximity test. The difference is the price - see the map-collision block
    // in update(), where a broken prop gives the racer its full motion back
    // instead of the player's half-speed penalty.
    this.terrain = collision ? new TerrainFollower(collision, describeVehicle(rig), 0) : null;
    // Body damage: dents + mirror cracks + smoke + pace loss. Guarded, so a
    // rig without a scene graph simply stays undamaged.
    const dmgDims = {
      halfLength: rig?.halfLength ?? CAR.length / 2,
      halfWidth: rig?.halfWidth ?? CAR.width / 2,
      height: rig?.height ?? CAR.height,
    };
    this.damage = createCarDamage(rig?.scene ?? null, dmgDims, { label: name });
    try {
      this.damage.attach(rig?.root ?? null);
    } catch {
      /* damage stays inert */
    }
    // AI rivals are cosmetically indestructible: dents, smoke and pace loss are
    // the PLAYER's alone. The damage model is kept only for its paint cycle, so
    // neuter hit recording — grip()/top() then stay at 1 (undamaged) forever.
    if (this.damage) this.damage.recordHit = () => {};
  }

  /**
   * Teleport onto a starting-grid slot. Also re-seeds the progress tracker, so
   * the car does not inherit a distance from wherever it was before.
   */
  placeOnGrid(pose) {
    this.state.x = pose.x;
    this.state.y = pose.y;
    this.state.z = pose.z;
    this.state.heading = pose.heading;
    this.state.speed = 0;
    this.steerAngle = 0;
    this._steerSm = 0;
    this.stuckTime = 0;
    this.idleTime = 0;
    this.recover = 0;
    this.wedged = 0;
    this.locked = true;
    this._wasLocked = true;
    this._overtakeSide = 0;
    this._overtakeTime = 0;
    this._bumpCooldown = 0;
    this._stuckRef = null;
    this._stuckWindow = 0;
    this.wrongWayTime = 0;
    this.stuckGrace = 0;
    this.finished = false;
    this.shove.time = 0;
    this.shove.vx = 0;
    this.shove.vz = 0;
    this.shove.vHeading = 0;
    this.shove.arcade = false;
    this.shoved = false;
    try {
      this.damage?.repair();
    } catch {
      /* fresh shell on the grid */
    }
    // Roll the rival to its next paint now that it is back to factory.
    // Deterministic colour from the seed alone: applied at build time (the
    // first _placeFieldOnGrid) and identical on every re-grid, so the field is
    // already wearing its race colours the moment it is revealed and never
    // swaps colour as the race begins.
    paintAt(this, this.paintSeed ?? 0);
    // Seed progress from the slot's KNOWN arc position when the grid supplies
    // it (authored tracks), so a loop/out-and-back that passes near the grid
    // twice can't seed onto the wrong branch and aim the car backwards. Fall
    // back to the nearest-point search only for grids without an arc (legacy).
    if (pose.s != null) this.progress.reset(pose.s);
    else this.progress.reset(this.track.startDistance, { x: pose.x, z: pose.z });
    if (this.terrain) {
      this.terrain.teleport(pose.y);
      this.terrain.apply(this.rig, pose.x, pose.z, pose.heading);
    } else {
      this.rig.setPosition(pose.x, pose.y, pose.z);
      this.rig.setHeading(pose.heading);
    }
    this.rig.setSteer(0);
    if (this.rig.setGroundTilt) this.rig.setGroundTilt(this.terrain?.pitch ?? 0, this.terrain?.roll ?? 0);
    this.syncWheels(0);
  }

  /** External impulse - arcade bump, NOT a traffic shove. */
  applyShove(vx, vz, yawRate, { arcade = false } = {}) {
    const speed = Math.hypot(vx, vz);
    // NFS/Forza style: contact nudges, never launches. A 6 m/s cap keeps the
    // jolt visible without flinging a racer across the road.
    const MAX_SHOVE = 6;
    if (speed > MAX_SHOVE) {
      const k = MAX_SHOVE / speed;
      vx *= k;
      vz *= k;
    }
    const MAX_SPIN = 1.1;
    if (Math.abs(yawRate) > MAX_SPIN) yawRate = Math.sign(yawRate) * MAX_SPIN;
    this.shove.vx += vx;
    this.shove.vz += vz;
    this.shove.vHeading += yawRate;
    this.shove.time = SHOVE_DECAY_TIME;
    // Remember what kind of hit this was: a racer bump carries no speed penalty
    // once the nudge has decayed (its momentum was handed over in pushForward),
    // while a traffic-style shove still costs the old scrub.
    this.shove.arcade = arcade;
    this.shoved = true;
    this.recover = 0;
    this.wedged = 0;
    // NOTE: the stuck counters are deliberately NOT cleared here. A car that is
    // being hit repeatedly - which is exactly what a car pinned in a scrum
    // experiences - used to have `stuckTime` reset on every impact, so it could
    // never accumulate enough to try to free itself and the scrum never broke
    // up. Being hit is not progress, so it must not count as some.
    this.stats.impacts++;
  }

  /**
   * Momentum transfer: a racer pressed from behind is driven FORWARD along its
   * own heading, not merely displaced.
   *
   * `applyShove` is a positional jolt: it lasts a third of a second and leaves
   * the car's own speed untouched, so the car-ahead rule brakes the pair back
   * to creep speed the moment it decays - a rear-end that should shunt the car
   * in front down the road became two cars parked on the racing line. This puts
   * the push into the car's SPEED, along the way it is already travelling, so
   * the struck racer keeps rolling after the contact and the follower's gap
   * reopens by itself.
   *
   * The caller bounds `amount` by the closing speed (see vehicleCollision.js),
   * so this can never be free speed: a car already travelling as fast as the
   * one behind it is handed nothing.
   *
   * @returns the speed actually gained, m/s (0 when the push did not apply).
   */
  pushForward(amount) {
    // Reversing out of a wedge is a deliberate move; a bumper behind it is not
    // a reason to fire it forwards out of the recovery it is mid-way through.
    if (!(amount > 0) || this.state.speed < 0) return 0;
    const before = this.state.speed;
    this.state.speed = Math.min(this.state.speed + Math.min(amount, PUSH_GAIN), CAR.maxSpeed);
    return this.state.speed - before;
  }

  /**
   * Report a blocked pose to the destructible system and return whether a prop
   * actually broke.
   *
   * This is the exact hook the player's car calls (`onImpact`, wired up by
   * RaceSystem to the same `DestructibleSystem`), handed the pose the car could
   * not reach plus the pose it swept from, which is what the break direction is
   * measured from. What the caller does with the answer is where these two cars
   * part company: the player halves their speed, a racer just drives on.
   */
  _smashProps(wantX, wantZ, prevX, prevZ) {
    if (!this.onImpact) return false;
    const g = this.terrain?.g;
    if (!g) return false;
    return this.onImpact({
      x: wantX,
      z: wantZ,
      prevX,
      prevZ,
      y: this.state.y,
      heading: this.state.heading,
      speed: this.state.speed,
      clearance: g.clearance,
      height: g.height,
      halfLength: g.halfLength,
      halfWidth: g.halfWidth,
    });
  }

  /**
   * @param opts.racers  every rival (so they race each other, not just the player)
   * @param opts.traffic the ambient traffic system, so rivals see parked traffic
   * @param opts.time    race clock at this frame, seconds
   */
  update(dt, { racers = [], traffic = null, time = 0 } = {}) {
    if (this.hidden) return;
    if (this.locked) {
      // Held on the grid for the countdown. Nothing moves, but the wheels are
      // still synced so the car sits correctly on the road.
      this.state.speed = 0;
      this._applyPose();
      return;
    }
    if (this._wasLocked) {
      // Just released at GO. A standing start has no progress yet by design, so
      // the stuck detector is held off until the field has had time to move.
      this._wasLocked = false;
      this._stuckRef = null;
      this._stuckWindow = 0;
      this.stuckTime = 0;
      this.idleTime = 0;
      this.stuckGrace = LAUNCH_GRACE;
    }

    // --- arcade bump absorption (NFS/Forza style) -------------------------
    // Contact is a lateral nudge applied ON TOP of driving, never instead of
    // it. The AI keeps steering + throttle through the hit, keeps ~85% of its
    // speed, and the shove decays in a third of a second. A racer never parks
    // itself like a traffic car because someone leaned on it.
    if (this.shove.time > 0) {
      this.shove.time -= dt;
      const friction = Math.exp(-this.shove.decay * dt);
      const prevSX = this.state.x;
      const prevSZ = this.state.z;
      this.state.x += this.shove.vx * dt;
      this.state.z += this.shove.vz * dt;
      this.state.heading = wrapAngle(this.state.heading + this.shove.vHeading * dt * 0.4);
      this.shove.vx *= friction;
      this.shove.vz *= friction;
      this.shove.vHeading *= friction;
      if (this.terrain) {
        let res = this.terrain.sweep(prevSX, prevSZ, this.state.x, this.state.z, this.state.heading, { ignoreDestructibles: true });
        if (res.blocked) {
          this.state.x = res.x;
          this.state.z = res.z;
          this.shove.vx *= 0.3;
          this.shove.vz *= 0.3;
        }
        this.terrain.follow(dt, this.state.x, this.state.z, this.state.heading);
        this.state.y = this.terrain.y;
      }
      const shoveSpeed = Math.hypot(this.shove.vx, this.shove.vz);
      if (this.shove.time <= 0 && shoveSpeed < SHOVE_RESUME_SPEED && Math.abs(this.shove.vHeading) < 0.8) {
        this.shoved = false;
        this.shove.vx = 0;
        this.shove.vz = 0;
        this.shove.vHeading = 0;
        // A racer bump is not a crash: the shove is a capped nudge and the
        // momentum has already been handed over (see pushForward), so charging
        // the old 15% on top just re-braked the car that had just been pushed
        // forward. A traffic-style shove still scrubs (was *0.3).
        if (!this.shove.arcade) this.state.speed = Math.max(0, this.state.speed * 0.85);
        this.shove.arcade = false;
        this.progress.resync(this.state.x, this.state.z);
      }
      // Fall through to normal driving below — the bump rides along while
      // the racer keeps racing.
    }
    if (this.shove.time <= 0 && this.shoved) {
      const residual = Math.hypot(this.shove.vx, this.shove.vz);
      if (residual < 0.5 && Math.abs(this.shove.vHeading) < 0.5) this.shoved = false;
    }

    // --- racing line ------------------------------------------------------
    // Pure pursuit with a speed-proportional preview that follows the line
    // instead of cutting it: long enough to start turn-in early at speed,
    // short enough that the aim point never jumps across a corner (which is
    // what threw cars at inside walls). Twistiness ahead shortens it further:
    // a sharp corner is tracked point-to-point, never chord-cut.
    this.prevX = this.state.x;
    this.prevZ = this.state.z;
    const speed = Math.abs(this.state.speed);
    const previewCurve = this._previewCurvature(speed);
    const lookAhead = clamp((7 + speed * 0.55) / (1 + previewCurve * 22), 6, 30);
    // Grip available right now — every speed/steer decision below is derived
    // from it, so the car only ever asks for what its handling can deliver.
    // Bent alignment steals grip (1 when undamaged).
    const gripNow = this._aiGrip(speed) * (this.damage?.grip() ?? 1);
    const here = this.path.sample(this.progress.distance);
    const lateral = (here.x - this.state.x) * Math.cos(this.state.heading) -
      (here.z - this.state.z) * Math.sin(this.state.heading);

    // The start of a race is a drag race, not a queue: for the first seconds
    // after GO the car-ahead rule is waived, so the whole field launches and
    // spreads instead of the back of the grid inheriting the front's speed and
    // tangling at the lights.
    const launching = this.stuckGrace > 0;
    // The standing-start waiver ends once rolling: the launch keeps its lanes
    // (see the aim target below), but from ~10 m/s the field races for real,
    // so a faster starter brakes for the car ahead instead of rear-ending it
    // through the rest of the grace period.
    const launchingHold = launching && Math.abs(this.state.speed) < 10;

    // Launch lane-keeping. During the launch each car aims at a point on the
    // circuit SHIFTED BY ITS OWN LATERAL OFFSET, i.e. it holds its grid lane,
    // rather than all six converging on the centre line at once. That merge is
    // what turned the start into a scrum: two cars arriving on the same line
    // together touch, the contact resolver slows both, and neither can break
    // free. After the launch they merge onto the racing line gradually, which
    // they can do because by then they are strung out along the road.
    const lane = this._laneHeading(0);
    const laneRightX = Math.cos(lane);
    const laneRightZ = -Math.sin(lane);
    const myLat = (this.state.x - here.x) * laneRightX + (this.state.z - here.z) * laneRightZ;
    const aim = this.path.sample(this.progress.distance + lookAhead);
    // On the launch, a car gridded on an attached approach road (which may join
    // the start at an angle, e.g. North Circuit arriving from the side) first
    // drives INTO the start line, then picks up the racing line - so it never
    // cuts the corner off its grid slot. Once at the line it follows the path.
    const sp = this.track.startPose;
    const distStart = sp ? Math.hypot(sp.x - this.state.x, sp.z - this.state.z) : 0;
    // Only steer to the line when it is actually AHEAD of the car (a grid on an
    // attached/side road), never when the car was gridded past the line
    // (dead-end fallback), which would make it drive backwards.
    const toLineDot = sp
      ? (sp.x - this.state.x) * Math.sin(this.state.heading) + (sp.z - this.state.z) * Math.cos(this.state.heading)
      : -1;
    const approaching = launching && this.progress.distance < 3 && distStart > 7 && toLineDot > 0;
    const target = approaching
      ? { x: sp.x, z: sp.z }
      : launching
        ? { x: aim.x + laneRightX * myLat, z: aim.z + laneRightZ * myLat }
        : aim;

    const desired = Math.atan2(target.x - this.state.x, target.z - this.state.z);
    const diff = wrapAngle(desired - this.state.heading);
    // Gentle gains everywhere, launch included: the car eases toward the line
    // instead of snapping at it. Snap steering was what made the field look
    // twitchy and what threw overtaking cars at walls.
    const pursuitGain = launching ? 1.3 : PURSUIT_GAIN;
    const lateralGain = launching ? 0.10 : LATERAL_GAIN;
    let steer = clamp(-diff * pursuitGain - lateral * lateralGain, -1, 1);

    // --- speed: corners, then whatever is in the way ----------------------
    // Finished rivals don't park on the finish line — they run a cooldown lap
    // at half pace (same line, same rules) until RaceSystem despawns them out
    // of the player's sight.
    const cruise = this.finished ? this.cruiseSpeed * 0.55 : this.cruiseSpeed;
    const cornerLimit = this._cornerSpeedLimit();
    let targetSpeed = Math.min(cruise, cornerLimit);
    // Turn costed from handling, not from feel: pure pursuit needs a lateral
    // acceleration of v^2 * kappa, where kappa comes straight from the aim
    // angle and the preview distance. Capping speed at sqrt(grip / kappa)
    // guarantees the commanded turn is one the tyres can actually hold, so
    // the car slows to exactly what the corner allows — no more, no less —
    // instead of arriving too hot and grinding along a building.
    const kappa = Math.abs((2 * Math.sin(diff)) / Math.max(lookAhead, 1));
    if (kappa > 1e-4) {
      targetSpeed = Math.min(targetSpeed, Math.sqrt((gripNow * CORNER_MARGIN) / kappa));
    }
    // Mild extra lift with lock for queue-like snarls the geometry misses.
    targetSpeed *= 1 - clamp(Math.abs(diff) / Math.PI, 0, 1) * 0.25;
    const absDiff = Math.abs(diff);
    if (absDiff > HAIRPIN_DIFF) targetSpeed = Math.min(targetSpeed, 10);
    else if (absDiff > SHARP_DIFF) targetSpeed = Math.min(targetSpeed, 14);

    const candidates = [];
    for (const r of racers) {
      if (r !== this && !r.hidden) candidates.push(r);
    }
    if (this.player) candidates.push(this.player);
    if (traffic?.vehicles) {
      for (const v of traffic.vehicles) candidates.push(v);
    }
    const blocker = this._blockerAhead(candidates);
    this.debugBlocker = blocker
      ? { gap: Number(blocker.gap.toFixed(2)), closing: Number(blocker.closing.toFixed(2)), name: blocker.vehicle?.name ?? "?" }
      : null;
    if (this._bumpCooldown > 0) this._bumpCooldown -= dt;
    if (blocker && !launchingHold) {
      // Racer rule: inherit the car ahead but close the gap hard. The gap
      // target stays tight at speed and the closing term is aggressive, so
      // rivals draft and dive rather than queue politely like traffic.
      // It is predictive, not just proportional: the wanted gap grows with
      // the stopping distance for the RELATIVE speed, so a car arriving hot
      // on a braking rival is already shedding speed instead of discovering
      // the bumper at the last metre. `RACE_BRAKE` undersells the true
      // brakes on purpose, which is what keeps braking zones orderly.
      // Fresh contact adds a temporary cushion on top, so two cars that just
      // touched separate instead of grinding frame after frame.
      const mySpeed = Math.abs(this.state.speed);
      const relSpeed = Math.max(0, mySpeed - Math.max(0, blocker.closing));
      const brakeDist = (relSpeed * relSpeed) / (2 * RACE_BRAKE);
      const desiredGap =
        RACE_MIN_GAP +
        Math.min(mySpeed, 50) * 0.08 +
        brakeDist +
        (this._bumpCooldown > 0 ? 4 : 0);
      const safeSpeed = blocker.closing + (blocker.gap - desiredGap) * 1.4;
      targetSpeed = Math.min(targetSpeed, Math.max(0, safeSpeed));
      if (!this.finished) {
        // Overtake commitment: when the SAME car holds us up (tight gap, it
        // is slower than us, and we are materially under the corner limit),
        // latch a pass side instead of queuing behind it forever. The latch
        // survives losing sight of the car mid-pass, so the rival diverts
        // around and through rather than sitting in the lane waiting for it
        // to clear.
        const spd = Math.abs(this.state.speed);
        const heldUp =
          blocker.gap < 9 && blocker.closing < spd - 1 && targetSpeed < cornerLimit - 2;
        if (heldUp) {
          this._overtakeTime += dt;
          if (this._overtakeSide === 0 && this._overtakeTime > 0.6) {
            const dx = blocker.vehicle.state.x - this.state.x;
            const dz = blocker.vehicle.state.z - this.state.z;
            const side = dx * Math.cos(this.state.heading) - dz * Math.sin(this.state.heading);
            // Pass on the open side: away from the car ahead, or down our own
            // offset side when it sits dead centre.
            this._overtakeSide = Math.abs(side) > 0.6 ? Math.sign(side) : lateral >= 0 ? 1 : -1;
          }
          // A pass that takes absurdly long is a wall, not a car: drop the
          // latch and re-evaluate instead of grinding the barrier.
          if (this._overtakeTime > 6) {
            this._overtakeTime = 0;
            this._overtakeSide = 0;
          }
        } else if (blocker.gap > 14) {
          this._overtakeTime = Math.max(0, this._overtakeTime - dt * 2);
          if (this._overtakeTime === 0) this._overtakeSide = 0;
        }
      }
      // Pull out of line to pass rather than sitting behind a slower car. The
      // bias is small and wall-checked: a blocked side flips, two blocked
      // sides mean hold the line — the map collision, not this number, is
      // what keeps the car on the road. Skipped while a pass is latched - the
      // commitment above already owns the steering and the two must not fight
      // mid-pass.
      if (blocker.gap < 14 && !this.finished && this._overtakeSide === 0) {
        const dx = blocker.vehicle.state.x - this.state.x;
        const dz = blocker.vehicle.state.z - this.state.z;
        const side = dx * Math.cos(this.state.heading) - dz * Math.sin(this.state.heading);
        let biasSide = Math.abs(side) > 0.6 ? Math.sign(side) : (lateral >= 0 ? 1 : -1);
        if (!this._sideClear(biasSide)) biasSide = this._sideClear(-biasSide) ? -biasSide : 0;
        // biasSide 0 means boxed in: sit behind and wait for room rather than
        // grinding a fence.
        if (biasSide !== 0) {
          // Steer harder the slower the car is going: a rival crawling behind a
          // slower car should commit to going round it, not sit and queue.
          const commit = 1 + clamp((6 - Math.abs(this.state.speed)) / 6, 0, 1);
          steer = clamp(steer + PASS_BIAS * commit * biasSide, -1, 1);
        }
      }
    } else if (!launchingHold && !this.finished) {
      // Open road: a latched pass holds its line through the move (it is
      // mid-pass, alongside rather than behind); an unlatched timer bleeds.
      if (this._overtakeSide === 0) {
        this._overtakeTime = Math.max(0, this._overtakeTime - dt * 2);
      }
    }
    // A latched pass holds its offset line with authority and carries passing
    // speed (capped by the corner limit, so commitment never out-drives the
    // tyres into a wall). The offset side is probed first: if a fence or wall
    // owns it, the pass flips to the other side, and if both are owned the
    // car holds the line this frame instead of grinding the barrier.
    if (this._overtakeSide !== 0 && !launchingHold && !this.finished) {
      let passSide = this._overtakeSide;
      if (!this._sideClear(passSide)) passSide = this._sideClear(-passSide) ? -passSide : 0;
      if (passSide !== 0) {
        this._overtakeSide = passSide;
        steer = clamp(steer + OVERTAKE_BIAS * passSide, -1, 1);
        const passSpeed = blocker ? Math.max(0, blocker.closing) + 6 : targetSpeed;
        targetSpeed = Math.max(targetSpeed, Math.min(cornerLimit, passSpeed));
      }
    }
    // A racer is never asked to stop dead while the race is on: see
    // MIN_CREEP_SPEED. The floor is applied to the FINAL target so the corner
    // limit and the car-ahead rule can slow it right down without ever
    // switching it off. Finished cars get a lower floor — they cruise, and a
    // hairpin cap may briefly ask less than creep speed on their cooldown lap.
    targetSpeed = this.finished ? Math.max(4, targetSpeed) : Math.max(MIN_CREEP_SPEED, targetSpeed);
    // Heavy body damage caps pace: a wrecked rival crawls (the creep floor
    // still applies, so it limps rather than parks).
    targetSpeed *= this.damage?.top() ?? 1;

    // --- wrong-way / spun recovery ----------------------------------------
    // A car shoved sideways or spun around cannot reorient itself by steering
    // alone: at a standstill there is no yaw, so it would sit broadside on the
    // racing line blocking the field for the rest of the race. Past a couple of
    // seconds of facing the wrong way it is re-seated on the circuit.
    const laneHeading = this._laneHeading(0);
    const offTrack = Math.abs(wrapAngle(laneHeading - this.state.heading));
    if (offTrack > WRONG_WAY_ANGLE && Math.abs(this.state.speed) < 3 && !this.finished) {
      this.wrongWayTime += dt;
      if (this.wrongWayTime > WRONG_WAY_TIME) {
        this.wrongWayTime = 0;
        this._reseat();
        return;
      }
    } else {
      this.wrongWayTime = 0;
    }

    // --- stuck recovery ---------------------------------------------------
    // Fast auto-reset: one reverse attempt, then straight back onto the
    // circuit. A stuck racer re-joins the race in ~2s instead of sitting as a
    // roadblock while the field piles into it.
    if (this.stuckGrace > 0) {
      this.stuckGrace -= dt;
      this.stuckTime = 0;
    }
    if ((this.stuckTime > STUCK_TRIGGER || this.idleTime > 2.0) && this.recover <= 0) {
      this.wedged++;
      if (this.wedged >= WEDGE_LIMIT) {
        this._reseat();
        this.wedged = 0;
      } else {
        this.recover = 0.9;
        this.stats.recoveries++;
      }
    }
    let recovering = false;
    if (this.recover > 0) {
      this.recover -= dt;
      recovering = true;
      steer = clamp(-steer, -1, 1);
    }

    this._steerSm = approach(this._steerSm, steer, STEER_RATE * dt);
    steer = this._steerSm;

    this.debugTarget = targetSpeed;
    const err = this.state.speed - targetSpeed;
    // Snappy pedals: brake authority matches the DECEL the planner assumes,
    // so the car actually sheds what the corner plan asked it to shed.
    const throttle = recovering ? 0 : err < 0 ? clamp(-err / 3, 0, 1) : 0;
    const brake = recovering ? 1 : err > 0.3 ? clamp(err / 3, 0, 1) : 0;

    const prevX = this.state.x;
    const prevZ = this.state.z;
    const speedBefore = this.state.speed;
    // Handling clamp: the tightest angle the tyres can hold at this speed is
    // atan(grip * wheelBase / v^2) — ask for more and the extra lock only
    // saturates the tyres, so the car understeers wide into the outside wall
    // while the wheels sit cranked. Clamping to feasible + a small over-lock
    // keeps the tyres gripping, which is what keeps the car off buildings.
    // (Near standstill the feasible angle is huge, so parking turns are
    // untouched.)
    const rawAngle = steer * CAR.maxSteer;
    const feasibleAngle = Math.atan((gripNow * CAR.wheelBase) / Math.max(speed * speed, 1));
    const steerAngle = clamp(rawAngle, -feasibleAngle * STEER_OVERLOCK, feasibleAngle * STEER_OVERLOCK);
    const yawRate = stepVehicle(this.state, dt, {
      throttle,
      brake,
      steerAngle,
      // Player-grade grip: the player corners at up to ~43 m/s^2 at speed
      // while the old AI figure sat at ~14, so the AI needed 3x the radius
      // for every corner and plowed off anything sharp at pace. The AI now
      // turns on the same tyres as the player (scaled by pace), so a corner
      // the player can take flat, a rival can take flat too.
      lateralAccel: gripNow,
    });
    const accel = (this.state.speed - speedBefore) / Math.max(dt, 1e-4);
    if (recovering && this.state.speed < -REVERSE_CAP) this.state.speed = -REVERSE_CAP;

    // --- map collision ----------------------------------------------------
    let moved = 0;
    let progress = 0;
    if (this.terrain) {
      // The pose this frame wanted, before the map argues with it. A prop that
      // breaks must be able to hand the car its FULL motion back (see below).
      const wantX = this.state.x;
      const wantZ = this.state.z;
      let res = this.terrain.sweep(prevX, prevZ, wantX, wantZ, this.state.heading, { ignoreDestructibles: true });
      if (res.escaped) {
        this.collided = true;
        this.state.x = res.x;
        this.state.z = res.z;
        // Arcade wall kiss: scrub, don't stop.
        this.state.speed *= 0.85;
      } else if (res.blocked) {
        this.collided = true;
        // Sliding along the wall keeps a car that clips a kerb going instead of
        // dead-stopping, which is what makes a race read as racing.
        const slideX = this.terrain.sweep(prevX, prevZ, this.state.x, prevZ, this.state.heading);
        const slideZ = this.terrain.sweep(prevX, prevZ, prevX, this.state.z, this.state.heading);
        const dxs = Math.abs(slideX.x - prevX);
        const dzs = Math.abs(slideZ.z - prevZ);
        if (!slideX.blocked && dxs >= dzs) {
          this.state.x = slideX.x;
          this.state.z = prevZ;
        } else if (!slideZ.blocked) {
          this.state.x = prevX;
          this.state.z = slideZ.z;
        } else {
          this.state.x = res.x;
          this.state.z = res.z;
          // Even a head-on keeps rolling — the reseat logic handles true wedges.
          this.state.speed *= 0.4;
        }
        if (this.state.speed !== 0) this.state.speed *= 0.88;
        // Body damage from the wall: severity from the speed scrubbed by the
        // impact this frame. Contact face approximated from travel: the nose
        // leads, so the dent lands on the front surface along the motion.
        try {
          const drop = Math.abs(speedBefore) - Math.abs(this.state.speed);
          const sev = Math.max(impactSeverity(Math.abs(speedBefore)), drop > 0.5 ? 0.12 : 0);
          if (sev > 0 && this.damage) {
            const mdx = this.state.x - prevX;
            const mdz = this.state.z - prevZ;
            const md = Math.hypot(mdx, mdz);
            const tx = md > 1e-4 ? mdx / md : Math.sin(this.state.heading);
            const tz = md > 1e-4 ? mdz / md : Math.cos(this.state.heading);
            const hl = this.rig?.halfLength ?? CAR.length / 2;
            this.damage.recordHit({
              x: this.state.x + tx * hl * 0.8,
              y: this.state.y + 0.8,
              z: this.state.z + tz * hl * 0.8,
              dirX: tx,
              dirZ: tz,
              severity: sev,
              speed: speedBefore,
              cx: this.state.x,
              cz: this.state.z,
              heading: this.state.heading,
              carY: this.state.y,
            });
          }
        } catch {
          /* dents are cosmetic: never fail a crash */
        }
      } else {
        this.collided = false;
        this.state.x = res.x;
        this.state.z = res.z;
      }

      this.terrain.follow(dt, this.state.x, this.state.z, this.state.heading);
      this.state.y = this.terrain.y;

      const dx = this.state.x - prevX;
      const dz = this.state.z - prevZ;
      moved = Math.hypot(dx, dz);
      progress = dx * Math.sin(this.state.heading) + dz * Math.cos(this.state.heading);

      if (moved < 0.02) this.idleTime += dt;
      else this.idleTime = Math.max(0, this.idleTime - dt * 2);
    } else {
      const dx = this.state.x - prevX;
      const dz = this.state.z - prevZ;
      moved = Math.hypot(dx, dz);
      progress = dx * Math.sin(this.state.heading) + dz * Math.cos(this.state.heading);
    }

    // --- progress: checkpoints, laps, circuit distance --------------------
    const events = this.progress.update(this.state.x, this.state.z, { time });
    if (events.finished) this.finished = true;

    // See STUCK_WINDOW: distance round the CIRCUIT, not distance travelled in
    // whatever direction the car happens to be pointing, is what says whether
    // it is racing. A car spun broadside keeps "moving" while getting nowhere;
    // this does not.
    if (this._stuckRef === null) this._stuckRef = this.progress.distance;
    if (this.stuckGrace <= 0) {
      // NET progress over the window, not the sum of every forward twitch. A car
      // pinned against another one is nudged back and forth by the contact
      // resolver every frame; summing the positive halves of that jitter
      // reported healthy progress for a car that was not moving at all, which
      // is why a pinned rival never tried to free itself. A window reference
      // taken from the circuit distance cannot be fooled that way: jitter
      // cancels, and only a real gain round the lap clears it.
      this._stuckWindow += dt;
      if (this._stuckWindow >= STUCK_WINDOW) {
        const net = wrapDelta(this.progress.distance - this._stuckRef, this.path.length);
        this._lastNet = net;
        this._stuckRef = this.progress.distance;
        this._stuckWindow = 0;
        if (net < STUCK_MIN_ADVANCE) this.stuckTime += STUCK_WINDOW;
        else this.stuckTime = 0;
      }
    }

    // --- presentation -----------------------------------------------------
    const denom = Math.max(Math.abs(this.state.speed), 0.4) / CAR.wheelBase;
    const visSteer = clamp(-Math.atan(yawRate / denom), -CAR.maxSteer, CAR.maxSteer);
    this.steerAngle = approach(this.steerAngle, visSteer, CAR.steerRate * dt);
    this.roll += (clamp(-this.state.speed * yawRate * 0.012, -0.07, 0.07) - this.roll) * 0.2;
    this.pitch += (clamp(accel * 0.002, -0.03, 0.03) - this.pitch) * 0.2;

    this._applyPose();
    // Wheels roll with the distance actually covered along the track, so a
    // blocked or spinning car does not wind its wheels up.
    this.syncWheels(progress);
    // Bonnet smoke follows the damage state.
    try {
      this.damage?.update(dt, {
        x: this.state.x,
        y: this.state.y,
        z: this.state.z,
        heading: this.state.heading,
        speed: this.state.speed,
      });
    } catch {
      /* smoke must never break racing */
    }
  }

  /** Last frame's speed target and the car that limited it (diagnostics). */
  debugInfo() {
    return {
      target: this.debugTarget === undefined ? null : Number(this.debugTarget.toFixed(2)),
      blocker: this.debugBlocker ?? null,
      overtake: this._overtakeSide,
      bump: Number(this._bumpCooldown.toFixed(2)),
      locked: this.locked,
      grace: Number(this.stuckGrace.toFixed(2)),
      stuck: Number(this.stuckTime.toFixed(2)),
      recover: Number(this.recover.toFixed(2)),
      net: Number(this._lastNet.toFixed(2)),
      win: Number(this._stuckWindow.toFixed(2)),
      speed: Number(this.state.speed.toFixed(2)),
      total: Number(this.progress.total.toFixed(1)),
    };
  }

  /**
   * Nearest car ahead of this one ON THE CIRCUIT, and the gap to it.
   *
   * This deliberately does not use the shared `nearestBlocker`, which answers
   * a road-user's question - "is something in the corridor I am about to drive
   * down" - and answers it with an oriented-box overlap that widens as the two
   * headings diverge. On a race grid that is exactly wrong: six cars start in
   * three side-by-side columns, neighbours are 2.6 m apart laterally, and the
   * slightest steering divergence widens the corridor until each car counts
   * its neighbours as blockers overlapping it by half a car length. Every gap
   * goes negative, every target speed collapses, and the whole field sits on
   * the line for the whole race.
   *
   * A racer's real question is "who is ahead of me on the racing line", which
   * the circuit already answers: every car follows the same `path`, so a car's
   * arc position orders it, and cars in the same grid row share one. A rival is
   * only a blocker if it is genuinely further round the circuit AND within a
   * car's width of our line, and the gap is then a real bumper-to-bumper
   * distance rather than a projection.
   */
  _blockerAhead(candidates) {
    const path = this.path;
    const myS = this.progress.distance;
    const here = path.sample(myS);
    const head = this._laneHeading(0);
    const sin = Math.sin(head);
    const cos = Math.cos(head);
    const myHalfW = this.rig?.halfWidth ?? CAR.width / 2;
    const myHalfL = this.rig?.halfLength ?? CAR.length / 2;
    const scan = 26;
    const reach = scan + 10;
    let best = null;
    for (const v of candidates) {
      if (!v || v === this || !v.state) continue;
      const ex = v.state.x - this.state.x;
      const ez = v.state.z - this.state.z;
      if (ex * ex + ez * ez > reach * reach) continue;
      const vs = this._arcNear(v.state.x, v.state.z, myS);
      if (vs === null) continue;
      const d = wrapDelta(vs - myS, path.length);
      if (d > scan) continue;
      const vHalfW = v.rig?.halfWidth ?? CAR.width / 2;
      const vHalfL = v.rig?.halfLength ?? CAR.length / 2;
      const dh = (v.state.heading ?? head) - head;
      if (d <= 1.5) {
        // Near-overlap: only a blocker if genuinely ahead of the nose in OUR
        // frame and laterally overlapping. A car directly alongside is raced
        // (steering deals with it), not braked for — but a car we are already
        // touching nose-to-tail must count, or a locked pair grinds forever
        // with neither braking.
        const fx = Math.sin(this.state.heading);
        const fz = Math.cos(this.state.heading);
        const along = ex * fx + ez * fz;
        const across = Math.abs(ex * Math.cos(this.state.heading) - ez * Math.sin(this.state.heading));
        if (along > 0.5 && across <= myHalfW + vHalfW + 0.5) {
          const closing = (v.state.speed ?? 0) * Math.cos(dh);
          const gap = along - myHalfL - vHalfL;
          if (!best || gap < best.gap) {
            best = { vehicle: v, distance: along, gap, speed: v.state.speed ?? 0, closing };
          }
        }
        continue;
      }
      // Lateral distance from OUR line, measured along the circuit's normal.
      const side = Math.abs(
        (v.state.x - here.x) * cos - (v.state.z - here.z) * sin,
      );
      if (side > myHalfW + vHalfW + 0.5) continue;
      const closing = (v.state.speed ?? 0) * Math.cos(dh);
      const gap = d - myHalfL - vHalfL;
      if (!best || gap < best.gap) {
        best = { vehicle: v, distance: d, gap, speed: v.state.speed ?? 0, closing };
      }
    }
    return best;
  }

  /**
   * Arc position of a world point on this circuit, searched near `hint`.
   * Returns null when the point is not on the circuit at all (ambient traffic
   * driving an unrelated road), which is what keeps stray traffic from being
   * treated as part of the race.
   */
  _arcNear(x, z, hint) {
    const path = this.path;
    const win = 34;
    const step = 2;
    let bestD = hint;
    let bestDist = Infinity;
    for (let d = hint - win; d <= hint + win; d += step) {
      const p = path.sample(d);
      const dist = Math.hypot(p.x - x, p.z - z);
      if (dist < bestDist) {
        bestDist = dist;
        bestD = d;
      }
    }
    for (let d = bestD - step; d <= bestD + step; d += step / 4) {
      const p = path.sample(d);
      const dist = Math.hypot(p.x - x, p.z - z);
      if (dist < bestDist) {
        bestDist = dist;
        bestD = d;
      }
    }
    return bestDist > 18 ? null : bestD;
  }

  /**
   * Tyre grip for this racer at a given speed: the player's own grip curve
   * scaled by pace. Shared by the physics step and the corner planner below,
   * so the speeds the planner asks for are speeds the tyres can actually hold.
   */
  _aiGrip(speed) {
    return playerLateralAccelAt(speed) * (0.78 + 0.22 * this.pace);
  }

  /** Fastest speed the circuit allows over the next stretch of road. */
  _cornerSpeedLimit() {
    const path = this.path;
    const step = 3;
    const speedNow = Math.abs(this.state.speed);
    const scan = Math.min(path.length * 0.5, 15 + speedNow * 4.5);
    // Planned on the same tyres the car drives on (see _aiGrip), minus a
    // margin — so the plan is fast but always inside what the car can hold.
    // Headings are read over a ±2 m baseline so single-point kinks in the
    // lane data can't masquerade as hairpins and stamp on the brakes; real
    // corners still read correctly because their curvature spans many steps.
    const grip = this._aiGrip(speedNow) * CORNER_MARGIN;
    let limit = this.cruiseSpeed;
    let prev = this._laneHeading(this.progress.distance, 2);
    for (let d = step; d <= scan; d += step) {
      const cur = this._laneHeading(this.progress.distance + d, 2);
      const turn = wrapAngle(cur - prev);
      prev = cur;
      const radius = Math.abs(turn) > 1e-4 ? step / Math.abs(turn) : Infinity;
      const cornerSpeed = Math.sqrt(grip * radius);
      const reach = Math.sqrt(cornerSpeed * cornerSpeed + 2 * DECEL * d);
      limit = Math.min(limit, reach);
    }
    return clamp(limit, 4, this.cruiseSpeed);
  }

  /** Direction of travel of the circuit `ahead` metres past the car. */
  _laneHeading(ahead, win = 1) {
    const a = this.path.sample(this.progress.distance + ahead - win);
    const b = this.path.sample(this.progress.distance + ahead + win);
    return Math.atan2(b.x - a.x, b.z - a.z);
  }

  /**
   * Sharpest curvature (1/metres) over the road ahead. Drives the lookahead
   * length: straights keep the long preview, twisty bits track point to
   * point instead of chord-cutting across corners into roadside props.
   */
  _previewCurvature(speed) {
    const step = 6;
    const scan = Math.min(this.path.length * 0.5, 15 + Math.abs(speed) * 3);
    let curve = 0;
    let prev = this._laneHeading(this.progress.distance, 2);
    for (let d = step; d <= scan; d += step) {
      const cur = this._laneHeading(this.progress.distance + d, 2);
      const turn = Math.abs(wrapAngle(cur - prev));
      prev = cur;
      const k = turn / step;
      if (k > curve) curve = k;
    }
    return curve;
  }

  /**
   * Is the road ahead clear toward a lateral offset? Probes the map a car
   * length out on the steered side, so an overtake or pass-feeler never
   * diverts into a wall it cannot see. Destructible clutter is ignored by the
   * probe (it is solid to the wheels, but smashing a sign mid-pass is fine and
   * free): grinding a building is not, diving through a sign is.
   *
   * @param side +1 = left of heading, -1 = right (matches steer convention)
   */
  _sideClear(side, dist = 8, offset = 2.4) {
    if (!this.terrain) return true;
    const h = this.state.heading;
    const fx = Math.sin(h);
    const fz = Math.cos(h);
    const px = this.state.x + fx * dist - Math.cos(h) * side * offset;
    const pz = this.state.z + fz * dist + Math.sin(h) * side * offset;
    return !this.terrain.blocked(px, pz, h, null, { ignoreDestructibles: true });
  }

  /**
   * Last resort: put the car back on the circuit, a little behind where it got
   * stuck so it has room to set off again. Nothing else can free a car wedged
   * between two props, and a race with a permanent roadblock in it is worse
   * than a rival that briefly teleports.
   */
  _reseat() {
    this._stuckRef = null;
    this._stuckWindow = 0;
    this.wrongWayTime = 0;
    this.stuckGrace = LAUNCH_GRACE;
    const back = Math.max(this.progress.distance - 8, 0);
    const p = this.path.sample(back);
    const a = this.path.sample(back - 3);
    const b = this.path.sample(back + 3);
    const heading = Math.atan2(b.x - a.x, b.z - a.z);
    const hit = this.terrain?.collision.groundAt(p.x, p.z, p.y + 1, { stepUp: 3, reach: 6 });
    const y = hit?.kind === "ground" ? hit.y : p.y;
    this.state.x = p.x;
    this.state.y = y;
    this.state.z = p.z;
    this.state.heading = heading;
    // Rejoin rolling, not parked — a reset car is racing again immediately.
    this.state.speed = 8;
    this.shove.time = 0;
    this.shove.vx = 0;
    this.shove.vz = 0;
    this.shove.arcade = false;
    this.shoved = false;
    this.stuckTime = 0;
    this.idleTime = 0;
    this.recover = 0;
    this._overtakeSide = 0;
    this._overtakeTime = 0;
    this._bumpCooldown = 0;
    if (this.terrain) {
      this.terrain.teleport(y);
      this.terrain.apply(this.rig, p.x, p.z, heading);
    }
    // Seed to the KNOWN arc we reseated onto (not a nearest-point search), so a
    // doubled-back track can't re-seed onto the wrong branch and send the car
    // off the wrong way straight into the thing it was stuck on.
    this.progress.seedDistance(back);
    this.stats.reseats++;
    this._applyPose();
  }

  _applyPose() {
    this.rig.setPosition(this.state.x, this.state.y, this.state.z);
    this.rig.setHeading(this.state.heading);
    this.rig.setSteer(this.steerAngle);
    if (this.rig.setGroundTilt) {
      this.rig.setGroundTilt(this.terrain?.pitch ?? 0, this.terrain?.roll ?? 0);
    }
    if (this.terrain) this.rig.setSuspension(this.terrain.travels);
  }

  syncWheels(distance) {
    this.rig.spinWheels(distance);
  }

  get position() {
    return this.state;
  }

  get speedKmh() {
    return Math.abs(this.state.speed) * 3.6;
  }
}

function wrapDelta(delta, length) {
  const half = length / 2;
  let d = delta;
  while (d > half) d -= length;
  while (d < -half) d += length;
  return d;
}

function wrapAngle(a) {
  let x = a;
  while (x > Math.PI) x -= Math.PI * 2;
  while (x < -Math.PI) x += Math.PI * 2;
  return x;
}
