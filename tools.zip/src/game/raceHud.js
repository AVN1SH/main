/**
 * The race overlay: the event prompt, the countdown, the live position/lap
 * readout and the result board.
 *
 * All of it is DOM (see `index.html`), not canvas, so the text stays crisp and
 * the buttons are real buttons. This class only ever reads the state object
 * `RaceSystem.hudState` and writes to those elements; it holds no race logic of
 * its own, which is what keeps the rules in one place.
 *
 * Every write is guarded by a change check - the loop calls `update` 60 times a
 * second and re-setting identical text would thrash layout for nothing.
 */

export class RaceHud {
  /**
   * @param race the RaceSystem, used for the START / RESTART / CONTINUE buttons and for
   *   nothing else (the buttons call straight back into it).
   */
  constructor(race) {
    this.race = race;
    this.el = {
      countdown: document.getElementById("race-countdown"),
      warn: document.getElementById("race-warn"),
      hud: document.getElementById("race-hud"),
      pos: document.getElementById("race-pos"),
      posLabel: document.getElementById("race-pos-label"),
      posKicker: document.getElementById("race-pos-kicker"),
      lap: document.getElementById("race-lap"),
      lapLabel: document.getElementById("race-lap-label"),
      cp: document.getElementById("race-cp"),
      cpLabel: document.getElementById("race-cp-label"),
      time: document.getElementById("race-time"),
      timeLabel: document.getElementById("race-time-label"),
      prompt: document.getElementById("race-prompt"),
      promptTitle: document.getElementById("race-prompt-title"),
      promptSub: document.getElementById("race-prompt-sub"),
      promptHint: document.getElementById("race-prompt-hint"),
      promptType: document.getElementById("race-prompt-type"),
      promptDiff: document.getElementById("race-prompt-diff"),
      startBtn: document.getElementById("race-start-btn"),
      board: document.getElementById("race-board"),
      boardName: document.getElementById("race-board-name"),
      boardBeaten: document.getElementById("race-board-beaten"),
      boardRank: document.getElementById("race-board-rank"),
      boardFinish: document.getElementById("race-board-finish"),
      boardMeta: document.getElementById("race-board-meta"),
      boardTargets: document.getElementById("race-board-targets"),
      boardTargetsTitle: document.getElementById("race-board-targets-title"),
      boardPrizes: document.getElementById("race-board-prizes"),
      boardList: document.getElementById("race-board-list"),
      againBtn: document.getElementById("race-again-btn"),
      continueBtn: document.getElementById("race-continue-btn"),
      beat: document.getElementById("race-beat"),
      beatHead: document.getElementById("race-beat-head"),
      beatBeaten: document.getElementById("race-beat-beaten"),
      beatFinish: document.getElementById("race-beat-finish"),
      wall: document.getElementById("race-wall"),
      wallPos: document.getElementById("race-wall-pos"),
      wallTime: document.getElementById("race-wall-time"),
      shade: document.getElementById("race-shade"),
      intro: document.getElementById("race-intro"),
      introType: document.getElementById("race-intro-type"),
      introDiff: document.getElementById("race-intro-diff"),
      introName: document.getElementById("race-intro-name"),
      introPrizes: document.getElementById("race-intro-prizes"),
    };
    this._cache = {};
    /** Optional CarAudio-like object for transition whooshes (set by main.js). */
    this.sfx = null;
    /** Optional RaceEventManager for multi-event cycling (set by main.js). */
    this.raceManager = null;
    this._hintEl = this._makeHint();
    this._chevronContainer = this._makeChevrons();

    const start = (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.race.requestStart();
    };
    this.el.startBtn?.addEventListener("click", start);
    this.el.againBtn?.addEventListener("click", start);
    const cont = (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.race.continueAfterFinish();
    };
    this.el.continueBtn?.addEventListener("click", cont);
    // The buttons are the reason this overlay exists in the DOM at all, so stop
    // a click on them from also reaching the canvas / minimap beneath.
    for (const node of [this.el.startBtn, this.el.againBtn, this.el.continueBtn, this.el.prompt, this.el.board]) {
      node?.addEventListener("pointerdown", (e) => e.stopPropagation());
    }
  }

  /** Lazily-created "N m ahead" line under the prompt. */
  _makeHint() {
    const host = this.el.prompt;
    if (!host) return null;
    const div = document.createElement("div");
    div.className = "race__prompt-hint";
    div.id = "race-prompt-hint";
    host.appendChild(div);
    return div;
  }

  /** Create left/right chevron navigation for multi-event spots. */
  _makeChevrons() {
    const host = this.el.prompt;
    if (!host) return null;
    const wrap = document.createElement("div");
    wrap.className = "race__prompt-nav";
    wrap.id = "race-prompt-nav";
    wrap.style.display = "none";

    const left = document.createElement("button");
    left.className = "race__prompt-nav-btn race__prompt-nav-btn--left";
    left.innerHTML = "&#9664;";
    left.title = "Previous event";
    left.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.raceManager?.cycleEvent(-1);
    });
    left.addEventListener("pointerdown", (e) => e.stopPropagation());

    const indicator = document.createElement("span");
    indicator.className = "race__prompt-nav-indicator";
    indicator.id = "race-prompt-nav-indicator";

    const right = document.createElement("button");
    right.className = "race__prompt-nav-btn race__prompt-nav-btn--right";
    right.innerHTML = "&#9654;";
    right.title = "Next event";
    right.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.raceManager?.cycleEvent(1);
    });
    right.addEventListener("pointerdown", (e) => e.stopPropagation());

    wrap.appendChild(left);
    wrap.appendChild(indicator);
    wrap.appendChild(right);
    // Insert at the TOP of the prompt so it sits above the title.
    host.insertBefore(wrap, host.firstChild);
    return wrap;
  }

  /** Push one frame of race state onto the DOM. */
  update(s) {
    if (!s || !this.el.hud) return;

    // --- countdown / GO ---------------------------------------------------
    let countText = "";
    let isGo = false;
    if (s.state === "countdown") {
      if (s.countdown > 3) countText = "3";
      else if (s.countdown > 2) countText = "2";
      else if (s.countdown > 1) countText = "1";
      else countText = "GO!";
      isGo = countText === "GO!";
    } else if (s.goFlash) {
      countText = "GO!";
      isGo = true;
    }
    this._set(this.el.countdown, "countdown", countText, (el, v) => {
      if (!v) {
        el.classList.remove("is-visible", "is-go", "is-animating");
        el.innerHTML = "";
        return;
      }
      const kicker = isGo ? "LAUNCH" : "READY";
      el.innerHTML = `
        <div class="race__countdown-wrap ${isGo ? "is-go" : ""}">
          <div class="race__countdown-stripes"></div>
          <div class="race__countdown-kicker">${kicker}</div>
          <div class="race__countdown-num">${v}</div>
        </div>
      `;
      el.classList.add("is-visible");
      el.classList.toggle("is-go", isGo);

      // Force restart of slide animation on each new count
      el.classList.remove("is-animating");
      void el.offsetWidth;
      el.classList.add("is-animating");

      // Start-light beeps with step awareness
      if (v === "3" || v === "2" || v === "1") {
        this.sfx?.countBeep?.(false, v);
      } else if (v && isGo) {
        this.sfx?.countBeep?.(true, "GO");
      }
    });

    // --- wrong way --------------------------------------------------------
    this._set(this.el.warn, "warn", s.wrongWay ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
    });

    // --- live readout -----------------------------------------------------
    // Racing only: once the player finishes, the beat/results cards own the
    // screen and this readout stands down (its clock would otherwise keep
    // running behind the results).
    const showHud = s.state === "racing";
    this._set(this.el.hud, "hudVisible", showHud ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
    });
    if (showHud) {
      // Position / Standing means different things per event family:
      // - NOCOLLIDE: "CAR CONTACTS" (0 Hits - Clean vs penalty count)
      // - TIME: "TARGET PACE" (+4.4s Behind 1st / -1.2s Ahead of 1st)
      // - RACE: "POSITION" (P1 / 6, Leader / Podium position)
      if (s.eventKind === "NOCOLLIDE") {
        const hits = s.contactHits ?? 0;
        this._set(this.el.posLabel, "posLabel", "CAR CONTACTS", (el, v) => {
          el.textContent = v;
        });
        const hitsTxt = hits === 0 ? "0 HITS" : `${hits} ${hits === 1 ? "HIT" : "HITS"}`;
        this._set(this.el.pos, "pos", hitsTxt, (el, v) => {
          el.textContent = v;
          el.className = `race__hud-val race__hud-val--pos ${hits === 0 ? "is-clean" : "is-penalty"}`;
        });
        if (this.el.posKicker) {
          const kicker = hits === 0 ? "PERFECT CLEAN LINE" : "TARGET: 0 HITS FOR 1ST";
          this._set(this.el.posKicker, "posKicker", kicker, (el, v) => {
            el.textContent = v;
            el.className = `race__hud-kicker ${hits === 0 ? "is-clean" : "is-penalty"}`;
          });
        }
      } else if (s.eventKind === "TIME") {
        const gap = s.goldGap ?? 0;
        const isAhead = gap <= 0;
        const absGap = Math.abs(gap).toFixed(1);
        const txt = `${isAhead ? "-" : "+"}${absGap}s`;
        this._set(this.el.posLabel, "posLabel", "TARGET PACE", (el, v) => {
          el.textContent = v;
        });
        this._set(this.el.pos, "pos", txt, (el, v) => {
          el.textContent = v;
          el.className = `race__hud-val race__hud-val--pos ${isAhead ? "is-ahead" : "is-behind"}`;
        });
        if (this.el.posKicker) {
          const kicker = isAhead ? "AHEAD OF 1ST PLACE PACE" : "BEHIND 1ST PLACE PACE";
          this._set(this.el.posKicker, "posKicker", kicker, (el, v) => {
            el.textContent = v;
            el.className = `race__hud-kicker ${isAhead ? "is-ahead" : "is-behind"}`;
          });
        }
      } else {
        const posNum = s.position ?? 1;
        const fieldTotal = s.fieldSize ?? 6;
        this._set(this.el.posLabel, "posLabel", "POSITION", (el, v) => {
          el.textContent = v;
        });
        const posHtml = `P${posNum}<span class="race__hud-sub"> / ${fieldTotal}</span>`;
        this._set(this.el.pos, "pos", posHtml, (el, v) => {
          el.innerHTML = v;
          el.className = `race__hud-val race__hud-val--pos ${posNum === 1 ? "is-p1" : posNum <= 3 ? "is-podium" : ""}`;
        });
        if (this.el.posKicker) {
          const kicker = posNum === 1 ? "RACE LEADER" : posNum <= 3 ? "PODIUM POSITION" : `CHASING P${posNum - 1}`;
          this._set(this.el.posKicker, "posKicker", kicker, (el, v) => {
            el.textContent = v;
            el.className = `race__hud-kicker ${posNum === 1 ? "is-p1" : posNum <= 3 ? "is-podium" : ""}`;
          });
        }
      }

      // Course / Lap status
      const totalLaps = s.laps ?? 1;
      const currentLap = s.lap ?? 1;
      if (totalLaps > 1) {
        const isFinal = currentLap === totalLaps;
        this._set(this.el.lap, "lap", `${currentLap} / ${totalLaps}`, (el, v) => {
          el.textContent = v;
          el.classList.toggle("is-final", isFinal);
        });
        if (this.el.lapLabel) {
          this._set(this.el.lapLabel, "lapLabel", isFinal ? "FINAL LAP" : "LAP", (el, v) => {
            el.textContent = v;
            el.classList.toggle("is-final", isFinal);
          });
        }
      } else {
        this._set(this.el.lap, "lap", "1 / 1", (el, v) => {
          el.textContent = v;
        });
        if (this.el.lapLabel) {
          this._set(this.el.lapLabel, "lapLabel", "LAP", (el, v) => {
            el.textContent = v;
          });
        }
      }

      // Checkpoint status ("CHECKPOINT 0 / 5" instead of obscure "CP")
      const cpVal = `${s.checkpoint ?? 0} / ${s.checkpointTotal ?? 0}`;
      this._set(this.el.cp, "cp", cpVal, (el, v) => {
        el.textContent = v;
      });
      if (this.el.cpLabel) {
        this._set(this.el.cpLabel, "cpLabel", "CHECKPOINT", (el, v) => {
          el.textContent = v;
        });
      }

      // Live race chronograph
      const timeText = formatTime(s.time);
      this._set(this.el.time, "time", timeText, (el, v) => {
        el.textContent = v;
      });
    }

    // --- event prompt -----------------------------------------------------
    // Event style: the button appears ONLY when the player visits the start
    // line (ARMED). From a distance the event is an icon — the 3D beacon and
    // the minimap event marker — not a DOM signpost.
    const showPrompt = !!s.prompt && (s.state === "armed" || s.state === "idle");
    this._set(this.el.prompt, "promptVisible", showPrompt ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
      if (v) this.sfx?.whoosh("ui");
    });
    if (showPrompt) {
      this._set(this.el.promptTitle, "promptTitle", s.eventName ?? "RACE EVENT", (el, v) => {
        el.textContent = v;
      });
      const diff = s.eventDifficulty ?? "MEDIUM";
      const type = s.eventType ?? "RACE";
      this._set(this.el.promptType, "promptType", type, (el, v) => {
        el.textContent = v;
      });
      this._set(this.el.promptDiff, "promptDiff", diff, (el, v) => {
        el.textContent = v;
        el.className = `race__prompt-tag race__prompt-tag--diff is-${v.toLowerCase()}`;
      });

      // --- multi-event chevron navigation ---------------------------------
      const colocCount = s.colocCount ?? 1;
      const colocIdx = s.colocIndex ?? 0;
      if (this._chevronContainer) {
        const showNav = colocCount > 1;
        this._set(this._chevronContainer, "navVisible", showNav ? 1 : 0, (el, v) => {
          el.style.display = v ? "" : "none";
        });
        if (showNav) {
          const navText = `${colocIdx + 1} / ${colocCount}`;
          const ind = this._chevronContainer.querySelector("#race-prompt-nav-indicator");
          if (ind) this._set(ind, "navText", navText, (el, v) => { el.textContent = v; });
        }
      }

      // --- completion badge for attempted events --------------------------
      const evState = s.eventState ?? "ACTIVE";
      const isAttempted = evState === "COMPLETED" || evState === "MASTERED";
      const currentColoc = (s.colocEvents ?? [])[colocIdx];
      const bestPlace = currentColoc?.bestPlace ?? 0;
      this._set(this.el.prompt, "promptFaded", isAttempted ? 1 : 0, (el, v) => {
        el.classList.toggle("is-attempted", !!v);
      });

      const prize = typeof s.eventPrize === "number" ? `+$${s.eventPrize.toLocaleString("en-US")}` : "";
      const targetVal = s.eventTargetTime
        ? `≤ ${formatTimeShort(s.eventTargetTime)}`
        : s.eventTargetHits != null
          ? (s.eventTargetHits === 0 ? "0 HITS" : `≤ ${s.eventTargetHits} HITS`)
          : "WIN (1ST PLACE)";
      const targetLabel = s.eventTargetTime ? "TARGET TIME" : s.eventTargetHits != null ? "MAX HITS" : "OBJECTIVE";
      const msg = s.eventMessage ?? "Finish to claim reward";

      // Show best position for attempted (but not mastered) events.
      const positionBadge = (isAttempted && bestPlace >= 2 && bestPlace <= 3)
        ? `<div class="race__prompt-best ${bestPlace === 2 ? "is-silver" : "is-bronze"}">BEST: ${bestPlace}${bestPlace === 2 ? "ND" : "RD"} PLACE</div>`
        : "";

      const subHtml = `
        ${positionBadge}
        <div class="race__prompt-grid">
          <div class="race__prompt-card race__prompt-card--prize">
            <span class="race__prompt-card-label">TOP REWARD</span>
            <span class="race__prompt-card-value">${prize} <span class="race__prompt-unit">SP</span></span>
          </div>
          <div class="race__prompt-card race__prompt-card--target">
            <span class="race__prompt-card-label">${targetLabel}</span>
            <span class="race__prompt-card-value">${targetVal}</span>
          </div>
        </div>
        ${msg ? `<div class="race__prompt-rule">${msg}</div>` : ""}
      `;
      this._set(this.el.promptSub, "promptSub", subHtml, (el, v) => {
        el.innerHTML = v;
      });
      this._set(this.el.startBtn, "startBtn", 1, (el, v) => {
        el.style.display = v ? "" : "none";
      });
      this._set(this._hintEl, "hint", "or press SPACE", (el, v) => {
        el.innerHTML = `or press <kbd class="race__keycap">SPACE</kbd>`;
      });
    }

    // --- intro event card -------------------------------------------------
    // Full-screen loading card while the grid assembles. It leaves before
    // the camera sweep finishes, so the reveal plays out in the open.
    const showIntro = !!s.intro && !!s.introCard;
    this._set(this.el.intro, "introVisible", showIntro ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
      el.setAttribute("aria-hidden", v ? "false" : "true");
      if (v) this.sfx?.whoosh("ui");
    });
    if (showIntro) {
      const sig = [s.eventName, s.eventType, s.eventDifficulty, s.eventPrize].join("|");
      this._set(this.el.intro, "introCard", sig, () => this._renderIntroCard());
    }

    // --- finish beat ------------------------------------------------------
    // "YOU BEAT THE X / FINISHED 1ST" slides in while still driving, then
    // hands over to the results screen.
    const showBeat = !!s.beat;
    this._set(this.el.beat, "beatVisible", showBeat ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
      el.setAttribute("aria-hidden", v ? "false" : "true");
      if (v) this.sfx?.whoosh("passby");
    });
    if (showBeat) {
      const sig = [s.eventName, s.beatenLine, s.playerRank].join("|");
      this._set(this.el.beat, "beatCard", sig, () => {
        if (this.el.beatHead) this.el.beatHead.textContent = s.eventName ?? "";
        if (this.el.beatBeaten) this.el.beatBeaten.textContent = s.beatenLine ?? "";
        if (this.el.beatFinish) this.el.beatFinish.textContent = s.madePodium ? `FINISHED ${ordinal(s.playerRank)}` : missFinishText(s);
      });
    }

    // --- result board -----------------------------------------------------
    // Shown for the finish cinematic; CONTINUE dismisses it and hands the car
    // back, RESTART runs the whole event again.
    const showBoard = !!s.resultsReady;
    this._set(this.el.board, "boardVisible", showBoard ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
      if (v) this.sfx?.whoosh("result");
    });
    // Speedwall strip lives and dies with the results screen.
    this._set(this.el.wall, "wallVisible", showBoard ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
      el.setAttribute("aria-hidden", v ? "false" : "true");
    });
    // Dim backdrop behind the finish modals (beat / results): drops the game
    // view back so focus lands on the cards, like the start loading screen.
    this._set(this.el.shade, "shadeVisible", showBeat || showBoard ? 1 : 0, (el, v) => {
      el.classList.toggle("is-visible", !!v);
      el.setAttribute("aria-hidden", v ? "false" : "true");
    });
    if (showBoard) {
      this._set(this.el.boardName, "boardName", s.eventName ?? "", (el, v) => {
        el.textContent = v;
      });
      this._set(this.el.boardBeaten, "boardBeaten", s.beatenLine ?? "", (el, v) => {
        el.textContent = v;
      });
      this._set(this.el.wallPos, "wallPos", s.playerRank >= 1 ? `${s.playerRank}` : "–", (el, v) => {
        el.textContent = v;
      });
      this._set(this.el.wallTime, "wallTime", formatTime(s.playerFinishTime), (el, v) => {
        el.textContent = v;
      });
      this._set(this.el.boardRank, "boardRank", s.playerRank >= 1 ? `P${s.playerRank}` : "–", (el, v) => {
        el.textContent = v;
      });
      this._set(this.el.boardFinish, "boardFinish", s.madePodium ? `FINISHED ${ordinal(s.playerRank)}` : missFinishText(s), (el, v) => {
        el.textContent = v;
      });
      const timeText = formatTime(s.playerFinishTime);
      const rewardText = `+$${Number(s.playerReward ?? 0).toLocaleString("en-US")}`;
      const cat = s.eventType ? `${s.eventType} · ` : "";
      const tgt = s.eventTargetTime
        ? ` (1ST ≤ ${formatTimeShort(s.eventTargetTime)})`
        : s.eventTargetHits != null
          ? ` (1ST ≤ ${s.eventTargetHits} HITS)`
          : "";
      this._set(this.el.boardMeta, "boardMeta", `${cat}${timeText}${tgt} · ${rewardText}`, (el, v) => {
        el.textContent = v;
      });
      // Solo events have a single results row whose raw circuit position is
      // always 1 - meaningless next to a scored tier. Show the scored place
      // instead (or – for a miss), so the list agrees with the header badge.
      const soloRank = s.results.length <= 1 ? (s.madePodium ? s.playerRank : 0) : null;
      const signature =
        s.results
          .map((r) => `${r.position}|${r.name}|${r.finished ? r.finishTime.toFixed(2) : "run"}`)
          .join(",") + `|rank${soloRank ?? "-"}`;
      this._set(this.el.boardList, "boardRows", signature, () => {
        this._renderRows(s.results, soloRank);
      });
      const prizesSig = `${s.playerRank}|${s.playerReward}|${s.eventName}|${s.eventTargetTime}|${s.eventTargetHits}`;
      this._set(this.el.boardPrizes, "boardPrizesSig", prizesSig, () => {
        this._renderBoardPrizes(s);
      });
    }
  }

  /**
   * Render the target prize tiers on the finish results board.
   * - Rank 2: displays 1st rank to show what is needed to reach first and how much more they get.
   * - Rank 3: displays both 1st and 2nd ranks to show what is needed to reach them.
   * - Rank 4+ (and misses): displays all 3 podium tiers (1st, 2nd, 3rd) to aim for.
   * - Rank 1: displays 1st rank highlighted with top prize claimed.
   */
  _renderBoardPrizes(s) {
    const host = this.el.boardPrizes;
    const title = this.el.boardTargetsTitle;
    if (!host) return;
    host.textContent = "";

    const prizes = s.eventPrizes?.length ? s.eventPrizes : (this.race?.event?.prizes ?? []);
    if (!prizes.length) {
      if (this.el.boardTargets) this.el.boardTargets.style.display = "none";
      return;
    }
    if (this.el.boardTargets) this.el.boardTargets.style.display = "";

    const rank = s.playerRank ?? 0;
    const playerReward = Number(s.playerReward ?? 0);

    let tiersToShow = [];
    let titleText = "TARGET REWARDS";

    if (rank === 1) {
      titleText = "TOP REWARD UNLOCKED";
      tiersToShow = [{ ...prizes[0], tierIndex: 0, status: "claimed" }];
    } else if (rank === 2) {
      titleText = "REACH 1ST PLACE TO GET";
      tiersToShow = [{ ...prizes[0], tierIndex: 0, status: "target" }];
    } else if (rank === 3) {
      titleText = "REACH 1ST & 2ND TO GET";
      tiersToShow = [
        { ...prizes[0], tierIndex: 0, status: "target" },
        { ...prizes[1], tierIndex: 1, status: "target" },
      ];
    } else {
      titleText = "PODIUM REWARDS TO GET";
      tiersToShow = prizes.slice(0, 3).map((p, idx) => ({
        ...p,
        tierIndex: idx,
        status: "target",
      }));
    }

    if (title) title.textContent = titleText;

    for (const item of tiersToShow) {
      const row = document.createElement("div");
      const tierNum = item.tierIndex + 1;
      const tierClass = tierNum === 1 ? "is-gold" : tierNum === 2 ? "is-silver" : "is-bronze";
      row.className = `race__board-prize ${tierClass}${item.status === "claimed" ? " is-claimed" : ""}`;

      const left = document.createElement("div");
      left.className = "race__board-prize-left";

      const badge = document.createElement("span");
      badge.className = "race__board-prize-badge";
      badge.textContent = ordinal(tierNum);

      const req = document.createElement("span");
      req.className = "race__board-prize-req";

      if (item.status === "claimed") {
        req.textContent = "1ST PLACE CLAIMED";
      } else if (item.time != null) {
        req.textContent = `≤ ${formatTimeShort(item.time)}`;
      } else if (item.hits != null) {
        req.textContent = item.hits === 0 ? "0 HITS" : `≤ ${item.hits} HITS`;
      } else {
        req.textContent = tierNum === 1 ? "WIN RACE" : `FINISH ${ordinal(tierNum)}`;
      }

      left.append(badge, req);

      const right = document.createElement("div");
      right.className = "race__board-prize-right";

      const amount = document.createElement("span");
      amount.className = "race__board-prize-amount";
      const amtVal = Number(item.amount ?? 0);
      amount.textContent = `+$${amtVal.toLocaleString("en-US")}`;

      right.appendChild(amount);

      if (item.status === "target" && rank >= 2 && rank <= 3) {
        const diff = amtVal - playerReward;
        if (diff > 0) {
          const diffSpan = document.createElement("span");
          diffSpan.className = "race__board-prize-diff";
          diffSpan.textContent = `(+$${diff.toLocaleString("en-US")} MORE)`;
          right.appendChild(diffSpan);
        }
      } else if (item.status === "claimed") {
        const diffSpan = document.createElement("span");
        diffSpan.className = "race__board-prize-diff";
        diffSpan.textContent = "✓ MAX";
        right.appendChild(diffSpan);
      }

      row.append(left, right);
      host.appendChild(row);
    }
  }

  /** Paint the intro loading card from the live event (once per event). */
  _renderIntroCard() {
    const ev = this.race?.event;
    if (!ev) return;
    if (this.el.introType) this.el.introType.textContent = ev.type ?? "";
    if (this.el.introDiff) {
      this.el.introDiff.textContent = ev.difficulty ?? "";
      this.el.introDiff.classList.toggle("is-easy", ev.difficulty === "EASY");
      this.el.introDiff.classList.toggle("is-hard", ev.difficulty === "HARD");
    }
    if (this.el.introName) this.el.introName.textContent = ev.name ?? "";
    const host = this.el.introPrizes;
    if (!host) return;
    host.textContent = "";
    for (const p of ev.prizes ?? []) {
      const row = document.createElement("div");
      row.className = "race__intro-prize";
      const label = document.createElement("span");
      label.textContent = p.label;
      const amount = document.createElement("span");
      // TIME trials show the time required for the place alongside the payout;
      // NO-COLLISION trials show the hit ceiling the same way.
      const timeReq = p.time != null ? `≤ ${formatTimeShort(p.time)}  ` : "";
      const hitReq = p.hits != null ? `≤ ${p.hits} HITS  ` : "";
      amount.textContent = `${timeReq}${hitReq}+$${Number(p.amount ?? 0).toLocaleString("en-US")}`;
      row.append(label, amount);
      host.appendChild(row);
    }
  }

  _renderRows(rows, soloRank = null) {
    const list = this.el.boardList;
    if (!list) return;
    list.textContent = "";
    const leaderTime = rows.find((r) => r.finished)?.finishTime ?? null;
    for (const r of rows) {
      const li = document.createElement("li");
      li.classList.toggle("is-player", !!r.isPlayer);
      const pos = document.createElement("span");
      pos.className = "race__board-pos";
      // Solo rows show the scored tier place (never the raw P1); a miss is –.
      pos.textContent = soloRank != null ? (soloRank >= 1 ? `${soloRank}` : "–") : `${r.position}`;
      const name = document.createElement("span");
      name.textContent = r.name;
      const time = document.createElement("span");
      time.className = "race__board-time";
      if (r.finished) {
        time.textContent = formatTime(r.finishTime);
      } else if (leaderTime !== null && r.position > 1) {
        time.textContent = `+${r.gap.toFixed(0)} m`;
      } else {
        time.textContent = "racing";
      }
      li.append(pos, name, time);
      list.appendChild(li);
    }
  }

  /** Write only when the value actually changed. */
  _set(el, key, value, apply) {
    if (!el || this._cache[key] === value) return;
    this._cache[key] = value;
    apply(el, value);
  }
}

/** Seconds -> `m:ss.hh`, keeping the minutes off a short race. */
export function formatTime(seconds) {
  const s = Math.max(0, seconds ?? 0);
  const m = Math.floor(s / 60);
  const rest = s - m * 60;
  const secs = rest.toFixed(2).padStart(5, "0");
  return `${m}:${secs}`;
}

/**
 * Seconds -> rounded `m:ss` (no milliseconds). Used ONLY for the 1st/2nd/3rd
 * tier targets - actual recorded times keep their hundredths above.
 */
export function formatTimeShort(seconds) {
  const total = Math.max(0, Math.round(seconds ?? 0));
  const m = Math.floor(total / 60);
  return `${m}:${String(total - m * 60).padStart(2, "0")}`;
}

/** 1 -> "1ST", 2 -> "2ND", 3 -> "3RD", 4+ -> "NTH" (0/negative -> "–"). */
export function ordinal(n) {
  if (!Number.isFinite(n) || n < 1) return "–";
  const s = ["TH", "ST", "ND", "RD"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/**
 * Finish line for a run that missed the podium, per event family: a TIME
 * miss names the target, a NO-COLLISION miss names the hits, and a real race
 * keeps its honest rank (it still pays the off-podium tip). Never a phantom
 * 1st place.
 */
export function missFinishText(s) {
  const kind = s?.eventKind ?? "RACE";
  if (kind === "TIME") return "TARGET MISSED";
  if (kind === "NOCOLLIDE") return "TOO MANY HITS";
  return `FINISHED ${ordinal(s?.playerRank)}`;
}
