import { RaceSystem, RACE_STATE } from "./RaceSystem.js";
import { buildTrackFromNodes } from "./raceTrack.js";
import { RACE_EVENTS, TIME_SPEEDS, HIT_TIERS } from "../data/raceEvents.js";
import ROAD_NODES from "../data/road-nodes.json";
import { loadProgress, saveProgress, recordFinish, selectEvents } from "./raceProgressStore.js";

/**
 * Owns the whole race-event layer: the registry, the progression state, and the
 * single RaceSystem that it points at whichever event the player is nearest to.
 *
 * - At most 3 "new" (unfinished) events are revealed at once (green on the
 *   minimap); completed-but-not-mastered events stay (gray) until won 1st.
 * - Driving near a startable event loads it into the RaceSystem so it can be
 *   armed/raced. Finishing on the podium pays the place's reward (to the garage
 *   balance), records progress, and reveals the next event; winning 1st
 *   masters it (removed from the map).
 *
 * See raceProgressStore.js for the lifecycle and the plan for the design.
 */

export class RaceEventManager {
  constructor(scene, { collision, traffic = null, player, assets = [], garageUI = null, anchor = null, destruction = null } = {}) {
    this.scene = scene;
    this.collision = collision;
    this.traffic = traffic;
    this.player = player;
    this.garageUI = garageUI;
    // Roadside-prop system, handed to the RaceSystem so rivals smash the
    // clutter in their line instead of clipping through it.
    this.destruction = destruction;
    this.events = RACE_EVENTS;
    this.progress = loadProgress();
    this._trackCache = new Map();
    this._loadedId = null;
    this._paid = false;
    this._needsRefresh = false;

    // The single RaceSystem builds the legacy fallback circuit in its ctor; we
    // immediately steer it at the nearest authored event below.
    this.race = new RaceSystem(scene, { collision, traffic, player, assets, anchor, fieldSize: 6, destruction });
    this.minimapData = [];
    this._refresh();
  }

  /** Resolve an event's start-line world position (its first node centre). */
  _startXZ(ev) {
    const n = ROAD_NODES[ev.nodes[0]];
    return n ? { x: n.x, z: n.z } : { x: 0, z: 0 };
  }

  /** Build (and cache) the drivable track for an event. */
  _track(ev) {
    const cached = this._trackCache.get(ev.id);
    if (cached) return cached;
    const pts = ev.nodes.map((n) => ROAD_NODES[n]).filter(Boolean).map((p) => ({ x: p.x, y: p.y, z: p.z }));
    // Optional approach node: where the grid lines up to arrive from, for a
    // smooth run into a start that joins at an angle (e.g. North Circuit).
    const ap = ev.approach ? ROAD_NODES[ev.approach] : null;
    const track = buildTrackFromNodes(this.collision, pts, {
      open: ev.open,
      laps: ev.laps,
      fieldSize: (ev.opponents || 0) + 1,
      id: ev.id,
      name: ev.name,
      approachPoint: ap ? { x: ap.x, z: ap.z } : null,
    });
    this._trackCache.set(ev.id, track);
    return track;
  }

  /** Recompute the active/completed sets, the minimap list, and the loaded event. */
  _refresh() {
    const sel = selectEvents(this.events, this.progress);
    this.active = sel.active;
    this.completed = sel.completed;
    this.startable = sel.startable;
    // Marks sit on the track's START LINE (what the billboard floats over),
    // not the raw node centre, which recentering can shift metres off. Built
    // tracks read their line; not-yet-built ones keep the node mark until
    // their first load patches it exact (see _loadNearest).
    const mark = (ev, state) => {
      const cached = this._trackCache.get(ev.id);
      const s = cached ? cached.startPose : this._startXZ(ev);
      return { id: ev.id, name: ev.name, x: s.x, z: s.z, state };
    };
    this.minimapData = [
      ...this.active.map((e) => mark(e, "active")),
      ...this.completed.map((e) => mark(e, "completed")),
    ];
    this._loadNearest(true);
  }

  /**
   * Find ALL startable events near the same start position, letting the player
   * cycle through them when multiple share a location.
   */
  _loadNearest(force = false) {
    if (this.race.state !== RACE_STATE.IDLE && this.race.state !== RACE_STATE.ARMED) return;
    const px = this.player.state.x;
    const pz = this.player.state.z;

    // Find the closest event.
    let best = null;
    let bestD = Infinity;
    const allEv = [...this.active, ...this.completed];
    for (const ev of allEv) {
      const s = this._startXZ(ev);
      const d = Math.hypot(s.x - px, s.z - pz);
      if (d < bestD) {
        bestD = d;
        best = ev;
      }
    }
    if (!best) return;

    // Gather all events that share the same start location (within 25 m).
    const bestS = this._startXZ(best);
    const colocated = allEv.filter((ev) => {
      const s = this._startXZ(ev);
      return Math.hypot(s.x - bestS.x, s.z - bestS.z) < 25;
    });

    // Sort colocated events: active first, then completed, by order.
    colocated.sort((a, b) => {
      const aActive = this.active.includes(a) ? 0 : 1;
      const bActive = this.active.includes(b) ? 0 : 1;
      if (aActive !== bActive) return aActive - bActive;
      return (a.order ?? 0) - (b.order ?? 0);
    });

    // If the colocated set changed, reset the cycle index.
    const colocIds = colocated.map((e) => e.id).join(",");
    if (colocIds !== this._colocIds) {
      this._colocIds = colocIds;
      this._colocList = colocated;
      this._colocIdx = 0;
    }

    // Use the currently selected event from the colocated set.
    const selected = this._colocList?.[this._colocIdx] ?? best;
    if (selected.id === this._loadedId && !force) return;

    try {
      const track = this._track(selected);
      this.race.loadEvent(selected, track);
      const st = this.progress[selected.id] ?? {};
      this.race.event.state = st.mastered ? "MASTERED" : st.completed ? "COMPLETED" : "ACTIVE";
      this.race.event.bestPlace = st.bestPlace ?? 0;
      if (st.completed && !st.mastered) this.race.event.message = "COMPLETED - win 1st for the top reward";

      // Expose multi-event navigation data on the event object for the HUD.
      this.race.event.colocCount = this._colocList?.length ?? 1;
      this.race.event.colocIndex = this._colocIdx;
      this.race.event.colocEvents = (this._colocList ?? [selected]).map((ev) => {
        const s = this.progress[ev.id] ?? {};
        return {
          id: ev.id,
          name: ev.name,
          type: ev.type,
          completed: !!s.completed,
          mastered: !!s.mastered,
          bestPlace: s.bestPlace ?? 0,
        };
      });

      this._loadedId = selected.id;
      this.player.opponents = this.race.field;
      this._paid = false;
      // The diamond now sits exactly under this event's billboard.
      const mark = this.minimapData.find((m) => m.id === selected.id);
      if (mark) {
        mark.x = track.startPose.x;
        mark.z = track.startPose.z;
      }
    } catch (e) {
      console.warn(`RaceEventManager: failed to load ${selected.id}`, e);
    }
  }

  /** Cycle to the next/previous colocated event at the same start. */
  cycleEvent(dir = 1) {
    if (!this._colocList || this._colocList.length <= 1) return;
    if (this.race.state !== RACE_STATE.IDLE && this.race.state !== RACE_STATE.ARMED) return;
    this._colocIdx = ((this._colocIdx + dir) % this._colocList.length + this._colocList.length) % this._colocList.length;
    this._loadedId = null; // force reload
    this._loadNearest(true);
  }

  /** Decide the player's podium place (1/2/3, or 0 = missed) for the finished run. */
  _placeFor(ev, hs) {
    if (ev.type === "TIME") {
      const t = hs.playerFinishTime || 0;
      // Score against the loaded event's own tiers (an event may pin explicit
      // targetTimes); fall back to the speed-derived tiers over the distance.
      const total = (this._trackCache.get(ev.id)?.length ?? 0) * (ev.laps || 1);
      const tiers = this.race.event?.tierTimes ?? TIME_SPEEDS.map((v) => total / v);
      for (let i = 0; i < 3; i++) if (t > 0 && t <= tiers[i]) return i + 1;
      return 0;
    }
    if (ev.type === "NOCOLLIDE") {
      const hits = this.player.contactHits ?? 0;
      for (let i = 0; i < 3; i++) if (hits <= HIT_TIERS[i]) return i + 1;
      return 0;
    }
    // RACE: finishing position vs the field, kept whole - off-podium still
    // takes the flat tip and the board shows the honest rank, never a 0.
    return hs.playerRank >= 1 ? hs.playerRank : 0;
  }

  /**
   * Score the run the instant it finishes and stamp it on the event, so the
   * beat card (which appears well before the results) already shows the true
   * place - the first screen after completion can never disagree with the
   * results that follow.
   */
  _score() {
    const ev = this.events.find((e) => e.id === this._loadedId) ?? this.active.concat(this.completed).find((e) => e.id === this._loadedId);
    if (!ev) return;
    this.race.event.resolvedPlace = this._placeFor(ev, this.race.hudState);
  }

  /** Pay the reward for the current finished run and record progress. */
  _award() {
    const ev = this.events.find((e) => e.id === this._loadedId) ?? this.active.concat(this.completed).find((e) => e.id === this._loadedId);
    if (!ev) return;
    const hs = this.race.hudState;
    // The place scored at the finish line; fall back to scoring now if unset.
    const place = this.race.event.resolvedPlace ?? this._placeFor(ev, hs);
    if (place >= 1) {
      if (place <= 3) {
        const amount = this.race.event.prizes?.[place - 1]?.amount ?? 0;
        if (amount > 0) this.garageUI?.addFunds?.(amount);
      } else if (ev.type === "RACE") {
        // Off-podium in a real race still takes the flat 10% tip (no progress).
        const tip = Math.round((this.race.event.prize ?? 0) * 0.1);
        if (tip > 0) this.garageUI?.addFunds?.(tip);
      }
      recordFinish(this.progress, ev.id, place, {
        timeMs: ev.type === "TIME" ? Math.round((hs.playerFinishTime || 0) * 1000) : null,
        hits: ev.type === "NOCOLLIDE" ? this.player.contactHits ?? 0 : null,
      });
      saveProgress(this.progress);

      // Immediately sync event state and colocEvents for HUD/prompt reflections
      const st = this.progress[ev.id] ?? {};
      this.race.event.state = st.mastered ? "MASTERED" : st.completed ? "COMPLETED" : "ACTIVE";
      if (this.race.event.colocEvents) {
        for (const item of this.race.event.colocEvents) {
          if (item.id === ev.id) {
            item.completed = !!st.completed;
            item.mastered = !!st.mastered;
            item.bestPlace = st.bestPlace ?? 0;
          }
        }
      }
    }
    // Surface the resolved place/reward to the HUD results, and schedule a
    // refresh so a mastered (1st) event is removed and the next revealed once
    // the race settles. A flag (not an edge test) because CONTINUE flips the
    // race to IDLE from a button callback, outside this update's before/after.
    this.race.event.resolvedPlace = place;
    this._needsRefresh = true;
  }

  update(dt, input) {
    this._loadNearest();
    const before = this.race.state;
    this.race.update(dt, input);
    const after = this.race.state;

    // Reset paid flag whenever a race is restarted or active (not FINISHED),
    // so any restarted run (from finish modal or pause menu) is eligible to be awarded and recorded.
    if (after !== RACE_STATE.FINISHED) {
      this._paid = false;
    }

    // Reset the contact counter the instant a run goes green.
    if (before !== RACE_STATE.RACING && after === RACE_STATE.RACING) this.player.contactHits = 0;
    // Score the run the instant it finishes (beat card reads this); pay once,
    // when the results are up.
    if (before !== RACE_STATE.FINISHED && after === RACE_STATE.FINISHED) this._score();
    if (after === RACE_STATE.FINISHED && this.race.hudState.resultsReady && !this._paid) {
      this._paid = true;
      this._award();
    }
    // Once the run has fully settled after a scored finish, advance the set:
    // remove a mastered event, promote the next, and reload the nearest.
    const settled = after === RACE_STATE.IDLE || after === RACE_STATE.ARMED;
    if (settled && this._needsRefresh) {
      this._needsRefresh = false;
      this._refresh();
    }
  }
}

