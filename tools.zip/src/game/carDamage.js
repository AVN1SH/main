import {
  Color4,
  DynamicTexture,
  ParticleSystem,
  StandardMaterial,
  Vector3,
  VertexBuffer,
} from "@babylonjs/core";
import { CAR } from "./driving.js";

/**
 * Arcade car-damage architecture: per-mesh dents, performance degradation
 * and bonnet smoke - one instance per car, shared by the player and rivals.
 *
 * Design notes (read before extending):
 *
 * - Cars are single-shell low-poly models (one body mesh + wheels, plus trim
 *   like bull bars on some). Dents are therefore addressed by WORLD-SPACE
 *   impact point across every panel. There is no mirror/glass crack path:
 *   it was removed per direction - hits reshape, smoke and soot tell the
 *   rest of the story.
 * - Geometry is reshaped, not swapped: dented vertices are pushed inward with
 *   a smooth falloff, originals are kept for `repair()` (the repair UI comes
 *   later - the restore path already exists). Dents move SHAPE ONLY: factory
 *   normals are never touched by a hit, so no impact ever flashes the car
 *   dark on its own.
 * - The black shade is SOOT, not impact lighting: while a smoking car is
 *   driven, its body materials darken gradually toward a clamped maximum.
 *   Parked/revving does nothing; short drives barely tint; long limps go
 *   properly sooty - then stop getting darker.
 * - DIRT is a separate, damage-independent finish layer (`addDirt`): grime
 *   painted as per-vertex colours so it multiplies the paint rather than
 *   replacing it. The caller decides how fast and what colour each surface
 *   deposits; this module owns the per-vertex weights (lower and rear panels
 *   collect more, splatter-patched) and the repaint. Cleaned by `repair()`.
 * - `attach()` calls `makeGeometryUnique()` on every panel: containers are
 *   shared between same-model cars, and without this a dent on one car
 *   reshapes every car using that geometry.
 * - Kinetics in, Hollywood out: dent depth/radius and the performance curves
 *   all key off impact speed, never timers.
 */

const WHEEL_RE = /wheel|tire/i;
// A hit softer than this leaves no mark (parking touches don't crumple).
const MIN_APPROACH = 1.5;
// Approach speed that counts as a full-severity hit.
const FULL_APPROACH = 19.5;
const MAX_DENT_DEPTH = 0.7;
const MIN_HIT_INTERVAL = 0.09;
// Damage accumulated on a panel per full-severity hit. Deliberately small so a
// car wears down over many solid impacts instead of being wrecked by one - a
// single hit should read as a scuff, not a total loss.
const HIT_DAMAGE = 0.14;
// Peak vertex push (metres) of a full-severity dent. Kept well under
// MAX_DENT_DEPTH so one hit dents shallowly and repeated hits deepen it.
const HIT_DENT_DEPTH = 0.32;
// Smoke staging (overall damage): wisp late, plume on a real wreck. The
// shell is deliberately tough - it takes repeated hard hits to get here.
const SMOKE_WISP = 0.6;
const SMOKE_PLUME = 0.78;
// Soot: full blackening after this many seconds of hard-smoking driving.
const SOOT_FULL_TIME = 25;
// Flat paints are multiplied into the body's base-colour texture, which is kept
// so panel lines, vents and decals survive. That texture is dark, so the raw
// palette came out muddy; this lifts the tint into a brighter, more saturated
// paint. Raise it for punchier colour, lower it for a subtler tint.
const PAINT_BRIGHTEN = 1.9;
// Soot never darkens past this share (the deep-crash look, clamped).
const SOOT_MAX_DARKEN = 0.45;

function clamp01(v) {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function smooth01(v) {
  const x = clamp01(v);
  return x * x * (3 - 2 * x);
}

/** Deterministic 0..1 hash of an integer lattice point (dirt splatter noise). */
function hash3(x, y, z) {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
}

/**
 * Can this material be treated as body paint?
 *
 * Emissive parts (lamps) and near-black textureless parts (glass, grille,
 * trim) are excluded so a colour cycle never tints the windows or the lights.
 * Everything else with a colour to tint qualifies.
 */
function isPaintableMaterial(mat) {
  if (!mat) return false;
  try {
    if (mat.emissiveTexture) return false;
    const e = mat.emissiveColor;
    if (e && e.r + e.g + e.b > 0.05) return false;
    const c = mat.albedoColor ?? mat.diffuseColor;
    const hasTex = !!(mat.albedoTexture || mat.diffuseTexture);
    if (!c && !hasTex) return false;
    if (c && !hasTex && c.r < 0.06 && c.g < 0.06 && c.b < 0.06) return false;
  } catch {
    return false;
  }
  return true;
}

  function makeSmokeTexture(scene) {
  const S = 128;
  const tex = new DynamicTexture("cardamage_smoke", { width: S, height: S }, scene, true);
  tex.hasAlpha = true;
  const g = tex.getContext();
  g.clearRect(0, 0, S, S);
  const grad = g.createRadialGradient(S / 2, S / 2, 4, S / 2, S / 2, S / 2);
  grad.addColorStop(0, "rgba(200,200,200,0.85)");
  grad.addColorStop(0.55, "rgba(160,160,160,0.4)");
  grad.addColorStop(1, "rgba(140,140,140,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, S, S);
  tex.update();
  return tex;
}

/**
 * @param scene  Babylon scene (for smoke)
 * @param dims   { halfLength, halfWidth, height } of the car
 * @param opts   { label } debug tag
 */
export function createCarDamage(scene, dims, opts = {}) {
  const label = opts.label ?? "car";
  const halfL = Math.max(dims?.halfLength ?? 2.15, 0.5);
  const height = Math.max(dims?.height ?? 1.42, 0.6);

  let rigRoot = null;
  // Panels: { mesh, original, disp, damage, mat, base, isPBR, origN }
  // mat is a per-car CLONE (shared containers would soot every same-model
  // car at once); baseColor is what repair() restores.
  let panels = [];
  let overall = 0;
  let soot = 0;
  let lastHit = -10;
  let now = 0;
  let smoke = null;
  const smokePos = new Vector3(0, 1, 0);
  let smokeRate = 0;

  // --- dirt / mud build-up ------------------------------------------------
  // A purely cosmetic finish layer, independent of damage: while the car is
  // driven it picks up grime that is heavier low and toward the rear (where
  // the tyres throw it), patchy like splatter, and tinted by the surface it
  // was picked up on. It is painted as VERTEX COLOURS so it multiplies the
  // existing paint/texture rather than replacing it.
  let dirt = 0; // 0 clean .. 1 filthy
  let dirtR = 0.55;
  let dirtG = 0.45;
  let dirtB = 0.32; // working tint the deposit is blended toward
  let dirtLastWritten = -1;

  /** Green accent mixed into some splatter vertices (grass dragged up). */
  const DIRT_FLECK = [0.34, 0.45, 0.2];

  function panelBounds(panel) {
    const bb = panel.mesh.getBoundingInfo().boundingBox;
    return { center: bb.centerWorld.clone(), radius: bb.extendSizeWorld.length() };
  }

  function clonePanelMaterial(mesh, tag) {
    try {
      const src = mesh.material;
      if (!src) return { mat: null, base: null, isPBR: false };
      const mat = src.clone(`${tag}_${mesh.name}_soot`);
      if (!mat) return { mat: null, base: null, isPBR: false };
      mesh.material = mat;
      if (mat.albedoColor) return { mat, base: mat.albedoColor.clone(), isPBR: true };
      if (mat.diffuseColor) return { mat, base: mat.diffuseColor.clone(), isPBR: false };
      return { mat, base: null, isPBR: false };
    } catch {
      return { mat: null, base: null, isPBR: false };
    }
  }

  function attach(root) {
    rigRoot = root;
    panels = [];
    try {
      const meshes = root?.getChildMeshes?.(false) ?? [];
      for (const mesh of meshes) {
        if (!mesh || WHEEL_RE.test(mesh.name ?? "")) continue;
        if (typeof mesh.getVerticesData !== "function") continue;
        const positions = mesh.getVerticesData(VertexBuffer.PositionKind);
        if (!positions || positions.length < 9) continue;
        try {
          // Containers are shared between same-model cars: without this a
          // dent on one car reshapes every car using that geometry.
          if (typeof mesh.makeGeometryUnique === "function") mesh.makeGeometryUnique();
        } catch {
          /* non-critical: deformation below still guards per-mesh state */
        }
        try {
          mesh.markVerticesDataAsUpdatable(VertexBuffer.PositionKind, true);
        } catch {
          /* older buffers stay writable through updateVerticesData anyway */
        }
        mesh.computeWorldMatrix(true);
        mesh.refreshBoundingInfo();
        const entry = { mesh, original: null, disp: null, damage: 0, mat: null, base: null, isPBR: false };
        panels.push(entry);
      }
    } catch {
      panels = [];
    }
    // Per-car material clones AFTER the panel list is final, so the soot
    // pass below owns every diffuse/albedo it will ever touch.
    for (const entry of panels) {
      try {
        const { mat, base, isPBR } = clonePanelMaterial(entry.mesh, label);
        entry.mat = mat;
        entry.base = base;
        entry.isPBR = isPBR;
        entry.paintable = isPaintableMaterial(mat);
        // Factory finish, kept so a paint cycle can hand the original body
        // back: the base-colour texture and the colour it was loaded with.
        entry.origBase = base ? base.clone() : null;
        entry.baseTex = mat ? (mat.albedoTexture ?? mat.diffuseTexture ?? null) : null;
        entry.alphaFromTex = mat ? !!mat.useAlphaFromAlbedoTexture : false;
      } catch {
        /* stock material stays; that panel simply never soots */
      }
    }
    // Dirt weights and the (white) vertex-colour buffer are built once, after
    // the panel list and material clones are final.
    buildDirtWeights();
    try {
      console.info(`[damage] ${label}: ${panels.length} panels`);
    } catch {
      /* logging must never break attach */
    }
    return panels.length;
  }

  function dentPanels(px, py, pz, dirX, dirZ, severity, cx, cz) {
    // Big, readable dents anywhere on the shell - front, back or flanks:
    // wide radius so the whole area caves, deep enough to see from the
    // chase cam on the first solid hit, deeper as damage accumulates.
    // The cave-in aims at the CABIN (blended with the impact travel), so a
    // smashed nose folds back toward the windshield like a real crumple
    // instead of sliding sideways along the hit.
    const radius = 0.55 + severity * 0.75;
    const baseDepth = severity * HIT_DENT_DEPTH;
    const dl = Math.hypot(dirX, dirZ) || 1;
    const tx = dirX / dl;
    const tz = dirZ / dl;
    for (const panel of panels) {
      const mesh = panel.mesh;
      try {
        mesh.computeWorldMatrix(true);
        const { center, radius: boundR } = panelBounds(panel);
        const dcx = px - center.x;
        const dcy = py - center.y;
        const dcz = pz - center.z;
        if (Math.hypot(dcx, dcy, dcz) > radius + boundR) continue;
        let positions = mesh.getVerticesData(VertexBuffer.PositionKind);
        if (!positions || positions.length > 60000) continue;
        if (!panel.original) {
          panel.original = positions.slice();
          panel.disp = new Float32Array(positions.length / 3);
        }
        const W = mesh.getWorldMatrix().clone();
        const inv = W.clone();
        inv.invert();
        const local = new Vector3(0, 0, 0);
        const world = new Vector3(0, 0, 0);
        const pushed = new Vector3(0, 0, 0);
        const scale = 1 - panel.damage * 0.4;
        const depth = baseDepth * (0.6 + 0.4 * panel.damage) * scale;
        const v = new Vector3(0, 0, 0);
        for (let i = 0; i < positions.length; i += 3) {
          v.set(positions[i], positions[i + 1], positions[i + 2]);
          Vector3.TransformCoordinatesToRef(v, W, world);
          const ddx = world.x - px;
          const ddy = world.y - py;
          const ddz = world.z - pz;
          const d = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
          if (d >= radius) continue;
          const w = (Math.cos((Math.PI * d) / radius) + 1) / 2;
          const vi = i / 3;
          const allow = Math.max(0, MAX_DENT_DEPTH - panel.disp[vi]);
          if (allow <= 0) continue;
          const push = Math.min(depth * w, allow);
          if (push <= 0) continue;
          panel.disp[vi] += push;
          // Cave toward the cabin: blend impact travel with the direction
          // from this vertex to the car centre, so the crumple folds inward
          // from wherever it was struck.
          let qx = tx;
          let qz = tz;
          const tox = cx - world.x;
          const toz = cz - world.z;
          const tol = Math.hypot(tox, toz);
          if (tol > 1e-4) {
            qx = (tx + tox / tol) / 2;
            qz = (tz + toz / tol) / 2;
            const ql = Math.hypot(qx, qz) || 1;
            qx /= ql;
            qz /= ql;
          }
          pushed.set(world.x + qx * push, world.y, world.z + qz * push);
          Vector3.TransformCoordinatesToRef(pushed, inv, local);
          positions[i] = local.x;
          positions[i + 1] = local.y;
          positions[i + 2] = local.z;
        }
        mesh.updateVerticesData(VertexBuffer.PositionKind, positions);
        // Normals stay factory: dents reshape only, so impacts never darken
        // the car on their own. Whole-car blackening comes from soot, which
        // accrues gradually while driving a smoking car.
        mesh.refreshBoundingInfo();
        panel.damage = Math.min(1, panel.damage + severity * HIT_DAMAGE);
      } catch {
        /* one bad panel must never break the hit */
      }
    }
    let top = 0;
    for (const panel of panels) if (panel.damage > top) top = panel.damage;
    overall = top;
  }

  function ensureSmoke() {
    if (smoke || !scene) return;
    try {
      smoke = new ParticleSystem(`${label}_bonnetsmoke`, 250, scene);
      smoke.particleTexture = makeSmokeTexture(scene);
      smoke.emitter = smokePos;
      smoke.minEmitBox = new Vector3(0, 0, 0);
      smoke.maxEmitBox = new Vector3(0, 0, 0);
      smoke.color1 = new Color4(0.16, 0.16, 0.17, 0.6);
      smoke.color2 = new Color4(0.32, 0.32, 0.33, 0.4);
      smoke.colorDead = new Color4(0.4, 0.4, 0.4, 0);
      smoke.minSize = 0.4;
      smoke.maxSize = 1.1;
      smoke.minLifeTime = 0.8;
      smoke.maxLifeTime = 1.6;
      smoke.emitRate = 0;
      smoke.minEmitPower = 1.2;
      smoke.maxEmitPower = 2.6;
      smoke.blendMode = ParticleSystem.BLENDMODE_STANDARD;
      smoke.gravity = new Vector3(0, 1.6, 0);
      smoke.start();
    } catch {
      smoke = null;
    }
  }

  /** Darken every cloned body material toward the soot cap. */
  function applySoot() {
    const k = 1 - SOOT_MAX_DARKEN * soot;
    for (const panel of panels) {
      try {
        if (!panel.mat || !panel.base) continue;
        if (panel.isPBR) {
          panel.mat.albedoColor.set(
            panel.base.r * k,
            panel.base.g * k,
            panel.base.b * k,
          );
        } else if (panel.mat.diffuseColor) {
          panel.mat.diffuseColor.set(
            panel.base.r * k,
            panel.base.g * k,
            panel.base.b * k,
          );
        }
      } catch {
        /* one stubborn material must not stop the rest */
      }
    }
  }
  /**
   * Precompute, per body vertex, how strongly it should hold dirt (a fixed
   * 0..1 weight) so the per-frame paint stays a cheap multiply. Weights are
   * baked from the mesh's world pose at attach: lower panels and the rear
   * gather most, with a quantised noise field so the build-up looks like
   * splatter rather than an even coat. Also creates each panel's vertex-colour
   * buffer, seeded to the mesh's original colours (white when it had none) so
   * clean means "no change".
   */
  function buildDirtWeights() {
    try {
      let minY = Infinity;
      let maxY = -Infinity;
      let minZ = Infinity;
      let maxZ = -Infinity;
      const v = new Vector3(0, 0, 0);
      for (const entry of panels) {
        const positions = entry.mesh.getVerticesData(VertexBuffer.PositionKind);
        if (!positions || positions.length > 60000) continue;
        entry.mesh.computeWorldMatrix(true);
        const W = entry.mesh.getWorldMatrix();
        const n = positions.length / 3;
        const world = new Float32Array(n * 3);
        for (let i = 0, j = 0; i < positions.length; i += 3, j++) {
          v.set(positions[i], positions[i + 1], positions[i + 2]);
          Vector3.TransformCoordinatesToRef(v, W, v);
          world[j * 3] = v.x;
          world[j * 3 + 1] = v.y;
          world[j * 3 + 2] = v.z;
          if (v.y < minY) minY = v.y;
          if (v.y > maxY) maxY = v.y;
          if (v.z < minZ) minZ = v.z;
          if (v.z > maxZ) maxZ = v.z;
        }
        entry.world = world;
      }
      const yRange = Math.max(0.001, maxY - minY);
      const zRange = Math.max(0.001, maxZ - minZ);
      for (const entry of panels) {
        const world = entry.world;
        entry.world = null;
        if (!world) continue;
        const mesh = entry.mesh;
        const n = world.length / 3;
        const dirtW = new Float32Array(n);
        const fleckW = new Float32Array(n);
        for (let j = 0; j < n; j++) {
          const x = world[j * 3];
          const y = world[j * 3 + 1];
          const z = world[j * 3 + 2];
          const h = (y - minY) / yRange;
          let w = 0.22 + 0.78 * (1 - h); // lower body holds more
          const rear = (maxZ - z) / zRange; // 1 at the rear (-Z is back)
          w *= 1 + 0.45 * rear; // tyres throw it up the tail
          const qx = Math.round(x / 0.35);
          const qy = Math.round(y / 0.35);
          const qz = Math.round(z / 0.35);
          w *= 0.3 + 0.7 * hash3(qx, qy, qz); // patchy splatter
          dirtW[j] = Math.min(1, w);
          fleckW[j] = smooth01((hash3(qx + 9, qy + 4, qz + 13) - 0.6) / 0.35);
        }
        entry.dirtW = dirtW;
        entry.fleckW = fleckW;
        const orig = mesh.getVerticesData(VertexBuffer.ColorKind);
        entry.colOrig = orig && orig.length >= n * 4 ? orig : null;
        const out = new Float32Array(n * 4);
        for (let j = 0; j < n; j++) {
          out[j * 4] = entry.colOrig ? entry.colOrig[j * 4] : 1;
          out[j * 4 + 1] = entry.colOrig ? entry.colOrig[j * 4 + 1] : 1;
          out[j * 4 + 2] = entry.colOrig ? entry.colOrig[j * 4 + 2] : 1;
          out[j * 4 + 3] = entry.colOrig ? entry.colOrig[j * 4 + 3] : 1;
        }
        entry.colOut = out;
        mesh.setVerticesData(VertexBuffer.ColorKind, out, true, 4);
        mesh.useVertexColors = true;
      }
    } catch {
      /* a car with no usable geometry simply never gets dirty */
    }
  }

  /** Repaint every panel's dirt vertex colours from the current `dirt`. */
  function refreshDirt() {
    for (const entry of panels) {
      if (!entry.dirtW || !entry.colOut) continue;
      const out = entry.colOut;
      const orig = entry.colOrig;
      const dirtW = entry.dirtW;
      const fleckW = entry.fleckW;
      const n = dirtW.length;
      for (let j = 0; j < n; j++) {
        const k = dirt * dirtW[j];
        let r = 1 + (dirtR - 1) * k;
        let g = 1 + (dirtG - 1) * k;
        let b = 1 + (dirtB - 1) * k;
        const fk = fleckW[j] * k * 0.55;
        if (fk > 0) {
          r += (DIRT_FLECK[0] - r) * fk;
          g += (DIRT_FLECK[1] - g) * fk;
          b += (DIRT_FLECK[2] - b) * fk;
        }
        out[j * 4] = orig ? r * orig[j * 4] : r;
        out[j * 4 + 1] = orig ? g * orig[j * 4 + 1] : g;
        out[j * 4 + 2] = orig ? b * orig[j * 4 + 2] : b;
        out[j * 4 + 3] = orig ? orig[j * 4 + 3] : 1;
      }
      try {
        entry.mesh.updateVerticesData(VertexBuffer.ColorKind, out, false);
      } catch {
        /* a stubborn panel must not stop the rest */
      }
    }
  }

  /**
   * Add grime. `amount` is the 0..1 increment; `tint` is the RGB the deposit
   * is blended toward (road dust, mud, sand, ...). Repaints only when the
   * total has moved enough to be visible, so a long drive stays cheap.
   */
  function addDirt(amount, tint) {
    if (!panels.length) return;
    const a = clamp01(amount);
    if (a <= 0) return;
    if (tint) {
      const w = Math.min(1, a * 6);
      dirtR += (tint[0] - dirtR) * w;
      dirtG += (tint[1] - dirtG) * w;
      dirtB += (tint[2] - dirtB) * w;
    }
    dirt = Math.min(1, dirt + a);
    if (dirtLastWritten < 0 || dirt - dirtLastWritten > 0.008) {
      dirtLastWritten = dirt;
      refreshDirt();
    }
  }

  /**
   * Repaint the body.
   *
   * `color` is a Color3 for a tint, or null/undefined to hand back the factory
   * finish (original colour). Only the paint panels are touched (see
   * isPaintableMaterial), so glass and lamps keep their finish. The colour
   * `repair()` restores is updated too, so a later repair keeps the new paint.
   * Returns the number of panels changed.
   *
   * The base-colour texture is deliberately KEPT: dropping it gave flat colours
   * but erased every panel line and decal. Instead the tint is lifted by
   * PAINT_BRIGHTEN, which brightens and saturates the paint while the texture
   * keeps the detail.
   */
  function paint(color) {
    let n = 0;
    for (const panel of panels) {
      const mat = panel.mat;
      if (!panel.paintable || !mat) continue;
      try {
        if (!color) {
          // Factory finish: restore texture, colour and alpha mode exactly.
          if (panel.baseTex) {
            if (panel.isPBR) mat.albedoTexture = panel.baseTex;
            else mat.diffuseTexture = panel.baseTex;
            if (panel.alphaFromTex) mat.useAlphaFromAlbedoTexture = true;
          }
          if (panel.origBase) {
            if (panel.isPBR && mat.albedoColor) mat.albedoColor.copyFrom(panel.origBase);
            else if (mat.diffuseColor) mat.diffuseColor.copyFrom(panel.origBase);
          }
          if (panel.base && panel.origBase) panel.base.copyFrom(panel.origBase);
        } else if (panel.isPBR) {
          if (!mat.albedoColor) continue;
          mat.albedoColor.set(
            color.r * PAINT_BRIGHTEN,
            color.g * PAINT_BRIGHTEN,
            color.b * PAINT_BRIGHTEN,
          );
          if (panel.base) panel.base.copyFrom(mat.albedoColor);
        } else {
          if (!mat.diffuseColor) continue;
          mat.diffuseColor.set(
            color.r * PAINT_BRIGHTEN,
            color.g * PAINT_BRIGHTEN,
            color.b * PAINT_BRIGHTEN,
          );
          if (panel.base) panel.base.copyFrom(mat.diffuseColor);
        }
        mat.markAsDirty?.();
        n++;
      } catch {
        /* one stubborn panel must not stop the repaint */
      }
    }
    return n;
  }

  /**
   * Record one impact.
   * @param hit { x,y,z } world point on/near the car, { dirX,dirZ } unit
   *   vector pointing INTO the car, { severity } 0..1 from impact kinetics.
   *   Extra fields (cx, cz, heading, carY, speed) are accepted and ignored.
   * @returns applied severity (0 when ignored)
   */
  function recordHit(hit) {
    try {
      const severity = clamp01(hit?.severity ?? 0);
      if (severity < 0.05 || !panels.length) return 0;
      if (now - lastHit < MIN_HIT_INTERVAL) return 0;
      lastHit = now;
      const px = hit.x;
      const py = hit.y;
      const pz = hit.z;
      dentPanels(
        px, py, pz,
        hit.dirX ?? 0, hit.dirZ ?? 0, severity,
        hit.cx ?? px, hit.cz ?? pz,
      );
      return severity;
    } catch {
      return 0;
    }
  }

  /** Per-frame: bonnet smoke follows damage. pose { x,y,z,heading,speed }. */
  function update(dt, pose) {
    now += dt;
    try {
      if (!pose) return;
      ensureSmoke();
      if (!smoke) return;
      const fx = Math.sin(pose.heading);
      const fz = Math.cos(pose.heading);
      smokePos.set(
        pose.x + fx * halfL * 0.72,
        (pose.y ?? 0) + height * 0.78,
        pose.z + fz * halfL * 0.72,
      );
      smoke.direction1.set(-fx * 1.2 - 0.3, 2.4, -fz * 1.2 - 0.3);
      smoke.direction2.set(-fx * 1.2 + 0.3, 3.2, -fz * 1.2 + 0.3);
      // Smoke stays off until the shell has taken real beating, then builds
      // gradually: a wisp first, a plume only on a wreck. Small hits never
      // puff on their own.
      const target =
        overall > SMOKE_PLUME
          ? 25 + (overall - SMOKE_PLUME) * 120
          : overall > SMOKE_WISP
            ? 12
            : 0;
      smokeRate += (target - smokeRate) * Math.min(1, 3 * dt);
      smoke.emitRate = smokeRate;
      // Soot: only while a SMOKING car is actually driven. Parked revving
      // does nothing; crawling tints slowly; sustained pace blackens toward
      // the clamp, then stops getting darker.
      const driving = Math.min(1, Math.abs(pose.speed ?? 0) / 8);
      const smokeFrac = clamp01(smokeRate / 45);
      if (smokeFrac > 0 && driving > 0 && soot < 1) {
        soot = Math.min(1, soot + ((dt * smokeFrac * driving) / SOOT_FULL_TIME));
        applySoot();
      }
    } catch {
      /* smoke must never break driving */
    }
  }

  function repair() {
    try {
      for (const panel of panels) {
        if (panel.original) {
          const mesh = panel.mesh;
          const fresh = panel.original.slice();
          mesh.updateVerticesData(VertexBuffer.PositionKind, fresh);
          mesh.refreshBoundingInfo();
          panel.original = null;
          panel.disp = null;
          panel.damage = 0;
        }
        // Factory paint back.
        try {
          if (panel.mat && panel.base) {
            if (panel.isPBR && panel.mat.albedoColor) panel.mat.albedoColor.copyFrom(panel.base);
            else if (panel.mat.diffuseColor) panel.mat.diffuseColor.copyFrom(panel.base);
          }
        } catch {
          /* paint restore is best-effort */
        }
      }
      overall = 0;
      soot = 0;
      smokeRate = 0;
      if (smoke) smoke.emitRate = 0;
      // Back to factory paint: strip the grime layer too.
      dirt = 0;
      dirtLastWritten = -1;
      dirtR = 0.55;
      dirtG = 0.45;
      dirtB = 0.32;
      if (panels.length) refreshDirt();
    } catch {
      /* repair best-effort only */
    }
  }

  function dispose() {
    try {
      smoke?.dispose();
    } catch { /* noop */ }
    smoke = null;
  }

  return {
    attach,
    recordHit,
    update,
    repair,
    dispose,
    addDirt,
    paint,
    dirt: () => dirt,
    paintablePanels: () => panels.filter((p) => p.paintable).length,
    overall: () => overall,
    panels: () => panels.length,
    /** Engine power multiplier (bent body steals power). */
    power: () => 1 - 0.38 * overall,
    /**
     * Top-speed multiplier. Past the smoke stages the curve gives way to
     * hard km/h caps: a smoking wreck holds under 100, a burning one
     * around 70-80 no matter the throttle.
     */
    top: () => {
      const curve = 1 - 0.3 * overall;
      const maxKmh = CAR.maxSpeed * 3.6;
      const cap = overall > SMOKE_PLUME ? 75 / maxKmh : overall > SMOKE_WISP ? 100 / maxKmh : 1;
      return Math.min(curve, cap);
    },
    /** Steering authority multiplier (bent alignment). */
    grip: () => 1 - 0.25 * overall,
    smoking: () => overall > SMOKE_WISP,
    /** Soot 0..1 (for HUD / tuning). */
    soot: () => soot,
    /** 0 below the wisp stage, ramping to 1 on a full wreck. */
    smokeLevel: () => clamp01((overall - SMOKE_WISP) / (1 - SMOKE_WISP)),
  };
}

/** Impact speed -> 0..1 severity. Hits under ~2.8 m/s leave no mark. */
export function impactSeverity(approachSpeed) {
  if (!Number.isFinite(approachSpeed)) return 0;
  return clamp01((Math.abs(approachSpeed) - MIN_APPROACH) / (FULL_APPROACH - MIN_APPROACH));
}
