/**
 * In-game pause menu.
 *
 * Owns the top-left pause icon (`#pause-btn`) and the pause modal
 * (`#pause-screen`) added in index.html. Clicking the icon freezes the world
 * (main.js skips its whole update block while `isOpen()`), then offers:
 *
 *   - Resume      -> close the menu, hand control back
 *   - Restart Race -> re-run the active event (via the `onRestart` callback)
 *   - Settings    -> the sound / music / vibration dialog
 *   - Quit Race   -> abandon the active event only (via `onQuitRace`); it does
 *                    NOT leave the game
 *
 * The objective and race-type labels are read live from `race.hudState`, so
 * the modal always describes the event the player is actually in. Restart and
 * Quit are only offered while an event is actually running.
 *
 * Holds no simulation logic of its own; main.js owns the game state.
 */
export class PauseMenu {
  /**
   * @param {object}   [opts]
   * @param {object}   [opts.race]        RaceSystem, read for the event labels.
   * @param {Function} [opts.onQuitRace]  Abandon the active event (Quit Race).
   * @param {Function} [opts.onRestart]   Restart Race action.
   * @param {Function} [opts.onSfxChange] Sound-effects toggle (true = on).
   * @param {Function} [opts.onMusicChange] Music toggle (true = on).
   */
  constructor({ race = null, onQuitRace = null, onRestart = null, onSfxChange = null, onMusicChange = null } = {}) {
    this.race = race;
    this.onQuitRace = onQuitRace;
    this.onRestart = onRestart;
    this.onSfxChange = onSfxChange;
    this.onMusicChange = onMusicChange;

    this.settings = { sfx: true, music: true, vibration: false };

    this.buttonEl = document.getElementById("pause-btn");
    this.rootEl = document.getElementById("pause-screen");
    this.settingsEl = document.getElementById("pause-settings");
    this.objectiveEl = document.getElementById("pause-objective");
    this.racetypeEl = document.getElementById("pause-racetype");
    this.restartBtn = this.rootEl?.querySelector('[data-pause-action="restart"]') ?? null;
    this.quitBtn = this.rootEl?.querySelector('[data-pause-action="quit"]') ?? null;

    this.opened = false;
    this._available = false;

    this._bind();
  }

  _bind() {
    // Top-left icon opens the menu.
    this.buttonEl?.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.open();
    });
    this.buttonEl?.addEventListener("pointerdown", (e) => e.stopPropagation());

    // Menu actions.
    this.rootEl?.querySelectorAll("[data-pause-action]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        this._action(btn.dataset.pauseAction);
      });
    });
    // Nothing inside the modal should reach the canvas / minimap beneath it.
    this.rootEl?.addEventListener("pointerdown", (e) => e.stopPropagation());

    // Settings dialog.
    document.getElementById("pause-settings-back")?.addEventListener("click", () => this.closeSettings());
    this.settingsEl?.addEventListener("click", (e) => {
      if (e.target === this.settingsEl) this.closeSettings();
    });

    document.getElementById("pause-set-sfx")?.addEventListener("change", (e) => {
      this.settings.sfx = e.target.checked;
      this.onSfxChange?.(this.settings.sfx);
    });
    document.getElementById("pause-set-music")?.addEventListener("change", (e) => {
      this.settings.music = e.target.checked;
      this.onMusicChange?.(this.settings.music);
    });
    document.getElementById("pause-set-vibration")?.addEventListener("change", (e) => {
      this.settings.vibration = e.target.checked;
      if (this.settings.vibration) {
        try {
          navigator.vibrate?.(30);
        } catch {
          /* unsupported: the preference is still stored */
        }
      }
    });

    // Escape closes the menu. Registered on the CAPTURE phase and stopped, so
    // the lobby's global "Escape opens the lobby" listener cannot fire on the
    // same keypress while the pause menu is up.
    window.addEventListener(
      "keydown",
      (e) => {
        if (!this.opened) return;
        if (e.code !== "Escape") return;
        e.preventDefault();
        e.stopImmediatePropagation();
        if (this.settingsEl?.classList.contains("is-open")) this.closeSettings();
        else this.close();
      },
      true,
    );
  }

  _action(action) {
    if (action === "resume") {
      this.close();
    } else if (action === "settings") {
      this.openSettings();
    } else if (action === "restart") {
      this.close();
      this.onRestart?.();
    } else if (action === "quit") {
      this.close();
      this.onQuitRace?.();
    }
  }

  openSettings() {
    this.settingsEl?.classList.add("is-open");
  }

  closeSettings() {
    this.settingsEl?.classList.remove("is-open");
  }

  /** Whether the pause modal is currently up (drives main.js's world freeze). */
  isOpen() {
    return this.opened;
  }

  /**
   * Show or hide the pause icon. It stays hidden until the game has actually
   * started (the entry cinematic, the lobby and the garage all suppress it).
   */
  setAvailable(on) {
    const next = !!on;
    if (next === this._available) return;
    this._available = next;
    this.buttonEl?.classList.toggle("is-hidden", !next);
    this.buttonEl?.setAttribute("aria-hidden", next ? "false" : "true");
    if (!next && this.opened) this.close();
  }

  open() {
    if (this.opened || !this._available) return;
    this.opened = true;
    this._refreshInfo();
    this.rootEl?.classList.add("is-visible");
    this.rootEl?.setAttribute("aria-hidden", "false");
    this.buttonEl?.classList.add("is-active");
  }

  close() {
    if (!this.opened) return;
    this.opened = false;
    this.closeSettings();
    this.rootEl?.classList.remove("is-visible");
    this.rootEl?.setAttribute("aria-hidden", "true");
    this.buttonEl?.classList.remove("is-active");
  }

  /**
   * Fill the objective / race-type labels from the live event. Outside a live
   * event (free-roam) the labels reset to roaming copy: `hudState` keeps
   * describing the last/nearest loaded event even in IDLE, so without this
   * the modal would present a stale mission as the current one.
   */
  _refreshInfo() {
    const s = this.race?.hudState;
    if (!s) return;

    // Restart / Quit are only meaningful while an event is actually running.
    // In free-roam (idle/armed) they are hidden so the menu only offers Resume
    // and Settings.
    const inRace =
      s.state === "intro" ||
      s.state === "countdown" ||
      s.state === "racing" ||
      s.state === "finished";
    this.restartBtn?.classList.toggle("is-hidden", !inRace);
    this.quitBtn?.classList.toggle("is-hidden", !inRace);

    if (!inRace) {
      if (this.objectiveEl) this.objectiveEl.textContent = "Explore the city — find your next event";
      if (this.racetypeEl) this.racetypeEl.textContent = "Free Roam";
      return;
    }

    const kind = s.eventKind ?? "RACE";
    const objective =
      kind === "TIME" ? "Beat the target time" : kind === "NOCOLLIDE" ? "Finish with zero hits" : "Win the race";
    if (this.objectiveEl) this.objectiveEl.textContent = objective;
    if (this.racetypeEl) this.racetypeEl.textContent = s.eventType || s.trackName || "Circuit";
  }
}
