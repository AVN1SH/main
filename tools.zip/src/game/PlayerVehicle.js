import {
  CAR,
  approach,
  clamp,
  commandedSteerAtSpeed,
  playerLateralAccelAt,
  smoothFactor,
  stepVehicle,
} from "./driving.js";
import { TerrainFollower, describeVehicle, TERRAIN } from "./terrain.js";
import { resolveVehicleCollision } from "./vehicleCollision.js";
import { createCarDamage, impactSeverity } from "./carDamage.js";
import { surfaceLook } from "./tireMarks.js";
import { soundManager } from "./soundManager.js";

/**
 * Dirt pick-up rate per metre of travel and the colour each surface leaves
 * behind, indexed by MARK_LOOK (road, dirt, grass, sand). Road only settles a
 * thin grey film; the loose surfaces cake the car quickly - grass fastest, and
 * the dirt layer adds green flecks to it.
 */
const DIRT_RATE = [0.0007, 0.004, 0.0055, 0.0045];
const DIRT_TINT = [
  [0.62, 0.58, 0.52], // road dust
  [0.5, 0.4, 0.28], // dirt
  [0.44, 0.36, 0.22], // mud
  [0.74, 0.66, 0.5], // sand
];

/**
 * Damage scale for player <-> vehicle contacts (ambient traffic and race
 * rivals). Trading paint should wear the car down gradually, not wreck it on
 * one solid hit, so vehicle impacts are dented far more gently than the base
 * impact curve - and only on a FRESH contact, never on every repeat frame of a
 * sustained push.
 */
const VEHICLE_HIT_SEVERITY = 0.7;

/**
 * The car the player drives.
 *
 * Motion comes from the kinematic bicycle model in driving.js, which is what
 * makes the turn rate depend on speed: at a standstill the wheels turn but the
 * car barely rotates, and at speed the same steering input produces a wide,
 * stable arc.
 *
 * On top of the physics this drives the model's visual feedback:
 *   - front wheels visibly steer
 *   - all wheels roll at a rate derived from real speed and wheel radius
 *   - the body leans in corners and pitches under acceleration/braking
 *
 * Terrain and collision come from `TerrainFollower`: the four wheels sample the
 * map's baked collision geometry, and the resulting contacts set the car's
 * height, slope and suspension. Horizontal motion is swept against the map so
 * the chassis cannot drive through walls, and gets blocked at steps too tall
 * for the tyres to climb.
 */
export class PlayerVehicle {
  constructor(rig, spawn, collision = null) {
    this.rig = rig;
    this.collision = collision;
    this.spawn = {
      x: spawn.x,
      y: spawn.y,
      z: spawn.z,
      heading: (spawn.headingDeg * Math.PI) / 180,
    };

    this.state = {
      x: this.spawn.x,
      y: this.spawn.y,
      z: this.spawn.z,
      heading: this.spawn.heading,
      speed: 0,
    };

    this.steerAngle = 0;
    this.roll = 0;
    this.pitch = 0;
    this.lastAccel = 0;
    this.collided = false;
    // Arcade hit reaction (see applyShove): when a rival runs into the
    // player, the player's car takes a physical jolt. It integrates beneath
    // the player's own inputs so control never pauses - the kick rides on top
    // of normal driving, NFS style.
    this.shove = { vx: 0, vz: 0, vHeading: 0, time: 0 };
    this.shoved = false;
    // Seconds the car has been pinned at a standstill against geometry. Used
    // to break a weld: a head-on hit into a barrier can leave the sweep with no
    // legal move, so after a moment the car is nudged toward open space.
    this._blockedTime = 0;
    // Sustained-contact memory (the anti-judder fix). A fresh hit gets the
    // full lively response (bounce + spin + shove-back), but contact that
    // persists across frames - leaning on a wall with the throttle held, or
    // pushing a traffic car - goes soft: no rebound, no spin, no big
    // separation kick. Without this the car ping-pongs (bounce out, drive
    // back in) or welds (full slowdown + yank-back every frame).
    this._time = 0;
    this._contactNx = 0;
    this._contactNz = 0;
    this._contactTime = 0;
    this._lastVehicleHit = null;
    this._vehicleHitTime = -10;
    // Visual steering shake while smoking (see update); physics untouched.
    this._steerWobble = 0;
    // Latest arcade slip blend (0..1), published each update for the audio mix.
    this.slip = 0;
    // Distinct contacts since the last reset (NO-COLLISION challenge): ANY hit
    // to the car counts - traffic, walls, props - not just traffic.
    this.contactHits = 0;
    // Cosmetic tail-out: a visual yaw (rad) that swings the back of the car out
    // through fast corners while the front holds its line. Rendered only (see
    // sync); never touches the physics pose, so handling is unaffected.
    this.skidYaw = 0;
    // Optional impact hook, set by the game to the destructible-object system.
    // Only the player car wires it up: AI traffic keeps normal collision.
    this.onImpact = null;
    // Optional traffic system reference, set by the game so the player
    // can physically collide with traffic vehicles. Without it, the
    // player only collides against the static map.
    this.traffic = null;
    // Optional list of race rivals, set by the game while a race is on. They
    // are resolved by exactly the same sweep as the traffic, so a rival is a
    // solid car rather than something to drive through - and through
    // `applyShove` above, contact shoves the player just as it shoves them.
    this.opponents = null;

    this.terrain = collision
      ? new TerrainFollower(collision, describeVehicle(rig), this.spawn.y)
      : null;

    // Body damage: per-mesh dents, mirror cracks, performance loss, smoke.
    // Never allowed to break driving - the module guards every call.
    const dmgDims = this.terrain?.g ?? {
      halfLength: CAR.length / 2,
      halfWidth: CAR.width / 2,
      height: CAR.height,
    };
    this.damage = createCarDamage(this.rig?.scene ?? null, dmgDims, { label: "player" });
    try {
      this.damage.attach(this.rig?.root ?? null);
    } catch {
      /* showroom-only rigs may lack a scene graph; damage stays inert */
    }

    // Tire-mark emitter (set by the game to a TireMarks instance, like
    // traffic). Stays null in tests, and every call below guards it.
    this.marks = null;
    this._markAcc = 0;
    this._markPX = null;
    this._markPZ = null;

    // Airborne spray emitter (a TireSpray instance, set by the game). Same
    // guards as the marks: null in tests, cosmetic-only, never fails driving.
    this.spray = null;

    // Previous position for the dirt build-up's distance measure.
    this._dirtPX = null;
    this._dirtPZ = null;

    this.sync();
  }

  /**
   * Swap in a different car's rig (garage equip) without resetting the drive.
   *
   * The rig, the terrain follower and the damage model are all built from the
   * rig's measurements, so all three are rebuilt together; everything that is
   * not car-specific (marks, spray, traffic, opponents, the impact hook) is
   * left untouched. The previous rig/damage are returned so the caller can
   * dispose them once the swap is complete.
   *
   * @param rig the new VehicleRig, already positioned at the car's pose.
   * @returns {{ oldRig, oldDamage }}
   */
  equip(rig) {
    const oldRig = this.rig;
    const oldDamage = this.damage;

    this.rig = rig;
    this.terrain = this.collision
      ? new TerrainFollower(this.collision, describeVehicle(rig), this.state.y)
      : null;

    const dmgDims = this.terrain?.g ?? {
      halfLength: CAR.length / 2,
      halfWidth: CAR.width / 2,
      height: CAR.height,
    };
    this.damage = createCarDamage(rig?.scene ?? null, dmgDims, { label: "player" });
    try {
      this.damage.attach(rig?.root ?? null);
    } catch {
      /* a rig without a scene graph keeps an inert damage model */
    }
    // A newly equipped car always starts in its factory (OG) finish: the
    // previous car's paint-shop colour must never carry over onto it. The
    // damage model is fresh (no dents/dirt/soot), but force the factory paint
    // explicitly so the new shell can never inherit a tint through shared or
    // re-attached materials.
    try {
      this.damage.paint?.(null);
    } catch {
      /* paint is cosmetic: the swap must not fail over it */
    }

    try {
      oldDamage?.dispose?.();
    } catch {
      /* nothing to release */
    }

    // Re-seat the new car on the ground at the pose it was swapped in at, and
    // clear any residual hazard so the fresh body starts clean.
    this.terrain?.teleport?.(this.state.y);
    this.sync();

    return { oldRig, oldDamage };
  }

  reset() {
    this.state.x = this.spawn.x;
    this.state.y = this.spawn.y;
    this.state.z = this.spawn.z;
    this.state.heading = this.spawn.heading;
    this.state.speed = 0;
    this.skidYaw = 0;
    this.steerAngle = 0;
    this.roll = 0;
    this.pitch = 0;
    this.collided = false;
    this._blockedTime = 0;
    this._contactTime = 0;
    this._lastVehicleHit = null;
    this._vehicleHitTime = -10;
    this._steerWobble = 0;
    this._markAcc = 0;
    this._markPX = null;
    this._markPZ = null;
    this._dirtPX = null;
    this._dirtPZ = null;
    try {
      this.damage?.repair();
    } catch {
      /* fresh shell anyway on respawn */
    }
    this.shove.vx = 0;
    this.shove.vz = 0;
    this.shove.vHeading = 0;
    this.shove.time = 0;
    this.shoved = false;
    this.terrain?.teleport(this.spawn.y);
    this.sync();
  }

  update(dt, input) {
    const { state } = this;
    this._time += dt;
    // Sustained-contact window: a contact counts as "still the same one" if
    // the previous frame also ended in contact. Decays when free.
    this._contactTime = Math.max(0, this._contactTime - dt);

    // --- steering: intent -> wheel angle ---
    //
    // The target is the lock the driver can COMMAND, not the lock the tyres can
    // use. Scaling the input by the grip limit (the old behaviour) deleted the
    // input at speed: full left lock at 120 km/h became a 1.4 deg wheel angle,
    // so the wheels stopped steering and the car ran wide with nothing on screen
    // to explain it. The commanded angle now goes straight to the wheels, and
    // `stepVehicle` refuses only the part the tyres cannot hold - so holding
    // lock at speed shows cranked front wheels and a car at the limit of its
    // grip, which is both correct and readable.
    const lock = commandedSteerAtSpeed(state.speed);
    const target = input.steer * lock;
    // Rate derived from the available lock so the time from centre to full lock
    // stays constant at every speed. A flat rad/s rate made the high-speed lock
    // arrive in a few frames, turning progressive steering into a snap.
    const lockTime = input.steer === 0 ? CAR.steerReturnTime : CAR.steerLockTime;
    this.steerAngle = approach(this.steerAngle, target, (lock / lockTime) * dt);

    // --- pedals ---
    // Bent body steals engine power (damage factor is 1 when undamaged).
    const isHandbrake = !!input.handbrake;
    const brake = isHandbrake ? 1 : input.brake;
    const throttle = (isHandbrake ? 0 : input.throttle) * (this.damage?.power() ?? 1);

    const prevX = state.x;
    const prevZ = state.z;
    const speedBefore = state.speed;
    const yawRate = stepVehicle(state, dt, {
      throttle,
      brake: brake * (isHandbrake ? 2.2 : 1),
      steerAngle: this.steerAngle,
      // The player car gets a speed-ramped grip: the original figure at low
      // speed (that band was already right) rising to a much higher one at
      // speed, which is what makes it rotate instead of tracking wide. The AI
      // cars keep their own value and are unaffected.
      lateralAccel: playerLateralAccelAt(state.speed) * (this.damage?.grip() ?? 1),
      // The handbrake has to cost lateral grip, or it is only ever a brake and
      // there is no way to rotate the car once the tyres are already saturated.
      grip: isHandbrake ? CAR.handbrakeGrip : 1,
      handbrake: isHandbrake,
    });
    // Dragging panels cap pace (1 when undamaged).
    const dmgTop = CAR.maxSpeed * (this.damage?.top() ?? 1);
    if (state.speed > dmgTop) state.speed = dmgTop;
    this.lastAccel = (state.speed - speedBefore) / Math.max(dt, 1e-4);

    // --- pending shove: a rival hit us (see applyShove) ------------------
    // Folded into the motion BEFORE the map sweep, so the same sweep that
    // validates driving also validates the jolt: a shove can shove the car
    // along a wall but never through one. Decays in under half a second.
    if (this.shove.time > 0) {
      this.shove.time -= dt;
      state.x += this.shove.vx * dt;
      state.z += this.shove.vz * dt;
      state.heading += this.shove.vHeading * dt;
      const fr = Math.exp(-5 * dt);
      this.shove.vx *= fr;
      this.shove.vz *= fr;
      this.shove.vHeading *= fr;
      if (this.shove.time <= 0) {
        this.shove.vx = 0;
        this.shove.vz = 0;
        this.shove.vHeading = 0;
        this.shoved = false;
      }
    }

    // --- map collision: sweep the wanted motion, sliding along walls ---
    if (this.terrain) {
      const wantedX = state.x;
      const wantedZ = state.z;
      let res = this.terrain.sweep(prevX, prevZ, wantedX, wantedZ, state.heading);
      // A destructible roadside prop hit hard enough is broken out of the way
      // and its collision released, so the car carries on through where it
      // stood. This runs only for the player (traffic leaves `onImpact` null),
      // only after the sweep proved real contact, and only when the handler's
      // own speed gate passes - `wantedX/Z` is the pose the car could not reach.
      //
      // `escaped` counts as contact too: a car that nudged a prop slowly and
      // then floors it starts the frame already overlapping its baked cells,
      // and without this the prop would be unbreakable exactly when leaned on
      // at speed. Props that merely overlap with no mesh (`_findHits` empty)
      // still report nothing, so phantom cells stay harmless.
      if ((res.blocked || res.escaped) && this.onImpact) {
        const broke = this.onImpact({
          isPlayer: true,
          x: wantedX,
          z: wantedZ,
          prevX,
          prevZ,
          y: state.y,
          heading: state.heading,
          speed: state.speed,
          clearance: this.terrain.g.clearance,
          height: this.terrain.g.height,
          halfLength: this.terrain.g.halfLength,
          halfWidth: this.terrain.g.halfWidth,
        });
        if (broke) {
          // Smashing through costs half the speed - the wreck visibly takes
          // the car's momentum with it instead of letting it through free.
          // A smashed prop is one clean hit to the car: the handler is already
          // speed-gated, so this fires once per smash, never per frame.
          this.contactHits = (this.contactHits ?? 0) + 1;
          state.speed *= 0.75;
          const through = this.terrain.sweep(prevX, prevZ, wantedX, wantedZ, state.heading);
          if (!through.blocked) res = through;
        }
      }
      const hasWallContact = res.blocked || res.escaped;
      if (hasWallContact) {
        this.collided = true;
        const contactX = res.x;
        const contactZ = res.z;
        const probe =
          this.terrain.collisionNormal(contactX, contactZ, state.heading) ||
          this.terrain.collisionNormal(prevX, prevZ, state.heading);
        let n = probe;
        const sustained = this._contactTime > 0;
        if (probe && sustained) {
          const dot = probe.x * this._contactNx + probe.z * this._contactNz;
          if (dot > 0.5) {
            const bx = probe.x + this._contactNx;
            const bz = probe.z + this._contactNz;
            const bl = Math.hypot(bx, bz);
            if (bl > 1e-4) n = { x: bx / bl, z: bz / bl };
          }
        }
        if (n) {
          this._contactNx = n.x;
          this._contactNz = n.z;
          this._contactTime = 0.4;
        }

        const speed = state.speed;
        const fx = Math.sin(state.heading);
        const fz = Math.cos(state.heading);
        let nx = n ? n.x : -fx;
        let nz = n ? n.z : -fz;
        const normalDot = fx * nx + fz * nz;
        const vn = speed * normalDot;
        const approach = Math.max(0, -vn);
        // Flank / glancing contact: angle is within ~50° of parallel to the wall
        const isSideHit = normalDot >= -0.65;

        if (n && isSideHit) {
          // --- BUTTERY-SMOOTH ARCADE WALL SLIDE (NFS / Forza / Burnout style) ---
          // Maintain uninterrupted forward slide momentum every frame without pausing or jitter
          const dx = wantedX - prevX;
          const dz = wantedZ - prevZ;
          const into = dx * n.x + dz * n.z;
          let tangX = dx - (into < 0 ? into * n.x : 0);
          let tangZ = dz - (into < 0 ? into * n.z : 0);
          const tangLen = Math.hypot(tangX, tangZ);

          const slideFriction = sustained ? 0.988 : 0.978;
          state.speed *= slideFriction;

          if (tangLen > 1e-4) {
            const tangUx = tangX / tangLen;
            const tangUz = tangZ / tangLen;
            const slideStep = Math.abs(state.speed) * dt;
            const moveX = tangUx * slideStep;
            const moveZ = tangUz * slideStep;

            // Start 3cm off wall into open road so sweep never snags the wall mesh
            const startX = contactX + n.x * 0.03;
            const startZ = contactZ + n.z * 0.03;
            const trial = this.terrain.sweep(
              startX,
              startZ,
              startX + moveX,
              startZ + moveZ,
              state.heading,
            );
            state.x = trial.x + n.x * 0.02;
            state.z = trial.z + n.z * 0.02;

            // Smoothly guide heading to follow the curvature of the wall tangent
            const tangHeading = Math.atan2(tangUx, tangUz);
            let hDiff = tangHeading - state.heading;
            while (hDiff > Math.PI) hDiff -= Math.PI * 2;
            while (hDiff < -Math.PI) hDiff += Math.PI * 2;
            state.heading += hDiff * Math.min(0.35, 8.0 * dt);
          } else {
            state.x = contactX + n.x * 0.03;
            state.z = contactZ + n.z * 0.03;
          }

          if (!sustained) {
            try {
              soundManager.playImpact("brick", { intensity: 0.25 });
            } catch {}
          }
        } else if (approach > 0) {
          // --- HEAD-ON / HIGH ANGLE WALL IMPACT ---
          state.x = contactX;
          state.z = contactZ;
          let applied = 0;
          try {
            const g = this.terrain?.g;
            const ext = g ? (g.halfLength + g.halfWidth) / 2 : 1.55;
            applied = this.damage?.recordHit({
              x: state.x - nx * ext,
              y: state.y + 0.85,
              z: state.z - nz * ext,
              dirX: nx,
              dirZ: nz,
              severity: impactSeverity(approach),
              speed: state.speed,
              cx: state.x,
              cz: state.z,
              heading: state.heading,
              carY: state.y,
            }) ?? 0;
          } catch {
            /* dents are cosmetic: never fail a crash */
          }
          if (applied > 0 && !sustained) this.contactHits = (this.contactHits ?? 0) + 1;
          if (applied > 0 && !sustained) {
            try {
              soundManager.playImpact("brick", { intensity: impactSeverity(approach) });
            } catch {
              /* audio must never interrupt driving */
            }
          }
          const hard = approach >= CAR.crashMinApproach && !sustained;
          const e = hard ? CAR.crashRestitution : 0;
          const tvx = fx * speed - vn * nx;
          const tvz = fz * speed - vn * nz;
          const rvx = tvx * CAR.crashTangentKeep - vn * e * nx;
          const rvz = tvz * CAR.crashTangentKeep - vn * e * nz;
          state.speed = clamp(rvx * fx + rvz * fz, -CAR.maxReverse, CAR.maxSpeed);
          if (hard) {
            const cross = fx * nz - fz * nx;
            state.heading += clamp(-cross * approach * CAR.crashSpin, -CAR.crashMaxSpin, CAR.crashMaxSpin);
          }
        } else {
          state.x = contactX + (n ? n.x * 0.03 : 0);
          state.z = contactZ + (n ? n.z * 0.03 : 0);
          state.speed *= 0.96;
        }
      } else {
        this.collided = false;
        state.x = res.x;
        state.z = res.z;
      }

      // --- anti-weld ---------------------------------------------------
      // A head-on hit into a barrier can pin the car: the sweep refuses every
      // forward candidate and both axis slides fail, so it sits at zero speed
      // and the next frame repeats. When that persists, walk the car toward
      // open space. `nearestFree` orders its search to prefer backing out (away
      // from what was hit), so the car eases off the wall instead of sticking.
      //
      // Hands off the pedals ONLY: while the driver holds throttle/brake into
      // the obstacle the correct behaviour is to sit against it revving, and
      // yanking the car out every 0.35 s reads as a back-and-forth glitch.
      // The driver can always reverse out themselves; the escape stays for a
      // genuinely wedged car with no drive intent.
      const hasDriveIntent =
        (input.throttle ?? 0) > 0.05 ||
        (input.brake ?? 0) > 0.05 ||
        !!input.handbrake;
      if (this.collided && Math.abs(state.speed) < 0.5 && !hasDriveIntent) this._blockedTime += dt;
      else this._blockedTime = 0;
      if (this._blockedTime > 0.35) {
        const free = this.terrain.nearestFree(
          state.x,
          state.z,
          state.heading,
          state.x + Math.sin(state.heading) * 2,
          state.z + Math.cos(state.heading) * 2,
        );
        if (free) {
          state.x = free.x;
          state.z = free.z;
        }
        this._blockedTime = 0;
      }
    }

    // --- terrain: chassis height, slope and suspension from wheel contacts ---
    if (this.terrain) {
      this.terrain.follow(dt, state.x, state.z, state.heading);
      state.y = this.terrain.y;
    }

    // --- player <-> dynamic vehicles -------------------------------------
    // Done AFTER the map collision so the player's terrain-following is
    // already finished; this checks only the dynamic, moving obstacles - the
    // ambient traffic and, during a race, the rivals.
    //
    // Two different feels by design:
    //   - traffic: solid road car with a full shove + slowdown;
    //   - racers (NFS/Forza style): arcade paint-trading. Both cars nudge,
    //     both keep most of their speed, nobody parks. Hidden (pre-race)
    //     rivals are skipped entirely so the empty event has no ghost cars.
    if (this.traffic?.vehicles?.length || this.opponents?.length) {
      const raceFoes = [];
      if (this.opponents) for (const o of this.opponents) {
        if (!o || o.hidden) continue;
        if (!o.state) continue;
        raceFoes.push(o);
      }
      if (raceFoes.length) {
        const hit = resolveVehicleCollision(this, raceFoes, prevX, prevZ, {
          spinScale: 0.22,
          arcade: true,
        });
        if (hit) {
          // Repeat contact with the same car (pushing it down the road)
          // goes soft: keep most of the speed and barely separate, or the
          // full resolve + shove-back every frame welds both cars into a
          // forward/slam judder. Fresh hits keep the full arcade nudge.
          const repeat = hit.v === this._lastVehicleHit && this._time - this._vehicleHitTime < 0.5;
          this._lastVehicleHit = hit.v;
          this._vehicleHitTime = this._time;
          const preSpeed = state.speed;
          // Sustained contact costs the player NO speed. A rival leaning on
          // the player used to take 6% a frame here - 0.94^30 is ~84% of the
          // car's speed gone in half a second of contact - so the player could
          // not drive away from the car holding them: the pair welded and the
          // race was lost to physics rather than to driving. Only a FRESH hit
          // (bounded by the closing speed, see vehicleCollision.js) costs
          // anything, exactly like the rivals' own rule.
          state.speed = repeat ? state.speed : hit.slowedSpeed;
          if (hit.resolveX !== undefined) {
            state.x = hit.resolveX;
            state.z = hit.resolveZ;
          }
          const dx = state.x - hit.hitX;
          const dz = state.z - hit.hitZ;
          const d = Math.hypot(dx, dz) || 1;
          // Paint trading leaves a mark: dent the face toward the other car,
          // severity from the pre-impact pace. A fresh one also scores the
          // contact tally (same new-contact rule as walls).
          try {
            const sev =
              Math.max(impactSeverity(Math.abs(preSpeed)), Math.abs(preSpeed) > 1 ? 0.1 : 0) *
              VEHICLE_HIT_SEVERITY;
            if (sev > 0 && !repeat) {
              const g = this.terrain?.g;
              const ext = g ? (g.halfLength + g.halfWidth) / 2 : 1.55;
              const ux = dx / d;
              const uz = dz / d;
              const applied = this.damage?.recordHit({
                x: state.x - ux * ext,
                y: state.y + 0.85,
                z: state.z - uz * ext,
                dirX: ux,
                dirZ: uz,
                severity: sev,
                speed: preSpeed,
                cx: state.x,
                cz: state.z,
                heading: state.heading,
                carY: state.y,
              }) ?? 0;
              if (applied > 0 && !repeat) this.contactHits = (this.contactHits ?? 0) + 1;
              // Rival paint-trading SFX (metal flavour): fresh hits only.
              if (!repeat) {
                try {
                  soundManager.playImpact("metal", { intensity: Math.max(sev, 0.25) });
                } catch {
                  /* audio must never interrupt driving */
                }
              }
            }
          } catch {
            /* dents are cosmetic: never fail a crash */
          }
          // Separation: on side contacts, lateral overlap is already resolved cleanly by hit.resolveX/Z.
          // Only apply separation push on head-on / rear impacts.
          if (!hit.isSide) {
            const sep = repeat ? 0.06 : 0.15;
            state.x += (dx / d) * sep;
            state.z += (dz / d) * sep;
          }
          this.collided = true;
        }
      }
      if (this.traffic?.vehicles?.length) {
        const others = [];
        for (const v of this.traffic.vehicles) others.push(v);
        const hit = resolveVehicleCollision(this, others, prevX, prevZ);
        if (hit) {
          // Same repeat-contact softening as the race branch: a sustained
          // push must creep and steer around, not slam to zero and get
          // yanked back every frame (that yank exceeds a frame's travel,
          // so holding throttle walks the car backwards - the weld).
          const repeat = hit.v === this._lastVehicleHit && this._time - this._vehicleHitTime < 0.5;
          // Count distinct contacts: a fresh car, not a sustained lean. Same
          // rule as walls and props - every real hit to the car scores the
          // NO-COLLISION run, not just traffic.
          if (!repeat) this.contactHits = (this.contactHits ?? 0) + 1;
          this._lastVehicleHit = hit.v;
          this._vehicleHitTime = this._time;
          // Apply the post-impact speed, then resolve the position: first back
          // the car to the last point on this frame's path that was clear of
          // the vehicle (so a fast hit cannot end the frame buried in the car),
          // then nudge it out along the contact normal so the two boxes do not
          // start the next frame overlapping.
          const preSpeed = state.speed;
          state.speed = repeat ? (hit.isSide ? state.speed : state.speed * 0.9) : hit.slowedSpeed;
          if (hit.resolveX !== undefined) {
            state.x = hit.resolveX;
            state.z = hit.resolveZ;
          }
          const dx = state.x - hit.hitX;
          const dz = state.z - hit.hitZ;
          const d = Math.hypot(dx, dz) || 1;
          // Dent the face toward the other car, severity from pre-impact pace.
          try {
            const sev =
              Math.max(impactSeverity(Math.abs(preSpeed)), Math.abs(preSpeed) > 1 ? 0.1 : 0) *
              VEHICLE_HIT_SEVERITY;
            if (sev > 0 && !repeat) {
              const g = this.terrain?.g;
              const ext = g ? (g.halfLength + g.halfWidth) / 2 : 1.55;
              const ux = dx / d;
              const uz = dz / d;
              this.damage?.recordHit({
                x: state.x - ux * ext,
                y: state.y + 0.85,
                z: state.z - uz * ext,
                dirX: ux,
                dirZ: uz,
                severity: sev,
                speed: preSpeed,
                cx: state.x,
                cz: state.z,
                heading: state.heading,
                carY: state.y,
              });
            }
          } catch {
            /* dents are cosmetic: never fail a crash */
          }
          // Traffic crash SFX (metal flavour): fresh hits only, so pushing a
          // car down the road doesn't machine-gun the sound.
          if (!repeat) {
            try {
              soundManager.playImpactForSpeed(Math.abs(preSpeed) * 3.6, "metal");
            } catch {
              /* audio must never interrupt driving */
            }
          }
          if (!hit.isSide) {
            const sep = repeat ? 0.08 : 0.35;
            state.x += (dx / d) * sep;
            state.z += (dz / d) * sep;
          }
          this.collided = true;
        }
      }
    }

    // --- body damage: bonnet smoke follows the car every frame ---------
    try {
      this.damage?.update(dt, {
        x: state.x,
        y: state.y,
        z: state.z,
        heading: state.heading,
        speed: state.speed,
      });
    } catch {
      /* smoke must never break driving */
    }

    // --- tire tracks + spray: rear-axle stamps while sliding, and the
    // loose material the tyres throw on any normal driving -----------------
    const slip = this._slip(input, yawRate, throttle, brake);
    // Expose the arcade slip blend so external systems (e.g. engine audio) can
    // read how hard the tyres are working without recomputing it.
    this.slip = slip;
    // Cosmetic tail-out: swing the body visually into the corner (tail steps
    // out, front holds - see sync). Driven DIRECTLY by the steer key so it
    // responds the instant you turn rather than waiting for a slide to build,
    // gated by speed, and wound out faster/further under braking. approach()
    // keeps it a smooth ramp, never a snap. Physics is untouched.
    const steerIn = input.steer ?? 0;
    const spd = Math.abs(state.speed);
    const fast = clamp((spd - 12) / 18, 0, 1); // ~43..108 km/h
    let skidMag = Math.abs(steerIn) * fast;
    if (steerIn !== 0) skidMag = clamp(skidMag + brake * 0.45 * fast, 0, 1);
    // Nose points into the corner (opposite sign to the steer input).
    const skidTarget = -Math.sign(steerIn) * skidMag * CAR.skidYawMax;
    const winding = Math.abs(skidTarget) > Math.abs(this.skidYaw);
    const skidRate = winding
      ? brake > 0.3 && steerIn !== 0
        ? CAR.skidYawBrakeBuild
        : CAR.skidYawBuild
      : CAR.skidYawRecover;
    this.skidYaw = approach(this.skidYaw, skidTarget, skidRate * dt);
    // Rear-wheel ground contacts, sampled once and shared by the marks, the
    // spray and the dirt build-up so all three always agree on the surface.
    let contacts = [];
    try {
      contacts = this._rearContacts();
    } catch {
      contacts = [];
    }
    try {
      this._emitTireMarks(dt, slip, contacts);
    } catch {
      /* marks are cosmetic: never fail driving */
    }
    try {
      this._emitTireSpray(dt, slip, contacts);
    } catch {
      /* spray is cosmetic: never fail driving */
    }
    try {
      this._accumulateDirt(slip, contacts);
    } catch {
      /* dirt is cosmetic: never fail driving */
    }

    // --- bent-axle wobble ------------------------------------------------
    // A smoking car shakes its wheels: mostly a visual tremor on the front
    // wheels, plus a slight wander so it feels mechanical. Scaled by smoke
    // level and pace - parked wrecks sit still.
    const wobble = this.damage?.smokeLevel?.() ?? 0;
    const wobblePace = Math.min(1, Math.abs(state.speed) / 20);
    this._steerWobble =
      wobble * wobblePace * (Math.sin(this._time * 9.1) * 0.045 + Math.sin(this._time * 15.7) * 0.015);
    if (wobble > 0 && wobblePace > 0) {
      state.heading += Math.sin(this._time * 7.3) * 0.06 * wobble * wobblePace * dt;
    }

    // --- body attitude ---
    // Lean is driven by lateral acceleration (v * yawRate) so it grows with
    // both speed and corner tightness, and it settles back on the straights.
    const lateral = state.speed * yawRate;
    const targetRoll = clamp(-lateral * 0.012, -0.09, 0.09);
    // Squat under power, dive under braking.
    const targetPitch = clamp(this.lastAccel * 0.004, -0.05, 0.05);

    this.roll += (targetRoll - this.roll) * smoothFactor(6, dt);
    this.pitch += (targetPitch - this.pitch) * smoothFactor(5, dt);

    this.sync();
  }

  /**
   * Arcade slip blend, 0..1. This is a VISUAL/AUDIO cue only - it drives the
   * rear tyre marks, the spray and the skid sound, and never the physics, so
   * the car keeps tracking its grip line (handling is unchanged).
   *
   * The rears skid when cornering at speed - driven by lateral load and by
   * steering held at speed - and skid a little more when braking into the turn.
   * Handbrake slides, standing burnouts and locked-up braking still peg it.
   */
  _slip(input, yawRate, throttle, brake) {
    const speed = Math.abs(this.state.speed);
    const latA = Math.abs(this.state.speed * yawRate);
    const steer = Math.abs(input.steer ?? 0);
    // "How fast": 0 below ~47 km/h, 1 by ~126 km/h. Keeps low-speed turns from
    // screeching while making genuine high-speed corners light up the rears.
    const fast = clamp((speed - 13) / 22, 0, 1);
    // Cornering skid: lateral load, emphasised at speed, plus a floor from
    // simply holding a steer direction fast enough.
    let skid = (latA / 24) * (0.35 + 0.65 * fast);
    skid = Math.max(skid, steer * fast * 0.95);
    // Braking into the corner adds a little more rear skid (trail-braking).
    if (steer > 0.1 && brake > 0.2 && speed > 10) {
      skid += brake * 0.3 * Math.max(fast, 0.4);
    }
    return clamp(
      Math.max(
        skid,
        input.handbrake && speed > 6 ? 0.95 : 0,
        throttle > 0.75 && speed < 9 ? 0.85 : 0,
        brake > 0.7 && speed > 14 ? 0.75 : 0,
      ),
      0,
      1,
    );
  }

  /**
   * Ground contact of both rear wheels: world point plus the surface look
   * there. Returns an empty list when a wheel is airborne or off the field.
   * Shared by the tire marks and the spray so both key off the same patch.
   */
  _rearContacts() {
    const { state } = this;
    const out = [];
    const g = this.terrain.g ?? {};
    const halfL = g.halfLength ?? CAR.length / 2;
    const halfW = g.halfWidth ?? CAR.width / 2;
    const fx = Math.sin(state.heading);
    const fz = Math.cos(state.heading);
    for (const s of [-1, 1]) {
      const wx = state.x - fx * halfL * 0.55 + fz * s * halfW * 0.8;
      const wz = state.z - fz * halfL * 0.55 - fx * s * halfW * 0.8;
      try {
        const r = this.collision.groundAt(wx, wz, state.y, {
          stepUp: TERRAIN.maxStepUp,
          reach: TERRAIN.reach,
        });
        if (!r || r.kind !== "ground" || r.y == null) continue;
        out.push({ x: wx, y: r.y, z: wz, look: surfaceLook(this.collision.surfaceAt(wx, wz)) });
      } catch {
        continue;
      }
    }
    return out;
  }

  /**
   * Stamp tire tracks for both rear wheels while the car is sliding.
   *
   * Each surface family gets its own look (rubber on road, mud on grass,
   * pale smear on sand) via the collision's surface grid; stamps sit on the
   * ground height so they ride decks and ramps instead of floating.
   */
  _emitTireMarks(dt, slip, contacts) {
    if (!this.marks || !this.collision || !this.terrain) return;
    const { state } = this;
    const speed = Math.abs(state.speed);
    if (this._markPX === null) {
      this._markPX = state.x;
      this._markPZ = state.z;
      return;
    }
    const moved = Math.hypot(state.x - this._markPX, state.z - this._markPZ);
    this._markPX = state.x;
    this._markPZ = state.z;
    if (speed < 3 || slip < 0.32) {
      this._markAcc = 0;
      return;
    }
    this._markAcc += moved;
    if (this._markAcc < 0.45) return;
    const len = Math.min(0.9, Math.max(0.5, this._markAcc));
    this._markAcc = 0;
    // Bold: a wider stamp laid down more opaquely so the marks read clearly.
    const alpha = Math.min(0.95, 0.45 + slip * 0.5);
    for (const c of contacts) {
      this.marks.emit(c.x, c.y + 0.03, c.z, state.heading, 0.38, len, alpha, c.look);
    }
  }

  /**
   * Throw loose material off the rear tyres. Unlike the marks this runs on
   * ANY normal driving - the point is the dust/mud/sand visible while the
   * car is simply moving - scaled by speed and slip, and keyed to whatever
   * surface each rear wheel is on.
   */
  _emitTireSpray(dt, slip, contacts) {
    if (!this.spray || !this.collision || !this.terrain) return;
    const speed = Math.abs(this.state.speed);
    if (speed < 2.5 || this.terrain.airborne || !contacts.length) {
      this.spray.idle(dt);
      return;
    }
    this.spray.update(dt, { heading: this.state.heading, speed, slip, wheels: contacts });
  }

  /**
   * Lay grime onto the shell as the car is driven, like a production racer
   * collecting mud. Rate and colour follow the material under the rear tyres,
   * so a long grass run cakes the body in mud (the dirt layer adds the green
   * flecks) while road driving only settles a thin dust. Cosmetic only:
   * `carDamage.addDirt` is a no-op on a car with no dirt weights.
   */
  _accumulateDirt(slip, contacts) {
    const dmg = this.damage;
    if (!dmg?.addDirt) return;
    const { state } = this;
    if (this._dirtPX === null) {
      this._dirtPX = state.x;
      this._dirtPZ = state.z;
      return;
    }
    const moved = Math.hypot(state.x - this._dirtPX, state.z - this._dirtPZ);
    this._dirtPX = state.x;
    this._dirtPZ = state.z;
    if (moved <= 1e-4 || !contacts.length) return;
    let look = 0;
    let rate = 0;
    for (const c of contacts) {
      if (DIRT_RATE[c.look] > rate) {
        rate = DIRT_RATE[c.look];
        look = c.look;
      }
    }
    if (rate <= 0) return;
    // Slipping tyres throw more of it.
    dmg.addDirt(moved * rate * (1 + slip * 0.8), DIRT_TINT[look]);
  }

  /**
   * External impulse - a rival ran into this car. Arcade rules: a capped
   * positional nudge plus a brief heading kick, decaying in under half a
   * second. Driving input is never interrupted; the jolt simply rides along
   * on top of it (integrated in update, before the map sweep).
   *
   * Both halves of that jolt are stack-capped, and the yaw cap is deliberately
   * the tighter of the two. A player muddled through a pack is hit again every
   * time the shove expires, so anything that accumulates here is not a nudge,
   * it is the wheel being taken away: the heading kick is what the driver feels
   * as losing the car, so a hit may bruise the line, never own it.
   */
  applyShove(vx, vz, yawRate) {
    const MAX_SHOVE = 8; // m/s of instant jolt velocity
    const MAX_SPIN = 0.55; // rad/s of instant yaw kick from ONE hit
    const MAX_SPIN_STACK = 0.7; // rad/s however many hits land together
    if (Math.abs(yawRate) > MAX_SPIN) yawRate = Math.sign(yawRate) * MAX_SPIN;
    this.shove.vx += vx;
    this.shove.vz += vz;
    this.shove.vHeading = clamp(this.shove.vHeading + yawRate, -MAX_SPIN_STACK, MAX_SPIN_STACK);
    // Cap the stack so a multi-car sandwich cannot pile impulses into a
    // launch; a rear-end reads as a solid nudge, never a catapult.
    const stacked = Math.hypot(this.shove.vx, this.shove.vz);
    if (stacked > MAX_SHOVE) {
      const k = MAX_SHOVE / stacked;
      this.shove.vx *= k;
      this.shove.vz *= k;
    }
    this.shove.time = 0.45;
    this.shoved = true;
  }

  /** Push the simulation state onto the model. */
  sync() {
    const { x, z, heading } = this.state;
    // Cosmetic tail-out: draw the body yawed by `skidYaw` about the FRONT axle,
    // so the nose stays on the real line and the back of the car swings out.
    // The physics pose (x, z, heading) is left untouched - this only moves the
    // drawn model - so collision and trajectory are unchanged.
    const skid = this.skidYaw || 0;
    let dx = x;
    let dz = z;
    let dh = heading;
    if (skid !== 0) {
      const lf = (this.terrain?.g?.halfLength ?? CAR.length / 2) * 0.75; // ~front axle
      const faX = x + Math.sin(heading) * lf; // front-axle pivot (held fixed)
      const faZ = z + Math.cos(heading) * lf;
      dh = heading + skid;
      dx = faX - Math.sin(dh) * lf;
      dz = faZ - Math.cos(dh) * lf;
      // Cancel the fore/aft part of the pivot so the car NEVER appears to slide
      // backward - keep only the lateral tail swing.
      const along = (dx - x) * Math.sin(heading) + (dz - z) * Math.cos(heading);
      dx -= along * Math.sin(heading);
      dz -= along * Math.cos(heading);
    }
    if (this.terrain) {
      this.terrain.apply(this.rig, dx, dz, dh);
    } else {
      this.rig.setPosition(dx, this.state.y, dz);
      this.rig.setHeading(dh);
    }
    this.rig.setSteer(this.steerAngle + (this._steerWobble ?? 0));
    this.rig.setTilt(this.roll, this.pitch);
  }

  /** Called once per frame with the distance travelled, to roll the wheels. */
  spin(dt) {
    this.rig.spinWheels(this.state.speed * dt);
  }

  get position() {
    return this.state;
  }

  get speedKmh() {
    return Math.abs(this.state.speed) * 3.6;
  }

  get gear() {
    const s = this.state.speed;
    if (s < -0.6) return "R";
    if (s < 0.6) return "N";
    const gear = Math.ceil((s / CAR.maxSpeed) * 6);
    return String(clamp(gear, 1, 6));
  }
}
