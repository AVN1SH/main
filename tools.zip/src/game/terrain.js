import { CAR, clamp, smoothFactor } from "./driving.js";

/**
 * Terrain following, suspension and body collision, shared by the player and
 * the traffic.
 *
 * The car is no longer glued to a constant height. Each frame the four wheels
 * are projected onto their own patch of the map (through MapCollision), the
 * contact points are fitted to a plane, and that plane decides:
 *
 *   - how high the chassis sits (`y`)
 *   - how it is pitched and rolled relative to the slope
 *   - how far each wheel droops or compresses (suspension travel)
 *
 * Low surfaces (kerbs, speed breakers, ramp entries) are climbed smoothly
 * because the wheel simply follows the surface up. Anything taller than
 * `maxStepUp` that the tyres cannot roll over is rejected by `blocked()` and the
 * chassis stops against it instead of clipping through.
 */
export const TERRAIN = {
  maxStepUp: 0.34, // tallest rise a wheel can roll over, metres
  reach: 6, // how far below the car to look for the surface it is on
  climbRate: 20, // rate the body rises to a higher surface
  /**
   * Extra climb rate per m/s of ground speed. A steep ramp taken at speed
   * rises many metres per second under the car; a fixed climb rate always
   * lags it by riseRate/climbRate, so the faster the car the deeper it sits
   * sunk in the road - exactly the high-speed submersion on the elevated
   * approaches. Scaling the rate with travel keeps the lag flat instead.
   * Stood still this term is zero and climbing is bit-for-bit the old tune.
   */
  climbRateGain: 1.2,
  /**
   * Extra climb headroom per metre travelled. The per-sample clamp above the
   * chassis exists for kerbs; at speed a valid ramp keeps rising past it for
   * the whole frame, so the band widens with travel (a 0.75 grade budget).
   * Genuine walls still report kind "wall"/"none" and never enter `usable`.
   */
  climbGrade: 0.75,
  /**
   * Largest instant drop a wheel latches onto, metres. Sampling past a deck
   * edge (or a bake gap) can return the ground storeys below in a single
   * frame; latching that would drag the chassis down through the deck it is
   * actually driving on. Real roads never drop this far between two frames -
   * ramps and kerbs arrive gradually - so bigger jumps keep the old surface.
   */
  latchDrop: 1.0,
  gravity: 24, // m/s^2 while the car is in the air
  settle: 14, // rate pitch/roll follow the slope
  maxSuspension: 0.16, // visible wheel droop/compression, metres
  /**
   * Largest surface drop (m) the chassis follows while staying planted instead
   * of going airborne. A downhill ramp drops a few centimetres per frame; a
   * kerb or a bridge edge drops a metre or more at once. Below this the wheels
   * stay on the surface (no bob), above it the car falls under gravity.
   */
  descentStick: 0.6,
  footprintStep: 0.4, // horizontal substep used when sweeping for collisions
  /**
   * Spacing of the look-ahead samples that test for an obstacle in front of the
   * car. Deliberately half `footprintStep`: the sweep moves the car in
   * `footprintStep` strides, so samples spaced that far apart can land in the
   * same gap between a narrow obstacle on every stride and miss it forever.
   * Overlapping the probes by half a stride makes that impossible, and it also
   * measures a climb more finely, which keeps the per-sample rise - and so the
   * gradient a ramp has to beat - comfortably under `maxStepUp`.
   */
  probeStep: 0.2,
  /**
   * Cap on how far one escape nudge may move the car, metres.
   *
   * The collision bake approximates some small props with their bounding box,
   * so the car can stop at a spot that the grid calls solid even though no
   * geometry is there. `blocked()` tests candidate POSITIONS, so once the car
   * is inside such a cell every candidate - including standing still - reads
   * blocked, and no input can move it: a total, permanent freeze. `sweep`
   * detects that (it starts by testing the current pose) and walks the car
   * toward the nearest free pose a cap at a time, which reads as a short slide
   * out rather than a teleport.
   */
  escapeStep: 0.5,
  /** Furthest the escape search looks for a free pose, metres. */
  escapeRange: 3.0,
};

/**
 * Measures the car's wheel layout in root space so the terrain sampler knows
 * where the wheels are.
 *
 * Front/rear and left/right are taken from the measured wheel POSITIONS, not
 * from the mesh names: the rig has already yaw-fixed the model so its forward
 * is +Z, which makes a wheel's z sign authoritative and immune to the asset's
 * mirrored axes.
 */
export function describeVehicle(rig) {
  const wheels = rig.wheelOffsets.map((w) => ({
    x: w.x,
    z: w.z,
    radius: w.radius,
    front: w.z >= 0,
  }));

  const fronts = wheels.filter((w) => w.front);
  const rears = wheels.filter((w) => !w.front);
  const posX = wheels.filter((w) => w.x > 0);
  const negX = wheels.filter((w) => w.x < 0);
  const avg = (list, key) => list.reduce((s, w) => s + w[key], 0) / (list.length || 1);

  return {
    wheels,
    wheelBase: Math.max(avg(fronts, "z") - avg(rears, "z"), 0.5),
    track: Math.max(avg(posX, "x") - avg(negX, "x"), 0.5),
    frontZ: avg(fronts, "z"),
    rearZ: avg(rears, "z"),
    wheelRadius: rig.wheelRadius,
    halfLength: CAR.length / 2,
    halfWidth: CAR.width / 2,
    height: CAR.height,
    clearance: CAR.clearance,
  };
}

export class TerrainFollower {
  /**
   * @param collision MapCollision built from the map
   * @param geometry  result of describeVehicle()
   * @param y         starting ground height
   * @param blockOptions optional { ignoreDestructibles } for `blockedRect`, so
   *        a caller can drive through roadside clutter (signs, fences) instead
   *        of stopping against it. Traffic passes it here; a race rival leaves
   *        it null (props are solid to it, which is what makes a break a real
   *        hit) and passes the flag per call only where it wants to look past
   *        the clutter - see `RaceDriver._sideClear`.
   */
  constructor(collision, geometry, y, blockOptions = null) {
    this.collision = collision;
    this.g = geometry;
    this.y = y;
    this.vy = 0;
    this.airborne = false;
    this.pitch = 0;
    this.roll = 0;
    this.travels = geometry.wheels.map(() => 0);
    this.grounded = true;
    // Options forwarded to `MapCollision.blockedRect`. Set to
    // `{ ignoreDestructibles: true }` for traffic so street signs and
    // barrels do not wedge AI cars against the kerb.
    this.blockOptions = blockOptions;
    // The surface each wheel is currently riding. Sampling is resolved against
    // this rather than against the chassis height, so a wheel stays on the
    // surface it is already on. Without it, wherever the map stacks two nearly
    // parallel surfaces (a road and its kerb, a deck and its parapet) the wheel
    // would jump between them and the car would stumble.
    this.wheelY = geometry.wheels.map(() => y);
  }

  teleport(y) {
    this.y = y;
    this.vy = 0;
    this.airborne = false;
    this.pitch = 0;
    this.roll = 0;
    this.travels = this.g.wheels.map(() => 0);
    this.wheelY = this.g.wheels.map(() => y);
    // Forget travel so the first follow after a teleport measures no speed.
    this._prevX = undefined;
    this._prevZ = undefined;
  }

  /** World position of one wheel for a car at (x,z) facing `heading`. */
  wheelWorld(x, z, heading, w) {
    const sin = Math.sin(heading);
    const cos = Math.cos(heading);
    return {
      x: x + sin * w.z + cos * w.x,
      z: z + cos * w.z - sin * w.x,
    };
  }

  /** Contact ground height under every wheel at a pose. */
  contacts(x, z, heading) {
    const out = [];
    for (let i = 0; i < this.g.wheels.length; i++) {
      const w = this.g.wheels[i];
      const p = this.wheelWorld(x, z, heading, w);
      const ref = this.wheelY[i] ?? this.y;
      const r = this.collision.groundAt(p.x, p.z, ref, {
        stepUp: TERRAIN.maxStepUp,
        reach: TERRAIN.reach,
        headroom: this.g.height,
      });
      out.push({ w, x: p.x, z: p.z, y: r.y, kind: r.kind });
    }
    return out;
  }

  /**
   * Is the car blocked at (x,z)?
   *
   * Three independent tests, because the map expresses obstacles three ways:
   *
   *  1. A solid column the chassis cannot occupy (a building, a fence, a parked
   *     car), tested as a rectangle against the obstacle grid.
   *  2. A surface in the way, tested by walking a line of height samples out to
   *     the front bumper and comparing each with the one before it. Chaining is
   *     what lets the car climb a ramp of any gradient - the rise per step is
   *     small - while a genuine step, where the surface jumps by more than the
   *     wheel can roll over, still stops it. Each sample is compared with the
   *     height the car is already resting on, never with a fixed reference, or a
   *     slope would read as a step everywhere along it.
   *  3. Each wheel against its own last height, catching a step the car has
   *     already driven into sideways.
   *
   * All three pass the car's height as `headroom`, which is what separates a
   * wall from something the car can pass underneath.
   */
  blocked(x, z, heading, hits = null, blockOptions = this.blockOptions) {
    const g = this.g;
    const sin = Math.sin(heading);
    const cos = Math.cos(heading);
    const bottom = this.y + g.clearance;
    const top = this.y + g.height;

    // 1. solid columns over the footprint, tested as a rectangle against the
    //    obstacle grid. Sampling a few points instead would miss a thin wall
    //    running alongside the car, which is exactly the shape that blocks a
    //    lane without ever being detected.
    //
    // Traffic is configured to ignore destructible families (street signs,
    // fences, barrels) so a misplaced kerb-side prop cannot strand a car
    // that is otherwise correctly on its lane - it drives through them instead.
    // The player keeps the strict collision because they can smash through, and
    // so does a race rival: being stopped by the sign it just hit is what makes
    // that hit real (RaceDriver then breaks it and takes no speed penalty for
    // it). The flag can also be overridden per call for a probe that only wants
    // to know about structure.
    if (
      this.collision.blockedRect(x, z, heading, g.halfLength, g.halfWidth, bottom, top, hits, blockOptions)
    ) {
      return true;
    }

    // 2. unclimbable step ahead, chained from the current height
    //
    // Seeded from the highest point the car already rests on, not from its
    // centre. Chaining alone is not enough on a slope: each sample only advances
    // the reference by one step, so a chain that starts at the centre spends the
    // first couple of metres catching up on ground the car is already sitting
    // on, and reads that as a wall in front of it. The body is rigid, so the
    // front wheels really are that much higher and are the right starting point.
    let prevY = this.y;
    for (let i = 0; i < this.wheelY.length; i++) {
      const wy = this.wheelY[i];
      if (wy !== null && wy !== undefined && wy > prevY) prevY = wy;
    }
    const step = TERRAIN.probeStep;
    for (let d = step; d <= g.halfLength + step; d += step) {
      const px = x + sin * d;
      const pz = z + cos * d;
      const r = this.collision.groundAt(px, pz, prevY, {
        stepUp: TERRAIN.maxStepUp,
        reach: 1.5,
        headroom: g.height,
      });
      if (r.kind === "wall") {
        if (hits) {
          // A "wall" is the height field, not a solid column: some surface here
          // is above the car by more than a step. Report the nearest one so the
          // marker sits on the lip the car actually met.
          const top_ = this.collision.highestAbove(px, pz, prevY + TERRAIN.maxStepUp);
          hits.push({ x: px, z: pz, y: top_ ?? prevY, kind: "step", mesh: null, from: 3 });
        }
        return true;
      }
      // Only a real surface advances the chain. A gap ("none") must not drop
      // the reference to the fallback height, or the next sample - the bridge
      // deck beyond the gap - would look like an unclimbable step.
      if (r.kind === "ground") prevY = r.y;
    }

    // 3. a wheel already against a step (e.g. driving sideways into a kerb wall)
    //
    // Each wheel is compared against its OWN last height, not the car's centre
    // height. The car is 4.3 m long, so on a slope the front wheels sit well
    // above the centre while the rear wheels sit below it. Referencing the
    // centre made every wheel test read a rise equal to the slope over its own
    // distance from the middle, which is exactly the thing test 2 exists to
    // allow, and it rejected any ramp past about 9 degrees. `contacts()` already
    // keeps these per-wheel heights, so the reference is the same one the wheel
    // was last resting on.
    for (let i = 0; i < g.wheels.length; i++) {
      const w = g.wheels[i];
      const p = this.wheelWorld(x, z, heading, w);
      const ref = this.wheelY[i] ?? this.y;
      const r = this.collision.groundAt(p.x, p.z, ref, {
        stepUp: TERRAIN.maxStepUp,
        reach: 1.5,
        headroom: g.height,
      });
      if (r.kind === "wall") {
        if (hits) {
          const top_ = this.collision.highestAbove(p.x, p.z, ref + TERRAIN.maxStepUp);
          hits.push({ x: p.x, z: p.z, y: top_ ?? ref, kind: "wheel", mesh: null, from: 3 });
        }
        return true;
      }
    }
    return false;
  }

  /**
   * Outward contact normal at a pose: a unit vector pointing from whatever is
   * blocking the car back toward the open space it can still move into.
   *
   * `blocked()` only answers yes/no, but a believable bounce needs the
   * DIRECTION of the surface. That is recovered by probing `blocked()` in a
   * ring around the pose and averaging the directions that are still clear:
   * against a flat wall the clear directions fill the half-plane on this side,
   * and the mean of a half circle points along its normal. In a corner the mean
   * points down the bisector of the open quadrant - exactly the direction that
   * eases the car out. Returns null only when every probe is blocked (fully
   * boxed in), in which case callers fall back to rebounding along the old
   * velocity.
   *
   * @param radius how far out each probe is taken; must reach past the car's
   *   own footprint or a nearby surface still reads as clear.
   */
  collisionNormal(x, z, heading, radius = 1.0) {
    const directions = 16;
    let sx = 0;
    let sz = 0;
    for (let k = 0; k < directions; k++) {
      const th = (k / directions) * Math.PI * 2;
      const dx = Math.cos(th);
      const dz = Math.sin(th);
      if (this.blocked(x + dx * radius, z + dz * radius, heading)) continue;
      sx += dx;
      sz += dz;
    }
    const len = Math.hypot(sx, sz);
    if (len < 1e-4) return null;
    return { x: sx / len, z: sz / len };
  }

  /**
   * Sweep from the previous position to the wanted one, stopping at the last
   * free point. The substeps stop a fast car from tunnelling through a wall in
   * a single 60 Hz frame.
   *
   * `blockOptions` overrides the follower's own (see the constructor) for this
   * call only, so a caller can re-run the very same motion with the roadside
   * clutter treated as passable - the backstop a race uses after a prop failed
   * to break, so clutter can never wedge a car (see RaceDriver).
   *
   * @returns {{ x:number, z:number, blocked:boolean }}
   */
  sweep(prevX, prevZ, nextX, nextZ, heading, blockOptions = this.blockOptions) {
    // Escape hatch: a sweep tests candidate positions, so a car that is ALREADY
    // inside geometry reads every candidate - even not moving - as blocked and
    // can never get out. That happens because the bake boxes some props, and a
    // car can stop on a cell the grid calls solid with no mesh there. Detect
    // it up front and nudge the car toward the nearest free pose instead.
    if (this.blocked(prevX, prevZ, heading, null, blockOptions)) {
      // First try nudging outward along the surface normal into open space,
      // avoiding the backward yank that causes jitter on wall grazes.
      const norm = this.collisionNormal(prevX, prevZ, heading);
      if (norm) {
        for (const dist of [0.04, 0.08, 0.14, 0.22]) {
          const escX = prevX + norm.x * dist;
          const escZ = prevZ + norm.z * dist;
          if (!this.blocked(escX, escZ, heading, null, blockOptions)) {
            return { x: escX, z: escZ, blocked: true, escaped: true };
          }
        }
      }
      const escape = this.nearestFree(prevX, prevZ, heading, nextX, nextZ, blockOptions);
      if (escape) return { x: escape.x, z: escape.z, blocked: true, escaped: true };
      return { x: prevX, z: prevZ, blocked: true };
    }

    const dist = Math.hypot(nextX - prevX, nextZ - prevZ);
    if (dist < 1e-4) return { x: nextX, z: nextZ, blocked: false };
    const steps = Math.max(1, Math.ceil(dist / TERRAIN.footprintStep));
    let lastX = prevX;
    let lastZ = prevZ;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const x = prevX + (nextX - prevX) * t;
      const z = prevZ + (nextZ - prevZ) * t;
      if (this.blocked(x, z, heading, null, blockOptions)) return { x: lastX, z: lastZ, blocked: true };
      lastX = x;
      lastZ = z;
    }
    return { x: nextX, z: nextZ, blocked: false };
  }

  /**
   * Nearest pose around (x,z) that is not blocked, searched outward from the
   * car. Directions are ordered to prefer backing out (opposite the wanted
   * motion) so a nudge never pops the car through the thing it just hit.
   *
   * @returns {{ x:number, z:number, distance:number }|null}
   */
  nearestFree(x, z, heading, wantX, wantZ, blockOptions = this.blockOptions) {
    const dx = wantX - x;
    const dz = wantZ - z;
    const len = Math.hypot(dx, dz);
    const ux = len > 1e-6 ? dx / len : 0;
    const uz = len > 1e-6 ? dz / len : 1;

    const dirs = [];
    const directions = 16;
    for (let k = 0; k < directions; k++) {
      const th = (k / directions) * Math.PI * 2;
      const cx = Math.cos(th);
      const cz = Math.sin(th);
      dirs.push({ x: cx, z: cz, align: cx * ux + cz * uz });
    }
    dirs.sort((a, b) => a.align - b.align);

    const radii = [0.2, 0.35, 0.5, 0.75, 1.0, 1.4, 1.9, 2.5, TERRAIN.escapeRange];
    for (const r of radii) {
      for (const d of dirs) {
        const nx = x + d.x * r;
        const nz = z + d.z * r;
        if (this.blocked(nx, nz, heading, null, blockOptions)) continue;
        const t = Math.min(1, TERRAIN.escapeStep / r);
        return { x: x + d.x * r * t, z: z + d.z * r * t, distance: r };
      }
    }
    return null;
  }

  /**
   * Update chassis height, attitude and suspension from the wheel contacts.
   * Must be called after the horizontal position is final.
   */
  follow(dt, x, z, heading) {
    const contacts = this.contacts(x, z, heading);
    const g = this.g;

    // How far the car travelled over the ground this frame. Everything
    // speed-sensitive below keys off this, so parked handling is untouched.
    const dx = x - (this._prevX ?? x);
    const dz = z - (this._prevZ ?? z);
    this._prevX = x;
    this._prevZ = z;
    const groundSpeed = Math.hypot(dx, dz) / Math.max(dt, 1e-4);

    // Latch each wheel onto the surface it just sampled, for next frame. A
    // wheel over a gap keeps its last surface so it does not snap to a lower
    // fallback and then refuse the real surface it is still over.
    for (let i = 0; i < contacts.length; i++) {
      if (contacts[i].kind !== "ground") continue;
      if (Math.abs(contacts[i].y - (this.wheelY[i] ?? this.y)) > TERRAIN.latchDrop) continue;
      this.wheelY[i] = contacts[i].y;
    }

    // A wheel hanging over a hole or facing an unclimbable step must not drag
    // the whole chassis with it, so its contribution is clamped to a band
    // around the current height before the plane is fitted. The upper edge
    // widens with travel: at speed a valid ramp keeps rising past the kerb
    // band for the whole frame, and holding the band fixed is what used to
    // sink fast cars into steep approaches.
    const riseBand = TERRAIN.maxStepUp + groundSpeed * dt * TERRAIN.climbGrade;
    const usable = contacts.map((c) => {
      if (c.kind === "wall" || c.kind === "none") return this.y;
      return clamp(c.y, this.y - 1.2, this.y + riseBand);
    });

    const sum = (list) => list.reduce((s, v) => s + v, 0);
    const avg = (list) => (list.length ? sum(list) / list.length : this.y);
    const center = avg(usable);

    const frontY = avg(contacts.map((c, i) => (c.w.front ? usable[i] : null)).filter((v) => v !== null));
    const rearY = avg(contacts.map((c, i) => (!c.w.front ? usable[i] : null)).filter((v) => v !== null));
    const posY = avg(contacts.map((c, i) => (c.w.x > 0 ? usable[i] : null)).filter((v) => v !== null));
    const negY = avg(contacts.map((c, i) => (c.w.x < 0 ? usable[i] : null)).filter((v) => v !== null));

    const slopeF = (frontY - rearY) / g.wheelBase;
    const slopeR = (posY - negY) / g.track;

    // --- vertical: climb smoothly, fall under gravity ---------------------
    // The climb rate scales with travel for the same reason as the band
    // above: an exponential approach lags a moving target by
    // riseRate/rate, so a fixed rate sinks fast cars into fast ramps.
    if (center >= this.y) {
      const climbRate = TERRAIN.climbRate + groundSpeed * TERRAIN.climbRateGain;
      this.y += (center - this.y) * smoothFactor(climbRate, dt);
      this.vy = 0;
      this.airborne = false;
    } else if (!this.airborne && this.y - center <= TERRAIN.descentStick) {
      // Continuous downhill. The surface drops only a little this frame, so
      // the tyres stay on it instead of the chassis free-falling for a frame
      // and popping back - that free-fall was the "jump" felt going down a
      // ramp, worst on the bridge approach where the grade is steep.
      this.y = center;
      this.vy = 0;
      this.airborne = false;
    } else {
      this.vy -= TERRAIN.gravity * dt;
      this.y += this.vy * dt;
      if (this.y <= center) {
        this.y = center;
        this.vy = 0;
        this.airborne = false;
      } else {
        this.airborne = true;
      }
    }
    this.grounded = !this.airborne;

    // --- attitude ---------------------------------------------------------
    // +Z is forward and +X is the car's right, so a nose-up slope needs a
    // negative rotation about X and a right-side-up slope a positive one about Z.
    const targetPitch = -Math.atan(slopeF);
    const targetRoll = Math.atan(slopeR);
    const settle = smoothFactor(TERRAIN.settle, dt);
    this.pitch += (targetPitch - this.pitch) * settle;
    this.roll += (targetRoll - this.roll) * settle;

    // --- per-wheel suspension --------------------------------------------
    for (let i = 0; i < contacts.length; i++) {
      const w = contacts[i].w;
      const planeY = center + slopeF * w.z + slopeR * w.x;
      const travel = clamp(usable[i] - planeY, -TERRAIN.maxSuspension, TERRAIN.maxSuspension);
      this.travels[i] += (travel - this.travels[i]) * settle;
    }

    return this;
  }

  /** Push the result onto the rig. */
  apply(rig, x, z, heading) {
    rig.setPosition(x, this.y, z);
    rig.setHeading(heading);
    rig.setGroundTilt(this.pitch, this.roll);
    rig.setSuspension(this.travels);
  }
}
