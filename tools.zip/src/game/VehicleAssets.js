import { LoadAssetContainerAsync } from "@babylonjs/core";
import "@babylonjs/loaders/glTF/2.0";

/**
 * Loads and caches every traffic vehicle model in `public/assets/vehicles/`.
 *
 * Each vehicle is a standalone GLB whose structure is uniform:
 *
 *   root  (e.g. "Ambulance-Truck", mesh = body, parent of all wheels)
 *    +- _TireFL   (mesh)
 *    +- _TireFR   (mesh)
 *    +- _TireBL   (mesh)
 *    +- _TireBR   (mesh)
 *
 * The SUV is the one exception: it ships with six wheels (BL1/BL2 + BR1/BR2
 * doubles on the rear axle). The TrafficRig averages the rear pairs so the
 * rest of the system only ever sees four contacts.
 *
 * Each model is normalised to a target length so the trucks read as trucks
 * and the city cars read as city cars, but they all share the same collision
 * footprint. The footprint is taken from the SCALED body bounds, so it
 * tracks the visible vehicle rather than a hand-picked constant.
 *
 * Loading is done with `LoadAssetContainerAsync`, which leaves the asset
 * parked in a container that can be `instantiateModelsToScene()`'d any
 * number of times - one per traffic vehicle on the road.
 */

/**
 * The full catalogue. `targetLength` was chosen by eye for each family so a
 * pickup is visibly larger than a muscle car and an ambulance is the biggest
 * thing on the road, but everything still fits inside a single lane.
 */
export const VEHICLE_CATALOG = [
  { file: "mini-car.glb",       label: "Mini Car",    targetLength: 3.4, colors: 6 },
  { file: "mini-car2.glb",      label: "Mini Car GT", targetLength: 3.4, colors: 6 },
  { file: "muscle-car.glb",     label: "Muscle Car",  targetLength: 4.1, colors: 6 },
  { file: "muscle-car2.glb",    label: "Muscle Car B",targetLength: 4.1, colors: 6 },
  { file: "muscle-car3.glb",    label: "Muscle Car C",targetLength: 4.1, colors: 6 },
  { file: "suv.glb",            label: "SUV",         targetLength: 4.4, colors: 6 },
  { file: "minivan.glb",        label: "Minivan",     targetLength: 4.4, colors: 6 },
  { file: "minivan2.glb",       label: "Minivan B",   targetLength: 4.4, colors: 6 },
  { file: "pickup.glb",        label: "Pickup",      targetLength: 5.0, colors: 6 },
  { file: "pickup2.glb",       label: "Pickup B",    targetLength: 5.0, colors: 6 },
  { file: "ambulance-truck.glb", label: "Ambulance", targetLength: 5.6, colors: 3 },
  { file: "iceCream-truck.glb", label: "Ice Cream", targetLength: 5.6, colors: 3 },
  { file: "post-truck.glb",     label: "Post Truck",targetLength: 5.6, colors: 3 },
];

/**
 * The RACE car catalogue: every car in `public/assets/` that is NOT the player
 * car and NOT a traffic model.
 *
 * `public/assets/vehicles/` is the ambient traffic fleet and is deliberately
 * not used here, and `car1.glb` is the player's own car, which a race must
 * never field as an opponent. What is left is the eight cars below.
 *
 * They come from two different authoring conventions (see RaceRig), so nothing
 * here may assume a wheel name or an axis: `targetLength` is the only thing
 * set by hand, and RaceRig measures everything else from the loaded model.
 *
 * `targetLength` normalises the field to the same envelope as the player's car
 * (4.0-4.7 m long, under 2.0 m wide). That is not cosmetic: the race lane is
 * validated for the player's footprint, so a 6 m monster truck left at its
 * authored size would scrape kerbs the rest of the field clears. Scaling the
 * models keeps every rival on the racing line.
 */
export const RACE_CAR_CATALOG = [
  { file: "Sport Car_39.glb",   label: "Sport Car 39",  targetLength: 4.5, color: [0.86, 0.13, 0.16], price: 28000 },
  { file: "N_Muscle Car_10.glb",label: "Muscle Car 10", targetLength: 4.5, color: [0.10, 0.28, 0.72], price: 22000 },
  { file: "Classic Car_9.glb",  label: "Classic Car 9", targetLength: 4.6, color: [0.93, 0.82, 0.18], price: 18500 },
  { file: "Hatchback Car_15.glb", label: "Hatchback 15", targetLength: 4.2, color: [0.20, 0.62, 0.34], price: 12000 },
  { file: "Monster Truck_15.glb", label: "Monster Truck", targetLength: 4.7, color: [0.92, 0.45, 0.08], price: 35000 },
  { file: "car4.glb",           label: "Rally Hilux",    targetLength: 4.4, color: [0.55, 0.58, 0.62], price: 24000 },
  { file: "car2.glb",           label: "Landy",         targetLength: 4.4, color: [0.30, 0.55, 0.45], price: 16000 },
  { file: "car3.glb",           label: "Beetle",        targetLength: 4.0, color: [0.78, 0.78, 0.82], price: 9500 },
];

const SITE_ASSETS = "assets/";
const VEHICLES_DIR = "assets/vehicles/";

/**
 * Loads every rival car model from `public/assets/`.
 *
 * Unlike the traffic loader this does NOT measure the model: the two authoring
 * conventions in play disagree about wheel names, axes and scale, so all of
 * that is measured once, in `RaceRig`, from the loaded model itself. Here we
 * only parse the GLB into a reusable container.
 */
export async function loadRaceCarAssets(scene, { onProgress = null } = {}) {
  const out = [];
  for (let i = 0; i < RACE_CAR_CATALOG.length; i++) {
    const spec = RACE_CAR_CATALOG[i];
    if (onProgress) onProgress(i, RACE_CAR_CATALOG.length, spec.label);
    const container = await LoadAssetContainerAsync(
      SITE_ASSETS + encodeURIComponent(spec.file),
      scene,
      { pluginExtension: ".glb" },
    );
    const root = (container.rootNodes ?? [])[0];
    if (!root) {
      console.warn(`RaceAssets: ${spec.file} produced no root node, skipping`);
      continue;
    }
    out.push({ index: i, spec, container, targetLength: spec.targetLength });
  }
  if (!out.length) throw new Error("RaceAssets: no rival car models could be loaded");
  return out;
}

/**
 * Loads every model in the catalogue. Returns one entry per model with the
 * asset container and the dimensions measured from its root mesh, ready to
 * hand to TrafficRig.
 *
 * Loading happens once, at startup; afterwards TrafficSystem picks a model
 * per spawn by index.
 */
export async function loadVehicleAssets(scene, { onProgress = null } = {}) {
  const out = [];
  for (let i = 0; i < VEHICLE_CATALOG.length; i++) {
    const spec = VEHICLE_CATALOG[i];
    const url = VEHICLES_DIR + spec.file;
    if (onProgress) onProgress(i, VEHICLE_CATALOG.length, spec.label);

    // `LoadAssetContainerAsync` parses the GLB without adding it to the
    // scene. The container is kept and re-instantiated per traffic vehicle,
    // which is cheaper than re-parsing the file every time.
    const container = await LoadAssetContainerAsync(url, scene, {
      pluginExtension: ".glb",
    });
    // Root node: the first root node the loader created. The vehicles have
    // a single root per file (the body mesh that also parents the wheels).
    const rootNodes = container.rootNodes ?? [];
    const root = rootNodes[0];
    if (!root) {
      console.warn(`VehicleAssets: ${spec.file} produced no root node, skipping`);
      continue;
    }

    const dims = measureVehicle(root);
    if (!dims) {
      console.warn(`VehicleAssets: ${spec.file} has no measurable wheels, skipping`);
      continue;
    }

    // Per-vehicle scale that brings the body's longest horizontal axis up
    // to the target length. Vertical is scaled the same so the wheels stay
    // round. Scale is applied by the TrafficRig at construction, not here,
    // because the asset container is shared and we never want to mutate it.
    const targetLen = spec.targetLength ?? 4.2;
    const scale = targetLen / Math.max(dims.length, 0.5);

    out.push({
      index: i,
      spec,
      container,
      // Pre-scaled body measurements, used by TrafficRig at construct time
      // to compute its own post-scale footprint and forward axis.
      raw: dims,
      scale,
      // Scaled dimensions, computed here so the system planner can pick
      // diverse routes without re-measuring.
      scaled: {
        length: dims.length * scale,
        width: dims.width * scale,
        height: dims.height * scale,
        wheelBase: dims.wheelBase * scale,
        track: dims.track * scale,
        wheelRadius: dims.wheelRadius * scale,
        clearance: 0.26, // assumed; matches the player car
      },
    });
  }
  if (!out.length) throw new Error("VehicleAssets: no vehicle models could be loaded");
  return out;
}

/**
 * Measures a vehicle's body and wheel layout directly from the loaded root.
 *
 * Forward is derived from the wheel names (FL/FR are front, BL/BR are rear),
 * not from the body axis: the assets are authored with X as the long axis,
 * but the game's convention is +Z forward, so the rig will rotate to match.
 *
 * Returns dimensions in the asset's LOCAL space; the TrafficRig scales and
 * re-orients them when it builds its own model.
 */
export function measureVehicle(root) {
  // Force the world matrix to update once so bounding info is current.
  root.computeWorldMatrix(true);
  for (const m of root.getChildMeshes(false)) m.computeWorldMatrix(true);

  const meshes = [...root.getChildMeshes(false)];
  if (root.getClassName && root.getClassName() === "Mesh") meshes.push(root);

  // Wheels: any mesh whose name matches the TireBL/BR/FL/FR convention used
  // by every model in the vehicles folder. The SUV's rear tyres carry a
  // numeric suffix (BL1, BL2, BR1, BR2) - the regex keeps the family letter
  // and ignores the digit so the rig sees four logical wheels.
  const wheelRe = /_Tire([FB])([LR])\d*$/i;
  const wheels = [];
  for (const m of meshes) {
    const match = wheelRe.exec(m.name);
    if (!match) continue;
    const box = m.getBoundingInfo().boundingBox;
    const center = box.centerWorld.clone();
    const size = box.extendSizeWorld.scale(2);
    wheels.push({
      mesh: m,
      name: m.name,
      front: match[1].toUpperCase() === "F",
      left: match[2].toUpperCase() === "L",
      center,
      // A wheel is roughly cylindrical; the smallest of its three box
      // extents is the tyre diameter (axle axis is the thin one).
      radius: Math.max(size.x, size.y, size.z) / 2,
    });
  }
  if (wheels.length < 4) return null;

  // Average the front and rear axles (handles the SUV's doubled rear
  // tyres without special-casing it elsewhere).
  const avg = (list, key) =>
    list.reduce((s, w) => s + w[key], 0) / (list.length || 1);
  const fronts = wheels.filter((w) => w.front);
  const rears = wheels.filter((w) => !w.front);
  const lefts = wheels.filter((w) => w.left);
  const rights = wheels.filter((w) => !w.left);

  const frontMid = avg(fronts, "x");
  const frontMidZ = avg(fronts, "z");
  const rearMid = avg(rears, "x");
  const rearMidZ = avg(rears, "z");
  const leftMid = avg(lefts, "x");
  const rightMid = avg(rights, "x");

  // Forward direction in the asset's local space: from rear axle toward
  // front axle. The Y component is dropped because some assets tilt the
  // wheels slightly off-plane (suspension pre-load) and that should not
  // tilt the forward axis.
  let fwdX = frontMid - rearMid;
  let fwdZ = frontMidZ - rearMidZ;
  let fwdY = 0;
  const len = Math.hypot(fwdX, fwdY, fwdZ) || 1;
  fwdX /= len; fwdZ /= len;

  const wheelBase = Math.hypot(frontMid - rearMid, frontMidZ - rearMidZ);
  const track = Math.hypot(leftMid - rightMid, 0);
  const wheelRadius = wheels.reduce((s, w) => s + w.radius, 0) / wheels.length;

  // Body bounds: every mesh that is NOT a wheel contributes. This is the
  // chassis box the rig uses for collision.
  let minX = Infinity, maxX = -Infinity;
  let minY = Infinity, maxY = -Infinity;
  let minZ = Infinity, maxZ = -Infinity;
  for (const m of meshes) {
    if (wheelRe.test(m.name)) continue;
    const bb = m.getBoundingInfo().boundingBox;
    const lo = bb.minimumWorld;
    const hi = bb.maximumWorld;
    if (lo.x < minX) minX = lo.x;
    if (lo.y < minY) minY = lo.y;
    if (lo.z < minZ) minZ = lo.z;
    if (hi.x > maxX) maxX = hi.x;
    if (hi.y > maxY) maxY = hi.y;
    if (hi.z > maxZ) maxZ = hi.z;
  }
  if (!Number.isFinite(minX)) return null;
  const length = Math.max(maxX - minX, maxZ - minZ);
  const width = Math.min(maxX - minX, maxZ - minZ);
  const height = Math.max(maxY - minY, 0.5);

  return {
    wheels,
    wheelBase,
    track,
    wheelRadius,
    length,
    width,
    height,
    // Body bounds in the asset's local space, kept so the rig can re-project
    // them after the yaw fix and the scale.
    body: { minX, minY, minZ, maxX, maxY, maxZ },
    forward: { x: fwdX, z: fwdZ },
  };
}
