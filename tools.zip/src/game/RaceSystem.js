import {
  Color3,
  DynamicTexture,
  Mesh,
  MeshBuilder,
  StandardMaterial,
  Texture,
  Vector3,
  Vector4,
} from "@babylonjs/core";
import { CAR, clamp } from "./driving.js";
import { RaceRig } from "./RaceRig.js";
import { RaceDriver } from "./RaceDriver.js";
import { RaceProgress } from "./raceProgress.js";
import { buildRaceTrack } from "./raceTrack.js";
import { resolveVehicleCollision } from "./vehicleCollision.js";
import { AI_IMPACT_SPEED_KMH } from "./destructibles.js";
import { impactSeverity } from "./carDamage.js";
import { TIME_SPEEDS, HIT_TIERS } from "../data/raceEvents.js";

/**
 * The one race the game ships, as a state machine around the player.
 *
 *   idle      the player is out driving. A start zone sits on the circuit.
 *   armed     the player is inside the zone; the prompt offers SPACE / START.
 *   countdown the field is aligned on the starting grid and held for 3-2-1-GO.
 *   racing    everyone drives; checkpoints, laps and the clock are live.
 *   finished  the player has crossed the line; the leaderboard is up while the
 *             rivals still running finish behind them.
 *
 * The rivals are excluded from the player's car model by construction: they are
 * built from `RACE_CAR_CATALOG` (everything in `public/assets/` that is NOT
 * `car1.glb` and NOT a `vehicles/` traffic model), and the catalogue check in
 * `tools/race-car-check.mjs` fails if that ever stops being true.
 *
 * Everything on screen - the floating event board, the checkpoint gates - is
 * built here out of Babylon primitives. That matters beyond looks: the map's
 * collision bake has already run by the time these exist, so none of them can
 * ever be baked into the collision grid and block a car.
 */

export const RACE_STATE = {
  IDLE: "idle",
  ARMED: "armed",
  INTRO: "intro",
  COUNTDOWN: "countdown",
  RACING: "racing",
  FINISHED: "finished",
};

/** How close the player must be to the start line to arm the event, metres. */
const START_RADIUS = 12;
/** The start offer needs the player nearly stopped under this, km/h. */
const START_SPEED_KMH = 10;
/** Countdown length: 3, 2, 1, GO. */
const COUNTDOWN_SECONDS = 3.9;
/** The "GO!" flash lingers this long after the lights go out. */
const GO_FLASH = 0.9;
/** Hard cap on the field, player included. */
export const MAX_FIELD = 6;
/**
 * Race-intro cinematic length, seconds: event card, staggered grid reveal
 * under a top camera, then a sweep down to the chase cam and the countdown.
 */
export const INTRO_SECONDS = 5.0;
/** Event card holds fully until this time, then fades out. */
const INTRO_CARD_HOLD = 1.6;
const INTRO_CARD_OUT = 2.4;
/** Camera blends top-down -> chase across this window. */
const INTRO_CAM_START = 1.2;
const INTRO_CAM_END = 4.6;
/** Stagger between cars fading in on the grid, seconds. */
const REVEAL_GAP = 0.18;
const REVEAL_DUR = 0.5;
/** "YOU BEAT THE X" panel window after the finish, seconds. */
const BEAT_IN = 0.4;
const BEAT_OUT = 4.0;
/** Results screen (world tilt + payouts) starts here. */
const RESULTS_IN = 4.0;
/** Rollout: cars start this far behind their slots and roll in, metres. */
const ROLLOUT_BACK = 8;
/** Rollout runs across this intro window (arrives before the countdown). */
const ROLLOUT_START = 0.3;
const ROLLOUT_END = 4.3;
/**
 * The floating event board appears inside this distance, metres. Up close it
 * sells the event (name / prize / difficulty); from far away the minimap
 * diamond is the signpost, so the board stays hidden.
 */
const BOARD_SHOW_RANGE = 320;
/** Event board size, world metres, and lift above the start line. */
const BOARD_W = 12;
const BOARD_H = 4.5;
const BOARD_LIFT = 6.5;
/** Event names, picked deterministically from the circuit id. */
const EVENT_NAMES = [
  "THE FUGITIVE",
  "REDLINE RUSH",
  "OVERDRIVE",
  "NIGHT MARKET",
  "CIRCUIT BREAK",
  "DOWNTOWN RUSH",
];
/**
 * Distance from the player past which a finished rival despawns, metres.
 * Finished cars run a cooldown lap first and vanish only once the player
 * can't see them — so nobody is left parked on the finish line, and nobody
 * pops out of existence on screen.
 */
const RIVAL_DESPAWN_DISTANCE = 150;
/** Rival pace by grid position — a tight NFS-style pack, nobody cruising. */
const RIVAL_PACE = [1.0, 0.97, 0.94, 0.91, 0.88];

const COLORS = {
  /** The arch band: white at every point of every gate, in every state. */
  arch: new Color3(1.0, 1.0, 1.0),
};

/**
 * Corner chevrons: the light blue boards that stand on the OUTSIDE of the
 * circuit's bends and point the way through them.
 */
/** The path is walked at this step while hunting for bends, metres. */
const CORNER_STEP = 3;
/** Heading change is summed across this many metres either side of a sample. */
const CORNER_WINDOW = 14;
/** A bend must turn at least this much across that window to earn boards, rad. */
const CORNER_MIN_TURN = 0.55;
/** Two bends closer together than this are one corner; the sharper one wins. */
const CORNER_MIN_GAP = 60;
/** Boards strung along each corner, their arc gap, and the most corners marked. */
const CHEVRON_COUNT = 7;
const CHEVRON_GAP = 3.5;
const CORNER_MAX = 12;
/**
 * Board size, metres, and its centre as a fraction of its height above road.
 * Kept broad rather than slender: a wide board carries a big, obvious chevron,
 * where a narrow one reads as a tall post with a tick painted on it.
 */
const CHEVRON_W = 2.6;
const CHEVRON_H = 3.2;
const CHEVRON_LIFT = 0.62;
/**
 * The boards' flat colour: one solid arrow, no outline and no second tone. A
 * light, vivid blue - the game's own signage colour, so the boards read as part
 * of the circuit rather than as something imported from another game.
 */
const CHEVRON_COLOR = "#2f9bff";
/**
 * Luminance lift applied over a plain white emissive: 1 is exactly the texture
 * colour, above 1 drives the arrow toward a lit white core so it reads as a
 * glowing sign instead of a flat decal. Fixed at build time, so it never costs
 * a shader recompile.
 */
const CHEVRON_EMISSIVE_GAIN = 1.5;
/**
 * Texture canvas, and the pad kept clear at every edge for the glow to sit in.
 * W/H must stay exactly equal to CHEVRON_W/CHEVRON_H (see _buildChevrons), or
 * the arrow lands stretched on the board.
 */
const CHEVRON_TEX_W = 325;
const CHEVRON_TEX_H = 400;
const CHEVRON_TEX_PAD = 0.18;
/**
 * The baked glow: the arrow re-filled as it grows outward, each ring fainter
 * than the last. Outermost first, as [scale about the centre, alpha]. The
 * outermost ring is deliberately almost invisible so its hard edge cannot be
 * seen, and the whole set is sized to stay inside the pad above - the glow must
 * not be cropped any more than the arrow may be.
 */
const CHEVRON_GLOW = [
  [1.34, 0.04],
  [1.28, 0.06],
  [1.22, 0.09],
  [1.17, 0.12],
  [1.12, 0.16],
  [1.07, 0.22],
  [1.03, 0.3],
];
/**
 * Face-UV rectangles for the two-sided boards: PLAIN shows the arrow exactly as
 * painted, FLIP mirrors it left-to-right. Each face of a board is given the
 * opposite one, so the chevron reads the SAME way from behind as from the
 * front. Without that, a board seen from its back is a mirror image and the
 * arrow appears to point the opposite way once the car has gone past it and
 * turned around.
 */
const CHEVRON_UV_PLAIN = new Vector4(0, 0, 1, 1);
const CHEVRON_UV_FLIP = new Vector4(1, 0, 0, 1);
/**
 * The corner boards' "running chase": a crest sweeps the row at this many
 * boards per second, in the direction the field drives, one crest every
 * CHEVRON_WAVE_PITCH boards. The wave is carried entirely by `alpha` - the
 * colour and emissive setup are written once and never touched, so the shader
 * is never recompiled while racing - and each board never leaves the spot it
 * was built on.
 */
const CHEVRON_ANIM_SPEED = 3.0;
const CHEVRON_WAVE_PITCH = 3;
/** A board fades down to this between waves: dimmed, but never invisible. */
const CHEVRON_ANIM_MIN_ALPHA = 0.35;
/** How far clear of a gate the car must be before a passed checkpoint drops. */
const GATE_HIDE_BEHIND = 10;
/**
 * How far behind the car a corner board may stand before it drops: boards
 * just passed stay up briefly so they don't blink out at the edge of vision.
 * Boards ahead are instead bounded by the NEXT checkpoint (see
 * _applyChevronVisibility) - only the road to the next gate stays marked.
 */
const CHEVRON_KEEP_BEHIND = 15;
/** Arch band radial half-width, metres: a thin flat band, not a round tube. */
const ARCH_BAND = 0.15;
const CHECKPOINT_BAND = 0.1;
/** Sweep resolution of the arch ribbon. */
const ARCH_STEPS = 30;
/**
 * Clearance (m) between the band and the outer edge of the chevron row that
 * runs inside it: the row sits ON the band's inner line, not floating away
 * from it. Because it is measured to the icon's outer edge, a thicker chevron
 * grows inward toward the road instead of drifting off the arc.
 */
const ARCH_CHEVRON_CLEARANCE = 0.06;
/** Arc spacing (m) of those inside chevrons: fewer, larger, evenly gapped. */
const ARCH_CHEVRON_PITCH = 1.15;
/** Fraction of the half-circle the inside chevrons run over. */
const ARCH_CHEVRON_SPAN = 0.94;

export class RaceSystem {
  /**
   * @param scene      Babylon scene
   * @param opts.collision must be set - the circuit is built from the baked map
   * @param opts.traffic   TrafficSystem, so rivals see ambient cars
   * @param opts.player    the player vehicle
   * @param opts.assets    rival assets from `loadRaceCarAssets`
   * @param opts.anchor    {x,z} paddock: the circuit is chosen near it and the
   *                       start line is the point of it closest to it
   * @param opts.fieldSize total cars on the grid, the player included (max 6)
   */
  constructor(scene, { collision, traffic = null, player, assets = [], anchor = null, fieldSize = MAX_FIELD, destruction = null } = {}) {
    if (!collision) throw new Error("RaceSystem requires the collision model");
    if (!player) throw new Error("RaceSystem requires the player vehicle");
    if (!assets.length) throw new Error("RaceSystem requires rival car assets");

    this.scene = scene;
    this.collision = collision;
    this.traffic = traffic;
    this.player = player;
    // Rival car assets, kept so loadEvent() can rebuild the field for a new event.
    this.assets = assets;
    // Roadside-prop system. Each rival's `onImpact` is wired to it (see
    // _installTrack), so a sign a rival hits breaks the way it does for the
    // player - minus the speed penalty (see RaceDriver's map-collision block).
    this.destruction = destruction;

    this._resetRaceState();

    // --- circuit + field --------------------------------------------------
    // Initial circuit: the legacy auto-selected loop near the paddock, used as
    // the fallback event. RaceEventManager swaps in authored node-path tracks
    // at runtime via loadEvent().
    const fieldSizeClamped = clamp(Math.round(fieldSize), 2, MAX_FIELD);
    const initialTrack = buildRaceTrack(collision, traffic?.allRoutes ?? [], {
      anchor: anchor ?? { x: player.state.x, z: player.state.z },
      fieldSize: fieldSizeClamped,
    });
    this._installTrack(null, initialTrack);
  }

  /**
   * Reset the per-race session/state-machine scalars (nothing track-derived).
   * Run on construction and again on every loadEvent so a stale state, finish
   * cinematic or results list can't bleed into the next event.
   */
  _resetRaceState() {
    this.state = RACE_STATE.IDLE;
    this.time = 0; // race clock, seconds, since the lights went out
    this.countdown = 0;
    this.goFlash = 0;
    this.startRequested = false;
    this.wrongWay = 0;
    this.message = "";
    this.results = [];
    this.playerPosition = null;
    /** Intro cinematic clock, seconds since START was hit. */
    this.introT = 0;
    /** Grid-slot-ordered rigs for the staggered reveal ({ rig }). */
    this._reveal = [];
    /** While true the start line will not re-arm (set on CONTINUE). */
    this._rearmLocked = false;
    /** Finish cinematic: beat panel, orbit and results play while true. */
    this.cineActive = false;
    /** Finish cinematic clock, seconds since the player crossed the line. */
    this.finishT = 0;
    /** Orbit start angle, captured on the first cinematic frame. */
    this._finishA0 = null;
    /** Seconds since the player finished, used to time the course reopening. */
    this._holdTimer = 0;
    /** Seconds the probe autopilot has been pinned, for its own unsticking. */
    this._autoStuck = 0;
  }

  /**
   * Build everything that depends on the circuit: the AI field, progress
   * trackers, the event descriptor, the world markers and the floating board.
   * `def` is the authored event (null for the legacy auto circuit); `track` is
   * the already-built track object. Reused by loadEvent for every event.
   */
  _installTrack(def, track) {
    this.def = def;
    this.track = track;
    // Legacy auto circuit sets its own lap count by length; an authored track
    // already carries def.laps from the builder.
    if (!def) this.track.laps = this.track.length >= 850 ? 1 : 2;
    // Traffic is held off an authored circuit unless the event wants it on
    // (the NO-COLLISION challenge); the legacy race always holds it.
    this._holdTraffic = def ? !def.traffic : true;

    this.field = [];
    this.rivals = [];
    const rivalCount = Math.min(this.track.fieldSize - 1, this.assets.length);

    // Scale difficulty dynamically with progression order (10..300):
    // Early events (order 10-60, Level 1-6) are eased up with gentle opponents
    // (pace ~0.70-0.76, cruise ~26-30 m/s ~95-110 km/h) so player can easily pass and win.
    // Higher levels gradually ramp up to tough Level 30 rivals (pace ~1.02, cruise ~48 m/s ~175 km/h).
    const order = def?.order ?? 10;
    const progressTier = clamp((order - 10) / 290, 0, 1);
    const basePace = 0.72 + progressTier * 0.30;
    const baseCruise = 26 + progressTier * 16;
    const rivalSpread = [0.03, 0.00, -0.03, -0.06, -0.09];

    for (let i = 0; i < rivalCount; i++) {
      const asset = this.assets[i % this.assets.length];
      const label = `rival${i}`;
      const rig = new RaceRig(this.scene, asset, label);
      const spec = asset.spec ?? {};
      if (spec.color) rig.setColor(new Color3(spec.color[0], spec.color[1], spec.color[2]));
      const pace = clamp(basePace + (rivalSpread[i % rivalSpread.length] || 0), 0.55, 1.05);
      const driver = new RaceDriver(rig, this.track, {
        name: spec.label ?? `Rival ${i + 1}`,
        label,
        pace,
        cruiseSpeed: baseCruise + pace * 8,
        collision: this.collision,
        player: this.player,
      });
      // Roadside objects: AI racing cars pass through without collision.
      // Prop destruction is reserved exclusively for the player car.
      driver.paintSeed = i;
      this.rivals.push(driver);
      this.field.push(driver);
    }

    // The player starts midfield (a race, not a time trial) - except a solo
    // event (TIME / NO-COLLISION) grids only the player.
    this.playerSlot = this.track.fieldSize <= 1 ? 0 : Math.floor(this.track.fieldSize / 2);
    this.rivalSlots = [];
    for (let s = 0; s < this.track.fieldSize; s++) {
      if (s !== this.playerSlot) this.rivalSlots.push(s);
    }

    this.playerProgress = new RaceProgress(this.track);
    this.event = makeRaceEvent(this.track, def);

    this._chevronT = 0;
    this.markers = this._buildMarkers();
    this.eventBoard = this._buildEventBoard();
    this._placeFieldOnGrid();
    this._hideField();
    this._applyGateMaterials();
    this._computeStandings();

    if (this.traffic) this.traffic.extraVehicles = [];
  }

  /**
   * Swap the active event+track at runtime (RaceEventManager calls this). Forced
   * to IDLE first so no in-flight intro/finish references dangle, then the old
   * field + markers are disposed and the new circuit is installed clean.
   */
  loadEvent(def, track) {
    this.state = RACE_STATE.IDLE;
    this._disposeMarkers();
    this._disposeField();
    this._resetRaceState();
    this._installTrack(def, track);
  }

  /** Dispose the current circuit's meshes AND their shared materials/textures
   *  (which mesh.dispose() does not free), so repeated loads don't leak. */
  _disposeMarkers() {
    const meshes = new Set();
    const add = (m) => m && meshes.add(m);
    if (this.markers) {
      for (const g of this.markers.gates ?? []) for (const m of g.meshes ?? []) add(m);
      for (const m of this.markers.chevrons ?? []) add(m);
      add(this.markers.finishBanner?.plane);
    }
    add(this.eventBoard?.board);
    const mats = new Set();
    const texs = new Set();
    for (const m of meshes) {
      const mat = m.material;
      if (mat) {
        mats.add(mat);
        for (const t of mat.getActiveTextures?.() ?? []) texs.add(t);
      }
    }
    // Shared handles the meshes may not surface.
    if (this.markers?.finishBanner?.mat) mats.add(this.markers.finishBanner.mat);
    if (this.markers?.finishBanner?.tex) texs.add(this.markers.finishBanner.tex);
    for (const p of this.markers?.chevronPulses ?? []) if (p?.mat) mats.add(p.mat);
    for (const m of meshes) try { m.dispose(false, false); } catch { /* gone */ }
    for (const mat of mats) try { mat.dispose(); } catch { /* gone */ }
    for (const t of texs) try { t.dispose(); } catch { /* gone */ }
    this.markers = null;
    this.eventBoard = null;
  }

  /** Dispose the current AI field (rival rigs) and detach it from traffic. */
  _disposeField() {
    if (this.traffic) this.traffic.extraVehicles = [];
    for (const d of this.rivals ?? []) {
      try { (d.rig ?? d._rig)?.dispose?.(); } catch { /* gone */ }
      try { d.dispose?.(); } catch { /* no dispose */ }
    }
    this.rivals = [];
    this.field = [];
    this._reveal = [];
  }

  // ---------------------------------------------------------------- markers

  /** Checkpoint gates for the circuit. Built once; never baked. */
  _buildMarkers() {
    const scene = this.scene;
    const track = this.track;
    const out = { gates: [], chevrons: [], chevronS: [], chevronPulses: [], finishBanner: null };

    const material = (name, color, alpha = 1) => {
      const m = new StandardMaterial(name, scene);
      m.emissiveColor = color;
      m.diffuseColor = Color3.Black();
      m.specularColor = Color3.Black();
      m.disableLighting = true;
      m.alpha = alpha;
      // Every gate is a thin structure the field drives THROUGH: the plates
      // must read from the arriving side and never vanish when a car clips a
      // post, so nothing here culls back faces.
      m.backFaceCulling = false;
      return m;
    };

    // One shared decal material for the chevron rows that run inside the arches.
    const archChevronMat = this._buildArchChevronMaterial();
    // The band itself is white everywhere, in every state - it is structure,
    // not a status light.
    const archMat = material("race_gate_arch_mat", COLORS.arch, 1);
    // Every arch is built at the WIDEST span the circuit offers, so the gates
    // read as one repeated structure instead of a mix of sizes. Each gate's own
    // measured half-width is deliberately not used: that is what made a wide
    // road's gate tower over a narrow one's.
    const archHalf = Math.max(...track.gates.map((g) => g.halfWidth));

    // NOTE: the old start-line clutter (ground pad, zone ring, beacon pillar)
    // is gone on purpose — the floating event board owns the spot now, and
    // the minimap diamond guides from far away. What stands on the circuit is
    // the checkpoint arches, plus the chevron boards on its corners.

    // --- checkpoint arches -------------------------------------------------
    // Each gate is the reference-shot arch: a flat white BAND (not a round
    // tube) swept over a half-circle that springs from the ground at both road
    // edges and crowns the road, with a chevron row inside it. The start/finish
    // arch alone carries a sign plate, lifted clear above the crown.
    //
    // The band is generated in WORLD space from the gate's own right/heading
    // frame, so it stands square across the road at any heading, and the two
    // ribbon edges are offset along the sweep's in-plane normal so the band
    // keeps a constant width from the ground to the apex.
    for (const gate of track.gates) {
      const isFinish = gate.isFinish;
      const group = [];
      // A true half-circle at the shared span.
      const rise = archHalf;
      const band = isFinish ? ARCH_BAND : CHECKPOINT_BAND;

      const inner = [];
      const outer = [];
      for (let i = 0; i <= ARCH_STEPS; i++) {
        const a = (Math.PI * i) / ARCH_STEPS;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        const cx = gate.x + gate.rightX * ca * archHalf;
        const cy = gate.y + sa * rise;
        const cz = gate.z + gate.rightZ * ca * archHalf;
        // In-plane normal of the sweep: (rise*cos, archHalf*sin) in
        // (lateral, up) - the direction the band is wide along.
        const nlen = Math.hypot(rise * ca, archHalf * sa) || 1;
        const nx = (rise * ca) / nlen;
        const ny = (archHalf * sa) / nlen;
        inner.push(
          new Vector3(
            cx + gate.rightX * nx * band,
            cy + ny * band,
            cz + gate.rightZ * nx * band,
          ),
        );
        outer.push(
          new Vector3(
            cx - gate.rightX * nx * band,
            cy - ny * band,
            cz - gate.rightZ * nx * band,
          ),
        );
      }
      const arch = MeshBuilder.CreateRibbon(
        `race_gate_${gate.index}_arch`,
        { pathArray: [inner, outer] },
        scene,
      );
      arch.material = archMat;
      arch.isPickable = false;
      arch.freezeWorldMatrix();
      group.push(arch);

      // The chevron row that feathers the INSIDE of the arch, each decal aimed
      // radially at the road below (see _buildGateChevrons).
      for (const icon of this._buildGateChevrons(gate, archHalf, band, archChevronMat)) group.push(icon);

      // The sign plate, mounted ABOVE the crown with a gap so it never
      // overlaps or merges with the band, and turned back down the road so the
      // field reads it on the way in. ONLY the start/finish gate has one: the
      // checkpoints are bare arches, because a plate on them has nothing to say.
      if (isFinish) {
        const plateW = Math.min(archHalf * 1.35, 5.8);
        const plateH = clamp(plateW * 0.3, 0.95, 1.7);
        const plate = this._buildFinishBanner(gate, plateW, plateH, gate.y + rise + plateH / 2 + 0.4);
        group.push(plate.plane);
        out.finishBanner = plate;
      }

      const entry = { index: gate.index, isFinish, meshes: group };
      out.gates.push(entry);
      // Checkpoints stay invisible until the race runs: pre-race the event is
      // the floating board alone, with no gates standing on the circuit.
      for (const m of group) m.isVisible = false;
    }

    // --- corner chevrons ---------------------------------------------------
    const chevrons = this._buildChevrons();
    out.chevrons = chevrons.meshes;
    out.chevronS = chevrons.arcS;
    out.chevronPulses = chevrons.pulses;
    for (const c of out.chevrons) c.isVisible = false;
    return out;
  }

  /**
   * The start/finish arch's text plate. Backed by a DynamicTexture so the one
   * mesh can read as the event's own plate at the start and then, only once
   * the race is actually winnable, as "FINISH" (see _updateFinishBanner).
   */
  _buildFinishBanner(gate, width, height, y) {
    const W = 640;
    // Match the texture to the plate's real aspect, so the lettering is not
    // stretched when the gate is wide.
    const H = Math.max(96, Math.round((W * height) / width));
    const tex = new DynamicTexture("race_finish_banner_tex", { width: W, height: H }, this.scene, true);
    tex.hasAlpha = true;
    const mat = new StandardMaterial("race_finish_plate_mat", this.scene);
    mat.diffuseTexture = tex;
    mat.emissiveTexture = tex;
    mat.emissiveColor = new Color3(0.74, 0.8, 0.88);
    mat.diffuseColor = new Color3(0, 0, 0);
    mat.specularColor = Color3.Black();
    mat.disableLighting = true;
    mat.backFaceCulling = false;
    mat.useAlphaFromDiffuseTexture = true;
    const plane = MeshBuilder.CreatePlane("race_finish_plate", { width, height }, this.scene);
    plane.position.set(gate.x, y, gate.z);
    // A plane's front face looks down -Z; turning it to the gate heading aims
    // that face back at the cars arriving down the road.
    plane.rotation.y = gate.heading;
    plane.material = mat;
    plane.isPickable = false;
    plane.freezeWorldMatrix();
    const banner = { plane, mat, tex, W, H, live: null };
    this._paintFinishBanner(banner, false);
    return banner;
  }

  /**
   * Paint the plate: the event's name while the race is still running, and
   * "FINISH" once the archetype is earned. The lettering is auto-fitted to the
   * panel, so a long event name shrinks instead of spilling off the board.
   * Called on every state flip only.
   */
  _paintFinishBanner(b, live) {
    b.live = live;
    const g = b.tex.getContext();
    const W = b.W;
    const H = b.H;
    g.clearRect(0, 0, W, H);

    // A near-opaque board with the racing cut corner, so it reads as its own
    // object rather than blending into the arch behind it.
    const px = 6;
    const py = 6;
    const pw = W - 12;
    const ph = H - 12;
    const cut = 26;
    g.beginPath();
    g.moveTo(px + cut, py);
    g.lineTo(px + pw, py);
    g.lineTo(px + pw, py + ph - cut);
    g.lineTo(px + pw - cut, py + ph);
    g.lineTo(px, py + ph);
    g.lineTo(px, py + cut);
    g.closePath();
    g.fillStyle = live ? "rgba(8,15,23,0.97)" : "rgba(8,15,23,0.92)";
    g.fill();
    g.lineWidth = 4;
    g.strokeStyle = "#e8eef5";
    g.stroke();
    // Trim strip along the top edge.
    g.fillStyle = "#ff7a18";
    g.fillRect(px + cut, py, pw - cut, Math.max(6, H * 0.06));

    const text = live ? "FINISH" : this.event?.name ?? "START";
    const maxW = pw - 48;
    const weight = live ? 900 : 800;
    let size = Math.round(H * (live ? 0.58 : 0.5));
    g.font = `italic ${weight} ${size}px Arial, sans-serif`;
    while (size > 16 && g.measureText(text).width > maxW) {
      size -= 2;
      g.font = `italic ${weight} ${size}px Arial, sans-serif`;
    }
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillStyle = "#ffffff";
    g.fillText(text, W / 2, py + ph / 2 + H * 0.06);
    if (live) {
      g.fillStyle = "#ffd60a";
      g.fillRect(W / 2 - W * 0.17, H - Math.max(10, H * 0.17), W * 0.34, Math.max(5, H * 0.05));
    }
    b.tex.update();
  }

  /**
   * Shared blue "v" decal used by the chevron row inside every arch.
   *
   * One SOLID blue stroke - no rim, no spine - drawn as a wide, open V rather
   * than a tall squeezed one, so on screen it reads as an arrow flat against
   * the arc. Two details keep the shape intact rather than clipped:
   *
   *   - a ROUND join, because at this opening angle a mitered tip would throw
   *     a spike roughly two stroke-widths past the apex and off the texture;
   *   - padding all round, sized from the stroke, so however fat the stroke
   *     gets no part of the arms, tips or apex touches the texture edge. The
   *     path is pulled in as the stroke grows rather than the texture growing
   *     with it, which would stretch the decal on its fixed-aspect plane.
   */
  _buildArchChevronMaterial() {
    const W = 128;
    const H = 72;
    const tex = new DynamicTexture("race_arch_chevron_tex", { width: W, height: H }, this.scene, true);
    tex.hasAlpha = true;
    const g = tex.getContext();
    g.clearRect(0, 0, W, H);
    g.lineJoin = "round";
    g.lineCap = "round";
    g.beginPath();
    g.moveTo(W * 0.16, H * 0.37);
    g.lineTo(W * 0.5, H * 0.72);
    g.lineTo(W * 0.84, H * 0.37);
    g.lineWidth = W * 0.25;
    g.strokeStyle = "#6fc6ff";
    g.stroke();
    tex.update();
    const mat = new StandardMaterial("race_arch_chevron_mat", this.scene);
    mat.diffuseTexture = tex;
    mat.emissiveTexture = tex;
    mat.emissiveColor = new Color3(1, 1, 1);
    mat.diffuseColor = Color3.Black();
    mat.specularColor = Color3.Black();
    mat.disableLighting = true;
    mat.backFaceCulling = false;
    mat.useAlphaFromDiffuseTexture = true;
    return mat;
  }

  /**
   * The row of small chevrons that runs along the INSIDE of a gate's arch.
   *
   * Each decal is a plane in the arch's own vertical plane. It is rolled about
   * its normal so the "v" aims radially at the road below - the feathering from
   * the reference - and then the plate is turned to the gate heading. With
   * Babylon's Ry * Rz euler order that is exactly `rotation = (0, heading,
   * roll)`: the roll happens in-plane first, then the plate faces the road.
   *
   * The count follows the arch radius, so the row keeps the same arc-to-arc
   * density on a wide gate and a narrow one; the icon size is a fixed fraction
   * of that pitch, so the gap between chevrons stays even too.
   */
  _buildGateChevrons(gate, archHalf, band, mat) {
    // Near the full half-circle: the row runs from just above the road on one
    // side, over the crown, and down to the road on the other.
    const span = Math.PI * ARCH_CHEVRON_SPAN;
    const from = (Math.PI - span) / 2;
    // Large, wide, and thick. Width is a fraction of the arc pitch: the bigger
    // the fraction, the smaller the leftover gap between neighbours, so the
    // row still spans the arc after taking chevrons out of it.
    const iw = ARCH_CHEVRON_PITCH * 0.78;
    const ih = iw * 0.55;
    const R = archHalf - band - ARCH_CHEVRON_CLEARANCE - ih / 2;
    if (R < 1.0) return [];
    // Many small chevrons rather than a few large ones.
    const count = clamp(Math.round((R * span) / ARCH_CHEVRON_PITCH), 6, 36);
    const out = [];
    for (let i = 0; i < count; i++) {
      const a = from + (span * (i + 0.5)) / count;
      const icon = MeshBuilder.CreatePlane(
        `race_gate_${gate.index}_chevron_${i}`,
        { width: iw, height: ih },
        this.scene,
      );
      icon.position.set(
        gate.x + gate.rightX * Math.cos(a) * R,
        gate.y + Math.sin(a) * R,
        gate.z + gate.rightZ * Math.cos(a) * R,
      );
      icon.rotation.set(0, gate.heading, Math.atan2(-Math.cos(a), Math.sin(a)));
      icon.material = mat;
      icon.isPickable = false;
      icon.freezeWorldMatrix();
      out.push(icon);
    }
    return out;
  }

  /**
   * The light blue directional boards that stand on the OUTSIDE of every bend
   * circuit and point the way through it.
   *
   * They are the race's only ground-level signage, so they go where a driver
   * actually needs telling — the turns — and never in a line along a straight,
   * where the road itself already says which way to go. Purely presentational
   * (no collision, not pickable) and up only while the event runs.
   */
  _buildChevrons() {
    const scene = this.scene;
    const t = this.track;

    // Portrait texture whose aspect matches the board EXACTLY (W/H === CHEVRON_W/
    // CHEVRON_H), so the arrow is neither squashed nor stretched when it lands
    // on the plane. The arrow itself is a single filled polygon, inset from
    // every edge: a stroked path's mitre overruns the canvas at the tip, which
    // is exactly what used to crop the arrow's point off. A filled outline has
    // no mitre, so nothing can spill past the texture edge.
    const W = CHEVRON_TEX_W;
    const H = CHEVRON_TEX_H;
    const tex = new DynamicTexture("race_chevron_tex", { width: W, height: H }, scene, true);
    tex.hasAlpha = true;
    const g = tex.getContext();
    g.clearRect(0, 0, W, H);
    const xBack = W * CHEVRON_TEX_PAD;
    const xTip = W - W * CHEVRON_TEX_PAD;
    const yTop = H * CHEVRON_TEX_PAD;
    const yBot = H - H * CHEVRON_TEX_PAD;
    const yMid = H * 0.5;
    const dx = xTip - xBack;
    const hs = (yBot - yTop) / 2;
    // Vertical band thickness at the back, plus the matching tip inset that
    // keeps the inner edge parallel to the outer one - so the arm stays the
    // same width all the way to the point instead of tapering.
    const band = hs * 0.42;
    const m = (band * dx) / hs;
    const cx = W * 0.5;
    const cy = H * 0.5;
    // One solid " > " per board: outer edge top -> tip -> bottom, then back
    // along the inner edge. Filled in one flat colour, no rim, no spine, and
    // no mitre to overrun the canvas. `scale` grows the arrow about the texture
    // centre, which is how the glow rings are drawn.
    g.fillStyle = CHEVRON_COLOR;
    const chevron = (scale, alpha) => {
      const sx = (x) => cx + (x - cx) * scale;
      const sy = (y) => cy + (y - cy) * scale;
      g.globalAlpha = alpha;
      g.beginPath();
      g.moveTo(sx(xBack), sy(yTop));
      g.lineTo(sx(xTip), sy(yMid));
      g.lineTo(sx(xBack), sy(yBot));
      g.lineTo(sx(xBack), sy(yBot - band));
      g.lineTo(sx(xTip - m), sy(yMid));
      g.lineTo(sx(xBack), sy(yTop + band));
      g.closePath();
      g.fill();
    };
    // Glow first, so the solid arrow sits on top of its own bloom.
    for (const [scale, alpha] of CHEVRON_GLOW) chevron(scale, alpha);
    chevron(1, 1);
    g.globalAlpha = 1;
    tex.update();

    // One material per board slot, so the slots can chase in sequence. These
    // are built EXPLICITLY rather than cloned from a shared material:
    // StandardMaterial.clone() serialises the material graph, and serialising a
    // DynamicTexture runs a synchronous canvas readback (toDataURL) - a GPU
    // stall on the load path that can wedge the loading overlay. A plain
    // `new StandardMaterial` that is handed the already-drawn texture has no
    // such path, so nothing here can stall the load.
    const slotMaterial = (name) => {
      const m = new StandardMaterial(name, scene);
      m.diffuseTexture = tex;
      m.emissiveTexture = tex;
      // A fixed, bright emissive: the board's colour lives entirely in the
      // texture, and the chase is carried by `alpha` (see _animateChevrons).
      // The colour is lifted past white so the arrow reads as a lit sign rather
      // than a flat decal - and because it is written once and never varied, no
      // define ever flips and nothing recompiles mid-race.
      m.emissiveColor = new Color3(
        CHEVRON_EMISSIVE_GAIN,
        CHEVRON_EMISSIVE_GAIN,
        CHEVRON_EMISSIVE_GAIN,
      );
      m.diffuseColor = Color3.Black();
      m.specularColor = Color3.Black();
      m.disableLighting = true;
      m.alpha = 1;
      // Each board is genuinely two-sided now, so the face turned away must be
      // culled - otherwise the far face would draw over the near one and the
      // board would blend its own alpha twice.
      m.backFaceCulling = true;
      m.useAlphaFromDiffuseTexture = true;
      // Signage must not be washed out by the world's linear fog: at 100 m the
      // fog would take a blue board to almost the sky colour and it would read
      // as invisible. Kept crisp so a corner can be picked out well down the
      // road. Set once, so no FOG define ever flips while racing.
      m.fogEnabled = false;
      return m;
    };
    const slots = [];
    const pulses = [];
    for (let i = 0; i < CHEVRON_COUNT; i++) {
      const mat = slotMaterial(`race_chevron_mat_${i}`);
      slots.push(mat);
      // Phase marches along the row, so the crest runs through each corner in
      // the direction of travel rather than every board flashing at once.
      pulses.push({ mat, phase: ((i % CHEVRON_WAVE_PITCH) / CHEVRON_WAVE_PITCH) * Math.PI * 2 });
    }

    const out = [];
    const arcS = [];
    let index = 0;
    const L = t.length || 1;
    for (const corner of this._cornerAnchors()) {
      // A bend that turns a car to its right has its inside on the right, so
      // the boards go opposite — on the OUTSIDE of the curve, where a driver
      // looking ahead through the corner actually sees them.
      const turnsLeft = corner.turn < 0;
      const side = turnsLeft ? 1 : -1;
      for (let i = 0; i < CHEVRON_COUNT; i++) {
        // Strung along the bend rather than bunched at its apex, so the row
        // reads as a wall of arrows sweeping through the turn.
        const s = corner.s + (i - (CHEVRON_COUNT - 1) / 2) * CHEVRON_GAP;
        // Remember each board's arclength (normalized): _applyChevronVisibility
        // stands down every board that is not on the road to the next gate.
        arcS.push((((s % L) + L) % L));
        const p = t.path.sample(s);
        const heading = this._pathHeading(s);
        const outX = Math.cos(heading) * side;
        const outZ = -Math.sin(heading) * side;
        const edge = this._roadEdge(p.x, p.z, outX, outZ, p.y ?? 6);
        const lat = clamp(edge + 1.2, 3.0, 11);
        const x = p.x + outX * lat;
        const z = p.z + outZ * lat;
        const ground = this.collision.groundAt?.(x, z, p.y ?? 6, { stepUp: 3, reach: 10 });
        const y = ground && ground.kind === "ground" ? ground.y : p.y ?? 0;
        // The painted ">" points to the car's right; on a left-hand bend the
        // FRONT face is UV-mirrored so the arrow points INTO the corner. The
        // back face uses the SAME UV rectangle as the front: a DOUBLESIDE plane
        // already winding-mirrors the back, so matching UVs make the back a true
        // mirror of the front and the arrow points ONE consistent WORLD
        // direction from either side. (Giving the back the opposite rectangle -
        // the old behaviour - cancelled that mirror, so the two faces pointed
        // opposite ways and the turn looked reversed when seen from behind.)
        const uv = turnsLeft ? CHEVRON_UV_FLIP : CHEVRON_UV_PLAIN;
        const panel = MeshBuilder.CreatePlane(
          `race_chevron_${index++}`,
          {
            width: CHEVRON_W,
            height: CHEVRON_H,
            sideOrientation: Mesh.DOUBLESIDE,
            frontUVs: uv,
            backUVs: uv,
          },
          scene,
        );
        panel.position.set(x, y + CHEVRON_H * CHEVRON_LIFT, z);
        // Front face (-Z) toward the arriving field, so the arrows point the way
        // the eye is already travelling.
        panel.rotation.y = heading;
        panel.material = slots[i];
        panel.isPickable = false;
        panel.freezeWorldMatrix();
        out.push(panel);
      }
    }
    return { meshes: out, pulses, arcS };
  }

  /**
   * Run the chase down the corner boards: a brightness crest sweeps the row in
   * the direction of travel, so each arrow appears as the wave arrives and
   * fades once it has passed, all while the board stays put. Only `alpha`
   * moves - the colour and texture are never touched, so the material is never
   * recompiled while the race runs.
   */
  _animateChevrons(dt) {
    const pulses = this.markers?.chevronPulses;
    if (!pulses?.length || !this._gatesLive) return;
    // Advance the crest by CHEVRON_ANIM_SPEED boards per second.
    this._chevronT += (dt * Math.PI * 2 * CHEVRON_ANIM_SPEED) / CHEVRON_WAVE_PITCH;
    for (const slot of pulses) {
      // Squared half-cosine: the board blooms as the wave reaches it, then
      // fades all the way back to a faint ghost - while the board itself never
      // moves off the spot it was built on.
      const c = Math.cos(this._chevronT - slot.phase);
      const k = c > 0 ? c * c : 0;
      slot.mat.alpha = CHEVRON_ANIM_MIN_ALPHA + (1 - CHEVRON_ANIM_MIN_ALPHA) * k;
    }
  }

  /**
   * The circuit's real bends, as `{ s, turn }` — arc length, and the signed
   * heading change across the bend (positive turns the car to its right).
   *
   * The path is walked at a fixed step and the heading change summed across a
   * window either side of each sample — summed in small increments, so a
   * hairpin that turns more than half a revolution across the window is still
   * measured whole instead of aliasing through the ±π wrap. Samples that turn
   * less than CORNER_MIN_TURN are dropped, and of the samples that describe the
   * SAME bend only the sharpest survives: that is what turns a couple of dozen
   * readings around one corner into the single anchor that corner deserves.
   */
  _cornerAnchors() {
    const L = this.track.length;
    if (!L) return [];
    const n = Math.max(12, Math.round(L / CORNER_STEP));
    const step = L / n;
    const turnAt = (s) => {
      let total = 0;
      for (let d = -CORNER_WINDOW; d < CORNER_WINDOW; d += CORNER_STEP) {
        total += wrapAngle(this._pathHeading(s + d + CORNER_STEP) - this._pathHeading(s + d));
      }
      return total;
    };
    const bends = [];
    for (let i = 0; i < n; i++) {
      const s = i * step;
      const turn = turnAt(s);
      if (Math.abs(turn) >= CORNER_MIN_TURN) bends.push({ s, turn });
    }
    const keep = [];
    for (const c of bends) {
      let sharpest = true;
      for (const o of bends) {
        if (o === c || Math.abs(o.turn) <= Math.abs(c.turn)) continue;
        const gap = Math.min(Math.abs(o.s - c.s), L - Math.abs(o.s - c.s));
        if (gap < CORNER_MIN_GAP) {
          sharpest = false;
          break;
        }
      }
      if (sharpest) keep.push(c);
    }
    // A long circuit can offer more bends than are worth marking: keep the
    // sharpest handful, then put them back into circuit order.
    if (keep.length > CORNER_MAX) {
      keep.sort((a, b) => Math.abs(b.turn) - Math.abs(a.turn));
      keep.length = CORNER_MAX;
    }
    keep.sort((a, b) => a.s - b.s);
    return keep;
  }

  /**
   * Distance (m) from a point on the circuit to the edge of the drivable
   * surface along `(dirX, dirZ)`: walks outward in 0.5 m steps while the ground
   * is real and still road, and returns the last step that was. Mirrors how
   * raceTrack.js measures a gate's half-width, so the boards stand against the
   * same road edge the arches span.
   */
  _roadEdge(x, z, dirX, dirZ, refY, max = 14) {
    let last = 0;
    for (let d = 0.5; d <= max; d += 0.5) {
      const gx = x + dirX * d;
      const gz = z + dirZ * d;
      const g = this.collision.groundAt?.(gx, gz, refY + 1, { stepUp: 2, reach: 6 });
      if (!g || g.kind !== "ground") break;
      if (this.collision.isRoadAt && !this.collision.isRoadAt(gx, gz)) break;
      last = d;
    }
    return last;
  }



  /**
   * Earn the finish plate. Pre-race (and on any lap but the last) the plate
   * reads as the event's own name; the moment the player clears the final
   * checkpoint of the final lap — i.e. the next gate is the line itself — it
   * flips to "FINISH". Cheaper than it looks: the state check is one compare
   * and the repaint only runs on the flip.
   */
  _updateFinishBanner() {
    const b = this.markers?.finishBanner;
    if (!b) return;
    const p = this.playerProgress;
    const onFinalLap = !!p && p.lap >= this.track.laps - 1;
    const allCheckpointsDone = !!p && p.gate === 0;
    const live = !!p && (p.finished || (onFinalLap && allCheckpointsDone));
    if (b.live === live) return;
    this._paintFinishBanner(b, live);
    b.mat.emissiveColor = live ? new Color3(1, 1, 1) : new Color3(0.74, 0.8, 0.88);
  }

  /**
   * Refresh the gates. Every arch is static white structure, so the live
   * elements are two: the start/finish plate, which reads as the event until
   * the player clears the final checkpoint and is earned as "FINISH" (see
   * _updateFinishBanner); and which arches are standing at all, since a
   * checkpoint that has been cleared is taken out of the world (see
   * _applyGateVisibility). Which checkpoint is next is told by the HUD counter
   * and the minimap's yellow gate mark, not by tinting the arches.
   */
  _applyGateMaterials() {
    this._updateFinishBanner();
    this._applyGateVisibility();
  }

  /**
   * Which arches are standing right now.
   *
   * A checkpoint the player has already cleared this lap is taken OUT of the
   * world, so the only gate in front of the car is the one still to be earned
   * and a passed arch is not left reading as something to drive at. The
   * start/finish arch is exempt — it is the circuit's landmark and the finish
   * plate's home — and every checkpoint returns when the next lap begins,
   * because the lap sequence resets to checkpoint 1.
   *
   * The drop waits until the car is GATE_HIDE_BEHIND metres clear of the gate,
   * so the arch never blinks out from over the car's own roof.
   */
  _applyGateVisibility() {
    const live = !!this._gatesLive;
    const p = this.playerProgress;
    const L = this.track.length || 1;
    const n = this.track.gateCount || this.markers.gates.length;
    const next = p?.gate ?? 0;
    const dist = p?.distance ?? 0;
    // The checkpoint most recently cleared (kept up briefly so it fades out
    // behind the car rather than blinking off over its roof).
    const prev = this.track.open ? next - 1 : (next - 1 + n) % n;
    for (const g of this.markers.gates) {
      let show = false;
      if (live) {
        if (g.index === next) {
          show = true; // ONLY the next checkpoint is standing
        } else if (g.index === prev && prev >= 0) {
          const gate = this.track.gates[g.index];
          const behind = (((dist - gate.s) % L) + L) % L;
          show = behind <= GATE_HIDE_BEHIND;
        }
      }
      if (g.visible === show) continue;
      g.visible = show;
      for (const m of g.meshes) m.isVisible = show;
    }
    this._applyChevronVisibility();
  }

  /**
   * Which corner boards are standing right now: ONLY the ones on the road to
   * the next checkpoint. The moment the car clears a gate, that gate's
   * approach boards stand down and the next gate's approach lights up, so the
   * arrows always answer "which way to the NEXT checkpoint" and never paint
   * the whole lap at once. Boards just passed keep a short grace
   * (CHEVRON_KEEP_BEHIND) so they don't blink out at the edge of vision, and
   * everything returns when its checkpoint comes back around next lap.
   */
  _applyChevronVisibility() {
    const boards = this.markers.chevrons ?? [];
    if (!boards.length) return;
    const arcS = this.markers.chevronS ?? [];
    const live = !!this._gatesLive;
    const p = this.playerProgress;
    const L = this.track.length || 1;
    const next = p?.gate ?? 0;
    const dist = p?.distance ?? 0;
    const nextS = this.track.gates?.[next]?.s;
    for (let i = 0; i < boards.length; i++) {
      const m = boards[i];
      let show = false;
      if (live) {
        if (nextS == null) {
          show = true; // window unknowable: fall back to all-standing
        } else {
          const bs = arcS[i] ?? 0;
          // Forward metres from the car to the board and to the next gate
          // (modulo arithmetic serves open tracks too: every s lives in
          // [0, L], so distances that can't wrap simply never do).
          const ahead = (((bs - dist) % L) + L) % L;
          const gateAhead = (((nextS - dist) % L) + L) % L;
          const behind = (((dist - bs) % L) + L) % L;
          show = ahead <= gateAhead || behind <= CHEVRON_KEEP_BEHIND;
        }
      }
      if (m.isVisible === show) continue;
      m.isVisible = show;
    }
  }

  // ---------------------------------------------------------- event board

  /**
   * The floating event board: a billboard above the start line showing the
   * difficulty tag, the race name, the prize and "Finish to claim reward".
   * Painted once onto a DynamicTexture (no extra dependencies), faced at the
   * camera every frame by billboarding, and shown only when the player is
   * close (see _updateEventBoard) — from far away the beacon + minimap
   * diamond are the signpost.
   */
  _buildEventBoard() {
    const scene = this.scene;
    const start = this.track.startPose;
    // High-resolution 2048x768 texture with anisotropic filtering for crystal-clear text
    const W = 2048;
    const H = 768;
    const tex = new DynamicTexture("race_event_board_tex", { width: W, height: H }, scene, true);
    tex.hasAlpha = true;
    tex.updateSamplingMode(Texture.TRILINEAR_SAMPLING_MODE);
    tex.anisotropicFilteringLevel = 16;
    this._paintEventBoard(tex.getContext(), W, H);
    tex.update();
    const mat = new StandardMaterial("race_event_board_mat", scene);
    mat.diffuseTexture = tex;
    mat.emissiveTexture = tex;
    mat.emissiveColor = new Color3(1, 1, 1);
    mat.diffuseColor = new Color3(0, 0, 0);
    mat.disableLighting = true;
    mat.backFaceCulling = false;
    mat.useAlphaFromDiffuseTexture = true;
    const board = MeshBuilder.CreatePlane("race_event_board", { width: BOARD_W, height: BOARD_H }, scene);
    board.position.set(start.x, start.y + BOARD_LIFT, start.z);
    board.material = mat;
    board.isPickable = false;
    board.billboardMode = Mesh.BILLBOARDMODE_ALL;
    board.isVisible = false;
    return { board, baseY: start.y + BOARD_LIFT };
  }

  /**
   * Paint the board as ONE compact section: a single bordered panel holding
   * the banner strip (difficulty / name / prize), the type line and the
   * reward message together — nothing floating outside it.
   */
  _paintEventBoard(g, W, H) {
    const scale = W / 1024;
    g.clearRect(0, 0, W, H);
    g.save();
    g.imageSmoothingEnabled = true;
    g.imageSmoothingQuality = "high";
    g.scale(scale, scale);

    const bW = 1024;
    const bH = 384;
    const ev = this.event;
    const diffColors = {
      EASY: { fill: "#2fbf4e", text: "#ffffff" },
      MEDIUM: { fill: "#ff8c1a", text: "#ffffff" },
      HARD: { fill: "#ff3b30", text: "#ffffff" },
    };
    const diff = diffColors[ev.difficulty] ?? diffColors.MEDIUM;
    const prize = typeof ev.prize === "number" ? `+$${ev.prize.toLocaleString("en-US")}` : "+$1,000";

    // --- 1. Outer chamfered racing frame ---
    const px = 18;
    const py = 16;
    const pw = bW - 36;
    const ph = bH - 32;
    const cut = 32;

    // Asymmetric racing chamfer: top-left & bottom-right cuts
    g.save();
    g.beginPath();
    g.moveTo(px + cut, py);
    g.lineTo(px + pw - 12, py);
    g.lineTo(px + pw, py + 12);
    g.lineTo(px + pw, py + ph - cut);
    g.lineTo(px + pw - cut, py + ph);
    g.lineTo(px + 12, py + ph);
    g.lineTo(px, py + ph - 12);
    g.lineTo(px, py + cut);
    g.closePath();

    // Deep carbon-tinted background gradient
    const bgGrad = g.createLinearGradient(px, py, px + pw, py + ph);
    bgGrad.addColorStop(0, "rgba(8, 14, 22, 0.94)");
    bgGrad.addColorStop(0.5, "rgba(12, 18, 28, 0.92)");
    bgGrad.addColorStop(1, "rgba(8, 12, 18, 0.95)");
    g.fillStyle = bgGrad;
    g.fill();
    g.clip();

    // Subtle background speedline stripes
    g.strokeStyle = "rgba(255, 255, 255, 0.035)";
    g.lineWidth = 14;
    for (let x = -bH; x < bW + bH; x += 36) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x + bH * 0.7, bH);
      g.stroke();
    }
    g.restore();

    // Outer border stroke
    g.save();
    g.beginPath();
    g.moveTo(px + cut, py);
    g.lineTo(px + pw - 12, py);
    g.lineTo(px + pw, py + 12);
    g.lineTo(px + pw, py + ph - cut);
    g.lineTo(px + pw - cut, py + ph);
    g.lineTo(px + 12, py + ph);
    g.lineTo(px, py + ph - 12);
    g.lineTo(px, py + cut);
    g.closePath();
    g.lineWidth = 2.5;
    g.strokeStyle = "rgba(255, 255, 255, 0.3)";
    g.stroke();

    // Glowing top racing speedline
    const topGrad = g.createLinearGradient(px, py, px + pw, py);
    topGrad.addColorStop(0, "#ff8c1a");
    topGrad.addColorStop(0.45, "#ff2d55");
    topGrad.addColorStop(0.85, "#37c8e8");
    topGrad.addColorStop(1, "transparent");
    g.lineWidth = 6;
    g.strokeStyle = topGrad;
    g.beginPath();
    g.moveTo(px + cut - 2, py);
    g.lineTo(px + pw - 12, py);
    g.stroke();
    g.restore();

    // Helper: slanted polygon with skew
    const slant = 18;
    const drawSlantPoly = (x, y, w, h) => {
      g.beginPath();
      g.moveTo(x + slant, y);
      g.lineTo(x + w, y);
      g.lineTo(x + w - slant, y + h);
      g.lineTo(x, y + h);
      g.closePath();
    };

    // --- 2. Top Header Row ---
    const topY = py + 22;
    const tagH = 50;

    // TYPE tag (Cyan) - dynamically sized according to text length so NO CONTACT / TIME TRIAL never overflow
    const typeText = (ev.type ?? "SPRINT").toUpperCase();
    g.font = "italic 900 28px Arial, sans-serif";
    const typeTextW = g.measureText(typeText).width;
    const typeW = Math.max(160, Math.ceil(typeTextW + slant + 44));
    const typeX = px + 24;
    drawSlantPoly(typeX, topY, typeW, tagH);
    g.fillStyle = "#37c8e8";
    g.fill();
    g.fillStyle = "#090d14";
    g.font = "italic 900 28px Arial, sans-serif";
    g.textAlign = "center";
    g.textBaseline = "middle";
    g.fillText(typeText, typeX + typeW / 2, topY + tagH / 2 + 1);

    // DIFFICULTY tag (Green/Orange/Red) - dynamically sized according to text length
    const diffText = ev.difficulty.toUpperCase();
    g.font = "italic 900 28px Arial, sans-serif";
    const diffTextW = g.measureText(diffText).width;
    const diffW = Math.max(150, Math.ceil(diffTextW + slant + 44));
    const diffX = typeX + typeW + 12;
    drawSlantPoly(diffX, topY, diffW, tagH);
    g.fillStyle = diff.fill;
    g.fill();
    g.fillStyle = diff.text;
    g.font = "italic 900 28px Arial, sans-serif";
    g.fillText(diffText, diffX + diffW / 2, topY + tagH / 2 + 1);

    // Top Purse (Right side) - dynamically sized to fit purse value
    g.font = "italic 900 32px Arial, sans-serif";
    const prizeTextW = g.measureText(prize).width;
    g.font = "italic 800 18px Arial, sans-serif";
    const purseTextW = g.measureText("PURSE").width;
    const prizeW = Math.max(250, Math.ceil(prizeTextW + purseTextW + slant + 52));
    const prizeX = px + pw - prizeW - 24;
    drawSlantPoly(prizeX, topY, prizeW, tagH);
    g.fillStyle = "rgba(18, 22, 32, 0.9)";
    g.fill();
    g.lineWidth = 2;
    g.strokeStyle = "rgba(255, 214, 10, 0.55)";
    g.stroke();

    // Gold accent on prize box
    g.fillStyle = "#ffd60a";
    g.font = "italic 900 32px Arial, sans-serif";
    g.textAlign = "right";
    g.textBaseline = "middle";
    g.fillText(prize, prizeX + prizeW - 22, topY + tagH / 2 + 1);

    g.fillStyle = "rgba(255, 255, 255, 0.65)";
    g.font = "italic 800 18px Arial, sans-serif";
    g.textAlign = "left";
    g.fillText("PURSE", prizeX + slant + 14, topY + tagH / 2 + 1);

    // Divider accent line
    const divY = topY + tagH + 14;
    const divGrad = g.createLinearGradient(px + 24, divY, px + pw - 24, divY);
    divGrad.addColorStop(0, "rgba(255, 140, 26, 0.85)");
    divGrad.addColorStop(0.55, "rgba(255, 45, 85, 0.45)");
    divGrad.addColorStop(1, "rgba(55, 200, 232, 0.15)");
    g.fillStyle = divGrad;
    g.fillRect(px + 24, divY, pw - 48, 3);

    // --- 3. Main Center Body ---
    // Right-hand Objective Card
    const cardW = 320;
    const cardH = 92;
    const cardX = px + pw - cardW - 24;
    const cardY = divY + 16;
    drawSlantPoly(cardX, cardY, cardW, cardH);
    g.fillStyle = "rgba(14, 20, 30, 0.85)";
    g.fill();
    g.lineWidth = 2;
    const isSolo = ev.kind !== "RACE";
    g.strokeStyle = isSolo ? "#37c8e8" : "#ffd60a";
    g.stroke();

    // Objective text
    const targetLabel = ev.targetTime ? "TARGET TIME" : ev.targetHits != null ? "MAX CONTACTS" : "OBJECTIVE";
    const targetVal = ev.targetTime
      ? `≤ ${fmtClock(ev.targetTime)}`
      : ev.targetHits != null
        ? (ev.targetHits === 0 ? "0 HITS (CLEAN)" : `≤ ${ev.targetHits} HITS`)
        : "WIN (1ST PLACE)";

    g.fillStyle = isSolo ? "#37c8e8" : "#ffd60a";
    g.font = "italic 800 18px Arial, sans-serif";
    g.textAlign = "left";
    g.fillText(targetLabel, cardX + slant + 18, cardY + 28);

    g.fillStyle = "#ffffff";
    g.font = "italic 900 28px Arial, sans-serif";
    g.fillText(targetVal, cardX + slant + 18, cardY + 62);

    // Event Name (Dynamic sizing to always fit cleanly)
    const titleY = divY + 50;
    let titleFontSize = 54;
    g.font = `italic 900 ${titleFontSize}px Arial Black, Arial, sans-serif`;
    const maxTitleW = cardX - (px + 28) - 20;
    while (g.measureText(ev.name.toUpperCase()).width > maxTitleW && titleFontSize > 32) {
      titleFontSize -= 4;
      g.font = `italic 900 ${titleFontSize}px Arial Black, Arial, sans-serif`;
    }

    g.save();
    g.shadowColor = "rgba(0, 0, 0, 0.95)";
    g.shadowBlur = 12;
    g.shadowOffsetX = 3;
    g.shadowOffsetY = 3;
    g.fillStyle = "#ffffff";
    g.textAlign = "left";
    g.textBaseline = "middle";
    g.fillText(ev.name.toUpperCase(), px + 28, titleY);
    g.restore();

    // Subtitle track spec under name
    const lapsText = this.track?.laps > 1 ? `${this.track.laps} LAPS` : "1 LAP";
    const fieldText = ev.kind === "RACE" ? ` · ${this.field?.length ? this.field.length + 1 : 6} CARS` : " · SOLO RUN";
    const distText = this.track?.length ? ` · ${(this.track.length / 1000).toFixed(1)} KM` : "";
    const specLine = `${lapsText}${fieldText}${distText}`.toUpperCase();

    g.fillStyle = "rgba(160, 175, 200, 0.85)";
    g.font = "italic 800 24px Arial, sans-serif";
    g.fillText(specLine, px + 30, titleY + 44);

    // --- 4. Bottom Call To Action Banner ---
    const botH = 58;
    const botY = py + ph - botH - 14;
    const botW = pw - 48;
    const botX = px + 24;

    g.fillStyle = "rgba(10, 16, 24, 0.88)";
    g.fillRect(botX, botY, botW, botH);
    g.lineWidth = 1.5;
    g.strokeStyle = "rgba(255, 255, 255, 0.15)";
    g.strokeRect(botX, botY, botW, botH);

    // Bottom left: rule message
    g.fillStyle = "#ffd60a";
    g.font = "italic 800 24px Arial, sans-serif";
    g.textAlign = "left";
    g.fillText(ev.message ?? "Finish to claim reward", botX + 20, botY + botH / 2 + 1);

    // Bottom right: call to action
    g.fillStyle = "#ff2d55";
    g.font = "italic 900 26px Arial, sans-serif";
    g.textAlign = "right";
    g.fillText("DRIVE INTO ZONE TO RACE ▶▶", botX + botW - 20, botY + botH / 2 + 1);

    g.restore();
  }

  /** Show the board only pre-race and only up close, gently bobbing. */
  _updateEventBoard(dist) {
    const b = this.eventBoard;
    if (!b) return;
    const live =
      (this.state === RACE_STATE.IDLE || this.state === RACE_STATE.ARMED) && dist < BOARD_SHOW_RANGE;
    b.board.isVisible = live;
    if (!live) return;
    b.board.position.y = b.baseY + Math.sin(Date.now() / 850) * 0.35;
  }

  // ---------------------------------------------------------------- grid

  _placeFieldOnGrid() {
    const grid = this.track.grid;
    const playerPose = grid[this.playerSlot] ?? grid[0];
    this.playerGridPose = playerPose;
    for (let i = 0; i < this.rivals.length; i++) {
      const slot = this.rivalSlots[i] ?? i;
      this.rivals[i].placeOnGrid(grid[slot] ?? grid[0]);
    }
  }

  /**
   * Show or hide every checkpoint gate structure and the corner chevrons.
   *
   * The per-gate half of that — a checkpoint the player has already cleared
   * stays down until the next lap — is applied by _applyGateVisibility, which
   * is always re-run here so a whole-circuit state flip can never leave a
   * passed gate standing on its own.
   */
  _setGatesLive(live) {
    if (this._gatesLive !== live) {
      this._gatesLive = live;
      for (const c of this.markers.chevrons) c.isVisible = live;
    }
    this._applyGateVisibility();
  }

  /** Hide the whole field (pre-race event state: icon only, no cars). */
  _hideField() {
    this.fieldVisible = false;
    for (const r of this.rivals) {
      r.hidden = true;
      r.locked = true;
      try {
        r.rig?.setVisible?.(false);
      } catch {
        /* rig not ready — hidden flag still hides it logically */
      }
    }
    if (this.traffic) this.traffic.extraVehicles = [];
  }

  /** Spawn + align the field on the grid for the countdown. */
  _showField() {
    this.fieldVisible = true;
    for (const r of this.rivals) {
      r.hidden = false;
      try {
        r.rig?.setVisible?.(true);
      } catch {
        /* ignore */
      }
    }
    if (this.traffic) this.traffic.extraVehicles = this.field;
  }

  /** Put the player on their grid slot (and kill their speed). */
  _placePlayerOnGrid() {
    const pose = this.playerGridPose;
    const state = this.player.state;
    state.x = pose.x;
    state.y = pose.y;
    state.z = pose.z;
    state.heading = pose.heading;
    state.speed = 0;
    this.player.steerAngle = 0;
    this.player.roll = 0;
    this.player.pitch = 0;
    // Every run starts on a fresh shell, like the rivals: dents, soot and
    // performance loss never carry from free roam (or a previous run) onto
    // the grid. Paint is untouched - repair() restores the current colour.
    try {
      this.player.damage?.repair();
    } catch {
      /* cosmetic-only: never block the start */
    }
    if (this.player.terrain) {
      this.player.terrain.teleport(pose.y);
      this.player.terrain.apply(this.player.rig, pose.x, pose.z, pose.heading);
    } else {
      this.player.rig.setPosition(pose.x, pose.y, pose.z);
      this.player.rig.setHeading(pose.heading);
    }
    this.player.rig.setSteer(0);
    // Seed from the slot's known arc position (see RaceDriver.placeOnGrid) so a
    // doubled-back track can't seed the player's progress onto the wrong branch.
    if (pose.s != null) this.playerProgress.reset(pose.s);
    else this.playerProgress.reset(this.track.startDistance, { x: pose.x, z: pose.z });
  }

  // ---------------------------------------------------------------- flow

  /**
   * The player pressed SPACE / clicked START inside the zone. This opens the
   * intro cinematic (event card, grid reveal, camera sweep) rather than the
   * countdown directly; the countdown follows when the intro plays out.
   * Controls stay locked from this frame, so the car cannot creep forward
   * off its grid slot while the cameras move.
   *
   * Starts only off a live offer (see canStart): at speed SPACE stays a
   * handbrake instead of hijacking the car into a race.
   */
  requestStart() {
    if (this.canStart) {
      this._startIntro();
      return true;
    }
    if (this.state === RACE_STATE.FINISHED) {
      this.raceAgain();
      return true;
    }
    return false;
  }

  /** Re-grid everyone and run the intro + countdown again. */
  raceAgain() {
    this.results = [];
    this.wrongWay = 0;
    this.message = "";
    this._startIntro();
  }

  /**
   * Open the race-intro cinematic: align the whole field on the grid, spawn
   * the cars (faded out — the reveal fades them in pole-first), raise the
   * gates, close the course to traffic, and park the player on their slot.
   */
  _startIntro() {
    this.state = RACE_STATE.INTRO;
    this.introT = 0;
    this.startRequested = false;
    // A replay must not flash the previous run's rank: the beat card reads
    // the scored place before the new run's award lands, so drop it here.
    this.event.resolvedPlace = null;
    this.time = 0;
    this.cineActive = false;
    this.finishT = 0;
    this._finishA0 = null;
    this._placeFieldOnGrid();
    this._showField();
    this._setGatesLive(true);
    this._placePlayerOnGrid();
    this._applyGateMaterials();
    this._beginReveal();
    // Close the course for the whole event, intro included.
    if (this._holdTraffic && this.traffic?.holdCircuit) this.traffic.holdCircuit(this.track.path);
    if (this.traffic?.clearArea) {
      this.traffic.clearArea(this.track.startPose.x, this.track.startPose.z, 30, 90);
      for (const slot of this.track.grid) this.traffic.clearArea(slot.x, slot.z, 12, 60);
    }
    this._holdTimer = 0;
    this._autoStuck = 0;
  }

  /** Line the reveal list up in grid order and stage the rollout. */
  _beginReveal() {
    const bySlot = new Map();
    for (let i = 0; i < this.rivals.length; i++) {
      const slot = this.rivalSlots[i] ?? i;
      bySlot.set(slot, { rig: this.rivals[i].rig, driver: this.rivals[i] });
    }
    bySlot.set(this.playerSlot, { rig: this.player.rig, driver: null });
    this._reveal = [];
    const grid = this.track.grid;
    for (let s = 0; s < this.track.fieldSize; s++) {
      const info = bySlot.get(s);
      if (!info) continue;
      const pose = grid[s] ?? grid[0];
      // Stage a few metres behind the slot, backing off until the pose is
      // on drivable road (a corner exit can curl the straight-back point
      // off the asphalt). Every car rolls its own lane, so lanes never cross.
      const fx = Math.sin(pose.heading);
      const fz = Math.cos(pose.heading);
      let back = ROLLOUT_BACK;
      const blockedAt = (d) => {
        const bx = pose.x - fx * d;
        const bz = pose.z - fz * d;
        return this.collision.blockedRect?.(
          bx, bz, pose.heading,
          2.15, 0.95, pose.y, pose.y + 1.5,
        );
      };
      while (back > 0 && blockedAt(back)) back -= 1;
      const bx = pose.x - fx * back;
      const bz = pose.z - fz * back;
      if (info.driver) {
        info.driver.state.x = bx;
        info.driver.state.z = bz;
        info.driver.state.y = pose.y;
        info.driver.terrain?.teleport(pose.y);
        info.driver.syncWheels(0);
      } else {
        this.player.state.x = bx;
        this.player.state.z = bz;
      }
      info.rig.setFade?.(0);
      this._reveal.push({
        rig: info.rig,
        driver: info.driver,
        heading: pose.heading,
        fromX: bx,
        fromZ: bz,
        toX: pose.x,
        toZ: pose.z,
        px: bx,
        pz: bz,
      });
    }
  }

  /**
   * Advance the staggered fade-in (pole slot first) and roll every car from
   * its staging point onto its slot - the F1-style arrival the top camera
   * watches. Rivals stay AI-locked; the motion is fully scripted, with
   * heights from their terrain followers and rolling wheels.
   */
  _updateReveal(dt) {
    const k0 = clamp((this.introT - ROLLOUT_START) / (ROLLOUT_END - ROLLOUT_START), 0, 1);
    const k = k0 * k0 * (3 - 2 * k0);
    for (let i = 0; i < this._reveal.length; i++) {
      const e = this._reveal[i];
      const f = clamp((this.introT - i * REVEAL_GAP) / REVEAL_DUR, 0, 1);
      e.rig.setFade?.(f);
      const x = e.fromX + (e.toX - e.fromX) * k;
      const z = e.fromZ + (e.toZ - e.fromZ) * k;
      const moved = Math.hypot(x - e.px, z - e.pz);
      e.px = x;
      e.pz = z;
      if (e.driver) {
        e.driver.state.x = x;
        e.driver.state.z = z;
        e.driver.state.heading = e.heading;
        if (e.driver.terrain) {
          e.driver.terrain.follow(dt, x, z, e.heading);
          e.driver.state.y = e.driver.terrain.y;
        }
        e.driver.syncWheels(moved);
        e.driver._applyPose();
      } else {
        this.player.state.x = x;
        this.player.state.z = z;
        this.player.rig.spinWheels(moved);
      }
    }
  }

  /** Every car fully visible (intro end, and a backstop for probes). */
  _finishReveal() {
    for (const r of this.rivals) r.rig.setFade?.(1);
    this.player.rig.setFade?.(1);
  }

  /**
   * Ideal cinematic lens for this intro instant (main.js eases the real
   * camera toward it). Opens high above the grid looking down the start
   * line, then sweeps down behind the player's car, arriving at the chase
   * pose just as the countdown starts - so the handoff is invisible.
   *
   * @returns {{ pos: Vector3, look: Vector3 }}
   */
  introCamPose() {
    const grid = this.track.grid;
    let cx = 0;
    let cy = 0;
    let cz = 0;
    for (const s of grid) {
      cx += s.x;
      cy += s.y;
      cz += s.z;
    }
    cx /= grid.length;
    cy /= grid.length;
    cz /= grid.length;
    // Top pose: high over the grid with a slow push-in while the card plays.
    const drift = Math.min(this.introT / INTRO_CAM_START, 1);
    const topX = cx + 6 - drift * 3;
    const topY = cy + 58 - drift * 10;
    const topZ = cz - 14 + drift * 5;
    // Chase pose behind the player's gridded car (speed 0 stance, matches
    // ChaseCamera so the handoff out of the intro is invisible).
    const st = this.player.state;
    const fx = Math.sin(st.heading);
    const fz = Math.cos(st.heading);
    const endX = st.x - fx * 6.2;
    const endY = st.y + 2.7;
    const endZ = st.z - fz * 6.2;
    const k0 = clamp((this.introT - INTRO_CAM_START) / (INTRO_CAM_END - INTRO_CAM_START), 0, 1);
    const k = k0 * k0 * (3 - 2 * k0);
    const pos = new Vector3(
      topX + (endX - topX) * k,
      topY + (endY - topY) * k,
      topZ + (endZ - topZ) * k,
    );
    const look = new Vector3(
      cx + (st.x + fx * 6 - cx) * k,
      cy + 1.5 + (st.y + 1.25 - (cy + 1.5)) * k,
      cz + (st.z + fz * 6 - cz) * k,
    );
    // Never let the scripted lens dip underground on crests. The window is
    // anchored at the lens itself, reaching down past the highest top pose.
    const g = this.collision?.groundAt?.(pos.x, pos.z, pos.y, { stepUp: 5, reach: 70 });
    const minY = g && g.y !== null && g.y !== undefined ? g.y + 1.6 : cy + 1.6;
    if (pos.y < minY) pos.y = minY;
    return { pos, look };
  }

  /**
   * Align the whole field on the grid and hold it for 3-2-1-GO. The rivals are
   * spawned here — not at world load — so the event reads as an icon until the
   * player visits and hits START, then the cars appear, align, and launch.
   * Normally reached through the intro; also the direct entry for probes.
   */
  _startCountdown() {
    this.state = RACE_STATE.COUNTDOWN;
    this.countdown = COUNTDOWN_SECONDS;
    this.startRequested = false;
    // Same stale-rank drop as _startIntro (probes enter here directly).
    this.event.resolvedPlace = null;
    this.time = 0;
    this._placeFieldOnGrid();
    this._showField();
    this._setGatesLive(true);
    this._finishReveal();
    this._placePlayerOnGrid();
    this._applyGateMaterials();
    // Close the course. The circuit is a road the traffic fleet also drives, so
    // the race holds its ambient vehicles off it for the duration; otherwise the
    // field spends the race queueing behind road cars on the racing line.
    if (this._holdTraffic && this.traffic?.holdCircuit) this.traffic.holdCircuit(this.track.path);
    // Clear the grid of whatever ambient traffic is left (cars on OTHER routes
    // that happen to cross the grid) before the lights go out: a parked traffic
    // car lying in a grid slot would otherwise be hit on launch.
    if (this.traffic?.clearArea) {
      this.traffic.clearArea(this.track.startPose.x, this.track.startPose.z, 30, 90);
      for (const slot of this.track.grid) this.traffic.clearArea(slot.x, slot.z, 12, 60);
    }
    this._holdTimer = 0;
    this._autoStuck = 0;
  }

  /** Player input is taken away for the countdown, the intro, and the finish cinematic. */
  get controlsLocked() {
    return (
      this.state === RACE_STATE.COUNTDOWN ||
      this.state === RACE_STATE.INTRO ||
      (this.state === RACE_STATE.FINISHED && this.cineActive)
    );
  }

  get racing() {
    return this.state === RACE_STATE.RACING || this.state === RACE_STATE.FINISHED;
  }

  /**
   * The start offer is live: the player is on the start line AND nearly
   * stopped. Recomputed every frame, so the modal (and SPACE) switch off the
   * instant the speedo climbs back over START_SPEED_KMH.
   */
  get canStart() {
    return (
      this.state === RACE_STATE.ARMED && Math.abs(this.player.state.speed) * 3.6 < START_SPEED_KMH
    );
  }

  // ---------------------------------------------------------------- update

  /**
   * @param dt     frame delta, seconds
   * @param input  the keyboard intent, so SPACE can start the race
   */
  update(dt, input = null) {
    if (input?.consumed) {
      // Space is the handbrake everywhere else, so it is only read as "start"
      // when the offer is actually live (see canStart), or as "restart" while
      // the finish card is up. After CONTINUE the car is free-driving and
      // SPACE stays a handbrake.
      const wantsStart = input.consumed("handbrake");
      if (wantsStart && (this.canStart || (this.state === RACE_STATE.FINISHED && this.cineActive))) {
        this.requestStart();
      }
    }
    if (this.startRequested && this.canStart) this._startIntro();
    this.startRequested = false;

    const px = this.player.state.x;
    const pz = this.player.state.z;
    const toStart = Math.hypot(px - this.track.startPose.x, pz - this.track.startPose.z);

    switch (this.state) {
      case RACE_STATE.IDLE:
        // Re-arming after CONTINUE waits until the zone was actually left.
        if (toStart > START_RADIUS * 1.6) this._rearmLocked = false;
        else if (!this._rearmLocked && toStart <= START_RADIUS) this.state = RACE_STATE.ARMED;
        break;
      case RACE_STATE.ARMED:
        if (toStart > START_RADIUS * 1.6) this.state = RACE_STATE.IDLE;
        break;
      case RACE_STATE.INTRO: {
        this.introT += dt;
        this._updateReveal(dt);
        if (this.introT >= INTRO_SECONDS) {
          this._startCountdown();
        }
        break;
      }
      case RACE_STATE.COUNTDOWN: {
        this.countdown -= dt;
        if (this.countdown <= 0) {
          this.state = RACE_STATE.RACING;
          this.time = 0;
          this.goFlash = GO_FLASH;
          for (const r of this.rivals) r.locked = false;
        }
        break;
      }
      default:
        break;
    }

    if (this.goFlash > 0) this.goFlash -= dt;

    // --- course closure ---------------------------------------------------
    // Held from the intro until well after the finish, so the rivals still
    // completing their laps run on a closed course too. Released a while after
    // the player finishes, so free roaming afterwards has its traffic back.
    if (this.traffic?.releaseCircuit) {
      const holding = this.state !== RACE_STATE.IDLE && this.state !== RACE_STATE.ARMED;
      if (!holding) {
        if (this.traffic.circuitHeld) this.traffic.releaseCircuit();
        this._holdTimer = 0;
      } else {
        // Sweep ambient cars that have wandered onto the closed course since
        // the last frame (they are on other routes that merely cross it).
        if (this.traffic.circuitHeld) this.traffic.sweepCircuit?.();
        if (this.state === RACE_STATE.FINISHED) {
          this._holdTimer += dt;
          if (this._holdTimer > 20 && this.traffic.circuitHeld) this.traffic.releaseCircuit();
        } else {
          this._holdTimer = 0;
        }
      }
    }

    // --- the field -------------------------------------------------------
    // Pre-race the field is hidden (event icon only): no AI updates, no
    // collisions, no traffic awareness of ghost cars.
    if (!this.fieldVisible && this.traffic && this.traffic.extraVehicles?.length) {
      this.traffic.extraVehicles = [];
    }
    // The floating board tracks proximity: near the event only.
    this._updateEventBoard(toStart);
    // Checkpoint gates stand from the intro reveal until the event is over —
    // pre-race the board owns the event alone, with no gates on the circuit.
    this._setGatesLive(
      this.state === RACE_STATE.INTRO ||
        this.state === RACE_STATE.COUNTDOWN ||
        this.racing,
    );
    this._animateChevrons(dt);
    if (this.state === RACE_STATE.RACING || this.state === RACE_STATE.FINISHED) {
      this.time += dt;
      if (this.state === RACE_STATE.FINISHED && this.cineActive) this.finishT += dt;
      this._updateRivals(dt);
      this._resolveFieldCollisions();
      const events = this.playerProgress.update(px, pz, { time: this.time });
      if (events.finished && this.state === RACE_STATE.RACING) this._onPlayerFinished();
      // Wrong-way guidance is a RACING-state warning only. Checked after the
      // finish above, so the moment the player takes the flag the warning is off
      // (see _onPlayerFinished): the gate it judges the bearing against is the
      // line they just crossed, which is now behind them, and the car is still
      // rolling down the road while the results come up - exactly the moment the
      // banner used to flash up over the standings.
      if (this.state === RACE_STATE.RACING) this._updateWrongWay(dt);
    }

    this._applyGateMaterials();
    if (this.racing) this._computeStandings();
  }

  _updateRivals(dt) {
    const px = this.player.state.x;
    const pz = this.player.state.z;
    for (const r of this.rivals) {
      if (r.hidden) continue;
      r.update(dt, { racers: this.rivals, traffic: this.traffic, time: this.time });
      // A finished rival that has left the player's sight is done: despawn it
      // (invisible, frozen, non-collidable) instead of leaving it sitting on
      // the circuit. Standings already hold its finish time, so nothing racing
      // related is lost. Unfinished rivals always stay — the race is live.
      if (r.progress.finished) {
        const d = Math.hypot(r.state.x - px, r.state.z - pz);
        if (d > RIVAL_DESPAWN_DISTANCE) {
          r.hidden = true;
          try {
            r.rig?.setVisible?.(false);
          } catch {
            /* rig already gone — hidden flag still hides it logically */
          }
        }
      }
    }
  }

  /**
   * Racer <-> racer and racer <-> traffic contact, using the same resolver the
   * player uses. Arcade rules (NFS/Forza style): racers trade paint — a damped
   * nudge plus the momentum of the hit, which drives the struck car forward
   * along its own heading (see RaceDriver.pushForward) — instead of the
   * traffic-style shove + spin + coast that parks both cars. A pair travelling
   * at the same pace are leaning on each other, not colliding, so they lose
   * nothing and keep racing.
   */
  _resolveFieldCollisions() {
    for (const r of this.rivals) {
      if (r.hidden) continue;
      // The racer records the pose it swept from this frame, so the contact
      // sweep tests the same segment the car actually travelled.
      const prevX = r.prevX ?? r.state.x;
      const prevZ = r.prevZ ?? r.state.z;
      const others = [];
      for (const o of this.rivals) if (o !== r && !o.hidden) others.push(o);
      if (this.player) others.push(this.player);
      // Arcade: tiny yaw kick, most speed kept. Trading paint is part of
      // racing; being spun onto the pavement is not.
      const hit = resolveVehicleCollision(r, others, prevX, prevZ, {
        spinScale: 0.22,
        arcade: true,
      });
      if (hit) {
        const preR = r.state.speed;
        r.state.speed = clamp(hit.slowedSpeed, -CAR.maxReverse, CAR.maxSpeed);
        if (hit.resolveX !== undefined) {
          r.state.x = hit.resolveX;
          r.state.z = hit.resolveZ;
        }
        // Trading paint marks the rival: dent the face toward the other car,
        // severity from pre-impact pace plus the scrub taken.
        try {
          const drop = Math.abs(preR) - Math.abs(r.state.speed);
          const sev = Math.max(impactSeverity(Math.abs(preR)), drop > 0.5 ? 0.12 : 0);
          if (sev > 0 && r.damage) {
            const ddx = r.state.x - hit.hitX;
            const ddz = r.state.z - hit.hitZ;
            const dd = Math.hypot(ddx, ddz) || 1;
            const ux = ddx / dd;
            const uz = ddz / dd;
            const ext = ((r.rig?.halfLength ?? 2.15) + (r.rig?.halfWidth ?? 0.95)) / 2;
            r.damage.recordHit({
              x: r.state.x - ux * ext,
              y: r.state.y + 0.8,
              z: r.state.z - uz * ext,
              dirX: ux,
              dirZ: uz,
              severity: sev,
              speed: preR,
              cx: r.state.x,
              cz: r.state.z,
              heading: r.state.heading,
              carY: r.state.y,
            });
          }
        } catch {
          /* dents are cosmetic: never fail a crash */
        }
        // Report the contact back to the driver: fresh contact buys extra
        // following gap (see _bumpCooldown), so the pair separates instead
        // of grinding frame after frame.
        r._bumpCooldown = 1.2;
      }
      if (this.traffic?.vehicles?.length) {
        const t = resolveVehicleCollision(r, this.traffic.vehicles, prevX, prevZ, {
          spinScale: 0.3,
          arcade: true,
        });
        if (t) {
          const preT = r.state.speed;
          r.state.speed = clamp(t.slowedSpeed, -CAR.maxReverse, CAR.maxSpeed);
          try {
            const drop = Math.abs(preT) - Math.abs(r.state.speed);
            const sev = Math.max(impactSeverity(Math.abs(preT)), drop > 0.5 ? 0.12 : 0);
            if (sev > 0 && r.damage) {
              const ddx = r.state.x - t.hitX;
              const ddz = r.state.z - t.hitZ;
              const dd = Math.hypot(ddx, ddz) || 1;
              const ux = ddx / dd;
              const uz = ddz / dd;
              const ext = ((r.rig?.halfLength ?? 2.15) + (r.rig?.halfWidth ?? 0.95)) / 2;
              r.damage.recordHit({
                x: r.state.x - ux * ext,
                y: r.state.y + 0.8,
                z: r.state.z - uz * ext,
                dirX: ux,
                dirZ: uz,
                severity: sev,
                speed: preT,
                cx: r.state.x,
                cz: r.state.z,
                heading: r.state.heading,
                carY: r.state.y,
              });
            }
          } catch {
            /* dents are cosmetic: never fail a crash */
          }
          r._bumpCooldown = 1.2;
        }
      }
    }
  }

  /** Flag (and clear) driving the wrong way. Measured against the bearing to
   *  the NEXT checkpoint, not the path tangent at the progress distance: on a
   *  track that doubles back on itself (an out-and-back sprint) the nearest-
   *  point search can lock onto the opposing branch and read a correct heading
   *  as "wrong way". The next gate is always unambiguously ahead on the route.
   *
   *  Only meaningful mid-race: a finished car has run out of gates to be told
   *  about, and the arc it would be judged against is the finish line itself -
   *  behind the car by then - so a finished run always decays instead. */
  _updateWrongWay(dt) {
    const decay = () => (this.wrongWay = Math.max(0, this.wrongWay - dt * 2));
    if (this.playerProgress?.finished) return decay();
    const gate = this.track.gates?.[this.playerProgress.gate];
    const moving = Math.abs(this.player.state.speed) > 4;
    if (!gate || !moving) return decay();
    const dx = gate.x - this.player.state.x;
    const dz = gate.z - this.player.state.z;
    // Too close to the gate to judge a bearing reliably (it flips as you pass).
    if (Math.hypot(dx, dz) < 10) return decay();
    const dot = Math.cos(Math.atan2(dx, dz) - this.player.state.heading);
    if (dot < -0.35) this.wrongWay += dt;
    else decay();
  }

  // ---------------------------------------------------------------- results

  /**
   * Live standings. Finishers are ranked by their time; everyone else by how far
   * round the circuit they are, which is what a race position means.
   */
  _computeStandings() {
    const entries = [];
    for (const r of this.rivals) {
      entries.push({
        name: r.name,
        isPlayer: false,
        finished: r.progress.finished,
        finishTime: r.progress.finishTime,
        total: r.progress.total,
        lap: r.progress.lap,
        gate: r.progress.gate,
        checkpoints: r.progress.checkpointsPassed,
      });
    }
    entries.push({
      name: "You",
      isPlayer: true,
      finished: this.playerProgress.finished,
      finishTime: this.playerProgress.finishTime,
      total: this.playerProgress.total,
      lap: this.playerProgress.lap,
      gate: this.playerProgress.gate,
      checkpoints: this.playerProgress.checkpointsPassed,
    });
    entries.sort((a, b) => {
      if (a.finished !== b.finished) return a.finished ? -1 : 1;
      if (a.finished) return a.finishTime - b.finishTime;
      return b.total - a.total;
    });
    const leader = entries[0];
    for (let i = 0; i < entries.length; i++) {
      entries[i].position = i + 1;
      entries[i].gap = Math.max(0, (leader.total ?? 0) - (entries[i].total ?? 0));
    }
    this.results = entries;
    this.playerPosition = entries.find((e) => e.isPlayer)?.position ?? entries.length;
    return entries;
  }

  /** Called once the player crosses the line. */
  _onPlayerFinished() {
    this.state = RACE_STATE.FINISHED;
    this.cineActive = true;
    this.finishT = 0;
    this._finishA0 = null;
    // The wrong-way warning dies with the race: from here the player is rolling
    // out while the beat panel and standings come up, and a "WRONG WAY" banner
    // over the results reads as the game having misjudged the finish. Cleared
    // outright rather than left to decay so it cannot be on screen when the
    // results land.
    this.wrongWay = 0;
    this._computeStandings();
  }

  /** Hand control back after the finish cinematic: board away, chase cam back. */
  continueAfterFinish() {
    if (this.state !== RACE_STATE.FINISHED) return false;
    this.cineActive = false;
    this._returnToFreeRoam();
    return true;
  }

  /**
   * Abandon the event the player is currently in (pause menu -> Quit Race):
   * end it immediately and hand the open world back, exactly like the finish
   * hand-off. A no-op when no event is running.
   */
  abandonRace() {
    if (this.state === RACE_STATE.IDLE || this.state === RACE_STATE.ARMED) return false;
    this.cineActive = false;
    this.results = [];
    this.message = "";
    this.wrongWay = 0;
    this._returnToFreeRoam();
    return true;
  }

  /**
   * Drop everything race-shaped and return to open-world traffic mode exactly
   * like pre-race: the road reopens to traffic, the field parks invisible, the
   * gates come down (the per-frame sync keeps them down), and re-arming waits
   * until the player has left the start zone - so the START offer doesn't pop
   * straight back up while still parked on the line.
   */
  _returnToFreeRoam() {
    this.state = RACE_STATE.IDLE;
    this._rearmLocked = true;
    this.fieldVisible = false;
    for (const r of this.rivals) {
      r.hidden = true;
      try {
        r.rig?.setVisible?.(false);
      } catch {
        /* rig already gone — hidden flag still hides it logically */
      }
    }
    if (this.traffic) {
      this.traffic.extraVehicles = [];
      if (this.traffic.circuitHeld) this.traffic.releaseCircuit();
    }
    this._setGatesLive(false);
    this._holdTimer = 0;
  }

  /**
   * Ideal orbit lens for this finish-cinematic instant (main.js eases the
   * real camera toward it). Circles the player's car while it rolls out,
   * tightening and lowering slightly as the results land.
   *
   * @returns {{ pos: Vector3, look: Vector3 }}
   */
  finishCamPose() {
    const st = this.player.state;
    if (this._finishA0 === null) {
      // Start on the chase side so there is no cut on the first frame.
      this._finishA0 = Math.atan2(-Math.sin(st.heading), -Math.cos(st.heading));
    }
    const a = this._finishA0 + this.finishT * 0.65;
    const radius = 11 - Math.min(this.finishT * 0.4, 2.5);
    const px = st.x + Math.sin(a) * radius;
    const pz = st.z + Math.cos(a) * radius;
    let py = st.y + 5 - Math.min(this.finishT * 0.35, 1.8);
    const g = this.collision?.groundAt?.(px, pz, py, { stepUp: 5, reach: 12 });
    if (g && g.y !== null && g.y !== undefined && py < g.y + 1.2) py = g.y + 1.2;
    return {
      pos: new Vector3(px, py, pz),
      look: new Vector3(st.x, st.y + 1.2, st.z),
    };
  }

  // ---------------------------------------------------------------- view

  /** Everything the HUD needs, recomputed once per frame. */
  get hudState() {
    const t = this.track;
    const entries = this.results;
    const lap = Math.min(this.playerProgress.lap + 1, t.laps);
    const intro = this.state === RACE_STATE.INTRO;
    const rawRank = entries.find((e) => e.isPlayer)?.position ?? entries.length;
    // Solo TIME / NO-COLLISION events have no field, so their podium place is
    // scored by the manager (time / contacts) and stamped on the event; a
    // place of 0 means the tier was missed (no reward).
    const scored = this.event.resolvedPlace;
    const playerRank = scored != null ? scored : rawRank;
    const onPodium = playerRank >= 1 && playerRank <= 3;
    // Winner's purse scales down the podium; a real race off the podium still
    // takes the flat 10% tip, but a missed solo tier pays nothing.
    const playerReward = onPodium
      ? (this.event.prizes[playerRank - 1]?.amount ?? 0)
      : playerRank >= 1 && (this.event.kind ?? "RACE") === "RACE"
        ? Math.round(this.event.prize * 0.1)
        : 0;
    const cine = this.state === RACE_STATE.FINISHED && this.cineActive;
    const beatenLine = beatenLineFor(entries, playerRank);
    return {
      state: this.state,
      countdown: this.countdown,
      goFlash: this.goFlash > 0,
      controlsLocked: this.controlsLocked,
      prompt: this.canStart,
      intro,
      introT01: intro ? Math.min(this.introT / INTRO_SECONDS, 1) : 0,
      // The event card holds, then fades while the camera keeps sweeping.
      introCard: intro && this.introT < INTRO_CARD_OUT,
      finishCine: this.state === RACE_STATE.FINISHED && this.cineActive,
      beat: cine && this.finishT >= BEAT_IN && this.finishT < BEAT_OUT,
      resultsReady: cine && this.finishT >= RESULTS_IN,
      beatenLine,
      playerRank,
      madePodium: onPodium,
      playerReward,
      playerFinishTime: this.playerProgress.finishTime ?? 0,
      // Live solo numbers: the hit count for NO-COLLISION, and the gap to the
      // 1st-place pace for TIME trials (negative = ahead of gold). Races keep
      // the raw circuit position (meaningless solo, where it is always P1).
      contactHits: this.player.contactHits ?? 0,
      goldGap:
        this.event.kind === "TIME"
          ? this.time - (this.playerProgress.total ?? 0) / TIME_SPEEDS[0]
          : null,
      inZone: this.state === RACE_STATE.ARMED || this.state === RACE_STATE.IDLE,
      position: entries.find((e) => e.isPlayer)?.position ?? entries.length,
      fieldSize: entries.length,
      lap,
      laps: t.laps,
      checkpoint: this.playerProgress.checkpointsPassed,
      checkpointTotal: Math.max(1, t.gateCount - 1),
      nextGate: this.playerProgress.gate,
      time: this.time,
      playerFinished: this.playerProgress.finished,
      wrongWay: this.wrongWay > 1.2,
      results: entries,
      message: this.message,
      trackName: t.name,
      eventName: this.event.name,
      eventType: this.event.type,
      eventDifficulty: this.event.difficulty,
      eventPrize: this.event.prize,
      eventMessage: this.event.message,
      eventTargetTime: this.event.targetTime ?? null,
      eventTargetHits: this.event.targetHits ?? null,
      eventKind: this.event.kind ?? "RACE",
      eventPrizes: this.event.prizes ?? [],
      // Multi-event navigation at same start location.
      colocCount: this.event.colocCount ?? 1,
      colocIndex: this.event.colocIndex ?? 0,
      colocEvents: this.event.colocEvents ?? [],
      eventState: this.event.state ?? "ACTIVE",
      bestPlace: this.event.bestPlace ?? 0,
      startDistance: Math.hypot(
        this.player.state.x - t.startPose.x,
        this.player.state.z - t.startPose.z,
      ),
    };
  }

  /** Compact view for the minimap: the circuit, the gates, and who is where. */
  getMinimapData() {
    const t = this.track;
    // Pre-race the field is hidden — there are no racer dots to draw, only
    // the event icon at the start line. Once the countdown spawns the field,
    // the dots come back. Despawned (finished + out of sight) rivals stay off
    // the map too — their dots would be ghosts of cars that are gone.
    const showRacers = !!this.fieldVisible && this.state !== RACE_STATE.IDLE;
    // Same rule for the checkpoint dots and the circuit line as for the 3D
    // gates: nothing race-shaped on the map until the event runs — pre-race
    // the minimap shows only the green event diamond.
    const showGates =
      this.state === RACE_STATE.INTRO ||
      this.state === RACE_STATE.COUNTDOWN ||
      this.racing;
    return {
      visible: true,
      active: this.racing,
      armed: this.state === RACE_STATE.ARMED,
      state: this.state,
      inRace:
        this.state === RACE_STATE.INTRO ||
        this.state === RACE_STATE.COUNTDOWN ||
        this.state === RACE_STATE.RACING,
      // The event diamond lives only outside the event: it marks where to
      // go before the race, hides for the whole run (countdown included -
      // the track, gates and arrows already say where everything is), and
      // comes back once the event is completely over (back to IDLE).
      event:
        this.state === RACE_STATE.IDLE || this.state === RACE_STATE.ARMED
          ? {
              x: t.startPose.x,
              z: t.startPose.z,
              heading: t.startPose.heading,
              idle: this.state === RACE_STATE.IDLE || this.state === RACE_STATE.ARMED,
            }
          : null,
      points: showGates ? t.points : [],
      start: t.startPose,
      gates: showGates ? t.gates : [],
      nextGate: this.playerProgress.gate,
      lap: this.playerProgress.lap,
      laps: t.laps ?? 1,
      finished: !!this.playerProgress.finished,
      isLastLap: this.playerProgress.lap >= (t.laps ?? 1) - 1 || !!this.playerProgress.finished,
      // Reveal-window support for the collapsed follow minimap (see
      // minimap.js): the player's authoritative along-track metres plus the
      // track's own length, openness and arclength-parameterized path, so a
      // local stretch can draw (upcoming revealed, passed fading) instead of
      // the whole circuit. Reads only - loading/race logic untouched.
      playerS: this.playerProgress.distance ?? 0,
      trackLength: t.length ?? 0,
      trackOpen: !!t.open,
      trackPath: t.path ?? null,
      racers: showRacers
        ? this.rivals
            .filter((r) => !r.hidden)
            .map((r) => ({
              x: r.state.x,
              z: r.state.z,
              heading: r.state.heading,
              finished: r.progress.finished,
            }))
        : [],
    };
  }

  /** Machine-readable report for the headless probes and the debug overlay. */
  debugReport() {
    return {
      state: this.state,
      time: Number(this.time.toFixed(2)),
      position: this.playerPosition ?? null,
      fieldSize: this.field.length + 1,
      track: this.track.stats,
      laps: this.track.laps,
      startPose: {
        x: Number(this.track.startPose.x.toFixed(2)),
        y: Number(this.track.startPose.y.toFixed(2)),
        z: Number(this.track.startPose.z.toFixed(2)),
        headingDeg: Number(((this.track.startPose.heading * 180) / Math.PI).toFixed(1)),
      },
      grid: this.track.grid.map((g) => ({
        slot: g.slot,
        x: Number(g.x.toFixed(2)),
        z: Number(g.z.toFixed(2)),
        headingDeg: Number(((g.heading * 180) / Math.PI).toFixed(1)),
      })),
      warnings: this.track.warnings,
      playerProgress: {
        lap: this.playerProgress.lap,
        gate: this.playerProgress.gate,
        checkpoints: this.playerProgress.checkpointsPassed,
        total: Number(this.playerProgress.total.toFixed(1)),
        finished: this.playerProgress.finished,
      },
      rivals: this.rivals.map((r) => ({
        name: r.name,
        pace: r.pace,
        cruise: r.cruiseSpeed,
        hidden: !!r.hidden,
        laps: r.progress.lap,
        gate: r.progress.gate,
        total: Number(r.progress.total.toFixed(1)),
        finished: r.progress.finished,
        finishTime: r.progress.finished ? Number(r.progress.finishTime.toFixed(2)) : null,
        stats: r.stats,
        target: r.debugInfo().target,
        blocker: r.debugInfo().blocker,
        stuck: r.debugInfo().stuck,
        recover: r.debugInfo().recover,
        rig: r.rig.diagnostics,
        state: {
          x: Number(r.state.x.toFixed(2)),
          y: Number(r.state.y.toFixed(2)),
          z: Number(r.state.z.toFixed(2)),
          speed: Number(r.state.speed.toFixed(2)),
        },
      })),
      results: this.results.map((e) => ({
        position: e.position,
        name: e.name,
        isPlayer: e.isPlayer,
        finished: e.finished,
        time: e.finished ? Number(e.finishTime.toFixed(2)) : null,
        gap: Number((e.gap ?? 0).toFixed(1)),
      })),
    };
  }

  /**
   * Drive the race from outside the game loop (headless probes): jump the
   * player to the start, run the countdown out, and optionally fast-forward the
   * field by stepping the whole system at a fixed timestep.
   */
  debugForceStart() {
    const t = this.track;
    this.player.state.x = t.startPose.x;
    this.player.state.z = t.startPose.z;
    this.player.state.y = t.startPose.y;
    this.player.state.heading = t.startPose.heading;
    // A debug teleport must not carry race speed into the offer check.
    this.player.state.speed = 0;
    this.state = RACE_STATE.ARMED;
    this.requestStart();
    return this.state;
  }

  /**
   * Step the race (and the player) at a fixed timestep, without rendering.
   *
   * By default the player is driven by `_autopilot`, so a probe can run a whole
   * race with nobody at the wheel. That matters: the previous stepper held the
   * throttle down with no steering, so the player drove blindly forward off its
   * grid slot straight into the car ahead and pinned it - a wrecking ball, not
   * a racer, and a poor way to ask whether the AI can drive. Pass
   * `{ autopilot: false }` for the old behaviour.
   */
  debugStep(seconds, step = 1 / 60, { autopilot = true } = {}) {
    const steps = Math.max(1, Math.round(seconds / step));
    for (let i = 0; i < steps; i++) {
      this.update(step, null);
      const locked = this.controlsLocked;
      // Same straight-line auto-brake the game loop applies while the finish
      // cinematic plays (see FINISH_BRAKE_INPUT in main.js), released at a
      // standstill so the car pins instead of reversing.
      const finishedBraking = 
        locked && this.state === RACE_STATE.FINISHED && this.player.state.speed > 0.5;
      const input = finishedBraking
        ? { steer: 0, throttle: 0, brake: 0.45, handbrake: false }
        : locked
          ? { steer: 0, throttle: 0, brake: 0, handbrake: false }
          : autopilot
            ? this._autopilot(step)
            : { steer: 0, throttle: 1, brake: 0, handbrake: false };
      this.player.update(step, input);
      this.player.spin(step);
    }
    return this.debugReport();
  }

  /**
   * A minimal circuit autopilot for the player, so the headless stepper can run
   * a real race. It follows the same `path` as the rivals with the same pursuit
   * law and a corner-speed limit, and exposes only the input the player's car
   * understands - it is a probe convenience, not a second AI.
   */
  _autopilot(dt = 1 / 60) {
    const path = this.track.path;
    const s = this.playerProgress.distance;
    const state = this.player.state;
    const speed = Math.abs(state.speed);
    const lookAhead = clamp(7 + speed * 0.6, 9, 20);
    const target = path.sample(s + lookAhead);
    const here = path.sample(s);
    const lateral =
      (here.x - state.x) * Math.cos(state.heading) - (here.z - state.z) * Math.sin(state.heading);
    const desired = Math.atan2(target.x - state.x, target.z - state.z);
    const diff = wrapAngle(desired - state.heading);
    const steer = clamp(-diff * 1.6 - lateral * 0.14, -1, 1);

    // Corner limit: the slowest speed from which the next stretch is reachable,
    // from the same grip figure the rivals use. Deliberately conservative - a
    // probe driver that overshoots a hairpin wedges on the kerb and blocks the
    // field it is supposed to be racing.
    let limit = 20;
    let prev = this._pathHeading(s);
    for (let d = 3; d <= 12 + speed * 4; d += 3) {
      const cur = this._pathHeading(s + d);
      const turn = wrapAngle(cur - prev);
      prev = cur;
      const radius = Math.abs(turn) > 1e-4 ? 3 / Math.abs(turn) : Infinity;
      const corner = Math.sqrt(CAR.maxLateralAccel * 0.7 * radius);
      limit = Math.min(limit, Math.sqrt(corner * corner + 2 * 5.5 * d));
    }
    const targetSpeed = clamp(limit, 5, 20);

    // Unstick: if pinned for a while, back out with opposite lock, then try
    // again. A human does this without thinking; without it the probe driver
    // leans on the same kerb for the rest of the race.
    if (speed < 1.5) this._autoStuck += dt;
    else this._autoStuck = Math.max(0, this._autoStuck - dt * 2);
    if (this._autoStuck > 1.2) {
      if (this._autoStuck > 3.2) this._autoStuck = 0;
      return { steer: clamp(-steer, -1, 1), throttle: 0, brake: 1, handbrake: false };
    }

    return {
      steer,
      throttle: speed < targetSpeed ? 1 : 0,
      brake: speed > targetSpeed + 0.6 ? 0.7 : 0,
      handbrake: false,
    };
  }

  /** Direction of travel of the circuit `s` metres along it. */
  _pathHeading(s) {
    const a = this.track.path.sample(s - 1);
    const b = this.track.path.sample(s + 1);
    return Math.atan2(b.x - a.x, b.z - a.z);
  }

  /** Advance the player along the circuit by arc length (probe helper). */
  debugSkipPlayerTo(distance) {
    const p = this.track.path.sample(distance);
    this.player.state.x = p.x;
    this.player.state.z = p.z;
    this.player.state.y = p.y;
    const a = this.track.path.sample(distance - 2);
    const b = this.track.path.sample(distance + 2);
    this.player.state.heading = Math.atan2(b.x - a.x, b.z - a.z);
    this.playerProgress.resync(p.x, p.z);
  }
}

function wrapAngle(a) {
  let x = a;
  while (x > Math.PI) x -= Math.PI * 2;
  while (x < -Math.PI) x += Math.PI * 2;
  return x;
}

/**
 * Results sub-headline, always truthful to the actual result. Real races name
 * a rival (the beaten runner-up on a win, the winner otherwise); solo TIME /
 * NO-COLLISION runs have no field, so they name the target/tier instead -
 * never a phantom "win". Pure (entries + rank in, text out) for unit tests.
 */
export function beatenLineFor(entries, playerRank) {
  const list = entries ?? [];
  const solo = !list.some((e) => !e.isPlayer);
  if (!(playerRank >= 1)) return "NO PODIUM";
  if (playerRank === 1) {
    if (solo) return "YOU BEAT THE TARGET";
    const runnerUp = list.find((e) => !e.isPlayer && e.position === 2)?.name ?? "THE PACK";
    return `YOU BEAT THE ${runnerUp}`;
  }
  if (solo) return `TIER ${playerRank}`;
  const winner = list.find((e) => !e.isPlayer && e.position === 1)?.name ?? "THE PACK";
  return `${winner} TAKES THE WIN`;
}

/**
 * The event this circuit sells. Priced and graded from the total race
 * distance so a long multi-lap event pays more than a short one - but always
 * in garage dollars, on a progression curve where ~5-6 winning races earn
 * the cheapest new car (Beetle, $9,500): a typical ~1.5-2 km event pays
 * ~$1,500-2,000 for the win, with the podium paying partial.
 */
function makeRaceEvent(track, def = null) {
  const total = Math.round(track.length * track.laps);
  let hash = 0;
  for (const ch of String(def?.id ?? track.id ?? "race")) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  const first = Math.round(total / 100) * 100;
  // Display type: authored events carry their own kind; the legacy circuit
  // derives it from lap count.
  let type = track.laps > 1 ? "CIRCUIT" : "SPRINT";
  if (def?.type === "TIME") type = "TIME TRIAL";
  else if (def?.type === "NOCOLLIDE") type = "NO CONTACT";
  const event = {
    id: def?.id ?? track.id,
    kind: def?.type ?? "RACE", // RACE | TIME | NOCOLLIDE (scoring family)
    open: !!track.open,
    laps: track.laps,
    traffic: !!def?.traffic,
    name: def?.name ?? EVENT_NAMES[hash % EVENT_NAMES.length],
    type,
    difficulty:
      (def?.order ?? 10) >= 240
        ? "EXPERT"
        : (def?.order ?? 10) >= 150
        ? "HARD"
        : (def?.order ?? 10) >= 70
        ? "MEDIUM"
        : "EASY",
    prize: first,
    // Loading-card payouts: the win pays full, the podium pays partial.
    prizes: [
      { label: "FINISH 1ST", amount: first },
      { label: "FINISH 2ND", amount: Math.round(first * 0.6) },
      { label: "FINISH 3RD", amount: Math.round(first * 0.3) },
    ],
    message: "Finish to claim reward",
  };
  // TIME trials: the podium is a time, not a position. Stamp the target times
  // on the event + prizes so the board, prompt, card and results can show
  // "finish under M:SS.hh for 1st" and the time required for each place.
  if (def?.type === "TIME") {
    const dist = track.length * track.laps;
    // An event can pin its own tiers (see targetTimes); otherwise they fall
    // out of the global average-speed tiers over the measured distance.
    const tierTimes = def?.targetTimes ?? TIME_SPEEDS.map((v) => dist / v); // seconds for 1st/2nd/3rd
    event.tierTimes = tierTimes;
    event.targetTime = tierTimes[0];
    event.prizes = event.prizes.map((p, i) => ({ ...p, time: tierTimes[i] }));
    event.message = `Finish under ${fmtClock(tierTimes[0])} for 1st`;
  }
  // NO-COLLISION trials: the podium is a hit count, not a position. Stamp the
  // per-place hit ceilings on the prizes so the prompt, loading card and
  // results can show "0 hits for 1st" etc., mirroring the TIME target times.
  else if (def?.type === "NOCOLLIDE") {
    event.prizes = event.prizes.map((p, i) => ({ ...p, hits: HIT_TIERS[i] }));
    event.targetHits = HIT_TIERS[0];
    event.message = "Don't get hit — 0 hits for 1st";
  }
  return event;
}

/** Seconds -> rounded `M:SS` (tier targets show no milliseconds). */
function fmtClock(seconds) {
  const total = Math.max(0, Math.round(seconds ?? 0));
  const m = Math.floor(total / 60);
  return `${m}:${String(total - m * 60).padStart(2, "0")}`;
}
