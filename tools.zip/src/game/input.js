/**
 * Keyboard input -> an intent object consumed by the player vehicle.
 * steer is +1 for left, -1 for right, matching the driving model.
 *
 * An optional TouchControls instance is merged in, so on-screen
 * pedals/steering feed the same intent the keyboard does (either
 * source alone is enough; both together just sum).
 */
const KEY_MAP = {
  ArrowUp: "up",
  ArrowDown: "down",
  ArrowLeft: "left",
  ArrowRight: "right",
  KeyW: "up",
  KeyS: "down",
  KeyA: "left",
  KeyD: "right",
  Space: "handbrake",
  KeyR: "reset",
  KeyC: "camera",
  // Testing probe keys (see src/game/coordProbe.js; active with ?testing=1).
  KeyX: "coords",
  KeyZ: "capture",
};

export function createInput(target = window, touch = null) {
  const held = new Set();
  const pressed = new Set();
  const heldCodes = new Set();

  const onKeyDown = (e) => {
    const action = KEY_MAP[e.code];
    if (!action) return;
    heldCodes.add(e.code);
    if (!e.repeat) pressed.add(action);
    held.add(action);
    touch?.setKeyActive?.(action, true);
    // stop the page scrolling while driving
    if (["up", "down", "left", "right", "handbrake"].includes(action)) e.preventDefault();
  };
  const onKeyUp = (e) => {
    heldCodes.delete(e.code);
    const action = KEY_MAP[e.code];
    if (action) {
      // Only release the action if no other key mapped to it is still held (e.g. W and ArrowUp)
      const stillHeld = Object.entries(KEY_MAP).some(
        ([code, act]) => act === action && heldCodes.has(code)
      );
      if (!stillHeld) {
        held.delete(action);
        touch?.setKeyActive?.(action, false);
      }
    }
  };
  const onBlur = () => {
    heldCodes.clear();
    held.clear();
    touch?.clearKeys?.();
  };

  target.addEventListener("keydown", onKeyDown);
  target.addEventListener("keyup", onKeyUp);
  target.addEventListener("blur", onBlur);

  return {
    get steer() {
      const keys = (held.has("left") ? 1 : 0) - (held.has("right") ? 1 : 0);
      if (!touch) return keys;
      return Math.max(-1, Math.min(1, keys + touch.steer));
    },
    get throttle() {
      return held.has("up") || (touch ? touch.throttle > 0 : false) ? 1 : 0;
    },
    get brake() {
      return held.has("down") || (touch ? touch.brake > 0 : false) ? 1 : 0;
    },
    get handbrake() {
      return held.has("handbrake") || (touch ? touch.handbrake : false);
    },
    /** True exactly once per key press. */
    consumed(action) {
      if (!pressed.has(action)) return false;
      pressed.delete(action);
      return true;
    },
    /** Clears per-frame press tracking; call at the end of each frame. */
    endFrame() {
      pressed.clear();
    },
    dispose() {
      target.removeEventListener("keydown", onKeyDown);
      target.removeEventListener("keyup", onKeyUp);
      target.removeEventListener("blur", onBlur);
    },
  };
}
