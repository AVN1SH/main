import { Color3 } from "@babylonjs/core";

/**
 * The paint cycle, shared by the gas-station paint shop (the player) and the
 * race grid (the rivals).
 *
 * Six flat colours, then the FACTORY finish (null -> the model's original
 * base-colour texture and colour), so the stock car is part of the loop too.
 * Each entry is applied through `carDamage.paint`, which is per-car: it works
 * off the car's OWN paintable panel, detected from its material (emissive and
 * glass are excluded), so one palette works across every garage model
 * whatever their body mesh is called.
 */
export const CAR_PAINT = [
  new Color3(1.0, 0.09, 0.05), // red
  new Color3(0.04, 0.33, 1.0), // blue
  new Color3(1.0, 0.52, 0.03), // orange
  new Color3(0.05, 0.78, 0.28), // green
  new Color3(0.58, 0.09, 0.95), // purple
  new Color3(1.0, 0.85, 0.06), // yellow
  null, // factory finish (original texture + colour)
];

/**
 * Apply `CAR_PAINT[index]` to a car that owns a `damage` object with `paint`.
 * The index wraps (and accepts negatives), so callers can just keep counting.
 * Returns true when the paint was applied.
 */
export function paintAt(car, index) {
  const dmg = car?.damage;
  if (!dmg?.paint) return false;
  const i = ((index % CAR_PAINT.length) + CAR_PAINT.length) % CAR_PAINT.length;
  try {
    return dmg.paint(CAR_PAINT[i]) > 0;
  } catch {
    return false; // paint is cosmetic: never interrupt driving
  }
}
