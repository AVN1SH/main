/**
 * Shared driving model.
 *
 * Conventions used throughout the game (derived from the car asset, see
 * tools/analyze-car.mjs):
 *
 *   - A vehicle's heading `h` points along forward = (sin h, 0, cos h).
 *   - `heading` maps straight onto `root.rotation.y`.
 *   - Steering follows the bicycle model: yawRate = -(v / wheelBase) * tan(steer).
 *   - steer > 0 turns LEFT, steer < 0 turns RIGHT, matching `rotation.y = -steer`
 *     on the front wheel pivots.
 *
 * The sign choices are not arbitrary: Babylon is left-handed, so for a car
 * facing +Z with +Y up, +X is screen-right. Turning left must therefore reduce
 * the heading angle, which is why the yaw term is negated.
 */

export const CAR = {
  wheelBase: 2.35, // measured: front axle x=-0.87, rear axle x=+1.48
  wheelRadius: 0.305, // measured: wheel AABB is 0.61 across
  // Box used for terrain/collision queries (metres).
  length: 4.3,
  width: 1.9,
  height: 1.42,
  clearance: 0.26, // chassis underside above the ground
  maxSteer: 0.62, // rad, ~35 deg at a standstill
  steerRate: 3.6, // rad/s the wheels move toward the target angle
  /**
   * Seconds for the wheels to travel from centre to full lock, and back again.
   *
   * The rate used to be a flat 3.6 rad/s, but the angle the driver can command
   * shrinks with speed, so a constant rate made the high-speed lock arrive in a
   * few milliseconds: the wheel snapped between extremes and lost the
   * progressive build-up that makes low-speed steering feel right. Deriving the
   * rate from the available lock keeps the *time* to full lock constant, so the
   * steering feels the same at 20 km/h and at 200 km/h.
   */
  steerLockTime: 0.14,
  steerReturnTime: 0.1, // quicker to unwind than to wind on
  /**
   * How much more lock the driver gets than the tyres can actually use, once
   * the speed is high enough for the over-lock to matter. See
   * `commandedSteerAtSpeed`.
   *
   * The lock used to be an absolute angle (`steerLockFloor` of full lock from
   * `steerLockMinSpeed` upward) which was completely wrong at speed: only ~1.8
   * deg of that was ever used to generate a yaw rate, so 90% of the wheel's
   * travel moved the car not at all. Expressed as a ratio of the *usable*
   * angle instead, the dead part stays a fixed fraction of the lock at every
   * speed, so the steering always has resolution.
   */
  steerLockOver: 4,
  /**
   * Fraction of grip the handbrake leaves the tyres. Without this the handbrake
   * is purely longitudinal - it stops the car but cannot rotate it, so there is
   * no way to rotate the car at speed when the tyres are already saturated.
   */
  handbrakeGrip: 0.42,
  /**
   * Crash response against non-destructible geometry (walls, buildings,
   * fences, barriers). A blocked sweep used to zero the speed, so every hit
   * read as hitting a brick wall: the car stopped dead, mid-motion, with no
   * deflection and no rebound. These make the impact behave like an arcade
   * racer instead - the velocity is split about the surface normal, the
   * into-wall part is absorbed and partly returned as a rebound, the
   * along-wall part is scrubbed but kept, and a lateral hit twists the nose
   * away from the wall. See `PlayerVehicle.update`.
   *
   * `crashRestitution` is the fraction of the closing speed returned as
   * rebound (0 = stop dead, 1 = perfectly elastic). `crashTangentKeep` is the
   * fraction of the along-wall speed kept through a scrape. `crashSpin`/
   * `crashMaxSpin` are the yaw impulse per m/s of lateral closing speed and its
   * cap, in radians. `crashMinApproach` is the closing speed below which a
   * touch just slides/stops with no bounce, so creeping into a wall at parking
   * speed does not jitter the car back and forth.
   */
  crashRestitution: 0.22,
  crashTangentKeep: 0.72,
  crashSpin: 0.02,
  crashMaxSpin: 0.16,
  crashMinApproach: 0.8,
  maxSpeed: 62, // m/s (~223 km/h)
  maxReverse: 14,
  enginePower: 13, // m/s^2 at zero speed, tapering to 0 at maxSpeed
  brakePower: 26,
  reversePower: 6,
  dragK: 0.0016, // quadratic drag -> sets terminal speed feel
  rollResist: 1.4, // constant deceleration when coasting
  /**
   * Peak lateral acceleration the tyres can hold, in m/s^2 (~0.97 g, about
   * what a grippy road car manages). This is the real limit on cornering and is
   * what makes the turn radius grow with the square of speed. This is the AI
   * cars' figure - they plan corner speeds from it and are tuned around it.
   */
  maxLateralAccel: 9.5,
  /**
   * The PLAYER car's grip ramp, in m/s^2.
   *
   * Cornering ability is capped by the tightest arc the tyres can hold, and
   * that arc is v^2 / grip. With a flat grip the achievable yaw rate is
   * grip / v, which falls as 1/v: a car holding 55 deg/s at 115 km/h was down
   * to 28 deg/s at top speed, so the harder you went the *less* the car would
   * turn. Grip therefore has to keep climbing with speed, or steering authority
   * is lost exactly where the player needs it most.
   *
   * The curve is three pieces (`playerLateralAccelAt`):
   *
   *   - `playerGripLow` up to `playerGripRampStart`, i.e. the original figure.
   *     Parking and tight low-speed manoeuvres are bit-for-bit unchanged.
   *   - ramping to `playerGripHigh` at `playerGripRampEnd`. The ramp used to
   *     start at 18 m/s and that put a hole in the middle of the range: grip was
   *     still 9.5 at 65 km/h, so turn rate bottomed out at 30 deg/s there -
   *     a third less than at 36 km/h. It now starts at 12 m/s, below the dip.
   *   - past `playerGripRampEnd` it keeps climbing at `playerGripHighGain` per
   *     m/s. Holding `playerGripHigh` flat above the ramp end was the other half
   *     of the problem.
   *
   * Resulting player turn rate: 45 deg/s at 43 km/h, peaking at ~55 deg/s near
   * 115 km/h, and easing to ~47 deg/s at top speed - i.e. the car turns about as
   * hard at 200 km/h as it does at 60. The turn radius still grows with speed
   * (11 m -> 33 m -> 76 m), so speed reads correctly through the corners.
   *
   * These are arcade figures: `playerGripHigh` is ~3.2 g and the top-speed grip
   * is above 5 g, far past any real tyre. That is deliberate - at `maxLateral-
   * Accel` (9.5) the player car needed a 95 m radius at 108 km/h and a 213 m
   * radius at top speed, so full lock at speed produced a barely perceptible
   * change of direction and the car ploughed straight on. Lower `playerGrip-
   * HighGain` to bring the high-speed end down toward realism.
   *
   * The AI keeps `maxLateralAccel` unchanged: raising the shared constant would
   * also inflate the corner speeds the traffic planner aims for, and those were
   * tuned separately.
   */
  playerGripLow: 13,
  playerGripHigh: 33,
  playerGripRampStart: 8, // m/s (~29 km/h) - responsive grip comes in early
  playerGripRampEnd: 32, // m/s (~115 km/h) - peak turn rate reached here
  playerGripHighGain: 0.66, // extra m/s^2 of grip per m/s above the ramp end

  /**
   * Cosmetic tail-out skid (player only). A VISUAL yaw that swings the back of
   * the car out while the front holds its line, the way arcade racers show a
   * car "skidding" through a fast corner. Driven directly by the steer key (so
   * it responds the moment you turn, not after a slide develops) and wound out
   * faster/further under braking. Applied to the drawn body in
   * PlayerVehicle.sync() ONLY - the physics pose, heading and collision use the
   * true values, so the car keeps tracking its line and handling is unchanged.
   *
   *   skidYawMax         biggest visual slide angle (rad).
   *   skidYawBuild       steer-only wind-out rate (rad/s). Deliberately very
   *                      slow and speed-INDEPENDENT: the tail swings at the same
   *                      gentle angular speed at 60 or at 200 km/h, so reaching
   *                      the full slide takes ~2 s of held steering however fast
   *                      you are going (no instant snap at speed).
   *   skidYawBrakeBuild  wind-out rate while braking into the corner - a boost
   *                      over steer-only (a few times faster) but still a
   *                      gradual ease, never a snap, even at high speed.
   *   skidYawRecover     how fast it realigns when you straighten.
   */
  skidYawMax: 0.34,
  skidYawBuild: 0.15,
  skidYawBrakeBuild: 0.4,
  skidYawRecover: 1.8,
};

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

export const lerp = (a, b, t) => a + (b - a) * t;

/** Frame-rate independent smoothing factor for exponential approach. */
export const smoothFactor = (rate, dt) => 1 - Math.exp(-rate * dt);

/** Move `current` toward `target` by at most `maxDelta`. */
export function approach(current, target, maxDelta) {
  const d = target - current;
  if (Math.abs(d) <= maxDelta) return target;
  return current + Math.sign(d) * maxDelta;
}

/**
 * Tightest steer angle the tyres can actually use at a given speed, derived
 * from grip rather than from an arbitrary curve.
 *
 * Cornering demands a lateral acceleration of v * yawRate, and yawRate is
 * (v / wheelBase) * tan(steer). Solving that for the steer angle that produces
 * exactly `maxLateralAccel` gives the tightest turn the car can physically
 * hold at that speed:
 *
 *     steer = atan(maxLateralAccel * wheelBase / v^2)
 *
 * The result is a turn radius of v^2 / maxLateralAccel: tight when parking,
 * wide at speed. An earlier linear falloff allowed ~3 g at 60 km/h, which made
 * the car corner like it was on rails.
 *
 * This is the *tyre* limit, NOT the amount of lock the driver gets. It is
 * applied to the achieved yaw rate (see `stepVehicle`), not to the input angle.
 */
export function maxSteerAtSpeed(speed, lateralAccel = CAR.maxLateralAccel) {
  const v2 = Math.max(speed * speed, 1e-3);
  const gripLimited = Math.atan((lateralAccel * CAR.wheelBase) / v2);
  return Math.min(CAR.maxSteer, gripLimited);
}

/**
 * Steering lock the driver can actually command at a given speed.
 *
 * Clamping the wheel angle to `maxSteerAtSpeed` (which is what this used to do)
 * is what made high-speed steering feel broken. Physical grip only needs a
 * couple of degrees at 100 km/h, so the clamp collapsed the target angle to
 * ~1.4 deg and then multiplied it by the input:
 *
 *     target = input.steer * maxSteerAtSpeed(speed)
 *
 * The driver's input was therefore *deleted* at speed - hold full left lock at
 * 120 km/h and the wheels froze within a degree of straight while the car
 * ploughed on. Nothing on screen explained why, so it read as broken controls
 * rather than as a car at the limit of its grip.
 *
 * Real cars keep mechanical lock and understeer instead: you crank the wheel,
 * the front tyres saturate, the car washes wide, and the cranked wheels plus the
 * wide arc tell you to lift off. That is what happens here - the wheels follow
 * this commanded lock, and any angle the tyres cannot use is refused by the yaw
 * rate instead of being applied to the wheel.
 *
 * The lock is `steerLockOver` times the angle the tyres can actually use at
 * that speed, faded in on `gripRampT` so it starts at exactly 1.0 (full lock,
 * nothing scaled) and reaches the full over-lock at `playerGripRampEnd`. Being
 * a *ratio* is the point: the usable angle shrinks as ~1/v, so an absolute lock
 * figure left a growing share of the wheel's travel doing nothing - at top
 * speed 10 of the 12 degrees on screen were dead, and easing off the key did
 * not ease off the turn. Scaling by the usable angle keeps roughly a quarter of
 * the lock live everywhere, so there is always visible cranked-wheel
 * understeer to read *and* steering that responds to how far you turn in.
 */
export function commandedSteerAtSpeed(speed) {
  const v = Math.abs(speed);
  const usable = maxSteerAtSpeed(v, playerLateralAccelAt(v));
  const t = gripRampT(v);
  if (t <= 0) return usable;
  return Math.min(CAR.maxSteer, usable * (1 + (CAR.steerLockOver - 1) * t));
}

/** 0 at and below the ramp start, 1 at and above the ramp end. */
function gripRampT(speed) {
  const v = Math.abs(speed);
  const span = Math.max(CAR.playerGripRampEnd - CAR.playerGripRampStart, 1e-3);
  return clamp((v - CAR.playerGripRampStart) / span, 0, 1);
}

/**
 * The player car's peak lateral acceleration at a given speed, in m/s^2.
 *
 *   - `playerGripLow` at and below `playerGripRampStart`
 *   - ramping to `playerGripHigh` at `playerGripRampEnd`
 *   - then `playerGripHighGain` more per m/s, forever
 *
 * The AI cars use `CAR.maxLateralAccel` instead and are unaffected.
 */
export function playerLateralAccelAt(speed) {
  const v = Math.abs(speed);
  if (v <= CAR.playerGripRampStart) return CAR.playerGripLow;
  if (v <= CAR.playerGripRampEnd) {
    return CAR.playerGripLow + (CAR.playerGripHigh - CAR.playerGripLow) * gripRampT(v);
  }
  return CAR.playerGripHigh + CAR.playerGripHighGain * (v - CAR.playerGripRampEnd);
}


/**
 * Advance a kinematic bicycle model by dt.
 *
 * @param state  mutated in place
 * @param opts.grip  multiplier on tyre grip, so the handbrake can break the
 *   rear away (1 = full grip, 0 = no lateral force at all)
 * @param opts.lateralAccel  the car's peak lateral acceleration in m/s^2
 * @returns the yaw rate actually applied, which callers use for body roll.
 */
export function stepVehicle(state, dt, { throttle, brake, steerAngle, grip = 1, lateralAccel = CAR.maxLateralAccel, handbrake = false }) {
  const { speed } = state;

  // --- longitudinal ---
  let accel = 0;
  if (throttle > 0) {
    accel += throttle * CAR.enginePower * Math.max(0, 1 - speed / CAR.maxSpeed);
  }
  if (brake > 0) {
    if (handbrake) {
      // Handbrake stops the car and holds it stationary; it NEVER engages reverse gear!
      if (speed > 0.2) {
        accel -= brake * CAR.brakePower;
      } else if (speed < -0.2) {
        accel += brake * CAR.brakePower; // brake reverse motion to a stop
      } else {
        accel = 0;
        state.speed = 0;
      }
    } else {
      if (speed > 0.4) accel -= brake * CAR.brakePower;
      else accel -= brake * CAR.reversePower; // roll into reverse
    }
  }
  if (throttle === 0 && brake === 0) {
    accel -= Math.sign(speed) * CAR.rollResist;
    if (Math.abs(speed) < CAR.rollResist * dt) accel = 0;
  }
  accel -= CAR.dragK * speed * Math.abs(speed);

  let next = speed + accel * dt;
  // coasting friction and handbrake should not overshoot through zero
  if (handbrake && (Math.sign(next) !== Math.sign(speed) || Math.abs(next) < 0.05)) {
    next = 0;
  }
  if (throttle === 0 && brake === 0 && Math.sign(next) !== Math.sign(speed)) next = 0;
  state.speed = clamp(next, -CAR.maxReverse, CAR.maxSpeed);
  if (handbrake && Math.abs(state.speed) < 0.05) {
    state.speed = 0;
  }

  // --- yaw (bicycle model) ---
  //
  // `steerAngle` is whatever the driver asked for, which is more lock than the
  // tyres can always use. Cornering needs a lateral acceleration of v * yawRate,
  // so the tyres cap |yawRate| at maxLateralAccel / v. Asking for more lock than
  // that is refused HERE rather than by trimming the wheel angle: the car
  // understeers on exactly the same arc it could always manage, the wheels stay
  // cranked where the driver put them, and the extra input is visibly spent on
  // nothing. Without this the caller had to pre-clamp the angle, which is what
  // made high-speed steering look broken.
  const desiredYawRate = -(state.speed / CAR.wheelBase) * Math.tan(steerAngle);
  const lateralLimit = (lateralAccel * clamp(grip, 0, 1)) / Math.max(Math.abs(state.speed), 1e-3);
  const wanted = Math.abs(desiredYawRate);
  const yawRate = wanted > lateralLimit ? Math.sign(desiredYawRate) * lateralLimit : desiredYawRate;
  state.heading += yawRate * dt;

  // --- integrate position along heading ---
  const forwardX = Math.sin(state.heading);
  const forwardZ = Math.cos(state.heading);
  state.x += forwardX * state.speed * dt;
  state.z += forwardZ * state.speed * dt;

  return yawRate;
}

/** Distance rolled this frame, used to spin the wheels. */
export const rollDistance = (speed, dt) => speed * dt;

/**
 * Pure-pursuit steering for AI vehicles.
 *
 * @param state      current {x, z, heading, speed}
 * @param tx, tz     look-ahead target point on the lane
 * @returns steer angle in the same convention as the player (>0 = left)
 */
export function pursuitSteer(state, tx, tz, wheelBase = CAR.wheelBase, lookAhead = 12) {
  const dx = tx - state.x;
  const dz = tz - state.z;
  const forward = dx * Math.sin(state.heading) + dz * Math.cos(state.heading);
  // right vector for heading h is (cos h, 0, -sin h)
  const right = dx * Math.cos(state.heading) - dz * Math.sin(state.heading);

  // angle to the target, positive when the target is to the right
  const alpha = Math.atan2(right, Math.abs(forward) + 1e-3);
  // negate because our steer convention is positive = left
  return -Math.atan2(2 * wheelBase * Math.sin(alpha), lookAhead);
}

/**
 * Polyline that can be sampled by arc length. Used for traffic lanes so
 * vehicles stay evenly spaced regardless of how the points were densified.
 */
export class Path {
  /**
   * @param points densified lane points.
   * @param options.open  when true the path is an OPEN polyline: it does NOT
   *   join the last point back to the first, and `sample` clamps to
   *   [0, length] instead of wrapping. Traffic on an open path recycles from
   *   its end back to its start (see TrafficVehicle), which lets a route that
   *   cannot exist as a closed loop - a bridge crossing, an open-ended
   *   highway - still carry continuous traffic.
   */
  constructor(points, { open = false } = {}) {
    this.points = points;
    this.open = open;
    this.cum = [0];
    const n = points.length;
    // Closed loops add a final segment from the last point back to the first;
    // open paths do not, so the end is a real end.
    const segs = open ? n - 1 : n;
    for (let i = 1; i <= segs; i++) {
      const a = points[i - 1];
      const b = points[i % n];
      this.cum.push(this.cum[i - 1] + Math.hypot(b.x - a.x, b.z - a.z));
    }
    this.length = this.cum[segs];
  }

  /** Position (and lane height) at arc length `dist`; wraps (closed) or clamps (open). */
  sample(dist) {
    const n = this.points.length;
    let d;
    if (this.open) {
      d = Math.max(0, Math.min(this.length, dist));
    } else {
      d = dist % this.length;
      if (d < 0) d += this.length;
    }

    // binary search for the segment containing d
    let lo = 0;
    let hi = this.open ? n - 1 : n;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (this.cum[mid + 1] <= d) lo = mid + 1;
      else hi = mid;
    }
    const i = this.open ? Math.min(lo, n - 2) : Math.min(lo, n - 1);
    const a = this.points[i];
    const b = this.points[this.open ? Math.min(i + 1, n - 1) : (i + 1) % n];
    const segLen = this.cum[i + 1] - this.cum[i] || 1;
    const t = (d - this.cum[i]) / segLen;
    return { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), z: lerp(a.z, b.z, t) };
  }
}
