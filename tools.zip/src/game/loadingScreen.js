/**
 * Boot loading screen: LIMITLESS CITY over the city backdrop.
 *
 * Owns the `#overlay` DOM from first paint until the game is ready:
 *   - loading phase: fixed "Loading..." text with a fade in/out pulse,
 *   - ready phase: "Tap to Continue", resolving on click/tap or Enter/Space,
 *     then fading the overlay out. `onContinue` fires the instant the
 *     player taps through - before the fade starts - so the next screen
 *     can fade in behind the overlay instead of after it.
 *   - failure phase: a static error message (see showLoadingFailure).
 *
 * Replaces the old generic overlay; Babylon's own loading UI is never used
 * (the engine only shows it when displayLoadingUI() is called, which the
 * game does not do). Holds no game logic - main.js drives the phases.
 */
export function createLoadingScreen() {
  const overlay = document.getElementById("overlay");
  const statusEl = document.getElementById("overlay-text");
  let continued = false;

  function setStatus() {
    // Loading-phase copy is fixed by design: a pulsing "LOADING...".
    if (statusEl) statusEl.textContent = "LOADING...";
    overlay?.classList.remove("is-hidden", "is-ready", "is-error");
  }

  function ready(onContinue) {
    return new Promise((resolve) => {
      if (!overlay) {
        onContinue?.();
        resolve();
        return;
      }
      if (statusEl) statusEl.textContent = "Tap to Continue";
      overlay.classList.add("is-ready");
      const finish = () => {
        if (continued) return;
        continued = true;
        cleanup();
        // Hand over before the fade begins: the overlay (z-index 9999)
        // fades out on top of whatever opens here, so the raw 3D scene
        // is never exposed between the loading screen and the lobby.
        onContinue?.();
        overlay.classList.add("is-fading");
        window.setTimeout(() => {
          overlay.classList.add("is-hidden");
          overlay.classList.remove("is-ready", "is-fading");
          resolve();
        }, 480);
      };
      const onTap = (e) => {
        e.preventDefault();
        finish();
      };
      const onKey = (e) => {
        if (e.code === "Enter" || e.code === "Space") {
          e.preventDefault();
          finish();
        }
      };
      const cleanup = () => {
        overlay.removeEventListener("click", onTap);
        window.removeEventListener("keydown", onKey);
      };
      overlay.addEventListener("click", onTap);
      window.addEventListener("keydown", onKey);
    });
  }

  return { setStatus, ready };
}

/**
 * Fatal boot failure. Grabs the same DOM without an instance, so main()'s
 * catch block can use it after a partial boot.
 */
export function showLoadingFailure(message) {
  const overlay = document.getElementById("overlay");
  const statusEl = document.getElementById("overlay-text");
  overlay?.classList.remove("is-hidden", "is-ready");
  overlay?.classList.add("is-error");
  if (statusEl) statusEl.textContent = message || "Failed to start.";
}
