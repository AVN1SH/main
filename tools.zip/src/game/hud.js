/**
 * Dash cluster wiring: the digital speedo, the gearbox readout with
 * its gear ladder, the rev-based shift lights, the speed bar and the
 * pedal bars.
 *
 * Purely a view: `update` reads the player's live speed/gear plus the
 * pedal intent actually applied that frame, then writes to the DOM.
 * Every write is guarded by a change check - the loop calls `update`
 * 60 times a second and re-setting identical values would thrash
 * layout for nothing.
 */
import { CAR } from "./driving.js";

const GEAR_COUNT = 6;
/** Rev fraction (within the gear) where the last LED starts flashing. */
const REDLINE = 0.86;

export class Hud {
  constructor() {
    this.speedEl = document.getElementById("speed-value");
    this.gearEl = document.getElementById("gear-value");
    this.fillEl = document.getElementById("speed-fill");
    this.throttleEl = document.getElementById("throttle-fill");
    this.brakeEl = document.getElementById("brake-fill");
    this.leds = Array.from(document.querySelectorAll("#shift-lights i"));
    this.ladder = Array.from(document.querySelectorAll("#gear-ladder i"));
    this._cache = {};
  }

  /**
   * @param player the PlayerVehicle (speedKmh / gear / state.speed)
   * @param intent the pedal intent applied this frame (throttle/brake/
   *   handbrake), so the pedal bars mirror what the car is actually
   *   doing - including the auto-brake of the finish cinematic.
   */
  update(player, intent = {}) {
    // --- speed number ---------------------------------------------------
    const kmh = Math.max(0, Math.round(player.speedKmh));
    if (this._cache.kmh !== kmh) {
      this._cache.kmh = kmh;
      this.speedEl.textContent = String(kmh);
    }

    // --- speed bar: fraction of the car's top speed ---------------------
    const frac = Math.min(1, Math.abs(player.state.speed) / CAR.maxSpeed);
    // 0.2% steps: smooth motion without a style write every frame.
    const pct = Math.round(frac * 500) / 5;
    if (this._cache.pct !== pct) {
      this._cache.pct = pct;
      this.fillEl.style.setProperty("--fill", `${pct}%`);
    }

    // --- gear: big readout + ladder -------------------------------------
    const gear = player.gear; // "R" | "N" | "1".."6"
    if (this._cache.gear !== gear) {
      this._cache.gear = gear;
      this.gearEl.textContent = gear;
      this.gearEl.classList.toggle("is-neutral", gear === "N");
      this.gearEl.classList.toggle("is-reverse", gear === "R");
      // Ladder order: R, N, then 1-6.
      const active = gear === "R" ? 0 : gear === "N" ? 1 : Number(gear) + 1;
      this.ladder.forEach((seg, i) => seg.classList.toggle("is-active", i === active));
    }

    // --- shift lights: revs sweep the current gear's band ---------------
    // The gearbox spreads the top speed over 6 gears, so the local
    // fraction inside the active band is the "rev" the LEDs show.
    let rev = 0;
    if (gear !== "N" && gear !== "R") {
      const g = Number(gear);
      rev = Math.min(1, Math.max(0, frac * GEAR_COUNT - (g - 1)));
    }
    const lit = Math.ceil(rev * this.leds.length);
    const flash = rev >= REDLINE;
    const sig = lit * 2 + (flash ? 1 : 0);
    if (this._cache.revSig !== sig) {
      this._cache.revSig = sig;
      this.leds.forEach((led, i) => {
        led.classList.toggle("is-lit", i < lit);
        led.classList.toggle(
          "is-flash",
          flash && i === this.leds.length - 1,
        );
      });
    }

    // --- pedal bars ------------------------------------------------------
    // Mirror the applied intent: handbrake eats the throttle, so it
    // shows as full brake instead (see PlayerVehicle.update).
    const thr = Math.round((intent.throttle ?? 0) * 100);
    const brk = Math.round((intent.handbrake ? 1 : intent.brake ?? 0) * 100);
    if (this._cache.thr !== thr) {
      this._cache.thr = thr;
      this.throttleEl.style.width = `${thr}%`;
    }
    if (this._cache.brk !== brk) {
      this._cache.brk = brk;
      this.brakeEl.style.width = `${brk}%`;
    }
  }
}
