/**
 * Boot-time asset preloader.
 *
 * Everything the 3D game needs is already parsed into asset containers during
 * the loading screen (the map, the player car, the whole traffic fleet and the
 * whole race/garage car set - see main.js). What is *not* loaded at that point
 * are the DOM-level assets: the lobby key art and the repair jingle. Those used
 * to fetch lazily the first time the lobby (or a repair pad) showed, so the
 * images popped in a beat after the boot screen lifted.
 *
 * This module front-loads them onto the loading screen instead:
 *   - images are decoded (`img.decode()`), so they paint on the first frame
 *     they are shown, not after a fetch + decode;
 *   - audio is loaded to `canplaythrough`, so the first repair plays instantly.
 *
 * Every load is wrapped so a single failure (or a stalled request) can never
 * block the boot - it resolves and the game continues.
 */
import { ALL_SOUND_URLS } from "./soundManager.js";

/** UI images referenced by index.html / pause.css. */
export const PRELOAD_IMAGES = [
  "assets/images/loading.webp",
  "assets/images/lobby.webp",
  "assets/images/lobby_head_to_head.jpg",
  "assets/images/logo.png",
  "assets/images/finish-flag.png",
];

/**
 * Sound files the game plays (the engine audio is synthesised, not a file).
 * Single source of truth lives in soundManager.js (`ALL_SOUND_URLS`) so adding
 * a file there preloads it here with no second list to maintain. Kept as an
 * explicit export for anything that imports PRELOAD_AUDIO directly.
 */
export const PRELOAD_AUDIO = [...ALL_SOUND_URLS];

/** Hard cap so a hung request cannot hold the loading screen forever. */
const LOAD_TIMEOUT_MS = 10000;

/** Fetch + DECODE an image so it is ready to paint the moment it is shown. */
function preloadImage(url) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      resolve(url);
    };
    try {
      const img = new Image();
      img.onload = () => {
        // decode() warms the decode cache too, so the first paint has zero cost.
        if (typeof img.decode === "function") img.decode().then(finish, finish);
        else finish();
      };
      img.onerror = finish;
      img.src = url;
      window.setTimeout(finish, LOAD_TIMEOUT_MS);
    } catch {
      finish();
    }
  });
}

/** Load a sound file to `canplaythrough` so its first play is instant. */
function preloadAudio(url) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      resolve(url);
    };
    try {
      const audio = new Audio();
      audio.preload = "auto";
      audio.addEventListener("canplaythrough", finish, { once: true });
      audio.addEventListener("loadeddata", finish, { once: true });
      audio.addEventListener("error", finish, { once: true });
      audio.src = url;
      audio.load();
      window.setTimeout(finish, LOAD_TIMEOUT_MS);
    } catch {
      finish();
    }
  });
}

/**
 * Load every DOM-level asset. Never rejects.
 *
 * @param {object}   [opts]
 * @param {Function} [opts.onProgress] called as (loaded, total) on each finish.
 * @returns {Promise<{ images: number, audio: number, total: number }>}
 */
export async function preloadAssets({ onProgress = null } = {}) {
  const jobs = [
    ...PRELOAD_IMAGES.map((url) => () => preloadImage(url)),
    ...PRELOAD_AUDIO.map((url) => () => preloadAudio(url)),
  ];
  const total = jobs.length;
  let loaded = 0;

  await Promise.all(
    jobs.map((run) =>
      run().then(() => {
        loaded += 1;
        try {
          onProgress?.(loaded, total);
        } catch {
          /* progress feedback must never break loading */
        }
      }),
    ),
  );

  return { images: PRELOAD_IMAGES.length, audio: PRELOAD_AUDIO.length, total };
}
