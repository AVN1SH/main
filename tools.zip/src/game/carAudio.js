import { CAR } from "./driving.js";

/**
 * Procedural car audio - no sound files, everything synthesised live.
 *
 * The engine is NOT a bank of oscillators (that always sounds like an
 * electrical synth drone). It is a physically-shaped COMBUSTION model running
 * on an AudioWorklet, per sample on the audio thread:
 *
 *   - a pulse train fires one combustion event per cylinder at the engine's
 *     firing rate (rpm/60 x cylinders/2 for a 4-stroke), so the rate - and the
 *     pitch - rises with revs exactly like a real motor;
 *   - each firing is an impulse injected into a bank of tuned two-pole
 *     resonators that model the exhaust/body formants: the low ones (40-80 Hz)
 *     give the deep growl, the higher ones the rasp. This ringing is what makes
 *     it sound like a pipe with gas pulsing through it rather than a buzzer;
 *   - per-cylinder timing/intensity jitter and an uneven firing pattern give
 *     the lumpy idle lope and stop it sounding mechanically perfect (the dead
 *     giveaway of a synth);
 *   - a load-dependent low-pass + tanh soft-clip open the sound up and add
 *     exhaust grit as the throttle comes in.
 *
 * On top ride three noise-based event layers (naturally broadband, so they
 * already sound real): tyre skid (keyed off slip), brake squeal, and wind.
 *
 * Each garage car maps to a profile that retunes the combustion model to match
 * the car's character; swapping cars just reconfigures the one live engine.
 */

/**
 * Per-car-type engine voices for the combustion model.
 *
 * The note blends a SMOOTH harmonic body (phase-locked partials at the firing
 * fundamental - the thing that makes a modern Audi/BMW read as a turbine-smooth
 * engine rather than a retro putt-putt) with a combustion TEXTURE (impulses
 * through exhaust resonators). Keep `tone` dominant for a clean modern voice,
 * `texture` for grit.
 *
 *   cylinders            firings per cycle (4 = compact, 8 = dense V8)
 *   idleRpm / maxRpm     rev range -> firing frequency (pitch). Low idle = the
 *                        slow, lazy idle of a big modern engine.
 *   partials [{n,g}]     harmonic body: n = multiple of the firing fundamental
 *                        (0.5 = half-order sub rumble, 1 = fundamental, 2..=
 *                        overtones), g = level. This carries the depth.
 *   formants [{f,r,g}]   combustion-texture resonances (f Hz, r ring, g mix)
 *   tone / texture       blend of body vs grit
 *   jitter / uneven      firing roughness + bank imbalance (low = smooth modern,
 *                        high = lumpy/vintage). Keep low to avoid a retro feel.
 *   turbo                1 adds induction whoosh + a blow-off on up-shifts
 *   noiseLevel           intake air
 *   drive                tanh pre-gain (bark); keep modest or it turns gritty
 *   bright               base low-pass openness; level/volume are mix gains
 */
export const AUDIO_PROFILES = {
  streetRacer: {
    label: "Street Racer", cylinders: 6, idleRpm: 620, maxRpm: 7000, turbo: 1,
    partials: [{ n: 0.5, g: 0.32 }, { n: 1, g: 0.95 }, { n: 2, g: 0.6 }, { n: 3, g: 0.34 }, { n: 4, g: 0.18 }],
    formants: [{ f: 70, r: 0.8, g: 0.5 }, { f: 160, r: 0.7, g: 0.32 }],
    tone: 0.6, texture: 0.4, jitter: 0.04, uneven: 0.03,
    noiseLevel: 0.14, drive: 1.2, bright: 0.5, level: 0.42, volume: 0.95,
  },
  sport: {
    label: "Sport Car", cylinders: 6, idleRpm: 700, maxRpm: 8000, turbo: 1,
    partials: [{ n: 0.5, g: 0.26 }, { n: 1, g: 0.9 }, { n: 2, g: 0.66 }, { n: 3, g: 0.46 }, { n: 4, g: 0.28 }, { n: 6, g: 0.15 }],
    formants: [{ f: 80, r: 0.82, g: 0.44 }, { f: 200, r: 0.7, g: 0.3 }],
    tone: 0.62, texture: 0.36, jitter: 0.035, uneven: 0.025,
    noiseLevel: 0.16, drive: 1.25, bright: 0.6, level: 0.42, volume: 0.95,
  },
  muscle: {
    label: "Muscle Car", cylinders: 8, idleRpm: 500, maxRpm: 6000, turbo: 0,
    partials: [{ n: 0.5, g: 0.62 }, { n: 1, g: 0.88 }, { n: 2, g: 0.5 }, { n: 3, g: 0.3 }],
    formants: [{ f: 55, r: 0.86, g: 0.58 }, { f: 120, r: 0.74, g: 0.34 }],
    tone: 0.54, texture: 0.44, jitter: 0.05, uneven: 0.12,
    noiseLevel: 0.12, drive: 1.35, bright: 0.44, level: 0.46, volume: 1.0,
  },
  classic: {
    label: "Classic Car", cylinders: 6, idleRpm: 580, maxRpm: 5600, turbo: 0,
    partials: [{ n: 0.5, g: 0.42 }, { n: 1, g: 0.86 }, { n: 2, g: 0.54 }, { n: 3, g: 0.3 }],
    formants: [{ f: 60, r: 0.84, g: 0.54 }, { f: 150, r: 0.72, g: 0.3 }],
    tone: 0.52, texture: 0.44, jitter: 0.07, uneven: 0.08,
    noiseLevel: 0.15, drive: 1.3, bright: 0.42, level: 0.44, volume: 0.9,
  },
  hatchback: {
    label: "Hatchback", cylinders: 4, idleRpm: 720, maxRpm: 6600, turbo: 1,
    partials: [{ n: 1, g: 0.88 }, { n: 2, g: 0.6 }, { n: 3, g: 0.4 }, { n: 4, g: 0.24 }, { n: 5, g: 0.14 }],
    formants: [{ f: 85, r: 0.8, g: 0.44 }, { f: 220, r: 0.68, g: 0.3 }],
    tone: 0.58, texture: 0.4, jitter: 0.04, uneven: 0.04,
    noiseLevel: 0.16, drive: 1.2, bright: 0.6, level: 0.4, volume: 0.86,
  },
  monster: {
    label: "Monster Truck", cylinders: 8, idleRpm: 460, maxRpm: 5000, turbo: 0,
    partials: [{ n: 0.5, g: 0.72 }, { n: 1, g: 0.85 }, { n: 2, g: 0.44 }, { n: 3, g: 0.24 }],
    formants: [{ f: 45, r: 0.88, g: 0.62 }, { f: 100, r: 0.76, g: 0.34 }],
    tone: 0.52, texture: 0.46, jitter: 0.06, uneven: 0.14,
    noiseLevel: 0.12, drive: 1.5, bright: 0.38, level: 0.5, volume: 1.1,
  },
  rally: {
    label: "Rally Hilux", cylinders: 4, idleRpm: 780, maxRpm: 7000, turbo: 1,
    partials: [{ n: 0.5, g: 0.3 }, { n: 1, g: 0.86 }, { n: 2, g: 0.6 }, { n: 3, g: 0.4 }, { n: 4, g: 0.22 }],
    formants: [{ f: 70, r: 0.82, g: 0.48 }, { f: 190, r: 0.7, g: 0.32 }],
    tone: 0.54, texture: 0.42, jitter: 0.06, uneven: 0.05,
    noiseLevel: 0.22, drive: 1.35, bright: 0.58, level: 0.42, volume: 0.95,
  },
  diesel: {
    label: "Landy", cylinders: 4, idleRpm: 560, maxRpm: 4200, turbo: 1,
    partials: [{ n: 0.5, g: 0.6 }, { n: 1, g: 0.82 }, { n: 2, g: 0.42 }, { n: 3, g: 0.22 }],
    formants: [{ f: 52, r: 0.86, g: 0.58 }, { f: 150, r: 0.72, g: 0.34 }, { f: 900, r: 0.4, g: 0.14 }],
    tone: 0.5, texture: 0.46, jitter: 0.1, uneven: 0.06,
    noiseLevel: 0.28, drive: 1.4, bright: 0.44, level: 0.44, volume: 0.92,
  },
  beetle: {
    label: "Beetle", cylinders: 4, idleRpm: 620, maxRpm: 5000, turbo: 0,
    partials: [{ n: 0.5, g: 0.4 }, { n: 1, g: 0.82 }, { n: 2, g: 0.5 }, { n: 3, g: 0.3 }],
    formants: [{ f: 62, r: 0.82, g: 0.5 }, { f: 160, r: 0.7, g: 0.3 }],
    tone: 0.52, texture: 0.44, jitter: 0.08, uneven: 0.1,
    noiseLevel: 0.18, drive: 1.3, bright: 0.46, level: 0.44, volume: 0.86,
  },
};

/** Exact catalogue-file -> profile wiring (robust to label edits). */
const FILE_PROFILE = {
  "car1.glb": "streetRacer",
  "Sport Car_39.glb": "sport",
  "N_Muscle Car_10.glb": "muscle",
  "Classic Car_9.glb": "classic",
  "Hatchback Car_15.glb": "hatchback",
  "Monster Truck_15.glb": "monster",
  "car4.glb": "rally",
  "car2.glb": "diesel",
  "car3.glb": "beetle",
};

/**
 * Pick the engine profile for a garage/catalogue entry. Matches by file first,
 * then by keywords in the label, then falls back to the balanced street voice.
 */
export function profileForCar(entry) {
  const file = entry?.file ?? "";
  const key = FILE_PROFILE[file];
  if (key && AUDIO_PROFILES[key]) return AUDIO_PROFILES[key];
  const label = String(entry?.label ?? file).toLowerCase();
  if (/monster/.test(label)) return AUDIO_PROFILES.monster;
  if (/muscle/.test(label)) return AUDIO_PROFILES.muscle;
  if (/sport/.test(label)) return AUDIO_PROFILES.sport;
  if (/classic/.test(label)) return AUDIO_PROFILES.classic;
  if (/hatch/.test(label)) return AUDIO_PROFILES.hatchback;
  if (/rally|hilux/.test(label)) return AUDIO_PROFILES.rally;
  if (/land|diesel|rover/.test(label)) return AUDIO_PROFILES.diesel;
  if (/beetle|bug/.test(label)) return AUDIO_PROFILES.beetle;
  return AUDIO_PROFILES.streetRacer;
}

const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

/**
 * Global rev scale applied to the engine before it reaches the worklet. Lower
 * = the whole range sits lower and less revvy (the car never pins the redline);
 * 1.0 would use the full idle->redline sweep. Tune here to make every car more
 * or less revvy at once.
 */
const RPM_SCALE = 0.7;

/**
 * Idle rev floor, as a fraction of the idle->redline sweep (0 = sit exactly at
 * the engine's idle firing rate). Lower = a slower, calmer idle note. This is
 * the knob for how revvy the car sounds while standing still.
 */
const IDLE_RPM = 0.02;

/** Ignition sequence length (starter crank + the engine catching), seconds. */
const START_DUR = 0.75;
/** Idle this long at a standstill and the engine switches itself off. */
const IDLE_OFF_SECS = 15;

/**
 * AudioWorklet processor source (self-contained; runs in the audio-render
 * thread). Loaded via a Blob URL so there is no build-tool asset wiring.
 *
 * The engine blends two things sample-by-sample:
 *   1. a SMOOTH harmonic body - phase-locked partials at the firing
 *      fundamental and its multiples. This is the modern, turbine-smooth voice
 *      (BMW/Audi) and carries the depth; it stays smooth even at a slow idle,
 *      which is what stops a low idle sounding like a retro putt-putt;
 *   2. a combustion TEXTURE - firing-rate impulses through tuned resonators,
 *      for the edge and grit.
 * Then intake/turbo induction noise (rises with throttle for the "hit"), a
 * load low-pass, and a gentle tanh. Config arrives in processorOptions and can
 * be swapped live via a 'config' message; rpm + throttle are audio params.
 */
const ENGINE_PROCESSOR_SRC = `
const TAU = 6.283185307179586;
class EngineProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      { name: 'rpm', defaultValue: 0.06, minValue: 0, maxValue: 1, automationRate: 'k-rate' },
      { name: 'throttle', defaultValue: 0, minValue: 0, maxValue: 1, automationRate: 'k-rate' },
    ];
  }
  constructor(options) {
    super();
    this.phase = 0; this.hPhase = 0; this.cyl = 0;
    this.noiseZ = 0; this.noiseZ2 = 0; this.brightZ = 0;
    this.configure((options && options.processorOptions) || {});
    this.port.onmessage = (e) => {
      if (e.data && e.data.type === 'config') this.configure(e.data.config);
    };
  }
  configure(c) {
    this.cylinders = Math.max(1, c.cylinders || 4);
    const perRev = this.cylinders / 2;              // 4-stroke firings per rev
    this.idleFire = (c.idleRpm || 650) / 60 * perRev;
    this.maxFire = (c.maxRpm || 7000) / 60 * perRev;
    this.noiseLevel = c.noiseLevel != null ? c.noiseLevel : 0.16;
    this.drive = c.drive || 1.2;
    this.level = c.level != null ? c.level : 0.42;
    this.bright = c.bright != null ? c.bright : 0.5;
    this.toneLevel = c.tone != null ? c.tone : 0.56;
    this.textureLevel = c.texture != null ? c.texture : 0.4;
    this.jitter = c.jitter != null ? c.jitter : 0.04;
    this.uneven = c.uneven != null ? c.uneven : 0.04;
    this.turbo = c.turbo ? 1 : 0;
    this.partials = (c.partials && c.partials.length) ? c.partials
      : [{ n: 1, g: 0.9 }, { n: 2, g: 0.5 }];
    const fs = (c.formants && c.formants.length) ? c.formants
      : [{ f: 70, r: 0.8, g: 0.5 }, { f: 160, r: 0.7, g: 0.3 }];
    this.res = fs.map((o) => {
      const r = Math.min(0.93, Math.max(0.1, o.r));  // clamp < 1 for stability
      const w = TAU * o.f / sampleRate;
      return { a1: 2 * r * Math.cos(w), a2: -(r * r), b0: (1 - r), g: o.g, y1: 0, y2: 0 };
    });
  }
  process(inputs, outputs, params) {
    const out = outputs[0];
    const ch0 = out[0];
    const n = ch0.length;
    const rpmK = params.rpm.length === 1;
    const thrK = params.throttle.length === 1;
    for (let i = 0; i < n; i++) {
      const rpm = rpmK ? params.rpm[0] : params.rpm[i];
      const thr = thrK ? params.throttle[0] : params.throttle[i];
      const fire = this.idleFire + (this.maxFire - this.idleFire) * rpm;
      const inc = fire / sampleRate;

      // 1. smooth harmonic body (phase-locked to the firing fundamental)
      this.hPhase += inc; if (this.hPhase >= 1) this.hPhase -= 1;
      let tone = 0;
      for (let p = 0; p < this.partials.length; p++) {
        const pt = this.partials[p];
        tone += Math.sin(TAU * pt.n * this.hPhase) * pt.g;
      }

      // 2. combustion texture: one impulse per cylinder firing, rung out
      this.phase += inc;
      let exc = 0;
      if (this.phase >= 1) {
        this.phase -= 1;
        this.cyl = (this.cyl + 1) % this.cylinders;
        const j = 1 + (Math.random() * 2 - 1) * this.jitter;
        const pat = (this.cyl % 2 === 0) ? 1 : (1 - this.uneven);
        exc = (0.4 + 0.6 * thr) * j * pat;
      }
      let tex = 0;
      for (let k = 0; k < this.res.length; k++) {
        const r = this.res[k];
        const y = r.b0 * exc + r.a1 * r.y1 + r.a2 * r.y2;
        r.y2 = r.y1; r.y1 = y;
        tex += y * r.g;
      }

      let s = tone * this.toneLevel + tex * this.textureLevel;

      // induction: low roar always, plus a bright turbo whoosh on throttle
      const air = this.noiseLevel * (0.15 + 0.85 * thr) * (0.4 + 0.6 * rpm);
      const nz = (Math.random() * 2 - 1) * air;
      this.noiseZ += 0.08 * (nz - this.noiseZ);
      this.noiseZ2 += 0.5 * (nz - this.noiseZ2);
      s += this.noiseZ;
      if (this.turbo) s += (nz - this.noiseZ2) * 0.6 * thr * rpm;

      // load low-pass: opens with revs + throttle (the acceleration "hit")
      const cut = Math.min(1, 0.06 + this.bright * 0.4 + 0.5 * rpm * (0.4 + 0.6 * thr));
      this.brightZ += cut * (s - this.brightZ);
      let o = Math.tanh(this.brightZ * this.drive);
      o *= this.level * (0.45 + 0.4 * rpm + 0.5 * thr);
      ch0[i] = o;
    }
    for (let ch = 1; ch < out.length; ch++) out[ch].set(ch0);
    return true;
  }
}
registerProcessor('engine-processor', EngineProcessor);
`;

/**
 * One live audio graph, driven once per frame from the player's driving state.
 * Construction never throws: with no Web Audio (or on failure) it degrades to
 * an inert no-op, so driving is never affected. The engine section loads
 * asynchronously (AudioWorklet) and stays silent until it is ready.
 */
export class CarAudio {
  constructor({ masterVolume = 0.6 } = {}) {
    this.ok = false;
    this.muted = false;
    this.enabled = true;
    this.engineReady = false;
    this._disposed = false;
    this.profile = AUDIO_PROFILES.streetRacer;
    this._rpm = IDLE_RPM; // smoothed engine speed, 0 (idle) .. 1 (redline)
    // Gearbox state: the last simulated gear, a cooldown so a boundary can't
    // machine-gun shift SFX, and the up-shift throttle-cut / down-shift blip
    // timers that punctuate the engine note.
    this._lastGear = -1;
    this._shiftCooldown = 0;
    this._cut = 0;
    this._blip = 0;
    // Engine run-state: it starts OFF (silent - no idle while the car is
    // parked). The first time the player drives it cranks and catches
    // ("starting") then runs ("on"); after IDLE_OFF_SECS stopped it shuts off
    // again, and the next move re-starts it.
    this.engineState = "off"; // "off" | "starting" | "on"
    this._startTimer = 0;
    this._stopTimer = 0;

    const AC = typeof window !== "undefined" && (window.AudioContext || window.webkitAudioContext);
    if (!AC) return;
    let ctx;
    try {
      ctx = new AC();
    } catch {
      return; // no audio device / blocked: stay inert
    }
    this.ctx = ctx;
    this.masterVolume = masterVolume;

    // --- master bus: submix -> compressor -> speakers ---------------------
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12;
    comp.knee.value = 22;
    comp.ratio.value = 3.5;
    comp.attack.value = 0.004;
    comp.release.value = 0.2;
    comp.connect(ctx.destination);
    const master = ctx.createGain();
    master.gain.value = 0; // faded up once the context is unlocked
    master.connect(comp);
    this.master = master;

    this._buildEvents();
    this.ok = true;
    this._initEngine(); // async; engine fades in when the worklet is ready

    try {
      ctx.resume?.();
    } catch {
      /* unlocked later by the first key / tap */
    }
  }

  /** A couple of seconds of white noise, shared by every noise layer. */
  _noiseBuffer() {
    if (this._noise) return this._noise;
    const ctx = this.ctx;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 2), ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    this._noise = buf;
    return buf;
  }

  _loopingNoise() {
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer();
    src.loop = true;
    src.start();
    return src;
  }

  /** Load the combustion worklet and wire the engine node (async, once). */
  async _initEngine() {
    const ctx = this.ctx;
    if (!ctx.audioWorklet) return; // very old browser: engine stays silent
    try {
      if (!CarAudio._workletURL) {
        const blob = new Blob([ENGINE_PROCESSOR_SRC], { type: "application/javascript" });
        CarAudio._workletURL = URL.createObjectURL(blob);
      }
      await ctx.audioWorklet.addModule(CarAudio._workletURL);
    } catch (err) {
      console.warn("CarAudio: engine worklet failed to load", err);
      return;
    }
    if (this._disposed) return;
    let node;
    try {
      node = new AudioWorkletNode(ctx, "engine-processor", {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [2],
        processorOptions: this._engineConfig(),
      });
    } catch (err) {
      console.warn("CarAudio: engine node failed", err);
      return;
    }
    const out = ctx.createGain();
    out.gain.value = 0.0001; // engine starts OFF; update() owns this gain (gate x volume)
    node.connect(out);
    out.connect(this.master);
    this.engineNode = node;
    this.engineOut = out;
    this._rpmParam = node.parameters.get("rpm");
    this._thrParam = node.parameters.get("throttle");
    this.engineReady = true;
  }

  /** Combustion-model config object derived from the current profile. */
  _engineConfig() {
    const p = this.profile;
    return {
      cylinders: p.cylinders, idleRpm: p.idleRpm, maxRpm: p.maxRpm,
      partials: p.partials, formants: p.formants, tone: p.tone, texture: p.texture,
      jitter: p.jitter, uneven: p.uneven, turbo: p.turbo,
      noiseLevel: p.noiseLevel, drive: p.drive, bright: p.bright, level: p.level,
    };
  }

  _buildEvents() {
    const ctx = this.ctx;

    // Tyre skid: twin bandpasses on shared noise give the screech body rather
    // than a thin whistle. Level is driven from the car's slip.
    const skidGain = ctx.createGain();
    skidGain.gain.value = 0;
    skidGain.connect(this.master);
    const skidSrc = this._loopingNoise();
    const skidBP = ctx.createBiquadFilter();
    skidBP.type = "bandpass";
    skidBP.frequency.value = 1200;
    skidBP.Q.value = 6;
    const skidBP2 = ctx.createBiquadFilter();
    skidBP2.type = "bandpass";
    skidBP2.frequency.value = 2500;
    skidBP2.Q.value = 9;
    skidSrc.connect(skidBP);
    skidSrc.connect(skidBP2);
    skidBP.connect(skidGain);
    skidBP2.connect(skidGain);
    this.skid = { gain: skidGain, bp: skidBP, bp2: skidBP2 };

    // Brake squeal: a high resonant whistle, loudest at low speed under brake.
    const brakeGain = ctx.createGain();
    brakeGain.gain.value = 0;
    brakeGain.connect(this.master);
    const brakeSrc = this._loopingNoise();
    const brakeBP = ctx.createBiquadFilter();
    brakeBP.type = "bandpass";
    brakeBP.frequency.value = 3400;
    brakeBP.Q.value = 22;
    brakeSrc.connect(brakeBP);
    brakeBP.connect(brakeGain);
    this.brake = { gain: brakeGain };

    // Wind / road roar: broadband noise rising with speed for high-speed body.
    const windGain = ctx.createGain();
    windGain.gain.value = 0;
    windGain.connect(this.master);
    const windSrc = this._loopingNoise();
    const windLP = ctx.createBiquadFilter();
    windLP.type = "lowpass";
    windLP.frequency.value = 500;
    const windHP = ctx.createBiquadFilter();
    windHP.type = "highpass";
    windHP.frequency.value = 120;
    windSrc.connect(windHP);
    windHP.connect(windLP);
    windLP.connect(windGain);
    this.wind = { gain: windGain, lp: windLP };
  }

  /**
   * Retune the engine to a car profile - cheap enough for every garage swap.
   * The running worklet is reconfigured live via a port message (no node churn,
   * no gap); the submix gain follows the new volume.
   */
  setProfile(profile) {
    this.profile = profile ?? AUDIO_PROFILES.streetRacer;
    if (!this.engineReady || !this.engineNode) return;
    try {
      this.engineNode.port.postMessage({ type: "config", config: this._engineConfig() });
      // engineOut.gain is driven by update() (gate x volume), not here.
    } catch {
      /* node gone: nothing to retune */
    }
  }

  _ramp(param, value, tau = 0.05) {
    try {
      param.setTargetAtTime(value, this.ctx.currentTime, tau);
    } catch {
      /* param detached: ignore */
    }
  }

  /**
   * Advance the whole mix one frame from the live driving state.
   *
   * @param dt     seconds since last frame
   * @param state  { speed (m/s), throttle 0..1, brake 0..1, handbrake bool,
   *                 slip 0..1 }
   */
  update(dt, state = {}) {
    if (!this.ok) return;
    const speed = Math.abs(state.speed ?? 0);
    const throttle = clamp01(state.throttle ?? 0);
    const brake = clamp01(state.brake ?? 0);
    const slip = clamp01(state.slip ?? 0);
    const speedFrac = clamp01(speed / CAR.maxSpeed);

    // Fade the whole mix in once unlocked; drop it for the garage/menu.
    const live = this.enabled && !this.muted && this.ctx.state === "running";
    this._ramp(this.master.gain, live ? this.masterVolume : 0, 0.08);

    // --- RPM from speed + a simulated six-speed box --------------------------
    // Within each gear the revs sweep idle->redline; crossing into the next
    // gear drops them back toward idle (an up-shift). Flooring it at a
    // near-standstill blips the revs off idle. The attack is snappy so flooring
    // the throttle "hits" instead of swelling in slowly.
    const gears = 6;
    const g = Math.min(Math.floor(speedFrac * gears), gears - 1);
    const local = clamp01(speedFrac * gears - g);
    const revBlip = throttle * (1 - speedFrac) * 0.55;
    const rpmTarget = clamp01(Math.max(IDLE_RPM + (1 - IDLE_RPM) * local, IDLE_RPM + revBlip));
    const k = 1 - Math.exp(-(throttle > 0.05 ? 10 : 4.5) * Math.max(dt, 1e-3));
    this._rpm += (rpmTarget - this._rpm) * k;

    // --- gearbox: fire a shift SFX + cut/blip when the gear changes ----------
    this._shiftCooldown = Math.max(0, this._shiftCooldown - dt);
    this._cut = Math.max(0, this._cut - dt);
    this._blip = Math.max(0, this._blip - dt);
    const gearNow = speed > 1.5 ? g : -1;
    if (gearNow >= 0 && this._lastGear >= 0 && gearNow !== this._lastGear && this._shiftCooldown <= 0) {
      this.shift(gearNow > this._lastGear);
      this._shiftCooldown = 0.35;
    }
    this._lastGear = gearNow;

    // --- engine run-state (off / starting / on) -----------------------------
    // Only runs once the context is unlocked and not in the garage; mute is a
    // separate master fade, so the engine can still start while muted.
    const canRun = this.enabled && this.ctx.state === "running";
    const moving = speed > 0.5 || throttle > 0.03;
    if (this.engineState === "off") {
      if (canRun && moving) {
        this.engineState = "starting";
        this._startTimer = START_DUR;
        this._stopTimer = 0;
        this._starter(); // crank + catch one-shot
      }
    } else if (this.engineState === "starting") {
      this._startTimer -= dt;
      if (this._startTimer <= 0) this.engineState = "on";
    } else {
      // Running: count stopped time, and shut the engine off after a while.
      if (speed < 0.4 && throttle < 0.03) this._stopTimer += dt;
      else this._stopTimer = 0;
      if (this._stopTimer >= IDLE_OFF_SECS) {
        this.engineState = "off";
        this._stopTimer = 0;
      }
    }

    // --- engine (combustion worklet): hand it rpm + throttle, with the -------
    // up-shift throttle cut (revs + fuel drop briefly) and the down-shift blip.
    let baseRpm = this._rpm;
    if (this.engineState === "starting") {
      // The engine catching: revs flare up then settle to idle over the crank.
      const p = clamp01(1 - this._startTimer / START_DUR);
      baseRpm = Math.max(this._rpm, IDLE_RPM + 0.34 * Math.sin(Math.PI * p));
    }
    let rpmOut = baseRpm * RPM_SCALE;
    let thrOut = this.engineState === "starting" ? 0 : throttle;
    if (this._cut > 0) { rpmOut *= 0.84; thrOut *= 0.12; }
    if (this._blip > 0) { rpmOut = Math.min(1, rpmOut + 0.12); thrOut = Math.max(thrOut, 0.8); }
    if (this.engineReady) {
      this._ramp(this._rpmParam, rpmOut, this._cut > 0 ? 0.02 : 0.05);
      this._ramp(this._thrParam, thrOut, 0.02);
      // Engine audibility gate: silent when off, swelling in through the start,
      // full when running. This is what keeps the idle quiet at a standstill.
      const gate = this.engineState === "off" ? 0 : 1;
      const tau = this.engineState === "off" ? 0.3 : this.engineState === "starting" ? 0.22 : 0.08;
      this._ramp(this.engineOut.gain, (this.profile.volume ?? 0.9) * gate, tau);
    }

    // --- tyre skid ----------------------------------------------------------
    const skidLevel = clamp01((slip - 0.3) / 0.7) * clamp01(speed / 7);
    this._ramp(this.skid.gain.gain, skidLevel * 0.5, 0.04);
    this._ramp(this.skid.bp.frequency, 1200 + speedFrac * 700, 0.08);
    this._ramp(this.skid.bp2.frequency, 2400 + speedFrac * 1100, 0.08);

    // --- brake squeal -------------------------------------------------------
    const speedKmh = speed * 3.6;
    const squeal = brake * clamp01((22 - speedKmh) / 18) * (speed > 0.6 ? 1 : 0);
    this._ramp(this.brake.gain.gain, squeal * 0.14, 0.03);

    // --- wind / road roar ---------------------------------------------------
    this._ramp(this.wind.gain.gain, Math.pow(speedFrac, 1.5) * 0.26, 0.1);
    this._ramp(this.wind.lp.frequency, 400 + speedFrac * 3200, 0.1);
  }

  /**
   * Punch in a gear change. Up-shifts get a mechanical clunk plus (on turbo
   * cars) a blow-off "pshh"; the throttle cut/blip that goes with it is applied
   * in update() via the _cut/_blip timers. Down-shifts get a lighter clunk and
   * a rev blip.
   */
  shift(up) {
    if (!this.ok) return;
    if (up) this._cut = 0.12;
    else this._blip = 0.16;
    this._clunk(up ? 1 : 0.7);
    if (up && this.profile.turbo) this._blowoff();
  }

  /** One-shot gearbox engagement thunk: a short low noise burst. */
  _clunk(amp = 1) {
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = this._loopingNoise();
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 190;
    bp.Q.value = 3;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.3 * amp, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.1);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.master);
    try {
      src.stop(t + 0.12);
    } catch {
      /* already scheduled */
    }
  }

  /** One-shot turbo blow-off: a bright noise burst sweeping down. */
  _blowoff() {
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = this._loopingNoise();
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = 1.2;
    bp.frequency.setValueAtTime(3800, t);
    bp.frequency.exponentialRampToValueAtTime(900, t + 0.18);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.12, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.master);
    try {
      src.stop(t + 0.22);
    } catch {
      /* already scheduled */
    }
  }

  /** One-shot ignition: a starter-motor crank chug for the engine catching. */
  _starter() {
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const dur = 0.55;
    const src = this._loopingNoise();
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 130;
    bp.Q.value = 4;
    // Starter chug: a square LFO tremolo on the filtered noise (rrr-rrr-rrr).
    const vca = ctx.createGain();
    vca.gain.setValueAtTime(0.5, t);
    const lfo = ctx.createOscillator();
    lfo.type = "square";
    lfo.frequency.value = 11;
    const lfoG = ctx.createGain();
    lfoG.gain.value = 0.5;
    lfo.connect(lfoG);
    lfoG.connect(vca.gain);
    // Overall crank envelope, trailing off as the engine catches.
    const env = ctx.createGain();
    env.gain.setValueAtTime(0.0001, t);
    env.gain.exponentialRampToValueAtTime(0.26, t + 0.05);
    env.gain.setValueAtTime(0.26, t + dur - 0.12);
    env.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(bp);
    bp.connect(vca);
    vca.connect(env);
    env.connect(this.master);
    lfo.start(t);
    try {
      src.stop(t + dur + 0.05);
      lfo.stop(t + dur + 0.05);
    } catch {
      /* already scheduled */
    }
  }

  /**
   * One-shot "whoosh" for race/UI transitions - band-passed noise whose centre
   * frequency sweeps under an envelope. Variants give each transition its own
   * voice: a bright rising swish for UI elements, a rising sweep for the results
   * board, and a long Doppler "pass-by" (rise then fall, swell then fade - like
   * a car ripping past at speed) for the finish camera move.
   */
  whoosh(variant = "ui") {
    if (!this.ok || this.muted || this.ctx.state !== "running") return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = this._loopingNoise();
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    const g = ctx.createGain();
    src.connect(bp);
    bp.connect(g);
    g.connect(this.master);

    if (variant === "passby") {
      // Doppler pass-by: pitch rises as it approaches, drops as it recedes;
      // level swells to a peak as it "passes" then fades. Long and loud.
      const dur = 1.15;
      bp.Q.value = 0.8;
      bp.frequency.setValueAtTime(380, t);
      bp.frequency.exponentialRampToValueAtTime(2200, t + dur * 0.42);
      bp.frequency.exponentialRampToValueAtTime(240, t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.5, t + dur * 0.42);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      try {
        src.stop(t + dur + 0.05);
      } catch {
        /* already scheduled */
      }
      return;
    }

    const cfg =
      {
        ui: { dur: 0.3, f0: 700, f1: 2800, q: 1.1, gain: 0.2 },
        camera: { dur: 0.55, f0: 3400, f1: 360, q: 0.9, gain: 0.32 },
        result: { dur: 0.65, f0: 420, f1: 2100, q: 0.9, gain: 0.34 },
      }[variant] ?? { dur: 0.3, f0: 700, f1: 2800, q: 1.1, gain: 0.2 };
    bp.Q.value = cfg.q;
    bp.frequency.setValueAtTime(cfg.f0, t);
    bp.frequency.exponentialRampToValueAtTime(cfg.f1, t + cfg.dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(cfg.gain, t + cfg.dur * 0.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t + cfg.dur);
    try {
      src.stop(t + cfg.dur + 0.05);
    } catch {
      /* already scheduled */
    }
  }

  /**
   * Race-start beeps: authentic arcade racing countdown audio.
   * Rising punchy synthesized dual-oscillator tones for 3, 2, 1, and a
   * triumphant high-energy power chord with sub-bass launch kick for GO!
   */
  countBeep(final = false, step = null) {
    if (!this.ok || this.muted || this.ctx.state !== "running") return;
    try {
      const ctx = this.ctx;
      const t = ctx.currentTime;

      const isFinal = !!final || step === "GO" || step === "GO!";
      if (isFinal) {
        // === GO! Launch Sound: Triumphant arcade power chord + pitch swoop + sub-bass kick ===
        const dur = 0.68;
        const chord = [1046.5, 1567.98, 2093.0]; // C6, G6, C7
        const chordGains = [0.32, 0.22, 0.14];

        for (let i = 0; i < chord.length; i++) {
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          const filter = ctx.createBiquadFilter();

          osc.type = i === 0 ? "sawtooth" : "triangle";
          const f = chord[i];
          // Initial energetic upward pitch scoop
          osc.frequency.setValueAtTime(f * 0.78, t);
          osc.frequency.exponentialRampToValueAtTime(f, t + 0.035);

          filter.type = "lowpass";
          filter.frequency.setValueAtTime(4500, t);
          filter.Q.value = 1.2;

          g.gain.setValueAtTime(0.0001, t);
          g.gain.exponentialRampToValueAtTime(chordGains[i], t + 0.012);
          g.gain.exponentialRampToValueAtTime(0.0001, t + dur);

          osc.connect(filter);
          filter.connect(g);
          g.connect(this.master);
          osc.start(t);
          try {
            osc.stop(t + dur + 0.05);
          } catch {}
        }

        // Sub-bass launch kick thump (engine launch feel)
        const sub = ctx.createOscillator();
        const subG = ctx.createGain();
        sub.type = "sine";
        sub.frequency.setValueAtTime(160, t);
        sub.frequency.exponentialRampToValueAtTime(45, t + 0.22);

        subG.gain.setValueAtTime(0.0001, t);
        subG.gain.exponentialRampToValueAtTime(0.42, t + 0.006);
        subG.gain.exponentialRampToValueAtTime(0.0001, t + 0.26);

        sub.connect(subG);
        subG.connect(this.master);
        sub.start(t);
        try {
          sub.stop(t + 0.3);
        } catch {}
      } else {
        // === 3, 2, 1 Countdown Beeps: Rising electronic arcade tones with punchy transient attack ===
        let baseFreq = 587.33; // D5 fallback
        if (step === "3" || step === 3) baseFreq = 523.25;      // C5
        else if (step === "2" || step === 2) baseFreq = 659.25; // E5
        else if (step === "1" || step === 1) baseFreq = 783.99; // G5

        const dur = 0.26;

        // 1. Primary body: warm triangle wave with sharp pitch-drop attack
        const osc1 = ctx.createOscillator();
        const g1 = ctx.createGain();
        osc1.type = "triangle";
        osc1.frequency.setValueAtTime(baseFreq * 1.42, t);
        osc1.frequency.exponentialRampToValueAtTime(baseFreq, t + 0.018);

        g1.gain.setValueAtTime(0.0001, t);
        g1.gain.exponentialRampToValueAtTime(0.38, t + 0.005);
        g1.gain.setValueAtTime(0.32, t + 0.12);
        g1.gain.exponentialRampToValueAtTime(0.0001, t + dur);

        // 2. Secondary overtone: filtered saw for bright arcade click
        const osc2 = ctx.createOscillator();
        const g2 = ctx.createGain();
        const bp = ctx.createBiquadFilter();
        osc2.type = "sawtooth";
        osc2.frequency.setValueAtTime(baseFreq, t);

        bp.type = "bandpass";
        bp.frequency.setValueAtTime(baseFreq * 2, t);
        bp.Q.value = 2.8;

        g2.gain.setValueAtTime(0.0001, t);
        g2.gain.exponentialRampToValueAtTime(0.16, t + 0.006);
        g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);

        osc1.connect(g1);
        g1.connect(this.master);
        osc1.start(t);

        osc2.connect(bp);
        bp.connect(g2);
        g2.connect(this.master);
        osc2.start(t);

        try {
          osc1.stop(t + dur + 0.05);
          osc2.stop(t + dur + 0.05);
        } catch {}
      }
    } catch {
      /* audio must never interrupt the race */
    }
  }

  /** Resume the context after a user gesture (browsers start it suspended). */
  unlock() {
    if (!this.ok) return;
    try {
      this.ctx.resume?.();
    } catch {
      /* will retry on the next gesture */
    }
  }

  /** Enable/disable the whole mix (used to silence it in the garage/menus). */
  setEnabled(on) {
    this.enabled = !!on;
  }

  setMuted(on) {
    this.muted = !!on;
  }

  /** @returns the new muted state (for a HUD/console toggle). */
  toggleMute() {
    this.muted = !this.muted;
    return this.muted;
  }

  dispose() {
    this._disposed = true;
    if (!this.ctx) return;
    try {
      this.ctx.close?.();
    } catch {
      /* already closed */
    }
    this.ok = false;
    this.engineReady = false;
  }
}


