import {
  Color3,
  Color4,
  DirectionalLight,
  Engine,
  HemisphericLight,
  Scene,
  Vector3,
} from "@babylonjs/core";

/**
 * Creates the renderer and a scene laid out for driving.
 *
 * The map is roughly 1000 x 600 world units with roads about 12 units wide and
 * the car about 1.9 units wide, so 1 unit reads as 1 metre and the camera's
 * near/far planes are set to cover the whole map.
 */
export function createScene(canvas) {
  const engine = new Engine(canvas, true, {
    stencil: true,
    preserveDrawingBuffer: true,
    antialias: true,
  });

  // Babylon's own loading overlay (black div + logo/spinner) is never part
  // of this game's UI - boot visuals belong to the custom #overlay only.
  // This no-op only mutes that foreign UI; every scene/asset load below
  // still runs exactly as before.
  engine.loadingScreen = {
    displayLoadingUI: () => {},
    hideLoadingUI: () => {},
  };

  // Enable true pixel-perfect High-DPI rendering (crisp on Windows 125%/150% scaling)
  const dpr = Math.min(typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1, 2);
  engine.setHardwareScalingLevel(1 / dpr);

  const scene = new Scene(engine);
  scene.clearColor = new Color4(0.45, 0.63, 0.83, 1);
  scene.ambientColor = new Color3(0.25, 0.25, 0.28);

  // Culling: this map is a single enclosed town. Fog is kept tight and the
  // far plane sits just past it: meshes beyond it are frustum-culled (never
  // rasterized) and the fog hides the cutoff, so distance costs nothing.
  scene.fogMode = Scene.FOGMODE_LINEAR;
  scene.fogColor = new Color3(0.45, 0.63, 0.83);
  scene.fogStart = 120;
  scene.fogEnd = 260;

  const hemi = new HemisphericLight("hemi", new Vector3(0, 1, 0), scene);
  hemi.intensity = 0.75;
  hemi.diffuse = new Color3(1, 1, 1);
  hemi.groundColor = new Color3(0.35, 0.36, 0.4);

  const sun = new DirectionalLight("sun", new Vector3(-0.45, -1, 0.35), scene);
  sun.intensity = 1.15;
  sun.diffuse = new Color3(1, 0.97, 0.9);

  return { engine, scene, lights: { hemi, sun } };
}

export { Vector3 };
