import { DracoDecoder } from "@babylonjs/core/Meshes/Compression/dracoDecoder.js";

/**
 * Self-hosted Draco decoder.
 *
 * `assets/map.glb` is Draco-compressed (`KHR_draco_mesh_compression`), so the
 * glTF loader needs the Draco decoder at runtime. Babylon's default
 * configuration fetches it from `https://cdn.babylonjs.com/...`; this game
 * ships its own copy under `public/draco/` and points the loader at it, so the
 * map loads with no external requests.
 *
 * Paths are relative on purpose: Babylon resolves them against the document
 * URL (`Tools.GetAbsoluteUrl`), so they work in dev, in the built `dist/`, and
 * under any sub-path host.
 */
export const DRACO_DECODER_PATHS = {
  wasmUrl: "draco/draco_wasm_wrapper_gltf.js",
  wasmBinaryUrl: "draco/draco_decoder_gltf.wasm",
  fallbackUrl: "draco/draco_decoder_gltf.js",
};

/**
 * Point Babylon's Draco decoder at the local copy. Called once, before the
 * first glTF load. The glTF loader reads `DracoDecoder.Default`, which is built
 * lazily from this configuration on first use.
 */
export function configureLocalDracoDecoder() {
  DracoDecoder.DefaultConfiguration = { ...DRACO_DECODER_PATHS };
}
