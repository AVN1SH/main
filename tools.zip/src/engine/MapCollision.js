/**
 * Collision model for the imported town.
 *
 * The map is one big glTF with ~3,100 meshes / ~7.5 M triangles - far too much
 * to test per frame, and it uses Draco compression so nothing about its shape
 * can be read offline. So the geometry is baked ONCE at load into two compact
 * lookup grids, and every runtime query is a handful of array reads:
 *
 *  - `ground`: a LAYERED height field. Each cell keeps the heights of the
 *    surfaces that cross it (a road at 0.1 m and a bridge deck at 6 m can share
 *    a cell), so the car can sit on the ground UNDER a bridge and also drive up
 *    onto it: a wheel resolves against whichever surface is nearest the one it
 *    is already on. A single top-surface height map could not do both.
  *  - `obstacles`: solid columns (bottom/top Y) baked from the meshes that are
  *    not drivable - buildings, fences, parked cars, signs. A column blocks the
  *    car only when its span overlaps the chassis, so an overhead sign does not
  *    stop a car driving underneath while its post does. Unclimbable walls that
  *    are part of the roads themselves are caught by the height field's "wall"
  *    result rather than by a column, which avoids double-counting.
  *  - world-edge walls: four invisible planes at the map geometry extents that
  *    block every footprint query at any height, so the player cannot drive
  *    off the world (including off the end of an elevated deck).
 *
 * This is deliberately not a rigid-body physics engine. Simulating 3,000 meshes
 * of static scenery would be far heavier than the arcade-scale driving model
 * the rest of the game uses, and the vehicle only ever needs to ask two
 * questions: "how high is the surface under this wheel?" and "is this space
 * filled?". Both are answered here.
 *
 * Heights are interpolated bilinearly across cells so a ramp reads as a smooth
 * slope instead of a 1 m staircase, and neighbouring cells only blend when
 * their surfaces are within `JOIN_TOL` of each other, which keeps a bridge edge
 * from melting into the ground beside it.
 */

const SURFACE_RE =
  /^(road_|bridge_a|parking_area|green_|basketballcourt|land$|land\.|landscape)/i;

/**
 * Subset of the surface families that are actual ROADWAY: tarmac, the elevated
 * deck, its ramps, and marked parking. The general bake also treats grass,
 * dirt and courts as drivable (a car CAN cross them), but traffic lanes must
 * stay on roadway, so cells are flagged here as they are baked.
 */
const ROADWAY_RE = /^(road_|bridge_a|parking_area)/i;

/**
 * Surface family per ground cell, for tire-mark looks (see `surfaceAt`).
 * Stamped during the surface bake from the mesh name; higher wins, so a
 * road poured over grass keeps road marks whatever order the meshes bake.
 * Sand is decor (never surface-baked), so its patches stamp their AABB
 * footprint in pass 2 instead - but only over dirt/grass, never over road.
 */
export const SURF = {
  DIRT: 1, // land / landscape / anything unbaked
  GRASS: 2, // green_ (muddy marks)
  SAND: 3, // sand_ patches (pale marks)
  ROAD: 4, // road / deck / parking / court (rubber marks)
};

function surfaceTypeFor(name) {
  if (/^(road_|bridge_a|parking_area|basketballcourt)/i.test(name)) return SURF.ROAD;
  if (/^green_/i.test(name)) return SURF.GRASS;
  if (/^(land$|land\.|landscape)/i.test(name)) return SURF.DIRT;
  return 0; // unknown: stamp nothing
}

/**
 * Families that are decoration rather than structure. They are neither
 * drivable nor solid: a tree canopy over the road must not become a wall, and
 * foliage/decals have no meaningful footprint. (Park structures are NOT here:
 * `park_*` bakes as solid like any other building.)
 */
const DECOR_RE =
  /^(tree|green_|plants|flowers|sand_|airballoon)/i;

/**
 * Tree family. The canopy stays non-solid (see DECOR_RE) and the trunk is
 * recorded as a camera-only occluder; the trunk's steep faces additionally
 * bake as car-solid walls, exactly where they stand. Only the low trunk
 * cylinder is kept for the camera, not the canopy AABB, so driving under
 * leaves does not yank the camera.
 */
const TREE_RE = /^tree/i;

/**
 * Water bodies (`water_a`, `water_b`, ...). A lake is a flat sheet, so it has
 * no steep faces and the normal solid bake would record nothing - leaving a car
 * free to drive in and fall through the world. Water is instead baked as a
 * solid barrier over its own footprint; see `bakeWater`.
 */
const WATER_RE = /^water/i;

/**
 * Families that are BOTH a drivable surface and a solid structure. They are
 * baked twice: the surface baker keeps their shallow faces, and the solid baker
 * records their steep faces as walls. Without the second half these read as
 * pass-through scenery, because the surface baker deliberately skips steep
 * faces (it relies on the height field's "wall" result, which a road's plain
 * barrier never triggers).
 *
 *  - `landscape` - mountains: drivable on the gentle slopes, a wall where they
 *    rise. Without this a car drives straight into a mountainside.
 *  - `road_c` - raised roadway with a low barrier down each side: the deck is
 *    drivable, the barriers must block. They are steep faces of a mesh the
 *    surface baker treats as road, and the car drove through them.
 *  - `bridge_a` - the bridge over the water channel. Its deck is road (see
 *    SURFACE_RE/ROADWAY_RE) but its rails/edges are the same kind of steep face
 *    as a `road_c` barrier. Without this the deck was drivable but the car
 *    drove straight off the sides: the edges baked as surface only, so there
 *    was nothing solid at the car's height to stop it.
 *  - `basketballcourt` - the court floor stays drivable, but hoop posts,
 *    backboards and court fencing are steep faces that must block like any
 *    building wall. Without this the car drove straight through the posts.
 */
const SURFACE_SOLID_RE = /^(landscape|road_c|basketballcourt)/i;

/**
 * The bridge family. Its drivable deck must stay clear, so it is NOT baked as a
 * solid mesh (its towers and 40 m cables would seal the deck). Instead its
 * surface cells are tagged and `_bakeBridgeEdges` builds a barrier only along
 * the deck's lateral edges.
 */
const BRIDGE_RE = /^bridge_a/i;

/**
 * Roads whose central divide is baked into the road geometry itself rather than
 * being a separate mesh - the `road_b` boulevard family. Their median is a
 * raised strip (a pair of steep "fins" a few tens of centimetres tall) down the
 * middle of the tile, so it never became a solid wall (the tile is not a
 * SURFACE_SOLID family) and the height field cannot see it either. Traffic
 * lanes therefore used to be built straight down the centre line - the median -
 * and cars straddled the divider. `bakeDividers` records those fins so lane
 * validation can steer around them.
 */
const DIVIDER_ROAD_RE = /^road_b/i;
/** Height band (m) a steep face must fall in to count as a median fin. */
const DIVIDER_MIN_RISE = 0.08;
const DIVIDER_MAX_RISE = 0.7;
const DIVIDER_MAX_TOP = 1.2; // fins sit at ground level
/** A fin must be this far inside the tile's own bounds to be a median, not a kerb. */
const DIVIDER_EDGE_MARGIN = 2.5;

/**
 * Subset of `SURFACE_SOLID_RE` whose triangles are large enough that tracing
 * their edges is not enough. A mountainside is made of big triangles, so its
 * face has to be filled or the middle of the slope stays open. A road barrier
 * is a thin wall, where the edge trace IS the wall - and filling it would spill
 * onto the deck's neighbouring cells and seal the road it guards.
 */
const SURFACE_SOLID_FILL_RE = /^landscape/i;

export const COLLISION_DEFAULTS = {
  cell: 1.0, // ground height-field cell, metres
  obstacleCell: 0.5, // obstacle grid cell, metres
  layers: 6, // surfaces kept per ground cell
  maxSlopeCos: 0.55, // normal.y at/above this counts as a drivable surface (~57 deg)
  joinTol: 0.6, // max height gap bridged by interpolation between cells
  minObstacleHeight: 0.35, // ignore stuff that barely pokes above the ground
  fallbackY: 0.056, // height used where the map has no surface at all
  // Invisible barrier along each side of the bridge deck (see
  // `_bakeBridgeEdges`). `bridgeEdgeInset` is how far INBOARD of the deck's
  // outer edge the wall is stamped: raise it to narrow the usable lane from
  // both sides, lower it to let the car run out to the visible edge. `range` is
  // how far the search looks for the deck edge and must stay >= `inset`.
  bridgeEdgeInset: 4.0, // metres in from each deck edge
  bridgeEdgeRange: 8.0, // metres searched out from a deck cell
  bridgeEdgeHeight: 1.6, // metres the barrier rises above the deck
  // Records which mesh made each solid cell, and whether it came from that
  // mesh's triangles or only from its bounding box. Purely diagnostic, so it is
  // off by default: the provenance grid costs ~3 bytes per 0.5 m cell.
  trackSources: false,
  /**
   * Optional `(mesh) => key | null`. Solid meshes that return a key have the
   * obstacle cells they bake recorded against that key, so their collision can
   * later be dropped in one call to `clearGroup` - this is what lets the player
   * smash a road sign out of the way instead of being stopped by its invisible
   * ghost. Only the roadside props this game makes destructible return a key;
   * for every other mesh the bookkeeping is skipped entirely, so the normal
   * bake pays nothing for it.
   */
  groupKey: null,
};

/** How a solid cell came to be marked. */
export const OBSTACLE_SOURCE = {
  NONE: 0,
  /** From the mesh's world AABB - a box, so it can cover empty space. */
  AABB: 1,
  /** From a real steep triangle, so it is on the mesh. */
  TRIANGLE: 2,
};

const LAYER_EPS = 0.03;

/**
 * Slack on the step-limit comparisons, in metres.
 *
 * Layer heights are baked into a Float32Array, so a surface that is exactly at
 * the step limit comes back as the nearest float32 to it: a 0.34 m kerb is
 * stored as 0.3400000035762787, which is fractionally *above* a 0.34 m limit
 * held in a float64. Comparing the two directly would call that kerb unclimbable
 * for no physical reason. One micrometre is far below anything the car could
 * notice and comfortably wider than the storage error, so it removes the
 * artifact without softening the limit in any meaningful way.
 */
const STEP_EPS = 1e-6;

export class MapCollision {
  /**
   * @param meshes  the loaded map meshes (world matrices already computed)
   * @param options see COLLISION_DEFAULTS
   */
  constructor(meshes, options = {}) {
    const o = { ...COLLISION_DEFAULTS, ...options };
    this.cell = o.cell;
    this.obstacleCell = o.obstacleCell;
    this.layers = o.layers;
    this.maxSlopeCos = o.maxSlopeCos;
    this.bridgeEdgeInset = o.bridgeEdgeInset;
    this.bridgeEdgeRange = o.bridgeEdgeRange;
    this.bridgeEdgeHeight = o.bridgeEdgeHeight;
    this.joinTol = o.joinTol;
    this.minObstacleHeight = o.minObstacleHeight;
    this.fallbackY = o.fallbackY;
    this.trackSources = !!o.trackSources;
    // Destructible-prop bookkeeping. `groups` maps a key to the obstacle cells
    // that object baked; `cellGroup` maps a cell back to the single key that
    // owns it, so clearing one object can never take collision away from a
    // building or another prop. Both stay null unless a groupKey is supplied.
    this.groupKey = typeof o.groupKey === "function" ? o.groupKey : null;
    this.groups = this.groupKey ? new Map() : null;
    this.cellGroup = this.groupKey ? new Map() : null;

    const t0 = performance.now();
    this.stats = { meshes: meshes.length };

    // --- world bounds over every mesh ------------------------------------
    let minX = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxZ = -Infinity;
    const boxes = [];
    for (const mesh of meshes) {
      const box = worldAabb(mesh);
      if (!box) continue;
      boxes.push({ mesh, box });
      minX = Math.min(minX, box.minX);
      minZ = Math.min(minZ, box.minZ);
      maxX = Math.max(maxX, box.maxX);
      maxZ = Math.max(maxZ, box.maxZ);
    }
    // Invisible world-edge walls (see `blockedRect`): the playable area ends
    // where the map geometry ends. Stored WITHOUT the query margin below, so
    // the wall stands exactly at the last mesh face instead of metres past it
    // out in the void.
    const hasBounds = Number.isFinite(minX) && Number.isFinite(maxX);
    this.edgeMinX = hasBounds ? minX : -Infinity;
    this.edgeMinZ = hasBounds ? minZ : -Infinity;
    this.edgeMaxX = hasBounds ? maxX : Infinity;
    this.edgeMaxZ = hasBounds ? maxZ : Infinity;
    const margin = 8;
    this.minX = minX - margin;
    this.minZ = minZ - margin;
    this.maxX = maxX + margin;
    this.maxZ = maxZ + margin;

    this.cols = Math.ceil((this.maxX - this.minX) / this.cell);
    this.rows = Math.ceil((this.maxZ - this.minZ) / this.cell);
    this.oCols = Math.ceil((this.maxX - this.minX) / this.obstacleCell);
    this.oRows = Math.ceil((this.maxZ - this.minZ) / this.obstacleCell);

    // --- storage ----------------------------------------------------------
    this.layerY = new Float32Array(this.cols * this.rows * this.layers);
    this.layerCount = new Uint8Array(this.cols * this.rows);
    // 1 = at least one roadway surface (road_/bridge_a/parking_area) was baked
    // into this cell. Traffic lanes validate against this rather than against
    // the general surface, which also counts grass and dirt as drivable.
    this.roadMask = new Uint8Array(this.cols * this.rows);
    // Surface family per ground cell for tire-mark looks (see SURF). Higher
    // wins; 0 is unbaked (renders as dirt).
    this.surfaceType = new Uint8Array(this.cols * this.rows);
    // Cells whose drivable surface came from the bridge family. Used by
    // `_bakeBridgeEdges` to add edge barriers without touching the deck.
    this.bridgeMask = new Uint8Array(this.cols * this.rows);
    // Cells on a raised median baked into a road's own geometry (the `road_b`
    // boulevard divider). Not solid, not a surface - purely a lane constraint.
    this.dividerMask = new Uint8Array(this.cols * this.rows);
    this.obstacleMask = new Uint8Array(this.oCols * this.oRows);
    this.obstacleBottom = new Float32Array(this.oCols * this.oRows);
    this.obstacleTop = new Float32Array(this.oCols * this.oRows);
    this.obstacleBottom.fill(Infinity);
    this.obstacleTop.fill(-Infinity);

    // --- optional provenance (debug only) ---------------------------------
    // `obstacleSource` is an index into `solidMeshes`; `obstacleKind` records
    // whether the cell was marked from that mesh's triangles or merely from its
    // bounding box. The second is the interesting one: a small mesh is baked as
    // a box, and a box covers far more ground than the mesh really occupies, so
    // it is the likely source of collisions that appear to happen in empty air.
    this.solidMeshes = [];
    if (this.trackSources) {
      this.obstacleSource = new Uint16Array(this.oCols * this.oRows);
      this.obstacleKind = new Uint8Array(this.oCols * this.oRows);
    } else {
      this.obstacleSource = null;
      this.obstacleKind = null;
    }

    // Camera-only occluders: world AABBs the chase camera must not enter,
    // even though the car ignores them (tree trunks, tall decor). Baked here
    // so the camera query stays a cheap array walk with no per-frame picking.
    // Each entry is [minX, minY, minZ, maxX, maxY, maxZ].
    this.cameraBoxes = [];
    // Camera voxel grid: the overhead geometry the CAR deliberately ignores
    // but the lens must not enter - high sign panels/arms and roofs. The car
    // grid skips anything above VEHICLE_MAX_HEIGHT (the
    // car passes underneath), so without this the boom sails straight through
    // a gantry board. Same 0.5 m cells as the car grid; each cell keeps the
    // merged [bottom, top] of that overhead matter and the boom tests its own
    // height against it, so empty air under a gantry stays clear while the
    // board itself pulls. Road/bridge DECK slabs are deliberately NOT here:
    // the lens drives on them, so a slab voxel cannot tell "on" from "under"
    // and yanks the boom on open deck. Decks are covered beneath-only by the
    // heightfield slab check in `cameraOcclusion` instead.
    this.camMask = new Uint8Array(this.oCols * this.oRows);
    this.camBottom = new Float32Array(this.oCols * this.oRows);
    this.camTop = new Float32Array(this.oCols * this.oRows);
    this.camBottom.fill(Infinity);
    this.camTop.fill(-Infinity);

    // --- bake -------------------------------------------------------------
    // Two passes: surfaces first, so every ground layer exists before any
    // solid measures car reach against it. A gantry standing on the 6 m
    // bridge deck must resolve the deck - not the ground far below it - or
    // its posts are filtered as "above the car" and the deck signs stay
    // pass-through (see bakeSolid).
    let surfaceMeshes = 0;
    let solidMeshes = 0;
    let triangles = 0;
    // Water is held back for a second pass: it must be baked after every road,
    // so a lake can never seal off a road that crosses it (see `bakeWater`).
    const waterMeshes = [];
    for (const { mesh, box } of boxes) {
      if (!mesh.name) continue;
      const name = mesh.name;
      if (WATER_RE.test(name)) {
        waterMeshes.push({ mesh, box });
        continue;
      }
      if (SURFACE_RE.test(name)) {
        triangles += bakeSurface(
          mesh,
          this,
          ROADWAY_RE.test(name),
          BRIDGE_RE.test(name),
          surfaceTypeFor(name),
        );
        if (DIVIDER_ROAD_RE.test(name)) bakeDividers(this, mesh, box);
        surfaceMeshes++;
        // NOTE: the bridge mesh is deliberately NOT baked into the camera
        // voxel grid. Its stay-cables fan across the lanes overhead, and a
        // voxel per cable yanks the boom for the whole crossing - far worse
        // than the one-frame cable pass-through AAA cameras accept from thin
        // geometry. The deck slab itself stays covered beneath-only by the
        // heightfield slab check in `cameraOcclusion`.
      }
    }
    // Pass 2 - solids and camera decor, with complete ground underneath.
    // Surfaces whose steep faces are structure (mountains, road barriers,
    // courts) must also block, so they fall through to the solid bake below.
    for (const { mesh, box } of boxes) {
      if (!mesh.name) continue;
      const name = mesh.name;
      if (WATER_RE.test(name)) continue;
      if (SURFACE_RE.test(name)) {
        if (!SURFACE_SOLID_RE.test(name)) continue;
      } else if (DECOR_RE.test(name)) {
        this._bakeCameraDecor(name, box);
        if (/^sand_/i.test(name)) this._stampSand(box);
        // Trees are decor for the camera (trunk-only occluder) but solid
        // for the car: their steep trunk faces bake as walls below, while
        // the canopy above car reach is skipped by the height filter.
        if (TREE_RE.test(name)) {
          // 0 is reserved for "no source recorded", so ids start at 1.
          const tsrc = this.trackSources ? this.solidMeshes.push({ mesh, box }) : 0;
          bakeSolid(this, mesh, box, tsrc, null, {
            anyHeight: false,
            fill: false,
            // Canopy flats must NOT become camera voxels: the lens has to
            // keep passing under leaves exactly as before.
            camFlats: false,
          });
          solidMeshes++;
        }
        continue;
      }
      // 0 is reserved for "no source recorded", so ids start at 1.
      const src = this.trackSources ? this.solidMeshes.push({ mesh, box }) : 0;
      const group = this.groupKey ? this.groupKey(mesh) : null;
      // These walls count at every height - a mountain is a wall at 20 m and an
      // elevated road's barrier is a wall at 4 m, both above the 2 m the filter
      // assumes a car can reach (see bakeSolidTriangles).
      const solidSurface = SURFACE_SOLID_RE.test(name);
      bakeSolid(this, mesh, box, src, group, {
        anyHeight: solidSurface,
        fill: solidSurface && SURFACE_SOLID_FILL_RE.test(name),
        // Road decks (`road_c`) and terrain must NOT voxelize their flat
        // faces for the camera: the lens drives ON those decks, and a deck
        // slab voxel would yank the boom even with open sky above. Decks only
        // matter when the car is BENEATH them, which the heightfield slab
        // check in `cameraOcclusion` handles (it can only fire from below).
        camFlats: !solidSurface,
      });
      solidMeshes++;
    }

    // Now every roadway layer exists, so the decks can be freed of the solid
    // their own structure baked into them. Water comes after this, as above.
    this._reliefBuriedSolids();

    for (const { mesh, box } of waterMeshes) {
      const src = this.trackSources ? this.solidMeshes.push({ mesh, box }) : 0;
      bakeWater(this, mesh, box, src);
      solidMeshes++;
    }

    // The bridge deck is drivable and must stay clear; only its side edges
    // should stop a car. Baking the whole bridge mesh sealed the deck, so the
    // barrier is synthesised here from the tagged deck cells instead.
    this._bakeBridgeEdges();

    let dividerCells = 0;
    for (let i = 0; i < this.dividerMask.length; i++) if (this.dividerMask[i]) dividerCells++;
    this.stats.dividerCells = dividerCells;
    this.stats.surfaceMeshes = surfaceMeshes;
    this.stats.solidMeshes = solidMeshes;
    this.stats.triangles = triangles;
    this.stats.cells = this.cols * this.rows;
    this.stats.buildMs = Math.round(performance.now() - t0);

    this._fillStats();
    console.info(
      `[collision] bake done in ${this.stats.buildMs} ms: ` +
        `${surfaceMeshes} surface, ${solidMeshes} solid, ` +
        `${this.stats.obstacleCells} obstacle cells`,
    );
  }

  /**
   * Build a barrier along the bridge deck's side edges only.
   *
   * The bridge mesh cannot be baked as a solid: its towers and 40 m cables are
   * steep faces that stamp straight across the drivable deck and seal it. So the
   * deck is located from the surface bake (`bridgeMask`) and this walks outward
   * from each deck cell to find where the drivable surface ends (the water beside
   * the deck). It then stamps a thin column at the car's height on the deck
   * cells within `inset` metres of that edge - NOT out at the water - so the
   * invisible wall sits inboard of the visible edge and the usable lane is
   * narrowed from both sides. `inset`/`range` come from the `bridgeEdgeInset`
   * and `bridgeEdgeRange` options; raise `bridgeEdgeInset` to pull the walls
   * further in, keep `range >= inset`.
   *
   * Requiring NO surface (rather than merely a lower one) is what keeps the
   * bridge approaches open: a ramp is still a surface, so its cells are never
   * within `inset` of a void edge and the path stays clear end to end.
   */
  _bakeBridgeEdges(range = 3.0, inset = 2.0, carHeight = 1.6) {
    if (!this.obstacleMask || !this.bridgeMask) return;
    const gc = this.cell;
    const maxSteps = Math.max(1, Math.ceil(range / gc));
    const insetSteps = Math.max(1, Math.round(inset / gc));
    const dirs = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ];
    const groundMax = (nr, nc) => {
      if (nr < 0 || nc < 0 || nr >= this.rows || nc >= this.cols)
        return -Infinity;
      const ngi = nr * this.cols + nc;
      const nb = ngi * this.layers;
      let m = -Infinity;
      for (let j = 0; j < this.layerCount[ngi]; j++) {
        if (this.layerY[nb + j] > m) m = this.layerY[nb + j];
      }
      return m;
    };
    // Steps from a deck cell to the nearest cell with no drivable surface.
    const stepsToVoid = (r, c) => {
      let best = Infinity;
      for (const [dr, dc] of dirs) {
        for (let s = 1; s <= maxSteps; s++) {
          if (groundMax(r + dr * s, c + dc * s) > -Infinity) continue;
          if (s < best) best = s;
          break;
        }
      }
      return best;
    };
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const gi = r * this.cols + c;
        if (!this.bridgeMask[gi] || !this.layerCount[gi]) continue;
        // Deck cells near an edge get the wall; interior cells (`d` large) do not.
        if (stepsToVoid(r, c) > insetSteps) continue;
        const base = gi * this.layers;
        let roadY = -Infinity;
        for (let j = 0; j < this.layerCount[gi]; j++) {
          if (this.layerY[base + j] > roadY) roadY = this.layerY[base + j];
        }
        const oi = this._obstacleCell(
          this.minX + (c + 0.5) * gc,
          this.minZ + (r + 0.5) * gc,
        );
        if (oi < 0) continue;
        const oc = oi % this.oCols;
        const or = (oi - oc) / this.oCols;
        this._markObstacle(
          oc,
          or,
          roadY - 1.0,
          roadY + carHeight,
          0,
          OBSTACLE_SOURCE.TRIANGLE,
          null,
        );
      }
    }
  }

  /**
   * Record a decor mesh as a camera-only occluder.
   *
   * The car bake skips DECOR families entirely (a canopy over the road must
   * not become a wall), but the chase camera still must not pass through a
   * tree trunk. Only trunks are kept: a narrow vertical cylinder around the
   * mesh centre, from the ground up ~3 m. The full canopy AABB is deliberately
   * NOT stored - it is metres wide and would yank the camera every time the
   * car passes under leaves. Other tall decor keeps its full box, but only
   * when it is tall enough to actually reach the boom.
   *
 * Trees additionally bake as solids (see the DECOR branch of the bake loop):
 * their steep trunk faces are walked exactly where they stand, so the car
 * hits the real trunk - never a cell offset by a lopsided canopy.
 */
  _bakeCameraDecor(name, box) {
    if (!box || !Number.isFinite(box.minX)) return;
    const height = box.maxY - box.minY;
    if (TREE_RE.test(name)) {
      if (height < 1.5) return;
      const cx = (box.minX + box.maxX) / 2;
      const cz = (box.minZ + box.maxZ) / 2;
      const r = 0.45;
      const top = Math.min(box.minY + 3.2, box.maxY);
      this.cameraBoxes.push([cx - r, box.minY - 0.2, cz - r, cx + r, top, cz + r]);
      return;
    }
    // Non-tree decor: keep it only if it can reach the camera boom (~1-4 m).
    // Bushes, flowers and ground decals stay ignored so they never pull the
    // camera for something the lens could simply pass over.
    if (height < 1.6) return;
    const spanX = box.maxX - box.minX;
    const spanZ = box.maxZ - box.minZ;
    if (spanX * spanZ > 60) return; // plazas/canopies, not occluders
    this.cameraBoxes.push([box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ]);
  }

  _fillStats() {
    let occupiedGround = 0;
    let roadCells = 0;
    let minGroundY = Infinity;
    let maxGroundY = -Infinity;
    for (let i = 0; i < this.layerCount.length; i++) {
      const n = this.layerCount[i];
      if (!n) continue;
      occupiedGround++;
      if (this.roadMask[i]) roadCells++;
      for (let j = 0; j < n; j++) {
        const y = this.layerY[i * this.layers + j];
        if (y < minGroundY) minGroundY = y;
        if (y > maxGroundY) maxGroundY = y;
      }
    }
    let occupiedObstacle = 0;
    for (let i = 0; i < this.obstacleMask.length; i++)
      if (this.obstacleMask[i]) occupiedObstacle++;
    this.stats.groundCells = occupiedGround;
    this.stats.roadCells = roadCells;
    this.stats.obstacleCells = occupiedObstacle;
    this.stats.cameraBoxes = this.cameraBoxes ? this.cameraBoxes.length : 0;
    let camCells = 0;
    if (this.camMask) for (let i = 0; i < this.camMask.length; i++) if (this.camMask[i]) camCells++;
    this.stats.cameraCells = camCells;
    const r2 = (v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : v);
    this.stats.worldEdge = {
      minX: r2(this.edgeMinX),
      minZ: r2(this.edgeMinZ),
      maxX: r2(this.edgeMaxX),
      maxZ: r2(this.edgeMaxZ),
    };
    this.stats.minGroundY = Number.isFinite(minGroundY)
      ? Math.round(minGroundY * 100) / 100
      : null;
    this.stats.maxGroundY = Number.isFinite(maxGroundY)
      ? Math.round(maxGroundY * 100) / 100
      : null;
  }

  // ---------------------------------------------------------------- queries

  /** Cell index for a world position; -1 when outside the baked area. */
  _groundCell(x, z) {
    const c = Math.floor((x - this.minX) / this.cell);
    const r = Math.floor((z - this.minZ) / this.cell);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return -1;
    return r * this.cols + c;
  }

  _obstacleCell(x, z) {
    const c = Math.floor((x - this.minX) / this.obstacleCell);
    const r = Math.floor((z - this.minZ) / this.obstacleCell);
    if (c < 0 || r < 0 || c >= this.oCols || r >= this.oRows) return -1;
    return r * this.oCols + c;
  }

  /**
   * Invisible world-edge walls: the production-standard way to keep the player
   * inside the map. Four axis-aligned planes at the map geometry extents; the
   * car collides with them like any other wall, at ANY height, so driving off
   * the end of an elevated deck (`road_c_03.012`) stops at the edge instead of
   * sailing out into the void.
   *
   * Tested as the footprint's world-axis extent (not the centre), so a bumper
   * crossing the line counts while every wheel is still on real ground. Full
   * height by design: there is no "over" for the edge of the world.
   */
  _outsidePlay(x, z, halfLength, halfWidth, heading) {
    const sin = Math.abs(Math.sin(heading));
    const cos = Math.abs(Math.cos(heading));
    const ex = halfLength * sin + halfWidth * cos;
    const ez = halfLength * cos + halfWidth * sin;
    return (
      x - ex < this.edgeMinX ||
      x + ex > this.edgeMaxX ||
      z - ez < this.edgeMinZ ||
      z + ez > this.edgeMaxZ
    );
  }

  /** Point version (plus a pad, e.g. the lens radius) for single queries. */
  _pointOutsidePlay(x, z, pad = 0) {
    return (
      x < this.edgeMinX - pad ||
      x > this.edgeMaxX + pad ||
      z < this.edgeMinZ - pad ||
      z > this.edgeMaxZ + pad
    );
  }

  /**
   * Height of the drivable surface at (x,z) as seen from a car whose current
   * ground height is `refY`.
   *
   * `headroom` is how tall the car is, and it is what separates "too tall to
   * climb" from "high enough to drive under". It defaults to 0, which disables
   * the check, so a caller that is not asking about a vehicle keeps the plain
   * height-field answer.
   *
   * @returns {{ y: number|null, kind: "ground"|"wall"|"drop"|"none" }}
   *   - ground: a surface within reach; `y` is its interpolated height
   *   - wall:   something is in the way - every surface is above the step
   *             limit, or one sits between the step limit and the roof
   *   - drop:   the surface fell further than `reach` (drive off a ledge)
   *   - none:   no baked surface at all (outside the map, or a gap)
   */
  groundAt(
    x,
    z,
    refY,
    { stepUp = 0.34, reach = 6, skipInterp = false, headroom = 0 } = {},
  ) {
    const cell = this._groundCell(x, z);
    if (cell < 0) return { y: this.fallbackY, kind: "none" };
    const count = this.layerCount[cell];
    if (count === 0) return { y: this.fallbackY, kind: "none" };

    const base = cell * this.layers;
    const lo = refY - reach;
    const hi = refY + stepUp;
    // Split the surfaces above the car three ways. Up to `hi` the wheel can
    // roll onto them. At `refY + headroom` and above the car passes underneath
    // (a bridge deck, a sign board, a gantry). The band in between is filled
    // space the car cannot get through, and it has to be reported.
    const over = refY + headroom;
    let best = null;
    let minL = Infinity;
    let maxL = -Infinity;
    let blocker = null;
    for (let j = 0; j < count; j++) {
      const h = this.layerY[base + j];
      if (h < minL) minL = h;
      if (h > maxL) maxL = h;
      if (
        h > hi + STEP_EPS &&
        h < over - STEP_EPS &&
        (blocker === null || h < blocker)
      ) {
        blocker = h;
      }
      if (h <= hi + STEP_EPS && h >= lo && (best === null || h > best))
        best = h;
    }
    if (best === null) {
      if (minL > hi + STEP_EPS) return { y: null, kind: "wall" };
      return { y: maxL, kind: "drop" };
    }

    // Bilinear blend with the four neighbouring cell centres. A neighbour only
    // contributes if it has a surface close to `best`, otherwise the field is
    // extended flat, so a deck edge never ramps down into thin air.
    const gx = (x - this.minX) / this.cell - 0.5;
    const gz = (z - this.minZ) / this.cell - 0.5;
    const ix = Math.floor(gx);
    const iz = Math.floor(gz);
    const fx = gx - ix;
    const fz = gz - iz;
    const h00 = this._join(ix, iz, best);
    const h10 = this._join(ix + 1, iz, best);
    const h01 = this._join(ix, iz + 1, best);
    const h11 = this._join(ix + 1, iz + 1, best);
    const top = h00 + (h10 - h00) * fx;
    const bottom = h01 + (h11 - h01) * fx;
    const y = skipInterp ? best : top + (bottom - top) * fz;

    // A height field stores one sample per cell per surface, so a hurdle
    // standing on a road shares a cell with that road. The road is a perfectly
    // good answer to "what height is the ground here", which is why the step
    // test used to miss every hurdle: it asked what the car could stand on, and
    // the road answered, so the car read straight through the obstacle and
    // drove over it. Only cells with NO surface in reach could ever report a
    // wall, and a hurdle is never alone in its cell.
    //
    // Comparing the obstacle against the interpolated ground rather than
    // against `refY` keeps ramps climbable. A layer is sampled at its cell
    // centre, so a ramp's stored height sits up to half a metre ahead of the
    // point being queried; measuring the rise from the interpolated surface
    // discounts that, leaving a continuous slope climbable while a discrete
    // obstacle, which is a full step above the road, still stops the car.
    if (blocker !== null && blocker - y > stepUp + STEP_EPS)
      return { y: null, kind: "wall" };
    return { y, kind: "ground" };
  }

  /** A neighbouring cell's surface nearest to `ref`, or `ref` if it has none. */
  _join(c, r, ref) {
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return ref;
    const cell = r * this.cols + c;
    const count = this.layerCount[cell];
    if (!count) return ref;
    const base = cell * this.layers;
    let pick = this.layerY[base];
    let bestD = Math.abs(pick - ref);
    for (let j = 1; j < count; j++) {
      const d = Math.abs(this.layerY[base + j] - ref);
      if (d < bestD) {
        bestD = d;
        pick = this.layerY[base + j];
      }
    }
    return bestD <= this.joinTol ? pick : ref;
  }

  /**
   * True when a solid column at (x,z) overlaps the vertical span
   * [bottomY, topY]. Called with the chassis span, so anything entirely below
   * the body (a kerb), or entirely above it (an overhead sign), is ignored.
   */
  blockedAt(x, z, bottomY, topY) {
    if (this._pointOutsidePlay(x, z)) return true;
    const cell = this._obstacleCell(x, z);
    if (cell < 0 || !this.obstacleMask[cell]) return false;
    return this.obstacleBottom[cell] < topY && this.obstacleTop[cell] > bottomY;
  }

  /**
   * True when the car's footprint overlaps anything solid.
   *
   * The footprint is tested as a rectangle against the obstacle grid rather than
   * by sampling a handful of points. Point sampling is not merely approximate
   * here, it is blind to the case that matters most: a thin wall running ALONGSIDE
   * the car, parallel to travel. A 0.5 m sign wall next to a 1.9 m wide car sits
   * neatly between two lateral sample points, so the car drives straight through
   * it. Iterating the cells the rectangle actually covers has no such gaps.
   *
   * @param x,z      centre of the car
   * @param heading  facing, as (sin, cos) on x/z
   * @param halfLength  half the car's length, along heading
   * @param halfWidth   half the car's width, across heading
   * @param hits     optional array; when given, every overlapping cell is
   *                 appended to it as a contact record instead of being
   *                 swallowed by the early return. Debug instrumentation only -
   *                 with no collector the loop is byte-for-byte the hot path.
   */
  blockedRect(
    x,
    z,
    heading,
    halfLength,
    halfWidth,
    bottomY,
    topY,
    hits = null,
    options = null,
  ) {
    const sin = Math.sin(heading);
    const cos = Math.cos(heading);
    // World-edge walls first: nothing past the map extents is drivable, at any
    // height. The footprint extent (not the centre) is what crosses the line,
    // so the car stops with its wheels still on real ground. Always solid -
    // destructible filtering must never open a hole in the edge of the world.
    if (this._outsidePlay(x, z, halfLength, halfWidth, heading)) {
      if (hits && hits.length < 64) {
        hits.push({
          x: Math.min(Math.max(x, this.edgeMinX), this.edgeMaxX),
          z: Math.min(Math.max(z, this.edgeMinZ), this.edgeMaxZ),
          y: (bottomY + topY) / 2,
          kind: "edge",
          mesh: "__world_edge__",
          from: 3,
          box: null,
          meshRef: null,
        });
      }
      return true;
    }
    // The rotated rectangle's extent is its half-diagonal, which bounds it.
    const reach = Math.hypot(halfLength, halfWidth);

    const c0 = Math.floor((x - reach - this.minX) / this.obstacleCell);
    const c1 = Math.floor((x + reach - this.minX) / this.obstacleCell);
    const r0 = Math.floor((z - reach - this.minZ) / this.obstacleCell);
    const r1 = Math.floor((z + reach - this.minZ) / this.obstacleCell);
    if (c1 < 0 || r1 < 0 || c0 >= this.oCols || r0 >= this.oRows) return false;

    const oc = this.obstacleCell;
    const mask = this.obstacleMask;
    const bottom = this.obstacleBottom;
    const top = this.obstacleTop;
    // Traffic skips cells owned by destructible families (street signs,
    // fences, barrels, etc.) so a misplaced kerb-side prop cannot strand a
    // car that is otherwise correctly on its lane. The cells stay solid
    // for the player, who smashes through them at speed instead. Cells
    // with no group ownership (walls, buildings, parked-scenery) still
    // block traffic, so this only relaxes the small roadside clutter.
    const ignoreDestructibles = !!(options && options.ignoreDestructibles);
    const cellGroup =
      ignoreDestructibles && this.cellGroup ? this.cellGroup : null;
    let found = false;

    for (let r = Math.max(0, r0); r <= Math.min(this.oRows - 1, r1); r++) {
      const rowBase = r * this.oCols;
      for (let c = Math.max(0, c0); c <= Math.min(this.oCols - 1, c1); c++) {
        const i = rowBase + c;
        if (!mask[i]) continue;
        if (cellGroup && cellGroup.get(i) !== undefined) continue;
        if (bottom[i] >= topY || top[i] <= bottomY) continue;

        const nx = this.minX + (c + 0.5) * oc;
        const nz = this.minZ + (r + 0.5) * oc;
        const dx = nx - x;
        const dz = nz - z;
        // Project onto the car's own axes: along = fore/aft, across = left/right.
        const along = Math.abs(dx * sin + dz * cos);
        const across = Math.abs(dx * cos - dz * sin);

        // Cell overlaps the rectangle? Compare the cell's centre against the
        // car's own axes, widened by half a cell. Half a cell is exactly the
        // distance from a cell's centre to its edge, so anything further out
        // than that provably cannot overlap - wider tolerances start reporting
        // phantom walls on roads that are actually clear.
        if (along <= halfLength + oc * 0.5 && across <= halfWidth + oc * 0.5) {
          found = true;
          if (hits && hits.length < 64)
            hits.push(this._contact(nx, nz, i, "column"));
          if (!hits) return true;
        }
      }
    }
    return found;
  }

  /**
   * Fraction along the segment pivot -> target where the chase camera first
   * becomes occluded, or 1 when the whole boom is clear.
   *
   * This is the camera's equivalent of the car's `blockedRect`, but for a
   * moving lens rather than a chassis: a thin sphere-cast from the car's roof
   * pivot to the ideal camera position. Two sources are tested:
   *
   *  - the baked solid grid (buildings, walls, signs, barriers) - the same
   *    cells that stop the car, tested as a vertical overlap of the ray's
   *    height against each cell's [bottom, top] span;
   *  - the camera voxel grid (high sign panels/arms, roofs) - the overhead
   *    matter the car passes under, tested the same way;
   *  - the heightfield slab test: a baked road/deck surface just above the
   *    boom point means the lens is entering the slab from below. This only
   *    fires when the car is BENEATH a deck - a boom on or above it can never
   *    match, so open-deck driving is never yanked;
   *  - `cameraBoxes` (tree trunks + tall decor the car ignores), tested as
   *    ray-vs-AABB slabs.
   *
   * `radius` inflates both tests by the lens size so the near plane never sits
   * exactly on a face. March step is half an obstacle cell, so no 0.5 m wall
   * can be skipped. Cheap by design: ~40 grid reads + a few hundred slab
   * tests, no mesh picking, no triangle work per frame.
   *
   * @returns t in (0, 1] - multiply the boom vector by it to reach the hit.
   */
  cameraOcclusion(ax, ay, az, bx, by, bz, radius = 0.35) {
    const dx = bx - ax;
    const dy = by - ay;
    const dz = bz - az;
    const len = Math.hypot(dx, dy, dz);
    if (!(len > 1e-6)) return 1;
    // March from the pivot outward so the FIRST hit wins (nearest occluder).
    const step = Math.max(0.2, this.obstacleCell * 0.5);
    const steps = Math.max(1, Math.ceil(len / step));
    const mask = this.obstacleMask;
    const bottom = this.obstacleBottom;
    const top = this.obstacleTop;
    const camMask = this.camMask;
    const camBottom = this.camBottom;
    const camTop = this.camTop;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      const x = ax + dx * t;
      const y = ay + dy * t;
      const z = az + dz * t;
      // World edge pulls the lens too, so the boom never shows the void past
      // the map while the car leans on the invisible wall.
      if (this._pointOutsidePlay(x, z, radius)) return t;
      const cell = this._obstacleCell(x, z);
      if (cell >= 0) {
        if (mask[cell]) {
          if (bottom[cell] - radius < y && y < top[cell] + radius) return t;
        }
        if (camMask && camMask[cell]) {
          if (camBottom[cell] - radius < y && y < camTop[cell] + radius) return t;
        }
        // Deck slab beneath-only check: a baked surface just above the boom
        // point means the lens is entering the slab body from below (driving
        // under a `road_c` deck or the bridge). A boom ON or above the deck
        // can never match - every surface there is below the lens - so this
        // cannot yank the camera on open deck, only from underneath.
        const over = this.highestAbove(x, z, y - radius);
        if (over !== null && over < y + CAM_SLAB_DOWN + radius) return t;
      }
      if (this.cameraBoxes && this.cameraBoxes.length) {
        for (let k = 0; k < this.cameraBoxes.length; k++) {
          const b = this.cameraBoxes[k];
          // Broadphase: skip boxes the sample cannot be inside (inflated).
          if (x < b[0] - radius || x > b[3] + radius) continue;
          if (z < b[2] - radius || z > b[5] + radius) continue;
          if (y < b[1] - radius || y > b[4] + radius) continue;
          return t;
        }
      }
    }
    // Slab test catches thin boxes the march stepped over between samples.
    // Kept second so the common clear case pays only the march above.
    if (this.cameraBoxes && this.cameraBoxes.length) {
      let best = 1;
      for (let k = 0; k < this.cameraBoxes.length; k++) {
        const t = rayAabb(ax, ay, az, dx, dy, dz, this.cameraBoxes[k], radius);
        if (t !== -1 && t < best) {
          best = t;
          if (best <= 1 / steps) break;
        }
      }
      if (best < 1) {
        // Confirm the slab hit is not behind a grid hit already returned;
        // the march above would have returned it, so this is a between-sample.
        return best;
      }
    }
    return 1;
  }

  /**
   * True when a camera-height point sits inside solid geometry (post-pull
   * safety check). Same tests as `cameraOcclusion` but for a single point.
   */
  cameraPointBlocked(x, y, z, radius = 0.3) {
    if (this._pointOutsidePlay(x, z, radius)) return true;
    const cell = this._obstacleCell(x, z);
    if (cell >= 0) {
      if (this.obstacleMask[cell]) {
        if (this.obstacleBottom[cell] - radius < y && y < this.obstacleTop[cell] + radius) return true;
      }
      if (this.camMask && this.camMask[cell]) {
        if (this.camBottom[cell] - radius < y && y < this.camTop[cell] + radius) return true;
      }
      // Same beneath-only slab test as the march (see `cameraOcclusion`).
      const over = this.highestAbove(x, z, y - radius);
      if (over !== null && over < y + CAM_SLAB_DOWN + radius) return true;
    }
    if (this.cameraBoxes) {
      for (let k = 0; k < this.cameraBoxes.length; k++) {
        const b = this.cameraBoxes[k];
        if (x < b[0] - radius || x > b[3] + radius) continue;
        if (z < b[2] - radius || z > b[5] + radius) continue;
        if (y < b[1] - radius || y > b[4] + radius) continue;
        return true;
      }
    }
    return false;
  }

  /** Contact record for one blocking cell, including where it came from. */
  _contact(x, z, i, kind) {
    const src = this.obstacleSource ? this.obstacleSource[i] : 0;
    const solid = src ? this.solidMeshes[src - 1] : null;
    return {
      x,
      z,
      y: (this.obstacleBottom[i] + this.obstacleTop[i]) / 2,
      kind,
      mesh: solid ? solid.mesh.name : null,
      // "aabb" means the cell is inside that mesh's bounding box but was NOT
      // backed by a triangle of its own - the case where a car can be blocked by
      // empty space.
      from: this.obstacleKind ? this.obstacleKind[i] : OBSTACLE_SOURCE.NONE,
      box: solid ? solid.box : null,
      meshRef: solid ? solid.mesh : null,
    };
  }

  /** Everything solid at (x,z), for debug inspection of a single spot. */
  obstacleInfoAt(x, z) {
    const i = this._obstacleCell(x, z);
    if (i < 0 || !this.obstacleMask[i]) return null;
    return this._contact(
      this.minX + ((i % this.oCols) + 0.5) * this.obstacleCell,
      this.minZ + (Math.floor(i / this.oCols) + 0.5) * this.obstacleCell,
      i,
      "column",
    );
  }

  /** Lowest surface in this cell strictly above `y`, or null (debug helper). */
  highestAbove(x, z, y) {
    const cell = this._groundCell(x, z);
    if (cell < 0) return null;
    const count = this.layerCount[cell];
    const base = cell * this.layers;
    let best = null;
    for (let j = 0; j < count; j++) {
      const h = this.layerY[base + j];
      if (h > y && (best === null || h < best)) best = h;
    }
    return best;
  }

  /** Lowest baked surface in a cell (used to place obstacles on the ground). */
  lowestAt(x, z) {
    const cell = this._groundCell(x, z);
    if (cell < 0) return null;
    const count = this.layerCount[cell];
    if (!count) return null;
    const base = cell * this.layers;
    let min = Infinity;
    for (let j = 0; j < count; j++) min = Math.min(min, this.layerY[base + j]);
    return min;
  }

  /**
   * True when the cell at (x,z) contains roadway surface (tarmac, deck, ramp
   * or parking). Coarse by design - it answers "is this spot on a road?" for
   * lane validation, not "where exactly is the lane edge?".
   */
  isRoadAt(x, z) {
    const cell = this._groundCell(x, z);
    return cell >= 0 && this.roadMask[cell] === 1;
  }

  /**
   * True when the cell at (x,z) is part of a raised median baked into a road's
   * own geometry - the `road_b` divider. Traffic lanes must never sit on or
   * cross these; the road surface there reads as roadway, which is exactly why
   * the divider used to be invisible to route building.
   */
  isDividerAt(x, z) {
    const cell = this._groundCell(x, z);
    return cell >= 0 && this.dividerMask[cell] === 1;
  }

  /** True when the cell at (x,z) is bridge-family roadway (the deck). */
  isBridgeAt(x, z) {
    const cell = this._groundCell(x, z);
    return cell >= 0 && this.bridgeMask[cell] === 1;
  }

  /**
   * Surface family at (x,z) for tire-mark looks: 0 unknown (= dirt look),
   * 1 dirt, 2 grass, 3 sand, 4 road. See SURF.
   */
  surfaceAt(x, z) {
    const cell = this._groundCell(x, z);
    if (cell < 0) return 0;
    return this.surfaceType[cell];
  }

  /**
   * Stamp a sand patch's AABB footprint as SURF.SAND, but only over
   * dirt/grass - never over road or court, which outrank it. Sand meshes
   * are decor (never surface-baked), so without this they would read as
   * whatever lies beneath them.
   */
  _stampSand(box) {
    const cs = this.cell;
    const c0 = Math.max(0, Math.floor((box.minX - this.minX) / cs));
    const c1 = Math.min(this.cols - 1, Math.floor((box.maxX - this.minX) / cs));
    const r0 = Math.max(0, Math.floor((box.minZ - this.minZ) / cs));
    const r1 = Math.min(this.rows - 1, Math.floor((box.maxZ - this.minZ) / cs));
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const i = r * this.cols + c;
        if (this.surfaceType[i] < SURF.SAND) this.surfaceType[i] = SURF.SAND;
      }
    }
  }

  /**
   * Height of the carriageway surface at (x,z), or null if this is not a road
   * cell.
   *
   * The TOPMOST layer, not `lowestAt`: where a road passes under a bridge the
   * cell holds both the road at ground level and the deck overhead, and it is
   * the upper one that a car driving on that structure actually rests on.
   */
  roadSurfaceAt(x, z) {
    const cell = this._groundCell(x, z);
    if (cell < 0 || this.roadMask[cell] !== 1) return null;
    const count = this.layerCount[cell];
    if (!count) return null;
    // `_insertLayer` keeps the list sorted DESCENDING, so the topmost surface
    // is the head of it, not the tail.
    return this.layerY[cell * this.layers];
  }

  // ---------------------------------------------------------------- baking

  /** Insert a surface height into a cell's sorted layer list. */
  _insertLayer(cell, y) {
    const base = cell * this.layers;
    const count = this.layerCount[cell];

    for (let j = 0; j < count; j++) {
      if (Math.abs(this.layerY[base + j] - y) <= LAYER_EPS) return;
    }

    if (count < this.layers) {
      let j = count;
      while (j > 0 && this.layerY[base + j - 1] < y) {
        this.layerY[base + j] = this.layerY[base + j - 1];
        j--;
      }
      this.layerY[base + j] = y;
      this.layerCount[cell] = count + 1;
      return;
    }

    // Full: drop the entry whose neighbours are closest, i.e. the most
    // redundant one. Keeps both a low ground surface and a high deck.
    const ys = new Float32Array(count);
    for (let j = 0; j < count; j++) ys[j] = this.layerY[base + j];
    let dropAt = 0;
    let dropCost = Infinity;
    for (let j = 0; j < count; j++) {
      const gapAbove = j > 0 ? Math.abs(ys[j - 1] - ys[j]) : Infinity;
      const gapBelow = j < count - 1 ? Math.abs(ys[j] - ys[j + 1]) : Infinity;
      const cost = Math.min(gapAbove, gapBelow);
      if (cost < dropCost) {
        dropCost = cost;
        dropAt = j;
      }
    }
    if (y > ys[dropAt]) ys[dropAt] = y;
    for (let a = 0; a < count; a++) {
      for (let b = a + 1; b < count; b++) {
        if (ys[b] > ys[a]) {
          const t = ys[a];
          ys[a] = ys[b];
          ys[b] = t;
        }
      }
    }
    for (let j = 0; j < count; j++) this.layerY[base + j] = ys[j];
  }

  /**
   * Free the carriageways that their own structure has sealed shut.
   *
   * A mesh that is both drivable and solid - a `road_c` deck, a `landscape`
   * slope - is stamped for its barriers, and the stamping is not selective: the
   * ramp slab, the embankment beneath it and the span between the pillars are
   * baked too. The obstacle grid keeps ONE merged [bottom, top] per cell, so the
   * slab's underside drags a cell's bottom down to the foot of the ramp while the
   * parapet beside it pushes the top up. Those two spans merge into a single
   * ground-to-sky column across the carriageway, and the car is walled off by the
   * very deck it is standing on. That is why both bridge approaches,
   * `road_c_02.003` and `road_c_02.004`, could not be driven on at all.
   *
   * A post-pass rather than a filter inside the bake, because the roadway layer
   * for a cell is often written by a DIFFERENT mesh that appears later in the
   * list - at the time the ramp is stamped, its own surface may not exist yet, so
   * an in-bake check would see no road and let the seal through.
   *
   * Two cases, both keyed on the drivable surface at the cell:
   *
   *  - nothing rises above it, so the solid is buried in the structure under
   *    the road and is dropped outright;
   *  - something does rise above it, so it is a barrier after all, and only the
   *    buried part of its span is trimmed. The part above the road is left
   *    alone, which is what keeps a parapet able to stop the car.
   *
   * Cells owned by a destructible prop keep their exact span: `clearGroup`
   * releases a cell only when the stored span still matches what that prop baked,
   * so trimming a prop's own column would make it impossible to destroy.
   *
   * Runs before the water pass, which stamps after it and skips roadway anyway.
   */
  /**
   * Height of the surface a mesh stands on: the highest baked ground layer
   * at or just below its base. A sign on the 6 m bridge deck resolves to the
   * deck, not the ground far below it. Falls back to the lowest layer present
   * (a mesh sunk below grade still resolves to the ground), then to the base
   * itself when there is no ground at all yet.
   *
   * Only meaningful after the surface pass has baked every layer.
   */
  _standSurface(x, z, baseY) {
    const c = Math.floor((x - this.minX) / this.cell);
    const r = Math.floor((z - this.minZ) / this.cell);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return baseY;
    const cell = r * this.cols + c;
    const n = this.layerCount[cell];
    if (!n) return baseY;
    const base = cell * this.layers;
    let best = -Infinity;
    let lowest = Infinity;
    for (let j = 0; j < n; j++) {
      const y = this.layerY[base + j];
      if (y < lowest) lowest = y;
      if (y <= baseY + 0.5 && y > best) best = y;
    }
    if (best > -Infinity) return best;
    if (lowest < Infinity) return lowest;
    return baseY;
  }

  _reliefBuriedSolids() {
    const oc = this.obstacleCell;
    let cleared = 0;
    let trimmed = 0;
    for (let r = 0; r < this.oRows; r++) {
      for (let c = 0; c < this.oCols; c++) {
        const i = r * this.oCols + c;
        if (!this.obstacleMask[i]) continue;
        const road = this.roadSurfaceAt(
          this.minX + (c + 0.5) * oc,
          this.minZ + (r + 0.5) * oc,
        );
        if (road === null) continue;
        if (this.obstacleTop[i] <= road + BURIED_SOLID_TOLERANCE) {
          this.obstacleMask[i] = 0;
          this.obstacleBottom[i] = Infinity;
          this.obstacleTop[i] = -Infinity;
          if (this.obstacleSource) {
            this.obstacleSource[i] = 0;
            this.obstacleKind[i] = OBSTACLE_SOURCE.NONE;
          }
          const key = this.cellGroup?.get(i);
          if (key !== undefined) {
            this.cellGroup.delete(i);
            this.groups?.get(key)?.cells.delete(i);
          }
          cleared++;
        } else if (
          this.obstacleBottom[i] < road &&
          this.cellGroup?.get(i) === undefined
        ) {
          this.obstacleBottom[i] = road;
          trimmed++;
        }
      }
    }
    this.stats.buriedCellsCleared = cleared;
    this.stats.buriedCellsTrimmed = trimmed;
  }

  _markObstacle(
    c,
    r,
    bottom,
    top,
    src = 0,
    kind = OBSTACLE_SOURCE.TRIANGLE,
    group = null,
  ) {
    if (c < 0 || r < 0 || c >= this.oCols || r >= this.oRows) return;
    const i = r * this.oCols + c;
    // Whether anything (any mesh, including an earlier triangle of this same
    // one) had already claimed this cell. Only the FIRST claimant may own it,
    // which is what keeps clearing a broken prop from deleting a wall.
    const wasEmpty = this.obstacleMask[i] === 0;
    if (bottom < this.obstacleBottom[i]) this.obstacleBottom[i] = bottom;
    if (top > this.obstacleTop[i]) this.obstacleTop[i] = top;
    this.obstacleMask[i] = 1;
    // Keep the first source recorded: a cell is only re-marked when another mesh
    // crosses it, and the first is the one the car will visually appear to hit.
    if (this.obstacleSource && !this.obstacleSource[i]) {
      this.obstacleSource[i] = src;
      this.obstacleKind[i] = kind;
    }
    // Record this object's own contribution to the cell, for later clearing.
    if (group !== null && this.groups) {
      if (this.cellGroup.get(i) === undefined) {
        if (wasEmpty) this.cellGroup.set(i, group);
      }
      if (this.cellGroup.get(i) === group) {
        let entry = this.groups.get(group);
        if (!entry) {
          entry = { cells: new Map(), cleared: new Set() };
          this.groups.set(group, entry);
        }
        const rec = entry.cells.get(i);
        if (!rec) entry.cells.set(i, { bottom, top });
        else {
          if (bottom < rec.bottom) rec.bottom = bottom;
          if (top > rec.top) rec.top = top;
        }
      }
    }
  }

  /**
   * Stamp overhead matter into the camera voxel grid.
   *
   * Unlike `_markObstacle` this keeps no source/group bookkeeping: camera
   * voxels are never cleared (destructible families are excluded at bake time
   * so there is nothing to clear) and never debugged per-mesh. Merged
   * [bottom, top] per cell like the car grid; the boom's point-height test
   * makes the merge harmless (empty air between two slabs in one cell reads
   * as solid, which is conservative but safe and rare).
   */
  _markCamera(c, r, bottom, top) {
    if (c < 0 || r < 0 || c >= this.oCols || r >= this.oRows) return;
    if (!(top > bottom)) {
      // Flat faces have zero thickness on paper; give them one so the lens
      // radius test has something to hit. The inflation in the query covers
      // the rest of a real slab's depth.
      const mid = (top + bottom) / 2;
      bottom = mid - 0.15;
      top = mid + 0.15;
    }
    const i = r * this.oCols + c;
    if (bottom < this.camBottom[i]) this.camBottom[i] = bottom;
    if (top > this.camTop[i]) this.camTop[i] = top;
    this.camMask[i] = 1;
  }

  /** Mark the cell containing a world point. */
  _markObstacleAt(
    x,
    z,
    bottom,
    top,
    src = 0,
    kind = OBSTACLE_SOURCE.TRIANGLE,
    group = null,
  ) {
    const c = Math.floor((x - this.minX) / this.obstacleCell);
    const r = Math.floor((z - this.minZ) / this.obstacleCell);
    this._markObstacle(c, r, bottom, top, src, kind, group);
  }

  /**
   * Drop the collision baked from one object (a key previously returned by
   * `groupKey`), so a prop the player has just destroyed stops blocking.
   *
   * A cell is only cleared when the object was its sole author - if another
   * mesh has since widened the same cell (a fence standing against a wall), the
   * stored span no longer matches what this object baked and the cell stays
   * solid. That keeps destruction from opening a hole in a building.
   *
   * @returns the number of obstacle cells released.
   */
  clearGroup(key) {
    const entry = this.groups?.get(key);
    if (!entry) return 0;
    let cleared = 0;
    for (const [i, rec] of entry.cells) {
      if (this.cellGroup?.get(i) === key) this.cellGroup.delete(i);
      if (!this.obstacleMask[i]) continue;
      if (Math.abs(this.obstacleBottom[i] - rec.bottom) > 0.05) continue;
      if (Math.abs(this.obstacleTop[i] - rec.top) > 0.05) continue;
      this.obstacleMask[i] = 0;
      this.obstacleBottom[i] = Infinity;
      this.obstacleTop[i] = -Infinity;
      entry.cleared.add(i);
      cleared++;
    }
    return cleared;
  }

  /**
   * Put back the collision `clearGroup` released, so a prop that has been left
   * behind repairs itself. Cells only refill if they are still empty, so a wall
   * or another prop that has since taken the space is never overwritten.
   *
   * @returns the number of obstacle cells restored.
   */
  restoreGroup(key) {
    const entry = this.groups?.get(key);
    if (!entry?.cleared?.size) return 0;
    let restored = 0;
    for (const i of entry.cleared) {
      const rec = entry.cells.get(i);
      if (!rec || this.obstacleMask[i]) continue;
      this.obstacleMask[i] = 1;
      this.obstacleBottom[i] = rec.bottom;
      this.obstacleTop[i] = rec.top;
      this.cellGroup.set(i, key);
      restored++;
    }
    entry.cleared.clear();
    return restored;
  }
}

// ------------------------------------------------------------------ baking

/**
 * Rasterise the raised median baked into a `road_b` tile's own geometry.
 *
 * A `road_b` boulevard runs both directions inside one mesh, divided by a
 * raised strip a few tens of centimetres tall. That strip is made of steep
 * triangle faces ("fins"), so the surface baker - which keeps only shallow
 * faces - never records it, and because `road_b` is not a SURFACE_SOLID family
 * it never became a wall either. The divider was therefore invisible: the mask
 * called it roadway, and traffic lanes were built straight down it.
 *
 * This pass finds the fins instead. A face qualifies when it is steep, rises
 * between `DIVIDER_MIN_RISE` and `DIVIDER_MAX_RISE` above the tile base, and
 * sits near the tile's centre in the axis ACROSS its own run - that last test
 * is what separates a central median from the outer kerbs at the tile edge,
 * which are the same height but hug the boundary. Marked cells are a lane
 * constraint only (`isDividerAt`); they stay non-solid and non-surface.
 */
function bakeDividers(col, mesh, box) {
  const m = mesh.getWorldMatrix().m;
  const positions = mesh.getVerticesData("position");
  if (!positions || positions.length < 9) return 0;
  const indices = mesh.getIndices();
  const triCount = indices ? indices.length / 3 : positions.length / 9;
  const det =
    m[0] * (m[5] * m[10] - m[6] * m[9]) -
    m[1] * (m[4] * m[10] - m[6] * m[8]) +
    m[2] * (m[4] * m[9] - m[5] * m[8]);
  const flip = det < 0 ? -1 : 1;

  const spanX = box.maxX - box.minX;
  const spanZ = box.maxZ - box.minZ;
  const tileCx = (box.minX + box.maxX) / 2;
  const tileCz = (box.minZ + box.maxZ) / 2;
  const px = (i) => m[0] * positions[i] + m[4] * positions[i + 1] + m[8] * positions[i + 2] + m[12];
  const py = (i) => m[1] * positions[i] + m[5] * positions[i + 1] + m[9] * positions[i + 2] + m[13];
  const pz = (i) => m[2] * positions[i] + m[6] * positions[i + 1] + m[10] * positions[i + 2] + m[14];

  let marked = 0;
  for (let t = 0; t < triCount; t++) {
    const ia = (indices ? indices[t * 3] : t * 3) * 3;
    const ib = (indices ? indices[t * 3 + 1] : t * 3 + 1) * 3;
    const ic = (indices ? indices[t * 3 + 2] : t * 3 + 2) * 3;
    const ax = px(ia), ay = py(ia), az = pz(ia);
    const bx = px(ib), by = py(ib), bz = pz(ib);
    const cx = px(ic), cy = py(ic), cz = pz(ic);
    const ux = bx - ax, uy = by - ay, uz = bz - az;
    const vx = cx - ax, vy = cy - ay, vz = cz - az;
    const ny = uz * vx - ux * vz;
    const nlen = Math.hypot(uy * vz - uz * vy, ny, ux * vy - uy * vx);
    if (nlen < 1e-9) continue;
    if (Math.abs(ny / nlen) > 0.5) continue; // shallow face, not a fin
    const minY = Math.min(ay, by, cy);
    const maxY = Math.max(ay, by, cy);
    const rise = maxY - minY;
    if (rise < DIVIDER_MIN_RISE || rise > DIVIDER_MAX_RISE) continue;
    if (maxY > DIVIDER_MAX_TOP) continue;
    const tminX = Math.min(ax, bx, cx);
    const tmaxX = Math.max(ax, bx, cx);
    const tminZ = Math.min(az, bz, cz);
    const tmaxZ = Math.max(az, bz, cz);
    const midX = (tminX + tmaxX) / 2;
    const midZ = (tminZ + tmaxZ) / 2;
    // A central median runs along the road and is centred across it; an outer
    // kerb of the same height hugs the tile boundary. Filter on the axis
    // ACROSS the fin's own run.
    if (tmaxX - tminX >= tmaxZ - tminZ) {
      if (Math.abs(midZ - tileCz) > spanZ * 0.3) continue;
    } else if (Math.abs(midX - tileCx) > spanX * 0.3) continue;

    const cell = col.cell;
    const c0 = Math.max(0, Math.floor((tminX - 0.3 - col.minX) / cell));
    const c1 = Math.min(col.cols - 1, Math.floor((tmaxX + 0.3 - col.minX) / cell));
    const r0 = Math.max(0, Math.floor((tminZ - 0.3 - col.minZ) / cell));
    const r1 = Math.min(col.rows - 1, Math.floor((tmaxZ + 0.3 - col.minZ) / cell));
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        const i = r * col.cols + c;
        if (!col.dividerMask[i]) {
          col.dividerMask[i] = 1;
          marked++;
        }
      }
    }
  }
  return marked;
}

/**
 * Rasterise one drivable-surface mesh.
 *
 * Only shallow (drivable) triangles are baked. Steep faces - a ramp lip, a
 * kerb side, an embankment wall - are deliberately NOT made solid here: the
 * height field already reports "wall" wherever the only surface above a cell
 * is out of step range, which blocks the car just as firmly. Baking the steep
 * faces too would double-count and, worse, turn a 0.4 m ramp lip into an
 * unclimbable wall because the face is tall even though the step is not.
 */
function bakeSurface(mesh, col, isRoad = false, isBridge = false, surfType = 0) {
  const m = mesh.getWorldMatrix().m;
  const positions = mesh.getVerticesData("position");
  if (!positions || positions.length < 9) return 0;
  const indices = mesh.getIndices();
  const triCount = indices ? indices.length / 3 : positions.length / 9;
  const cosMax = col.maxSlopeCos;
  // The glTF import mirrors part of the town (`__root__` has scale (1,1,-1)),
  // which reverses triangle winding, so a world-space cross product points the
  // "wrong" way for a mirrored mesh. The determinant of the world matrix says
  // whether that happened, and flipping the normal by it recovers which faces
  // really point up. Without this, both the top and the underside of every flat
  // slab get baked as drivable, and the car picks whichever it likes.
  const det =
    m[0] * (m[5] * m[10] - m[6] * m[9]) -
    m[1] * (m[4] * m[10] - m[6] * m[8]) +
    m[2] * (m[4] * m[9] - m[5] * m[8]);
  const flip = det < 0 ? -1 : 1;

  let baked = 0;
  for (let t = 0; t < triCount; t++) {
    const ia = indices ? indices[t * 3] : t * 3;
    const ib = indices ? indices[t * 3 + 1] : t * 3 + 1;
    const ic = indices ? indices[t * 3 + 2] : t * 3 + 2;

    const ax =
      m[0] * positions[ia * 3] +
      m[4] * positions[ia * 3 + 1] +
      m[8] * positions[ia * 3 + 2] +
      m[12];
    const ay =
      m[1] * positions[ia * 3] +
      m[5] * positions[ia * 3 + 1] +
      m[9] * positions[ia * 3 + 2] +
      m[13];
    const az =
      m[2] * positions[ia * 3] +
      m[6] * positions[ia * 3 + 1] +
      m[10] * positions[ia * 3 + 2] +
      m[14];
    const bx =
      m[0] * positions[ib * 3] +
      m[4] * positions[ib * 3 + 1] +
      m[8] * positions[ib * 3 + 2] +
      m[12];
    const by =
      m[1] * positions[ib * 3] +
      m[5] * positions[ib * 3 + 1] +
      m[9] * positions[ib * 3 + 2] +
      m[13];
    const bz =
      m[2] * positions[ib * 3] +
      m[6] * positions[ib * 3 + 1] +
      m[10] * positions[ib * 3 + 2] +
      m[14];
    const cx =
      m[0] * positions[ic * 3] +
      m[4] * positions[ic * 3 + 1] +
      m[8] * positions[ic * 3 + 2] +
      m[12];
    const cy =
      m[1] * positions[ic * 3] +
      m[5] * positions[ic * 3 + 1] +
      m[9] * positions[ic * 3 + 2] +
      m[13];
    const cz =
      m[2] * positions[ic * 3] +
      m[6] * positions[ic * 3 + 1] +
      m[10] * positions[ic * 3 + 2] +
      m[14];

    // world-space normal (not normalised yet)
    const ux = bx - ax;
    const uy = by - ay;
    const uz = bz - az;
    const vx = cx - ax;
    const vy = cy - ay;
    const vz = cz - az;
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz);
    if (len < 1e-9) continue;
    const slope = (ny / len) * flip;

    if (slope >= cosMax) {
      bakeGroundTriangle(
        col,
        ax,
        ay,
        az,
        bx,
        by,
        bz,
        cx,
        cy,
        cz,
        nx,
        ny,
        nz,
        isRoad,
        isBridge,
        surfType,
      );
      baked++;
    }
  }
  return baked;
}

/** Rasterise the plane of a shallow triangle into ground cells. */
function bakeGroundTriangle(
  col,
  ax,
  ay,
  az,
  bx,
  by,
  bz,
  cx,
  cy,
  cz,
  nx,
  ny,
  nz,
  isRoad,
  isBridge = false,
  surfType = 0,
) {
  const cellSize = col.cell;
  const minx = Math.min(ax, bx, cx);
  const maxx = Math.max(ax, bx, cx);
  const minz = Math.min(az, bz, cz);
  const maxz = Math.max(az, bz, cz);
  const c0 = Math.max(0, Math.floor((minx - col.minX) / cellSize));
  const c1 = Math.min(col.cols - 1, Math.floor((maxx - col.minX) / cellSize));
  const r0 = Math.max(0, Math.floor((minz - col.minZ) / cellSize));
  const r1 = Math.min(col.rows - 1, Math.floor((maxz - col.minZ) / cellSize));

  // Edge functions in the XZ plane. The sign convention is flipped when the
  // triangle is wound the other way, so compare against the sign of the area.
  const e0 = (bx - ax) * (cz - az) - (bz - az) * (cx - ax);
  const sign = e0 >= 0 ? 1 : -1;

  for (let r = r0; r <= r1; r++) {
    const pz = col.minZ + (r + 0.5) * cellSize;
    for (let c = c0; c <= c1; c++) {
      const px = col.minX + (c + 0.5) * cellSize;
      const w0 = ((bx - ax) * (pz - az) - (bz - az) * (px - ax)) * sign;
      if (w0 < -1e-4) continue;
      const w1 = ((cx - bx) * (pz - bz) - (cz - bz) * (px - bx)) * sign;
      if (w1 < -1e-4) continue;
      const w2 = ((ax - cx) * (pz - cz) - (az - cz) * (px - cx)) * sign;
      if (w2 < -1e-4) continue;
      const y = ay - (nx * (px - ax) + nz * (pz - az)) / ny;
      const cellIndex = r * col.cols + c;
      col._insertLayer(cellIndex, y);
      if (isRoad) col.roadMask[cellIndex] = 1;
      if (isBridge && col.bridgeMask) col.bridgeMask[cellIndex] = 1;
      // Surface family for tire-mark looks; higher wins (see SURF).
      if (surfType > 0 && surfType > col.surfaceType[cellIndex]) {
        col.surfaceType[cellIndex] = surfType;
      }
    }
  }
}

/**
 * Record a non-drivable mesh as solid.
 *
 * Small, roughly-cubic meshes (barrels, bollards, low kerb trim) may use their
 * world AABB as a shortcut — the box is a close enough fit and far cheaper than
 * walking their triangles.
 *
 * Meshes that are tall relative to their XZ footprint (sign gantries, lamp
 * posts, flagpoles) or that exceed the footprint / span thresholds MUST be
 * baked triangle-by-triangle so that overhead panels only block at the height
 * they actually sit at, not as a ground-to-sky column.
 *
 * A mesh that barely rises above the local ground (a decal, a kerb trim) is
 * skipped so the car does not trip over painted lines.
 */
function bakeSolid(col, mesh, box, src = 0, group = null, { anyHeight = false, fill = false, heightLimit = VEHICLE_MAX_HEIGHT, camFlats = true } = {}) {
  const ground = col.lowestAt(
    (box.minX + box.maxX) / 2,
    (box.minZ + box.maxZ) / 2,
  );
  const reference = ground ?? col.fallbackY;
  if (box.maxY - reference < col.minObstacleHeight) return 0;

  const spanX = box.maxX - box.minX;
  const spanZ = box.maxZ - box.minZ;
  const spanY = box.maxY - box.minY;
  const footprint = spanX * spanZ;

  // Force triangle baking when the mesh is disproportionately tall (sign posts,
  // gantries).
  const maxXZ = Math.max(spanX, spanZ);
  const isTall = maxXZ > 0 && spanY / maxXZ > TALL_SOLID_ASPECT;

  // Force triangle baking when the mesh is narrow in one XZ direction but long
  // in the other (a sign gantry arm, a fence panel, an overhead beam). The
  // compact AABB would cover the road cells the arm crosses even though the
  // physical structure only blocks at height. Example: a sign 0.9 m × 7.2 m
  // in plan view has aspect ≈ 8, well above the threshold of 3.
  const minXZ = Math.min(spanX, spanZ);
  const isElongated = minXZ > 0.01 && maxXZ / minXZ > ELONGATED_XZ_ASPECT;

  if (
    !isTall &&
    !isElongated &&
    footprint <= SMALL_SOLID_FOOTPRINT &&
    spanX <= SMALL_SOLID_SPAN &&
    spanZ <= SMALL_SOLID_SPAN
  ) {
    const cell = col.obstacleCell;
    const c0 = Math.max(0, Math.floor((box.minX - col.minX) / cell));
    const c1 = Math.min(
      col.oCols - 1,
      Math.floor((box.maxX - col.minX) / cell),
    );
    const r0 = Math.max(0, Math.floor((box.minZ - col.minZ) / cell));
    const r1 = Math.min(
      col.oRows - 1,
      Math.floor((box.maxZ - col.minZ) / cell),
    );
    for (let r = r0; r <= r1; r++) {
      for (let c = c0; c <= c1; c++) {
        col._markObstacle(c, r, box.minY, box.maxY, src, OBSTACLE_SOURCE.AABB, group);
      }
    }
    return 1;
  }

  return bakeSolidTriangles(col, mesh, src, group, anyHeight, fill,
    // Car reach is measured from the surface the mesh stands on, not from
    // sea level: a gantry on the 6 m bridge deck keeps its posts, while its
    // board above still clears. Ground meshes resolve ~0, exactly as before.
    col._standSurface(
      (box.minX + box.maxX) / 2,
      (box.minZ + box.maxZ) / 2,
      box.minY,
    ) + heightLimit,
    camFlats);
}

/** Footprint (m^2) below which a mesh's AABB is a good enough stand-in. */
const SMALL_SOLID_FOOTPRINT = 25;
/**
 * Longest footprint span (m) for that compact-AABB shortcut.
 *
 * Lowered from 8 m to 4 m so that any mesh longer than 4 m in any direction
 * (overhead sign gantries, fence panels, retaining walls) is baked from
 * triangles rather than a bounding box. A box covering a 7 m gantry arm
 * would wall off every road cell underneath it, which is exactly the ghost
 * collision the player sees as an invisible barrier in mid-air.
 */
const SMALL_SOLID_SPAN = 4;
/**
 * If a mesh is taller than this multiple of its widest XZ span it is treated
 * as "tall" and always baked from triangles, regardless of footprint.
 */
const TALL_SOLID_ASPECT = 1.2;
/**
 * If the mesh is elongated in plan view — one XZ span is much longer than the
 * other (fence panels, sign arms, gantry beams) — the AABB shortcut is
 * inappropriate even when the footprint area is small. A narrow-but-long box
 * stretches across the road and creates a solid wall over the driving lane.
 */
const ELONGATED_XZ_ASPECT = 3.0;

/**
 * Bake a mesh as solid by walking its WALL triangles.
 *
 * Only steep (near-vertical) triangles are rasterised. Flat faces (roof,
 * floor, overhead sign board) are intentionally skipped:
 *
 *  - A ground-level flat face is already recorded by the surface baker as a
 *    drivable layer; double-counting it as a solid column would make it
 *    impassable from both sides.
 *
 *  - An OVERHEAD flat face (e.g. the sign board of a gantry) sits above the
 *    car's reach. Baking it fills the road cells underneath with a solid
 *    entry. Because the obstacle grid stores ONE merged [bottom,top] Y per
 *    cell, any cell already touched by a lower triangle (post base, kerb) has
 *    its bottom merged down to 0 via min(). The overhead entry then produces a
 *    solid column from ground to sky right in the driving lane.
 *
 * Wall triangles are also filtered by height: if every vertex of a triangle
 * is above the mesh's own stand surface plus VEHICLE_MAX_HEIGHT the car can
 * never physically contact it, so stamping it into the grid would only
 * create phantom blocks in road cells that happen to share the same XZ
 * column as overhead structure (cross-beams, sign arms). Skipping those
 * triangles leaves the road clear.
 */
function bakeSolidTriangles(col, mesh, src = 0, group = null, anyHeight = false, fill = false, heightLimit = VEHICLE_MAX_HEIGHT, camFlats = true) {
  const m = mesh.getWorldMatrix().m;
  const positions = mesh.getVerticesData("position");
  if (!positions || positions.length < 9) return 0;
  const indices = mesh.getIndices();
  const triCount = indices ? indices.length / 3 : positions.length / 9;
  const cosMax = col.maxSlopeCos;
  let baked = 0;

  for (let t = 0; t < triCount; t++) {
    const ia = indices ? indices[t * 3] : t * 3;
    const ib = indices ? indices[t * 3 + 1] : t * 3 + 1;
    const ic = indices ? indices[t * 3 + 2] : t * 3 + 2;

    const ax =
      m[0] * positions[ia * 3] +
      m[4] * positions[ia * 3 + 1] +
      m[8] * positions[ia * 3 + 2] +
      m[12];
    const ay =
      m[1] * positions[ia * 3] +
      m[5] * positions[ia * 3 + 1] +
      m[9] * positions[ia * 3 + 2] +
      m[13];
    const az =
      m[2] * positions[ia * 3] +
      m[6] * positions[ia * 3 + 1] +
      m[10] * positions[ia * 3 + 2] +
      m[14];
    const bx =
      m[0] * positions[ib * 3] +
      m[4] * positions[ib * 3 + 1] +
      m[8] * positions[ib * 3 + 2] +
      m[12];
    const by =
      m[1] * positions[ib * 3] +
      m[5] * positions[ib * 3 + 1] +
      m[9] * positions[ib * 3 + 2] +
      m[13];
    const bz =
      m[2] * positions[ib * 3] +
      m[6] * positions[ib * 3 + 1] +
      m[10] * positions[ib * 3 + 2] +
      m[14];
    const cx =
      m[0] * positions[ic * 3] +
      m[4] * positions[ic * 3 + 1] +
      m[8] * positions[ic * 3 + 2] +
      m[12];
    const cy =
      m[1] * positions[ic * 3] +
      m[5] * positions[ic * 3 + 1] +
      m[9] * positions[ic * 3 + 2] +
      m[13];
    const cz =
      m[2] * positions[ic * 3] +
      m[6] * positions[ic * 3 + 1] +
      m[10] * positions[ic * 3 + 2] +
      m[14];

    const ux = bx - ax;
    const uy = by - ay;
    const uz = bz - az;
    const vx = cx - ax;
    const vy = cy - ay;
    const vz = cz - az;
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz);
    if (len < 1e-9) continue;
    const triBottom = Math.min(ay, by, cy);
    const triTop = Math.max(ay, by, cy);
    // Flat faces are skipped for the car (see comment above) but they are
    // exactly what the CAMERA collides with: deck slabs, roofs, sign boards
    // seen edge-on. Forward them to the camera voxel grid - unless this mesh
    // is a smashable prop (group), whose ghost must not linger for the lens
    // after the car has cleared its car-grid cells.
    if (Math.abs(ny) / len >= cosMax) {
      if (camFlats && group === null && triTop > CAM_MIN_Y) {
        fillCamTriangleXZ(col, ax, az, bx, bz, cx, cz, triBottom, triTop);
      }
      continue; // flat face — skip for the car (see comment above)
    }

    const bottom = triBottom;
    // Skip wall triangles that sit entirely above the car's reach. Their edges
    // pass through road cells at the wrong height and would merge a high bottom
    // down to 0 once another triangle has already touched those cells. The car
    // cannot physically contact geometry above VEHICLE_MAX_HEIGHT anyway.
    //
    // The lens CAN: a gantry board at 5 m or a tall sign arm crosses the boom
    // every time the car passes under it in high view. Those faces go to the
    // camera voxel grid instead (same group rule as above).
    //
    // Terrain (`anyHeight`) is the exception: a mountainside is a wall at
    // whatever height it happens to be, and the car reaches those heights by
    // driving up the drivable slopes below. Skipping them would let it drive
    // straight into the mountain, which is exactly the bug this fixes.
    if (!anyHeight && bottom >= heightLimit) {
      if (group === null) {
        const tri = [ax, ay, az, bx, by, bz, cx, cy, cz];
        markCamSegment(col, tri, 0, 1);
        markCamSegment(col, tri, 1, 2);
        markCamSegment(col, tri, 2, 0);
      }
      continue;
    }

    const top = triTop;
    // A large face (a mountainside) also needs its interior filled; a thin wall
    // (a road barrier) is fully described by its edges. The fill skips cells that
    // already carry roadway so it can never seal the road a barrier guards; the
    // edge trace below deliberately does not, or a barrier standing on a road
    // (as every road_c parapet does) would never be stamped at all.
    if (fill) fillTriangleXZ(col, ax, az, bx, bz, cx, cz, bottom, top, src, true);
    const tri = [ax, ay, az, bx, by, bz, cx, cy, cz];
    markSegment(col, tri, 0, 1, src, group);
    markSegment(col, tri, 1, 2, src, group);
    markSegment(col, tri, 2, 0, src, group);
    baked++;
  }
  return baked;
}

/**
 * Maximum world-space Y at which a wall triangle's lowest vertex can sit
 * before it is considered unreachable by ground vehicles and skipped.
 *
 * Set to slightly above the car's chassis top (1.42 m) plus a small margin so
 * that sign arms and overhead beams are never stamped into the obstacle grid.
 * Adjust if the game adds taller obstacles (buses, trucks) that need top-impact
 * detection.
 */
const VEHICLE_MAX_HEIGHT = 2.0;

/**
 * Assumed depth of a deck slab below its top surface, metres.
 *
 * The heightfield only stores top surfaces, so when the boom nears a deck
 * from below the slab body itself is inferred: a boom point counts as inside
 * the slab when a baked surface sits within `radius` above it or up to
 * `CAM_SLAB_DOWN + radius` below... precisely: surface S blocks boom point y
 * when y - radius < S < y + CAM_SLAB_DOWN + radius. Open air further under the
 * deck stays clear, and a boom above the deck can never match (S is below it).
 */
const CAM_SLAB_DOWN = 0.5;

/**
 * Faces entirely below this are never camera occluders.
 *
 * The boom runs ~1.5 m (pivot) to ~4-7 m (lens) above the car, so ground-level
 * flats (roads at 0.06 m, kerbs, decals) can never touch it. Skipping them
 * keeps the camera voxel grid sparse: only decks, panels, arms and roofs pay
 * for cells.
 */
const CAM_MIN_Y = 0.8;

/**
 * How far below the carriageway a solid column may stop and still be treated as
 * buried in the structure under the road rather than as something in the way.
 *
 * A car's chassis starts `CAR.clearance` (0.26 m) above the surface it rests on,
 * so anything whose top is below that cannot stop a car driving on that surface
 * anyway. The figure is set above 0.26 m to leave room for float error in the
 * baked layer heights, while staying far below the ~1 m parapets it must keep.
 */
const BURIED_SOLID_TOLERANCE = 0.4;

/** Mark every obstacle cell a plan-view segment passes through. */
/**
 * Clip a triangle to one obstacle cell's plan-view box and return the vertical
 * extent of what is left in `out` as [minY, maxY].
 *
 * The clip is what makes the height a face presents LOCAL rather than global.
 * A bridge ramp's retaining wall is a single triangle lying in a vertical plane:
 * its footprint is one triangle 40 m long and 6 m tall, from the ramp's foot up
 * to deck level. Stamped with its own [minY, maxY], every cell along it gets the
 * full 6 m, so the foot of the ramp is ringed by a phantom wall as tall as the
 * bridge and the carriageway is sealed along its whole length. Clipped to a cell,
 * the same triangle only reaches as high as it actually is there - a few
 * centimetres above the deck - so it is trimmed away instead of blocking the car.
 *
 * A triangle clipped to nothing returns false and the cell is left alone.
 */
const _spanCur = new Float64Array(24);
const _spanNext = new Float64Array(24);
const _spanOut = new Float64Array(2);

function triSpanInCell(ax, ay, az, bx, by, bz, cx, cy, cz, x0, x1, z0, z1, out) {
  let cur = _spanCur;
  let nxt = _spanNext;
  cur[0] = ax;
  cur[1] = ay;
  cur[2] = az;
  cur[3] = bx;
  cur[4] = by;
  cur[5] = bz;
  cur[6] = cx;
  cur[7] = cy;
  cur[8] = cz;
  let n = 3;

  // Sutherland-Hodgman against the four sides of the cell, in XZ only.
  for (let plane = 0; plane < 4; plane++) {
    if (!n) return false;
    const onX = plane < 2;
    const low = plane % 2 === 0;
    const limit = onX ? (low ? x0 : x1) : low ? z0 : z1;
    const sign = low ? 1 : -1;
    let m = 0;
    for (let i = 0; i < n; i++) {
      const i3 = i * 3;
      const j3 = ((i + 1) % n) * 3;
      const ci = onX ? cur[i3] : cur[i3 + 2];
      const cj = onX ? cur[j3] : cur[j3 + 2];
      const di = (ci - limit) * sign;
      const dj = (cj - limit) * sign;
      if (di >= 0) {
        nxt[m * 3] = cur[i3];
        nxt[m * 3 + 1] = cur[i3 + 1];
        nxt[m * 3 + 2] = cur[i3 + 2];
        m++;
      }
      if ((di >= 0) !== (dj >= 0)) {
        const dc = cj - ci;
        const t = dc !== 0 ? (limit - ci) / dc : 0;
        nxt[m * 3] = cur[i3] + (cur[j3] - cur[i3]) * t;
        nxt[m * 3 + 1] = cur[i3 + 1] + (cur[j3 + 1] - cur[i3 + 1]) * t;
        nxt[m * 3 + 2] = cur[i3 + 2] + (cur[j3 + 2] - cur[i3 + 2]) * t;
        m++;
      }
      if (m >= 8) break;
    }
    n = m;
    const swap = cur;
    cur = nxt;
    nxt = swap;
  }

  if (!n) return false;
  let lo = Infinity;
  let hi = -Infinity;
  for (let i = 0; i < n; i++) {
    const y = cur[i * 3 + 1];
    if (y < lo) lo = y;
    if (y > hi) hi = y;
  }
  out[0] = lo;
  out[1] = hi;
  return true;
}

/**
 * Outline one edge of `tri` and stamp the cells it crosses.
 *
 * Each cell is stamped with the triangle's vertical extent over that cell, not
 * with the triangle's overall [bottom, top], so a face that rises as it runs -
 * a ramp's flank, a hillside - only counts for the height it has reached by the
 * time it gets there. The cell's own extent is also the whole reason a wall
 * standing on a road is still stamped at all, while the carriageway beside it
 * stays clear.
 */
function markSegment(col, tri, i0, i1, src = 0, group = null) {
  const x0 = tri[i0 * 3];
  const z0 = tri[i0 * 3 + 2];
  const x1 = tri[i1 * 3];
  const z1 = tri[i1 * 3 + 2];
  const dx = x1 - x0;
  const dz = z1 - z0;
  const len = Math.hypot(dx, dz);
  if (len < 1e-6) return;
  const cell = col.obstacleCell;
  const steps = Math.max(1, Math.ceil(len / (cell * 0.5)));
  let lastC = -1;
  let lastR = -1;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const c = Math.floor((x0 + dx * t - col.minX) / cell);
    const r = Math.floor((z0 + dz * t - col.minZ) / cell);
    if (c < 0 || r < 0 || c >= col.oCols || r >= col.oRows) continue;
    if (c === lastC && r === lastR) continue;
    lastC = c;
    lastR = r;
    const cx0 = col.minX + c * cell;
    const cz0 = col.minZ + r * cell;
    if (
      !triSpanInCell(
        tri[0], tri[1], tri[2], tri[3], tri[4], tri[5], tri[6], tri[7], tri[8],
        cx0, cx0 + cell, cz0, cz0 + cell, _spanOut,
      )
    ) {
      continue;
    }
    col._markObstacle(c, r, _spanOut[0], _spanOut[1], src, OBSTACLE_SOURCE.TRIANGLE, group);
  }
}

/**
 * Edge-trace one triangle edge into the camera voxel grid, stamping each
 * crossed cell with the triangle's height over THAT cell (not the triangle's
 * overall span). Same local-height logic as `markSegment`, without any car
 * bookkeeping.
 */
function markCamSegment(col, tri, i0, i1) {
  const x0 = tri[i0 * 3];
  const z0 = tri[i0 * 3 + 2];
  const x1 = tri[i1 * 3];
  const z1 = tri[i1 * 3 + 2];
  const dx = x1 - x0;
  const dz = z1 - z0;
  const len = Math.hypot(dx, dz);
  if (len < 1e-6) return;
  const cell = col.obstacleCell;
  const steps = Math.max(1, Math.ceil(len / (cell * 0.5)));
  let lastC = -1;
  let lastR = -1;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const c = Math.floor((x0 + dx * t - col.minX) / cell);
    const r = Math.floor((z0 + dz * t - col.minZ) / cell);
    if (c < 0 || r < 0 || c >= col.oCols || r >= col.oRows) continue;
    if (c === lastC && r === lastR) continue;
    lastC = c;
    lastR = r;
    const cx0 = col.minX + c * cell;
    const cz0 = col.minZ + r * cell;
    if (
      !triSpanInCell(
        tri[0], tri[1], tri[2], tri[3], tri[4], tri[5], tri[6], tri[7], tri[8],
        cx0, cx0 + cell, cz0, cz0 + cell, _spanOut,
      )
    ) {
      continue;
    }
    col._markCamera(c, r, _spanOut[0], _spanOut[1]);
  }
}

/**
 * Fill a flat (horizontal) triangle's plan-view interior into the camera voxel
 * grid. This is what covers deck slabs, roofs and horizontal sign boards -
 * the faces the car bake skips on purpose. No roadway skip: a deck over a
 * road must still stop the lens.
 */
function fillCamTriangleXZ(col, ax, az, bx, bz, cx, cz, bottom, top) {
  const cell = col.obstacleCell;
  const c0 = Math.max(0, Math.floor((Math.min(ax, bx, cx) - col.minX) / cell));
  const c1 = Math.min(col.oCols - 1, Math.floor((Math.max(ax, bx, cx) - col.minX) / cell));
  const r0 = Math.max(0, Math.floor((Math.min(az, bz, cz) - col.minZ) / cell));
  const r1 = Math.min(col.oRows - 1, Math.floor((Math.max(az, bz, cz) - col.minZ) / cell));
  const denom = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz);
  if (Math.abs(denom) < 1e-9) return;
  const eps = 1e-6;
  for (let r = r0; r <= r1; r++) {
    const z = col.minZ + (r + 0.5) * cell;
    for (let c = c0; c <= c1; c++) {
      const x = col.minX + (c + 0.5) * cell;
      const a = ((bz - cz) * (x - cx) + (cx - bx) * (z - cz)) / denom;
      const b = ((cz - az) * (x - cx) + (ax - cx) * (z - cz)) / denom;
      if (a < -eps || b < -eps || a + b > 1 + eps) continue;
      col._markCamera(c, r, bottom, top);
    }
  }
}

/**
 * Bake a water body as a solid barrier.
 *
 * Water is a flat sheet: it has no wall triangles, so `bakeSolidTriangles` -
 * which only walks steep faces - records nothing for it. A car then drives
 * straight in and drops to the fallback ground height, below the water surface,
 * which reads as sinking into the lake.
 *
 * Instead the plan-view footprint of every water triangle is filled, and each
 * filled cell gets a solid column spanning the water body's own vertical
 * extent. The span is what makes an approaching car stop at the shoreline: it
 * reaches from the lake bed up to the surface, so anything crossing ABOVE the
 * water - a bridge deck, the viaduct - passes over it untouched.
 *
 * Cells that already carry roadway are skipped, so a road built out over the
 * water keeps its drivable surface rather than being sealed off by the lake
 * beneath it. This is why water is baked in a second pass, after every road.
 */
function bakeWater(col, mesh, box, src = 0) {
  const m = mesh.getWorldMatrix().m;
  const positions = mesh.getVerticesData("position");
  if (!positions || positions.length < 9) return 0;
  const indices = mesh.getIndices();
  const triCount = indices ? indices.length / 3 : positions.length / 9;
  const bottom = box.minY;
  const top = box.maxY;
  let baked = 0;
  for (let t = 0; t < triCount; t++) {
    const ia = indices ? indices[t * 3] : t * 3;
    const ib = indices ? indices[t * 3 + 1] : t * 3 + 1;
    const ic = indices ? indices[t * 3 + 2] : t * 3 + 2;
    const ax =
      m[0] * positions[ia * 3] + m[4] * positions[ia * 3 + 1] + m[8] * positions[ia * 3 + 2] + m[12];
    const az =
      m[2] * positions[ia * 3] + m[6] * positions[ia * 3 + 1] + m[10] * positions[ia * 3 + 2] + m[14];
    const bx =
      m[0] * positions[ib * 3] + m[4] * positions[ib * 3 + 1] + m[8] * positions[ib * 3 + 2] + m[12];
    const bz =
      m[2] * positions[ib * 3] + m[6] * positions[ib * 3 + 1] + m[10] * positions[ib * 3 + 2] + m[14];
    const cx =
      m[0] * positions[ic * 3] + m[4] * positions[ic * 3 + 1] + m[8] * positions[ic * 3 + 2] + m[12];
    const cz =
      m[2] * positions[ic * 3] + m[6] * positions[ic * 3 + 1] + m[10] * positions[ic * 3 + 2] + m[14];
    fillTriangleXZ(col, ax, az, bx, bz, cx, cz, bottom, top, src, true);
    baked++;
  }
  return baked;
}

/**
 * Mark every obstacle cell whose centre falls inside a plan-view triangle.
 * Unlike `markSegment`, which outlines a triangle for thin walls, this fills it:
 * the interior of a large water triangle has to be solid, not just its edges.
 */
function fillTriangleXZ(col, ax, az, bx, bz, cx, cz, bottom, top, src, skipRoad = false) {
  const cell = col.obstacleCell;
  const c0 = Math.max(0, Math.floor((Math.min(ax, bx, cx) - col.minX) / cell));
  const c1 = Math.min(col.oCols - 1, Math.floor((Math.max(ax, bx, cx) - col.minX) / cell));
  const r0 = Math.max(0, Math.floor((Math.min(az, bz, cz) - col.minZ) / cell));
  const r1 = Math.min(col.oRows - 1, Math.floor((Math.max(az, bz, cz) - col.minZ) / cell));
  // Barycentric denominator; a degenerate (edge-on) triangle covers nothing.
  const denom = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz);
  if (Math.abs(denom) < 1e-9) return;
  const eps = 1e-6;
  for (let r = r0; r <= r1; r++) {
    const z = col.minZ + (r + 0.5) * cell;
    for (let c = c0; c <= c1; c++) {
      const x = col.minX + (c + 0.5) * cell;
      const a = ((bz - cz) * (x - cx) + (cx - bx) * (z - cz)) / denom;
      const b = ((cz - az) * (x - cx) + (ax - cx) * (z - cz)) / denom;
      if (a < -eps || b < -eps || a + b > 1 + eps) continue;
      // Water only: a road crossing the water wins, so its cells are never
      // sealed off. Structure (mountains, road barriers) must NOT skip roadway,
      // or a barrier that overlaps the deck it protects would leave a gap.
      if (skipRoad) {
        const gc = Math.floor((x - col.minX) / col.cell);
        const gr = Math.floor((z - col.minZ) / col.cell);
        if (
          gc >= 0 &&
          gr >= 0 &&
          gc < col.cols &&
          gr < col.rows &&
          col.roadMask[gr * col.cols + gc]
        ) {
          continue;
        }
      }
      col._markObstacle(c, r, bottom, top, src, OBSTACLE_SOURCE.TRIANGLE, null);
    }
  }
}

/**
 * Ray vs AABB slab test for the camera boom.
 *
 * @param ax,ay,az  ray origin (roof pivot)
 * @param dx,dy,dz  FULL ray vector (target - origin), so t is in 0..1
 * @param b         [minX, minY, minZ, maxX, maxY, maxZ], inflated by radius
 * @returns entry t in [0,1], or -1 on miss.
 */
function rayAabb(ax, ay, az, dx, dy, dz, b, radius = 0) {
  const minX = b[0] - radius;
  const minY = b[1] - radius;
  const minZ = b[2] - radius;
  const maxX = b[3] + radius;
  const maxY = b[4] + radius;
  const maxZ = b[5] + radius;
  let tmin = 0;
  let tmax = 1;
  // X slab
  if (Math.abs(dx) < 1e-9) {
    if (ax < minX || ax > maxX) return -1;
  } else {
    let t1 = (minX - ax) / dx;
    let t2 = (maxX - ax) / dx;
    if (t1 > t2) {
      const t = t1;
      t1 = t2;
      t2 = t;
    }
    if (t1 > tmin) tmin = t1;
    if (t2 < tmax) tmax = t2;
    if (tmin > tmax) return -1;
  }
  if (Math.abs(dy) < 1e-9) {
    if (ay < minY || ay > maxY) return -1;
  } else {
    let t1 = (minY - ay) / dy;
    let t2 = (maxY - ay) / dy;
    if (t1 > t2) {
      const t = t1;
      t1 = t2;
      t2 = t;
    }
    if (t1 > tmin) tmin = t1;
    if (t2 < tmax) tmax = t2;
    if (tmin > tmax) return -1;
  }
  if (Math.abs(dz) < 1e-9) {
    if (az < minZ || az > maxZ) return -1;
  } else {
    let t1 = (minZ - az) / dz;
    let t2 = (maxZ - az) / dz;
    if (t1 > t2) {
      const t = t1;
      t1 = t2;
      t2 = t;
    }
    if (t1 > tmin) tmin = t1;
    if (t2 < tmax) tmax = t2;
    if (tmin > tmax) return -1;
  }
  return tmin;
}

/** World-space AABB from a mesh's local bounding box and world matrix. */
function worldAabb(mesh) {
  if (!mesh.getTotalVertices || mesh.getTotalVertices() < 3) return null;
  mesh.computeWorldMatrix(true);
  const bb = mesh.getBoundingInfo().boundingBox;
  const m = mesh.getWorldMatrix().m;
  let minX = Infinity;
  let minY = Infinity;
  let minZ = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let maxZ = -Infinity;
  for (let i = 0; i < 8; i++) {
    const x = i & 1 ? bb.maximum.x : bb.minimum.x;
    const y = i & 2 ? bb.maximum.y : bb.minimum.y;
    const z = i & 4 ? bb.maximum.z : bb.minimum.z;
    const wx = m[0] * x + m[4] * y + m[8] * z + m[12];
    const wy = m[1] * x + m[5] * y + m[9] * z + m[13];
    const wz = m[2] * x + m[6] * y + m[10] * z + m[14];
    if (wx < minX) minX = wx;
    if (wy < minY) minY = wy;
    if (wz < minZ) minZ = wz;
    if (wx > maxX) maxX = wx;
    if (wy > maxY) maxY = wy;
    if (wz > maxZ) maxZ = wz;
  }
  if (!Number.isFinite(minX)) return null;
  return { minX, minY, minZ, maxX, maxY, maxZ };
}
