import { UniversalCamera, Vector3 } from "@babylonjs/core";
import { clamp, smoothFactor } from "../game/driving.js";

/**
 * Third-person camera that trails the car.
 *
 * Follows the heading convention from driving.js: forward = (sin h, 0, cos h),
 * so "behind the car" is -forward. Both the position and the look-at point are
 * eased exponentially, which keeps the motion smooth regardless of frame rate.
 *
 * Collision (production-grade boom, NFS/Forza/GTA style):
 *
   *   - The ideal position is a boom from a roof pivot (car + PIVOT_H) to the
   *     speed-dependent chase point. Every frame the boom is sphere-cast against
   *     `MapCollision.cameraOcclusion` (car solids + voxel grid for high sign
   *     panels / roofs + tree-trunk boxes + a beneath-only deck-slab test),
   *     which returns the first hit as a fraction of the boom. Decks use the
   *     beneath-only test on purpose: it can only fire when the car is UNDER
   *     the slab, so driving on open deck or over the bridge never yanks the
   *     boom, while a `streetsigns.028`-style gantry board always pulls.
 *   - The boom LENGTH is then smoothed asymmetrically: it snaps in fast when
 *     something appears (no frame ever shows the inside of a wall) and eases
 *     back out slowly once clear (no pop or jitter when brushing past a
 *     building). A sudden wall (> SNAP_DIST closer) snaps immediately so a
 *     fast turn around a corner cannot clip for even one frame.
 *   - The rendered position lerps toward the safe point for calm turning, then
 *     is hard-clamped back inside the proven-clear length - so lerp lag can
 *     never leave the lens inside geometry.
 *   - Finally the lens is kept above the height field so it never dips under
 *     the road on crests or ramps.
 */
const PIVOT_H = 1.55; // roof pivot above the chassis ground, metres
const LENS_RADIUS = 0.35; // inflation so the near plane clears faces
const BACK_MARGIN = 0.55; // pull-back from the hit point, metres
const MIN_BOOM = 1.4; // shortest boom: inside the car beats inside a wall
const PULL_IN_RATE = 30; // 1/s: ~95% pulled in within 0.1 s
const PUSH_OUT_RATE = 3.0; // 1/s: ~1 s to ease back out, no pop
const FOLLOW_RATE = 12; // 1/s: rendered position tracks the safe point
const SNAP_DIST = 2.5; // pull-in larger than this snaps, never lerps
const GROUND_CLEAR = 0.45; // lens height above the surface, metres

export class ChaseCamera {
  constructor(scene, collision = null) {
    this.camera = new UniversalCamera("chase", new Vector3(0, 8, -16), scene);
    this.camera.fov = 1.0;
    this.camera.minZ = 0.35;
    // Far plane ends just past the fog wall: fully fogged meshes pop
    // invisibly, and nothing beyond is ever rasterized.
    this.camera.maxZ = 250;
    this.camera.inputs.clear(); // no manual control; the car drives it

    this.target = new Vector3(0, 0, 0);
    this.collision = collision ?? null;
    this.boom = 0; // smoothed pivot -> lens distance
    this.initialised = false;
    this.mode = 0; // 0 = chase, 1 = higher/side view
  }

  setCollision(collision) {
    this.collision = collision ?? null;
  }

  toggleMode() {
    this.mode = (this.mode + 1) % 2;
  }

  update(dt, position, heading, speed) {
    const speedT = clamp(Math.abs(speed) / 60, 0, 1);

    // Close, low chase stance: the car fills the lower frame like the
    // reference, pulling back and rising only slightly with speed.
    const back = (this.mode === 0 ? 6.2 : 9.5) + speedT * (this.mode === 0 ? 3.0 : 3.8);
    const height = (this.mode === 0 ? 2.7 : 5.2) + speedT * (this.mode === 0 ? 0.7 : 0.8);

    const fx = Math.sin(heading);
    const fz = Math.cos(heading);
    const desired = new Vector3(
      position.x - fx * back,
      position.y + height,
      position.z - fz * back,
    );

    const lookAt = new Vector3(
      position.x + fx * 6,
      position.y + 1.25,
      position.z + fz * 6,
    );

    const pivot = new Vector3(position.x, position.y + PIVOT_H, position.z);
    const boomVec = desired.subtract(pivot);
    const fullLen = boomVec.length() || 1;
    const boomDir = boomVec.scale(1 / fullLen);

    // --- proven-clear length along this frame's boom --------------------
    let allowed = fullLen;
    const col = this.collision;
    if (col && typeof col.cameraOcclusion === "function") {
      const t = col.cameraOcclusion(
        pivot.x, pivot.y, pivot.z,
        desired.x, desired.y, desired.z,
        LENS_RADIUS,
      );
      if (t < 1) allowed = Math.max(MIN_BOOM, t * fullLen - BACK_MARGIN);
      else allowed = fullLen;
      if (allowed > fullLen) allowed = fullLen;
      if (allowed < MIN_BOOM) allowed = MIN_BOOM;
    }

    // --- asymmetric boom smoothing: fast in, slow out -------------------
    if (!this.initialised) {
      this.boom = allowed;
    } else if (allowed < this.boom) {
      if (this.boom - allowed > SNAP_DIST) this.boom = allowed;
      else {
        this.boom += (allowed - this.boom) * smoothFactor(PULL_IN_RATE, dt);
        if (this.boom < allowed) this.boom = allowed;
      }
    } else if (allowed > this.boom) {
      this.boom += (allowed - this.boom) * smoothFactor(PUSH_OUT_RATE, dt);
      if (this.boom > allowed) this.boom = allowed;
      // Never let the eased boom exceed the ideal length for this frame
      // (speed lift shortens/lengthens `fullLen` continuously).
      if (this.boom > fullLen) this.boom = fullLen;
    }
    if (!(this.boom > 0)) this.boom = allowed;

    const safePoint = (len) => pivot.add(boomDir.scale(len));

    // Keep the safe point out of solid and above ground. The occlusion march
    // already guarantees clearance, but the ground lift can push the lens up
    // into a wall above (under a bridge, beside a hill), so re-pull up to a
    // few times until it is free.
    let safe = safePoint(this.boom);
    if (col) {
      let len = this.boom;
      for (let i = 0; i < 4; i++) {
        let lifted = false;
        if (typeof col.groundAt === "function") {
          const g = col.groundAt(safe.x, safe.z, position.y, { stepUp: 5, reach: 10 });
          if (g && g.y !== null && g.y !== undefined && safe.y < g.y + GROUND_CLEAR) {
            safe.y = g.y + GROUND_CLEAR;
            lifted = true;
          }
        }
        const blocked =
          typeof col.cameraPointBlocked === "function" &&
          col.cameraPointBlocked(safe.x, safe.y, safe.z, LENS_RADIUS * 0.9);
        if (!blocked) {
          if (lifted) continue; // lifted into the clear: re-check once more
          break;
        }
        len = Math.max(MIN_BOOM, len - 0.6);
        safe = safePoint(len);
        // Remember the shorter boom so the push-out eases from here.
        this.boom = len;
        if (len <= MIN_BOOM) break;
      }
      // The eased boom may now be shorter than proven-clear `allowed` (ground
      // lift pulled it in); keep `allowed` as the hard authority for the
      // clamp below by shrinking it to match.
      const safeLen = safe.subtract(pivot).length();
      if (safeLen < allowed) allowed = safeLen;
    }

    if (!this.initialised) {
      this.camera.position.copyFrom(safe);
      this.target.copyFrom(lookAt);
      this.initialised = true;
      return;
    }

    // position tracks the safe point, so turning feels responsive while
    // the horizon stays calm
    this.camera.position = Vector3.Lerp(
      this.camera.position,
      safe,
      smoothFactor(FOLLOW_RATE, dt),
    );

    // Hard guarantee: lerp lag must never leave the lens past the proven-clear
    // length. When pulling in fast this snaps the rendered position inside on
    // the same frame instead of trailing through the wall for 2-3 frames.
    const camVec = this.camera.position.subtract(pivot);
    const camLen = camVec.length();
    if (camLen > allowed && camLen > 1e-6) {
      this.camera.position.copyFrom(pivot.add(camVec.scale(allowed / camLen)));
    }
    // Ground clamp applies to the rendered position too (crests/ramps).
    if (col && typeof col.groundAt === "function") {
      const g = col.groundAt(
        this.camera.position.x, this.camera.position.z, position.y,
        { stepUp: 5, reach: 10 },
      );
      if (g && g.y !== null && g.y !== undefined) {
        const minY = g.y + GROUND_CLEAR;
        if (this.camera.position.y < minY) this.camera.position.y = minY;
      }
    }

    this.target = Vector3.Lerp(this.target, lookAt, smoothFactor(9, dt));
    this.camera.setTarget(this.target);
  }

  /** Called on reset/teleport so the camera does not fly across the map. */
  snap() {
    this.initialised = false;
  }

  /**
   * Cinematic pose driver for the race intro: ease the lens toward an
   * explicit position + look target. The intro path moves slowly, so a
   * gentle ease both smooths frame-rate wobble and flies the lens up from
   * wherever the chase cam was when START was hit.
   */
  driveTo(dt, pos, look, rate = 3.5) {
    const t = smoothFactor(rate, dt);
    this.camera.position = Vector3.Lerp(this.camera.position, pos, t);
    this.target = Vector3.Lerp(this.target, look, t);
    this.camera.setTarget(this.target);
  }
}
