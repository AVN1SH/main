import { AppendSceneAsync, LoadAssetContainerAsync, Matrix, Quaternion, SceneLoader, Vector3 } from "@babylonjs/core";
// Register ONLY the glTF loader. registerBuiltInLoaders() would also pull in
// FBX, OBJ, STL, SPLAT and USD, none of which this game can load.
import "@babylonjs/loaders/glTF/2.0";
import { configureLocalDracoDecoder } from "./engine/dracoConfig.js";

// The map is Draco-compressed, so point the decoder at the copy we ship in
// public/draco/ before any glTF is loaded. Without this Babylon would fetch the
// decoder from cdn.babylonjs.com at runtime.
configureLocalDracoDecoder();

import { createScene } from "./engine/createScene.js";
import { MapCollision } from "./engine/MapCollision.js";
import { ChaseCamera } from "./engine/ChaseCamera.js";
import { createInput } from "./game/input.js";
import { VehicleRig } from "./game/VehicleRig.js";
import { PlayerVehicle } from "./game/PlayerVehicle.js";
import { TrafficSystem } from "./game/TrafficSystem.js";
import { loadRaceCarAssets, loadVehicleAssets } from "./game/VehicleAssets.js";
import { GARAGE_CATALOG, createGarageScreen } from "./game/garageScreen.js";
import { LobbyUI } from "./game/LobbyUI.js";
import { createGarageMarker } from "./game/garageMarker.js";
import { createCoordProbe } from "./game/coordProbe.js";
import { RACE_STATE } from "./game/RaceSystem.js";
import { RaceEventManager } from "./game/raceManager.js";
import { RaceHud } from "./game/raceHud.js";
import {
  DestructibleSystem,
  IMPACT_SPEED_KMH,
  destructibleGroupKey,
} from "./game/destructibles.js";
import { Hud } from "./game/hud.js";
import { TouchControls } from "./game/touchControls.js";
import { PauseMenu } from "./game/pauseMenu.js";
import { createLoadingScreen, showLoadingFailure } from "./game/loadingScreen.js";
import { preloadAssets } from "./game/preload.js";
import { Minimap } from "./game/minimap.js";
import { TireMarks } from "./game/tireMarks.js";
import { CAR_PAINT, paintAt } from "./game/carPaint.js";
import { TireSpray } from "./game/tireSpray.js";
import { CarAudio, profileForCar } from "./game/carAudio.js";
import { soundManager } from "./game/soundManager.js";
import { createRoadTest, publish, runSelfTest } from "./game/debug.js";
import { CollisionDebug, instrumentFollower } from "./game/collisionDebug.js";
import routeData from "./data/routes.json";

const MAP_URL = "assets/map.glb";
const CAR_URL = "assets/car1.glb";

/** Ground used for the car; the map's roads all sit within ~0.2 of this. */
const GROUND_Y = routeData.groundY ?? 0.056;

/**
 * Intent handed to the player while the countdown holds the field: every input
 * is zero, so the car sits on its grid slot instead of creeping forward.
 */
const LOCKED_INPUT = { steer: 0, throttle: 0, brake: 0, handbrake: false };
/**
 * Intent while the finish cinematic plays: straight-line auto-brake so the
 * car pulls itself up promptly instead of free-coasting uncontrolled into
 * whatever the road points at next.
 */
const FINISH_BRAKE_INPUT = { steer: 0, throttle: 0, brake: 0.45, handbrake: false };

const errors = [];
window.addEventListener("error", (e) => errors.push(`error: ${e.message}`));
window.addEventListener("unhandledrejection", (e) => errors.push(`rejection: ${String(e.reason)}`));

async function main() {
  const canvas = document.getElementById("game-canvas");
  const params = new URLSearchParams(location.search);
  const debugMode = params.has("debug");
  // `?hits=1` marks every collision contact in the world so it can be seen:
  // green = blocked by a real triangle, red = blocked only by a mesh's bounding
  // box (i.e. by empty space), blue = an unclimbable step from the height field.
  const hitsMode = params.has("hits");
  // Frames to wait before publishing diagnostics. Software WebGL (used by
  // headless test runs) renders slowly, so allow overriding it.
  const debugFrame = Number(params.get("frames") ?? 90);
  // Testing coordinate probe (see src/game/coordProbe.js): only with
  // `?testing=1`, invisible and inert otherwise.
  const testingMode = params.get("testing") === "1";

  const hud = new Hud();
  // On-screen touch controls (mobile): only mounted on touch-capable
  // devices (or ?touch=1) and merged into the same intent object the
  // keyboard feeds, so the driving code reads one input either way.
  const touch = new TouchControls();
  const input = createInput(window, touch);
  // Boot loading screen (LIMITLESS CITY backdrop). All step updates funnel
  // through it; it shows a pulsing "Loading..." until boot finishes.
  const loading = createLoadingScreen();
  // Never let Babylon paint its own loader (logo div) behind/after the
  // custom overlay: loading calls below are untouched, only their
  // built-in UI is muted (see also the no-op engine.loadingScreen in
  // createScene.js and the #babylonjsLoadingDiv guard in main.css).
  SceneLoader.ShowLoadingScreen = false;
  const { engine, scene } = createScene(canvas);

  // ---------------------------------------------------------------- map
  loading.setStatus();
  const t0 = performance.now();
  await AppendSceneAsync(MAP_URL, scene);
  const mapMs = Math.round(performance.now() - t0);

  // The town never moves, so its world matrices and bounding info can be
  // frozen - with ~1300 meshes that is a large per-frame saving.
  const mapMeshes = scene.meshes.slice();
  let mapVertices = 0;
  for (const mesh of mapMeshes) {
    mapVertices += mesh.getTotalVertices();
    mesh.freezeWorldMatrix();
    mesh.doNotSyncBoundingInfo = true;
    mesh.isPickable = false;
  }
  const mapStats = { meshes: mapMeshes.length, vertices: mapVertices, loadMs: mapMs };

  // Preload the DOM-level assets (lobby key art + every file SFX: click,
  // repair, whooshes, impacts — see soundManager.js) NOW, while the loading
  // screen is still up, so nothing pops in or fetches later. Kicked off here
  // (just after the big map download) so it overlaps the car/traffic/race
  // loading below and the whole thing is done before the screen hands over.
  // Never rejects, so a bad asset cannot stall the boot.
  const assetsReady = preloadAssets({ onProgress: () => loading.setStatus() });
  // Warm the SoundManager's pooled <audio> elements in parallel with the above
  // (the browser cache makes the second fetch free). Also binds the global
  // button-click sound once, so every current and future <button> clicks.
  const soundReady = soundManager.preload().catch(() => ({}));
  soundManager.bindGlobalClickSound();

  // ---------------------------------------------------------------- collision
  // Bake the map's real geometry into query-able collision data: a layered
  // ground height field the wheels follow and a solid grid the chassis hits.
  // Done once here because a per-frame test against 7.5 M triangles is not
  // possible, and the map uses Draco compression so it cannot be measured
  // offline either.
  loading.setStatus();
  // `groupKey` makes the bake remember which obstacle cells each roadside prop
  // owns, so a prop the player destroys can have exactly its collision removed.
  const collision = new MapCollision(mapMeshes, {
    trackSources: hitsMode,
    groupKey: destructibleGroupKey,
  });

  // A glTF file may bring its own camera; make sure ours wins.
  scene.activeCamera = null;

  // Minimap overlay (bottom-left). Built from the baked roadway mask; all
  // rendering logic lives in src/game/minimap.js.
  const minimap = new Minimap(collision);

  // Grounded garage marker at the captured spot (from the coord probe).
  // Spins in place; the handle stays for later (entering the garage, hide/show).
  const GARAGE_SPOT = { x: 36.5, z: 102.9 };
  const garage = createGarageMarker(scene, collision, GARAGE_SPOT);
  minimap.setGarage(GARAGE_SPOT.x, GARAGE_SPOT.z);
  // Repair shops (green wrench icons): probed off the map meshes. NOTE the
  // handedness flip: the glTF loader mirrors the map into the world
  // (in-game x = -GLB x, z unchanged - confirmed against probe readouts),
  // so raw GLB coords must be x-negated here. There is no
  // gasstation_a.002 in the map - the numbered stations are .001 and
  // gasstation_b.002 - so the second wrench sits on gasstation_b.002.
  const REPAIR_SPOTS = [
    { x: 321.8, z: 39.9 }, // gasstation_a.001 (GLB -321.8)
    { x: -341.2, z: 101.0 }, // gasstation_b.002 (GLB 341.2)
  ];
  minimap.setRepairSpots(REPAIR_SPOTS);
  // Repair pads: the CENTER rectangle of each gas-station mesh (a quarter of
  // its measured footprint each way). Driving a damaged car onto one repairs
  // it instantly with a light-blink. gasstation_a has no wrench icon (the
  // garage mark already covers that area) but repairs just the same.
  const REPAIR_ZONES = [
    { x: 321.8, z: 39.9, hx: 7.5, hz: 12.5 }, // gasstation_a.001 (30x50)
    { x: -341.2, z: 101.0, hx: 7.5, hz: 7.5 }, // gasstation_b.002 (30x30)
    { x: 29.8, z: 110.9, hx: 7.5, hz: 12.5 }, // gasstation_a (GLB -29.8, 30x50)
  ];
  const repairFlashEl = document.getElementById("repair-flash");
  // Edge-trigger latch for the gas-station pads: the pad fires once when the
  // car ENTERS it, not continuously while parked on it. Driving off re-arms
  // it (after a short debounce so boundary flicker can't double-fire), so
  // each revisit repairs and rolls the paint exactly once.
  let padArmed = true;
  let padOffTime = 99;

  // --- paint shop (NFS-style body-colour cycle) --------------------------
  // Every visit to a gas-station pad rolls the car to the next entry in the
  // shared palette (six flat paints + the factory finish). The palette and
  // its apply helper live in carPaint.js, which the race grid also uses for
  // the rivals. Wired to the PLAYER car for the pad; traffic is not painted.
  let paintIndex = -1;
  /** Advance a car's body to the next palette entry. */
  function cycleCarPaint(car) {
    if (!car?.damage?.paint) return false;
    paintIndex = (paintIndex + 1) % CAR_PAINT.length;
    return paintAt(car, paintIndex);
  }
  function flashRepair() {
    if (!repairFlashEl) return;
    repairFlashEl.classList.remove("is-active");
    void repairFlashEl.offsetWidth;
    repairFlashEl.classList.add("is-active");
    window.setTimeout(() => repairFlashEl.classList.remove("is-active"), 600);
  }
  // Repair-shop jingle via the central SoundManager (preloaded at boot with
  // every other file SFX). Played on every pad visit - a repair, a paint
  // change, or both. Never throws; a blocked play just stays silent.
  function playRepairSound() {
    try {
      soundManager.playRepair();
    } catch {
      /* audio must never interrupt driving */
    }
  }

  // Garage entry modal (same language as the race prompt): offered while the
  // car is on the marker, outside of races.
  const garagePrompt = document.getElementById("garage-prompt");
  const garageEnterBtn = document.getElementById("garage-enter-btn");
  garageEnterBtn?.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    enterGarage();
  });
  garagePrompt?.addEventListener("pointerdown", (e) => e.stopPropagation());

  // Garage screen flow: ENTER zooms the lens out to a top view, then the DOM
  // showroom (grid + live 3D preview) opens on top of it. Closing hands the
  // chase cam + controls back. The showroom controller owns its overlay
  // element; main.js only tracks the open flag for camera/input gating.
  let garageOpen = false;
  let garageArrival = 0;
  const garageUI = createGarageScreen();
  // Exposed for console poking and headless diagnostics.
  window.__garageUI = garageUI;

  let startCinematicShowcase;
  // Music gating flags: `bootDone` flips once loading finishes (so the bed
  // starts under "Tap to Continue", before any tap); `enteredGame` flips on
  // the first Play. Between the two the player sits on the loading screen
  // with music already running.
  let bootDone = false;
  let enteredGame = false;

  const lobbyUI = new LobbyUI({
    onPlay: () => {
      enteredGame = true;
      startCinematicShowcase?.();
      carAudio?.setEnabled?.(true);
    },
    onOpenGarage: () => {
      garageOpen = true;
      garageArrival = 0;
    },
    onCloseGarage: () => {
      garageOpen = false;
    },
    garageUI,
  });
  window.__lobbyUI = lobbyUI;

  function enterGarage() {
    garageOpen = true;
    garageArrival = 0;
    garageUI.open();
  }
  function closeGarage() {
    garageOpen = false;
    garageUI.close();
    if (lobbyUI.isOpen()) {
      lobbyUI.setTab("home");
    }
  }
  document.getElementById("garage-close-btn")?.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    closeGarage();
  });
  document.getElementById("garage-screen")?.addEventListener("pointerdown", (e) => e.stopPropagation());

  window.addEventListener("keydown", (e) => {
    if ((e.code === "Enter" || e.code === "NumpadEnter") && !garageOpen && !lobbyUI.isOpen() && garagePrompt?.classList.contains("is-visible")) {
      e.preventDefault();
      enterGarage();
    }
    if (e.code === "Escape" && garageOpen) {
      e.preventDefault();
      closeGarage();
    }
  });
  function garageTopPose() {
    const st = player.state;
    return {
      pos: new Vector3(st.x + 4, st.y + 42, st.z - 6),
      look: new Vector3(st.x, st.y + 1, st.z),
    };
  }

  // Nothing in the game is clickable, and pointer picking walks the whole
  // 3000-mesh scene on every mouse move, so turn it off entirely.
  scene.skipPointerMovePicking = true;
  scene.skipPointerDownPicking = true;
  scene.skipPointerUpPicking = true;

  // ---------------------------------------------------------------- car
  loading.setStatus();
  const carContainer = await LoadAssetContainerAsync(CAR_URL, scene, {
    pluginExtension: ".glb",
  });

  // `let`: the garage can swap this whole rig out (see `equipCar` below).
  let playerRig = new VehicleRig(
    scene,
    carContainer.instantiateModelsToScene((n) => n, false).rootNodes[0],
    "player",
  );

  // Spawn on the `parking_area_c` slot: read straight off that mesh (the glTF
  // loader names meshes after their nodes, so it is `parking_area_c` at
  // runtime), seated exactly on the baked surface. Falls back to the measured
  // coordinates, then a nearby ground point, then the old roadway search, so
  // nothing can strand the car in the void.
  const PARKING_ANCHOR = { x: -34.8, z: 146.0 };
  /** Small east nudge: the mesh origin sits slightly west of the stall's
   *  visual centre, so this centers the car between the lines. */
  const SLOT_CENTER_EAST = -1;
  let parkingAnchor = { x: PARKING_ANCHOR.x + SLOT_CENTER_EAST, z: PARKING_ANCHOR.z };
  const parkingMesh =
    scene.meshes.find((m) => m.name === "parking_area_c") ??
    scene.meshes.find((m) => /^parking_area_c(\.|$)/i.test(m.name ?? ""));
  if (parkingMesh) {
    const p = parkingMesh.getAbsolutePosition();
    if (Number.isFinite(p?.x) && Number.isFinite(p?.z)) {
      parkingAnchor = { x: p.x + SLOT_CENTER_EAST, z: p.z };
    }
  }
  function findParkingSpawn(cx, cz) {
    const g0 = collision.groundAt(cx, cz, 6, { stepUp: 3, reach: 8 });
    if (g0.kind === "ground") return { x: cx, z: cz, y: g0.y };
    for (let d = 2; d <= 24; d += 2) {
      for (let a = 0; a < 12; a++) {
        const th = (a / 12) * Math.PI * 2;
        const x = cx + Math.cos(th) * d;
        const z = cz + Math.sin(th) * d;
        const g = collision.groundAt(x, z, 6, { stepUp: 3, reach: 8 });
        if (g.kind === "ground") return { x, z, y: g.y };
      }
    }
    return null;
  }
  function findRoadSpawn(cx, cz) {
    if (collision.isRoadAt(cx, cz)) return { x: cx, z: cz };
    for (let d = 2; d <= 40; d += 2) {
      for (let a = 0; a < 16; a++) {
        const th = (a / 16) * Math.PI * 2;
        const x = cx + Math.cos(th) * d;
        const z = cz + Math.sin(th) * d;
        if (collision.isRoadAt(x, z)) return { x, z };
      }
    }
    return { x: cx, z: cz }; // nowhere better; keep the stored spot
  }
  const parking = findParkingSpawn(parkingAnchor.x, parkingAnchor.z);
  const spawnSpot = parking ?? findRoadSpawn(routeData.playerSpawn.x, routeData.playerSpawn.z);
  const spawnY =
    parking?.y ??
    collision.groundAt(spawnSpot.x, spawnSpot.z, routeData.playerSpawn.y ?? GROUND_Y + 0.02, {
      stepUp: 2,
      reach: 2,
    }).y;

  const player = new PlayerVehicle(
    playerRig,
    {
      x: spawnSpot.x,
      y: spawnY ?? routeData.playerSpawn.y ?? GROUND_Y + 0.02,
      z: spawnSpot.z,
      headingDeg: routeData.playerSpawn.headingDeg,
    },
    collision,
  );

  // Face north toward gasstation_a, the way the parking slot points: the
  // slot's heading is the line from the slot to the station. Falls back to
  // sweep-tested cardinals if that exact line is ever blocked.
  // The old stored heading is tried after it to keep continuity otherwise.
  let gasDir = null;
  const gasMesh =
    scene.meshes.find((m) => m.name === "gasstation_a") ??
    scene.meshes.find((m) => /^gasstation_a(\.|$)/i.test(m.name ?? ""));
  if (gasMesh) {
    const gp = gasMesh.getAbsolutePosition();
    if (gp && Number.isFinite(gp.x) && Number.isFinite(gp.z)) {
      const dir = Math.atan2(gp.x - spawnSpot.x, gp.z - spawnSpot.z);
      // Snap to the nearest cardinal: the stalls run axis-aligned, so aiming
      // the raw station bearing would sit the car a few degrees crooked in
      // the lines. Here that lands due north, square with the slot.
      gasDir = Math.round(dir / (Math.PI / 2)) * (Math.PI / 2);
    }
  }
  if (player.terrain) {
    const deg = routeData.playerSpawn.headingDeg ?? 90;
    const rad = (deg * Math.PI) / 180;
    const candidates = [...(gasDir !== null ? [gasDir] : []), rad, 0, Math.PI / 2, Math.PI, -Math.PI / 2];
    let picked = null;
    player.terrain.teleport(player.state.y);
    for (const h of candidates) {
      const res = player.terrain.sweep(
        spawnSpot.x,
        spawnSpot.z,
        spawnSpot.x + Math.sin(h) * 8,
        spawnSpot.z + Math.cos(h) * 8,
        h,
      );
      if (!res.blocked) {
        picked = h;
        break;
      }
    }
    if (picked !== null) {
      player.state.heading = picked;
      player.terrain.teleport(player.state.y);
      player.sync();
    }
  }

  // ------------------------------------------------------ destructible props
  // Roadside fences, signs and small clutter that the player can smash through
  // above IMPACT_SPEED_KMH. Only the player is wired to it, so AI traffic still
  // stops against these props exactly as before. Broken props are thrown by the
  // system's own rigid-body integrator, which keeps them visible throughout the
  // reaction (Havok desynced the mesh and made props vanish on impact).
  const destruction = new DestructibleSystem(scene, mapMeshes, collision, {
    speedThresholdKmh: IMPACT_SPEED_KMH,
  });
  player.onImpact = (info) => destruction.handleImpact(info);

  // ---------------------------------------------------------------- traffic
  loading.setStatus();
  const vehicleAssets = await loadVehicleAssets(scene, {
    onProgress: () => loading.setStatus(),
  });

  loading.setStatus();
  const traffic = new TrafficSystem(scene, vehicleAssets, routeData, {
    maxVehicles: 24,
    collision,
    player,
  });
  // Wire the player -> traffic collision back-reference so the player's
  // update can call `traffic.collideWithPlayer` and the traffic AI can
  // see the player as a blocker ahead.
  player.traffic = traffic;

  // Tire tracks: one pooled renderer for every surface look, fed by the
  // player (rear axle stamps while sliding). Lives outside any vehicle so
  // marks persist after resets and respawns. The spray is the airborne half
  // of the same event - dust/dirt/mud/sand thrown off the tyres while driving.
  loading.setStatus();
  const tireMarks = new TireMarks(scene);
  player.marks = tireMarks;
  const tireSpray = new TireSpray(scene);
  player.spray = tireSpray;

  // ---------------------------------------------------------------- race
  // One race, built from the roads the game already drives on: the rivals are
  // the cars in public/assets/ that are neither the player's car nor a traffic
  // model, the circuit is one of the validated lane loops nearest the player's
  // spawn, and the start line is the point of it closest to that spawn, so the
  // event is in sight from the first frame.
  loading.setStatus();
  const raceAssets = await loadRaceCarAssets(scene, {
    onProgress: () => loading.setStatus(),
  });
  // The race-event manager owns the registry + progression and drives a single
  // RaceSystem, pointing it at whichever authored event the player is nearest.
  // The legacy auto-circuit (anchored at the original spawn) is the fallback
  // the RaceSystem builds in its constructor.
  const raceManager = new RaceEventManager(scene, {
    collision,
    traffic,
    player,
    assets: raceAssets,
    garageUI,
    // Rivals hit and break the destructible roadside props on their line (see
    // RaceDriver's impact hook), so the same system is shared.
    destruction,
    anchor: (() => {
      const old = findRoadSpawn(routeData.playerSpawn.x, routeData.playerSpawn.z);
      return { x: old.x, z: old.z };
    })(),
  });
  const race = raceManager.race;
  const raceHud = new RaceHud(race);
  raceHud.raceManager = raceManager;
  minimap.setRace(race);
  minimap.setEvents(raceManager.minimapData);
  // The player collides with the rivals, and the traffic fleet brakes for them
  // (see vehicleCollision.js and TrafficSystem.extraVehicles).
  player.opponents = race.field;

  // ---------------------------------------------------------------- car equip
  // The garage can swap the player's car between races. Every catalogue model
  // is parsed once into a container that stays parked for the session; a swap
  // instantiates a fresh copy, scales it to the catalogue's target length (so
  // the wheelbase/track stay inside the envelope the map's lanes were
  // validated for) and builds a normal `VehicleRig` from it, which the player
  // then adopts wholesale - rig, terrain follower and damage model together.
  const CAR_ASSET_DIR = "assets/";
  const carContainers = new Map([[CAR_URL, carContainer]]);
  // What the player is driving right now (the rig loaded above), not what the
  // garage remembers - the two only match after the restore below.
  let equippedFile = "car1.glb";

  // ---------------------------------------------------------------- audio
  // Two halves plus a bed: the synthesised engine/skid/brake/wind mix
  // (CarAudio, live AudioWorklet graph), the file SFX (SoundManager: click,
  // repair, whooshes, crash impacts from public/assets/audio/) and the looped
  // lobby music bed (bg.mp3, lobby-only). The engine voice
  // matches the equipped car's type (see carAudio.js) and retunes on every
  // garage swap. Browsers hold the context suspended until a gesture, so the
  // first key / tap unlocks both halves; a muted mix stays silent.
  const carAudio = new CarAudio();
  carAudio.setProfile(profileForCar({ file: equippedFile }));
  /** Single mute gate for BOTH halves (lobby / pause / M key funnel here). */
  const applySfxSetting = (on) => {
    try {
      carAudio.setMuted(!on);
    } catch {
      /* ignore */
    }
    try {
      soundManager.setMuted(!on);
    } catch {
      /* ignore */
    }
  };
  /** Lobby/pause music toggle (independent of the SFX mute above). */
  const applyMusicSetting = (on) => {
    try {
      soundManager.setMusicMuted(!on);
    } catch {
      /* ignore */
    }
  };
  // Late-wire the lobby's toggles (the lobby was built before carAudio).
  try {
    lobbyUI.onSfxChange = applySfxSetting;
  } catch {
    /* lobby optional in tests */
  }
  try {
    lobbyUI.onMusicChange = applyMusicSetting;
  } catch {
    /* lobby optional in tests */
  }
  const unlockAudio = () => {
    try {
      carAudio.unlock();
    } catch {
      /* ignore */
    }
    try {
      soundManager.unlock();
    } catch {
      /* ignore */
    }
  };
  window.addEventListener("keydown", unlockAudio, { once: true });
  window.addEventListener("pointerdown", unlockAudio, { once: true });
  // 'M' toggles the whole mix — engine, file SFX and lobby music together.
  window.addEventListener("keydown", (e) => {
    if (e.code === "KeyM") {
      let muted = false;
      try {
        muted = carAudio.toggleMute();
      } catch {
        /* ignore */
      }
      try {
        soundManager.setMuted(muted);
      } catch {
        /* ignore */
      }
      try {
        soundManager.setMusicMuted(muted);
      } catch {
        /* ignore */
      }
    }
  });
  // Race HUD transitions: file whooshes for the cards + synth beeps for the
  // countdown. `whoosh` matches CarAudio's signature so the HUD needs no
  // changes to use the mp3 sweeps.
  raceHud.sfx = {
    whoosh: (variant) => soundManager.playWhoosh(variant),
    countBeep: (...args) => carAudio.countBeep(...args),
  };

  // ---------------------------------------------------------------- pause
  // In-game pause menu (top-left icon): freezes the world and offers resume /
  // restart / settings / quit. It owns its own DOM (see index.html + pause.css)
  // and only reports open state here; main.js does the actual freezing.
  const pauseMenu = new PauseMenu({
    race,
    // Quit Race ends the active event and hands the open world back; it never
    // leaves the game (only the lobby button / Escape do that).
    onQuitRace: () => race.abandonRace(),
    onRestart: () => {
      // Only a live event can be restarted; idle free-roam has nothing to run.
      const st = race.state;
      if (
        st === RACE_STATE.INTRO ||
        st === RACE_STATE.COUNTDOWN ||
        st === RACE_STATE.RACING ||
        st === RACE_STATE.FINISHED
      ) {
        race.raceAgain();
      }
    },
    onSfxChange: (on) => {
      applySfxSetting(on);
    },
    onMusicChange: (on) => {
      applyMusicSetting(on);
    },
  });
  window.__pauseMenu = pauseMenu;

  /** Longest horizontal extent of an instantiated car (metres). */
  function measureCarLength(loadedRoot) {
    loadedRoot.computeWorldMatrix(true);
    const meshes = [...loadedRoot.getChildMeshes(false)];
    if (loadedRoot.getClassName?.() === "Mesh") meshes.push(loadedRoot);
    let minX = Infinity;
    let maxX = -Infinity;
    let minZ = Infinity;
    let maxZ = -Infinity;
    for (const m of meshes) {
      m.computeWorldMatrix(true);
      const bb = m.getBoundingInfo().boundingBox;
      minX = Math.min(minX, bb.minimumWorld.x);
      maxX = Math.max(maxX, bb.maximumWorld.x);
      minZ = Math.min(minZ, bb.minimumWorld.z);
      maxZ = Math.max(maxZ, bb.maximumWorld.z);
    }
    return Math.max(maxX - minX, maxZ - minZ);
  }

  async function loadCarAsset(file) {
    let container = carContainers.get(file);
    if (container) return container;
    container = await LoadAssetContainerAsync(
      CAR_ASSET_DIR + encodeURIComponent(file),
      scene,
      { pluginExtension: ".glb" },
    );
    carContainers.set(file, container);
    return container;
  }

  /**
   * Swap the player's car to a garage catalogue entry.
   *
   * @returns true when the swap happened (or was already in place), false when
   *          it was refused (mid-race) or the model could not be rigged.
   */
  async function equipCar(entry) {
    if (!entry?.file) return false;
    if (entry.file === equippedFile) return true;
    // A swap mid-race would leave the grid and the standings describing a car
    // that is no longer there, so only the idle/armed states may change car.
    if (race.state !== RACE_STATE.IDLE && race.state !== RACE_STATE.ARMED) {
      console.warn("Equip: refused, a race is under way");
      return false;
    }

    let container;
    try {
      container = await loadCarAsset(entry.file);
    } catch (err) {
      console.warn(`Equip: ${entry.file} failed to load`, err);
      return false;
    }
    const loadedRoot = container.instantiateModelsToScene((n) => n, false).rootNodes[0];
    if (!loadedRoot) return false;

    const target = Number(entry.targetLength);
    if (Number.isFinite(target) && target > 0) {
      const length = measureCarLength(loadedRoot);
      if (length > 0.5) {
        const s = target / length;
        loadedRoot.scaling.setAll(loadedRoot.scaling.x * s);
      }
    }

    let nextRig;
    try {
      nextRig = new VehicleRig(scene, loadedRoot, `pcar_${entry.file.replace(/\W+/g, "_")}`);
    } catch (err) {
      console.warn(`Equip: could not rig ${entry.file}`, err);
      try {
        loadedRoot.dispose(false, false);
      } catch {
        /* nothing to release */
      }
      return false;
    }

    const { oldRig } = player.equip(nextRig);
    nextRig.setFade?.(1);
    // A new car starts from a clean slate: the paint-shop cycle is per-driver
    // state, so without this the freshly equipped car would be repainted with
    // the NEXT palette entry the moment it touched a gas-station pad, i.e. the
    // previous car's colour sequence would carry straight over onto it. Force
    // the factory finish and rewind the cycle to the start.
    paintIndex = -1;
    try {
      player.damage?.paint?.(null);
    } catch {
      /* paint is cosmetic: the swap must not fail over it */
    }
    try {
      console.info(
        `[equip] ${entry.file} reset to factory finish (${player.damage?.paintablePanels?.() ?? "?"} paintable panels), paint cycle rewound`,
      );
    } catch {
      /* logging must never break the swap */
    }
    playerRig = nextRig;
    equippedFile = entry.file;
    // Match the engine voice to the newly equipped car.
    carAudio.setProfile(profileForCar(entry));
    if (window.game) window.game.playerRig = nextRig;
    // The collision overlay patches one follower per vehicle; the swapped-in
    // follower is a different object, so re-instrument when it is running.
    if (hitDebug && player.terrain) instrumentFollower(player.terrain, hitDebug, "player");
    try {
      oldRig?.dispose?.();
    } catch {
      /* already gone */
    }
    return true;
  }

  // ---------------------------------------------------------------- collision overlay
  // Only built when asked for. It records which mesh caused each contact so
  // phantom walls can be spotted by eye rather than inferred from numbers.
  // Every follower is patched once, here - never inside the frame loop.
  const hitDebug = hitsMode ? new CollisionDebug(scene) : null;
  if (hitDebug) {
    if (player.terrain) instrumentFollower(player.terrain, hitDebug, "player");
    for (const v of traffic.vehicles) instrumentFollower(v.terrain, hitDebug, "traffic");
  }

  // ---------------------------------------------------------------- equip wiring
  // Hook the garage's EQUIP button to the swap. Declared last so `hitDebug`
  // (above) already exists when a swap re-instruments the follower.
  garageUI.setEquipHandler(equipCar);

  // Restore the saved garage slot so a reload keeps driving the chosen car.
  {
    const savedEntry = garageUI.getEquipped?.();
    if (savedEntry && savedEntry.file !== equippedFile) await equipCar(savedEntry);
  }

  // ---------------------------------------------------------------- camera
  // Collision-aware boom: the lens sphere-casts against the baked solids +
  // tree trunks and pulls in instead of entering buildings/trees/signs.
  const chase = new ChaseCamera(scene, collision);
  chase.update(0, player.position, player.state.heading, 0);
  scene.activeCamera = chase.camera;

  // ---------------------------------------------------------------- entry cinematic
  // Professional game start as one continuous move: the lens pushes in over
  // the car from the top, swoops down to a front close-up, glides around
  // the side profile, and settles onto the chase stance, where control hands
  // to the player. Never static, never cutting - always gliding.
  // Letterbox bars ride the whole sweep and slide away on control.
  const CINE_TOP_END = 2.0;
  const CINE_FRONT_END = 3.2;
  const CINE_SIDE_END = 5.2;
  const CINE_END = 6.8;
  let cineT = 0;
  let cineDone = false;
  let barsShown = false;
  const barTop = document.getElementById("cine-bar-top");
  const barBottom = document.getElementById("cine-bar-bottom");
  const cineCar = {
    x: player.state.x,
    y: player.state.y,
    z: player.state.z,
    heading: player.state.heading,
  };
  playerRig.setFade?.(1);
  function catmullRom(p0, p1, p2, p3, t) {
    const t2 = t * t;
    const t3 = t2 * t;
    return new Vector3(
      0.5 * ((2 * p1.x) + (-p0.x + p2.x) * t + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3),
      0.5 * ((2 * p1.y) + (-p0.y + p2.y) * t + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3),
      0.5 * ((2 * p1.z) + (-p0.z + p2.z) * t + (2 * p0.z - 5 * p1.z + 4 * p2.z - p3.z) * t2 + (-p0.z + 3 * p1.z - 3 * p2.z + p3.z) * t3),
    );
  }

  function cinePose(t) {
    const clampedT = Math.max(0, Math.min(t, CINE_END));

    const fx = Math.sin(cineCar.heading);
    const fz = Math.cos(cineCar.heading);
    const rx = fz;
    const rz = -fx;

    // Helper: translate car-local forward/right/up offsets to world coordinates
    const pt = (fwd, right, up) =>
      new Vector3(
        cineCar.x + fx * fwd + rx * right,
        cineCar.y + up,
        cineCar.z + fz * fwd + rz * right,
      );

    // Continuous spline waypoints from top view down into the car showcase and chase stance:
    // P0: Starting top view (y + 34, front-right) - matches the top view in the lobby
    const p0 = pt(3.0, 4.0, 34.0);
    // P1: Mid-altitude sweeping arc (y + 16, gracefully descending without sudden plunge)
    const p1 = pt(4.6, 2.8, 16.0);
    // P2: Front close-up (y + 1.75, low front showcase)
    const p2 = pt(5.8, 0.4, 1.75);
    // P3: Side flank dolly (y + 1.65, sleek side profile)
    const p3 = pt(0.5, -5.8, 1.65);
    // P4: Rear quarter wrap (y + 2.1, carving toward the back)
    const p4 = pt(-4.5, -3.8, 2.1);
    // P5: Chase stance (y + 2.7, directly behind the car)
    const p5 = pt(-6.2, 0.0, 2.7);

    // Look-at targets along the flight
    const lCar = new Vector3(cineCar.x, cineCar.y + 1.0, cineCar.z);
    const lFront = new Vector3(cineCar.x, cineCar.y + 0.95, cineCar.z);
    const lQuarter = new Vector3(cineCar.x + fx * 1.5, cineCar.y + 1.05, cineCar.z + fz * 1.5);
    const lChase = new Vector3(cineCar.x + fx * 6.0, cineCar.y + 1.25, cineCar.z + fz * 6.0);

    const positions = [p0, p0, p1, p2, p3, p4, p5, p5];
    const targets = [lCar, lCar, lCar, lFront, lFront, lQuarter, lChase, lChase];

    const segTimes = [0, 1.6, 3.2, 4.8, 5.8, 6.8];
    let seg = 0;
    while (seg < segTimes.length - 2 && clampedT > segTimes[seg + 1]) {
      seg++;
    }

    const segStart = segTimes[seg];
    const segDur = segTimes[seg + 1] - segStart;
    let u = Math.max(0, Math.min(1, (clampedT - segStart) / segDur));

    // Smooth ease-in at the very start (segment 0) so the camera begins moving gently from rest
    if (seg === 0) {
      u = u * u * (2 - u);
    } else if (seg === segTimes.length - 2) {
      // Smooth ease-out at the end (segment 4) so it settles into chase stance with zero snap
      u = u + u * u - u * u * u;
    }

    const pos = catmullRom(positions[seg], positions[seg + 1], positions[seg + 2], positions[seg + 3], u);
    const look = catmullRom(targets[seg], targets[seg + 1], targets[seg + 2], targets[seg + 3], u);

    const g = collision.groundAt?.(pos.x, pos.z, pos.y, { stepUp: 5, reach: 70 });
    const minY = g && g.y !== null && g.y !== undefined ? g.y + 1.4 : cineCar.y + 1.4;
    if (pos.y < minY) pos.y = minY;

    return { pos, look };
  }

  // Pre-position camera at top view overlooking the car initially
  const initialTopPose = cinePose(0);
  chase.camera.position.copyFrom(initialTopPose.pos);
  chase.target = initialTopPose.look.clone();
  chase.camera.setTarget(initialTopPose.look);

  startCinematicShowcase = function () {
    cineCar.x = player.state.x;
    cineCar.y = player.state.y;
    cineCar.z = player.state.z;
    cineCar.heading = player.state.heading;
    cineT = 0;
    cineDone = false;
    barsShown = true;
    barTop?.classList.add("is-visible");
    barBottom?.classList.add("is-visible");
    playerRig?.setFade?.(1);

    const initialPose = cinePose(0);
    chase.camera.position.copyFrom(initialPose.pos);
    chase.target = initialPose.look.clone();
    chase.camera.setTarget(initialPose.look);

    const minimap = document.getElementById("minimap");
    if (minimap) minimap.style.display = "none";
  };

  // Allow pressing Space / Enter / Escape to skip cinematic showcase
  window.addEventListener("keydown", (e) => {
    if (!cineDone && !lobbyUI.isOpen() && (e.code === "Space" || e.code === "Enter" || e.code === "Escape")) {
      e.preventDefault();
      cineT = CINE_END;
      cineDone = true;
      playerRig?.setFade?.(1);
      barsShown = false;
      barTop?.classList.remove("is-visible");
      barBottom?.classList.remove("is-visible");
      const minimap = document.getElementById("minimap");
      if (minimap) minimap.style.display = "";
    }
  });

  // ---------------------------------------------------------------- loop
  // Testing coordinate probe (remove with src/game/coordProbe.js): created
  // only with `?testing=1`.
  const probe = testingMode ? createCoordProbe(scene) : null;
  let elapsed = 0;
  let frame = 0;

  engine.runRenderLoop(() => {
    const dt = Math.min(engine.getDeltaTime() / 1000, 0.05); // clamp after tab switches
    elapsed += dt;
    frame++;

    // Lobby music bed (looped bg.mp3): starts the moment loading finishes —
    // even under "Tap to Continue", before the first tap — then plays while
    // the lobby is open and stops the moment driving starts. Idempotent, so
    // calling it every frame covers every path (loading screen, tap-through,
    // Escape reopen). Note: browsers may block the pre-tap attempt until the
    // first gesture; SoundManager keeps the intent and retries on unlock, so
    // the tap itself kicks it in with no extra wiring. The lobby's music
    // toggle + M key gate it via setMusicMuted; SFX are unaffected.
    try {
      if (lobbyUI.isOpen() || (bootDone && !enteredGame)) soundManager.startMusic();
      else soundManager.stopMusic();
    } catch {
      /* music must never interrupt the frame */
    }

    // Pause menu: freeze the entire simulation while it is up. The scene keeps
    // presenting the last rendered frame underneath the modal, and the car
    // audio ramps to silence instead of holding its last engine note.
    if (pauseMenu.isOpen()) {
      carAudio.setEnabled(false);
      carAudio.update(dt, { speed: 0, throttle: 0, brake: 0, handbrake: false, slip: 0 });
      input.endFrame();
      scene.render();
      return;
    }

    // Update order: traffic first, then player. This means the player's
    // collision check (inside player.update) sees traffic positions
    // that are already advanced to this frame - no 1-frame lag on the
    // collision response. The traffic AI reads the player position from
    // last frame, which is fine because player motion between frames
    // is small relative to the AI's reaction distance.
    //
    // While the entry cinematic plays, every drive input is ignored: the car
    // stays parked, the race sees no input (so no accidental SPACE start),
    // and the HUD stays frozen until the handoff gives control to the player.
    if (!cineDone && !lobbyUI.isOpen()) {
      cineT += dt;
      if (cineT >= CINE_END) {
        cineDone = true;
        playerRig.setFade?.(1);
        const minimap = document.getElementById("minimap");
        if (minimap) minimap.style.display = "";
      }
    }
    // Letterbox bars ride the entry sweep, sliding away on the handoff.
    const wantBars = !cineDone && !lobbyUI.isOpen();
    if (barsShown !== wantBars) {
      barsShown = wantBars;
      barTop?.classList.toggle("is-visible", barsShown);
      barBottom?.classList.toggle("is-visible", barsShown);
    }
    traffic.update(dt, player.position);
    // The race runs before the player so that a countdown that starts this
    // frame already locks the controls, and so the player's collision sweep
    // sees the rivals where they are now rather than a frame behind.
    raceManager.update(dt, cineDone && !garageOpen && !lobbyUI.isOpen() ? input : null);
    minimap.setEvents(raceManager.minimapData);
    // Locked intents: countdown/intro pin the car; the finish cinematic
    // straight-line brakes until nearly stopped, then pins too — braking past
    // standstill would roll the car backwards into reverse. The garage screen
    // and main lobby pin everything while open.
    let intent = input;
    if (!cineDone || garageOpen || lobbyUI.isOpen()) {
      intent = LOCKED_INPUT;
    } else if (race.controlsLocked) {
      intent =
        race.state === RACE_STATE.FINISHED && player.state.speed > 0.5
          ? FINISH_BRAKE_INPUT
          : LOCKED_INPUT;
    }
    player.update(dt, intent);
    player.spin(dt);
    // Drive the synthesised car audio from the intent actually applied this
    // frame (so the countdown/garage lock idles the engine) plus the car's
    // live speed and tyre slip. Silenced while the garage overlay or lobby is open.
    carAudio.setEnabled(!garageOpen && !lobbyUI.isOpen());
    carAudio.update(dt, {
      speed: player.state.speed,
      throttle: intent.throttle,
      brake: intent.handbrake ? 1 : intent.brake,
      handbrake: intent.handbrake,
      slip: player.slip,
    });
    destruction.update(dt, player.position);
    if (hitDebug) hitDebug.update(dt);
    // Entry cinematic lens, then: garage top view, race intro top view,
    // finish orbit, or the chase cam trailing the player.
    if (garageOpen) {
      const pose = garageTopPose();
      chase.driveTo(dt, pose.pos, pose.look);
      // Reveal the showroom only once the zoom-out has actually arrived
      // (with a timeout backstop), so the flight always plays in the open
      // instead of behind the fade.
      garageArrival += dt;
      const arrived =
        chase.camera.position.subtract(pose.pos).length() < 4 || garageArrival > 4;
      if (arrived) garageUI.reveal();
    } else if (lobbyUI.isOpen()) {
      cineCar.x = player.state.x;
      cineCar.y = player.state.y;
      cineCar.z = player.state.z;
      cineCar.heading = player.state.heading;
      const pose = cinePose(0);
      chase.driveTo(dt, pose.pos, pose.look, 5);
    } else if (!cineDone) {
      const pose = cinePose(Math.min(cineT, CINE_END));
      chase.driveTo(dt, pose.pos, pose.look, 7.0);
    } else if (race.state === RACE_STATE.INTRO) {
      const pose = race.introCamPose();
      chase.driveTo(dt, pose.pos, pose.look);
    } else if (race.state === RACE_STATE.FINISHED && race.cineActive) {
      const pose = race.finishCamPose();
      chase.driveTo(dt, pose.pos, pose.look);
    } else {
      chase.update(dt, player.position, player.state.heading, player.state.speed);
    }

    // The pause icon appears only once the game is actually running: hidden
    // through the boot/loading, entry cinematic, lobby and garage.
    pauseMenu.setAvailable(cineDone && !garageOpen && !lobbyUI.isOpen());

    hud.update(player, intent);
    // The prompt stays frozen away for the entry cinematic, so there is no
    // START button to mis-click mid-sweep (and nothing else to update yet).
    if (cineDone) raceHud.update(race.hudState);
    minimap.update(player, traffic, dt);
    garage.update(dt, player.position);
    // Tire tracks fade on their own clock, independent of driving.
    tireMarks.update(dt);
    // Station repair + paint shop: fires ONCE per visit (edge-triggered).
    // A car parked on the pad keeps its colour no matter how long it sits;
    // driving off re-arms the pad (past a short debounce) so the next visit
    // repairs and rolls the paint again.
    if (!garageOpen) {
      const px = player.state.x;
      const pz = player.state.z;
      const onPad = REPAIR_ZONES.some(
        (zone) => Math.abs(px - zone.x) <= zone.hx && Math.abs(pz - zone.z) <= zone.hz,
      );
      if (onPad) {
        padOffTime = 0;
        if (padArmed) {
          // Repair whatever damage there is (a pristine car skips this) and,
          // as at any gas station, roll the paint to the next colour - the
          // pad is a repair shop AND a paint shop.
          if ((player.damage?.overall() ?? 0) > 0.02) {
            try {
              player.damage.repair();
            } catch {
              /* visual-only: never interrupt driving */
            }
          }
          cycleCarPaint(player);
          flashRepair();
          playRepairSound();
          padArmed = false;
        }
      } else {
        padOffTime += dt;
        if (padOffTime > 0.5) padArmed = true;
      }
    }
    // Garage offer mirrors the race prompt: only while touching the marker
    // and only outside of races.
    garagePrompt?.classList.toggle(
      "is-visible",
      !garageOpen &&
        !lobbyUI.isOpen() &&
        garage.inRange() &&
        (race.state === RACE_STATE.IDLE || race.state === RACE_STATE.ARMED),
    );
    // Testing probe keys (X toggle readout, Z capture spot).
    if (probe) {
      if (input.consumed("coords")) probe.toggle();
      if (input.consumed("capture")) probe.capture(player);
      probe.update(player);
    }

    input.endFrame();
    // During the ENTER zoom-out the main scene still presents so the flight
    // stays visible; once the showroom overlay has revealed, its own engine
    // presents instead.
    const garageShown = garageOpen && typeof garageUI.isShown === "function" && garageUI.isShown();
    if (!garageShown) scene.render();
    if (garageShown) garageUI.render(dt);

    // Publish diagnostics once the world has settled, for headless runs.
    if (debugMode && frame === debugFrame) {
      const isOnRoad = createRoadTest(routeData, collision);
      const results = runSelfTest({ rig: playerRig, player, traffic, isOnRoad, routeData, mapStats, collision });
      publish(
        {
          passed: results.filter((r) => r.pass).length,
          failed: results.filter((r) => !r.pass).length,
          results,
          fps: Math.round(engine.getFps()),
          map: mapStats,
          collision: collision.stats,
          routes: routeData.routes.length,
          traffic: traffic.plan,
          destruction: destruction.stats,
          race: race.debugReport(),
          hitDebug: hitDebug
            ? {
                tally: hitDebug.tally,
                tracked: hitDebug.hits.length,
                // The meshes responsible for the most recent box-only blocks -
                // the ones to look at first when hunting a phantom wall.
                boxOnly: hitDebug.hits
                  .filter((h) => h.bucket === "aabb")
                  .slice(-8)
                  .map((h) => ({ mesh: h.mesh, x: Math.round(h.x), z: Math.round(h.z) })),
              }
            : null,
          player: {
            x: Number(player.state.x.toFixed(2)),
            z: Number(player.state.z.toFixed(2)),
            heading: Number(player.state.heading.toFixed(3)),
            speed: Number(player.state.speed.toFixed(2)),
          },
          rig: playerRig.diagnostics,
          errors,
        },
        debugMode,
      );
    }
  });

  window.addEventListener("resize", () => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    engine.setHardwareScalingLevel(1 / dpr);
    engine.resize();
  });

  // Everything is loaded; make sure the preloaded DOM assets AND the pooled
  // file SFX are done too before the loading screen offers "Tap to Continue".
  await assetsReady;
  try {
    await soundReady;
  } catch {
    /* a bad sound file never blocks the boot */
  }
  // Boot finished: flag the frame loop to start the music bed immediately —
  // under "Tap to Continue", without waiting for the tap. If the browser
  // blocks audio pre-gesture, the attempt is kept and retried on unlock.
  bootDone = true;

  // Boot finished: the loading screen swaps to "Tap to Continue" and the
  // lobby opens the moment the player taps through - while the overlay
  // fades out on top of it, so the handoff reads as one continuous fade
  // instead of a flash of the 3D scene between the two. Not awaited, so
  // the handles below (resize, console probes) are live even before the tap.
  loading.ready(() => {
    lobbyUI.open("home");
  });

  // Expose a few handles for console poking and for the headless test probes.
  window.game = {
    engine,
    scene,
    lobbyUI,
    player,
    traffic,
    chase,
    input,
    minimap,
    routeData,
    collision,
    playerRig,
    equipCar,
    garageCatalog: GARAGE_CATALOG,
    carContainer,
    vehicleAssets,
    hitDebug,
    destruction,
    race,
    raceHud,
    raceManager,
    pauseMenu,
    raceAssets,
    carAudio,
    soundManager,
    Vector3,
    Quaternion,
    Matrix,
  };
}

main().catch((err) => {
  console.error(err);
  showLoadingFailure(`Failed to start: ${err.message}`);
  publish({ fatal: String(err?.stack ?? err), errors }, true);
});
