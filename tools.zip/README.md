# Street Racer

A street racing game built with plain HTML/CSS/JS and [Babylon.js](https://babylonjs.com).
Vite is used as the dev server and bundler; the game code itself is framework-free.

## Run

```bash
pnpm install
pnpm dev
```

Opens on http://localhost:5173.

```bash
pnpm build     # bundle to dist/
pnpm preview   # serve dist/ to check the production build
```

## Controls

| Key | Action |
| --- | --- |
| `W` / `↑` | throttle |
| `S` / `↓` | brake, then reverse |
| `A` `D` / `←` `→` | steer |
| `Space` | handbrake |

## Structure

```
index.html          # page shell: canvas, HUD, overlay
src/
  main.js           # bootstrap: load assets, build the world, run the loop
  engine/
    createScene.js  # engine, scene, lights, fog
    ChaseCamera.js  # smoothed third-person camera
    MapCollision.js # bakes the map into ground + obstacle lookup grids
  game/
    driving.js      # shared car constants, bicycle model, lane Path
    terrain.js      # wheel contacts, suspension, terrain following
    PlayerVehicle.js# the driven car (collides with traffic)
    TrafficVehicle.js# one AI road user (lane-following + impact shove + recovery)
    TrafficSystem.js# spawns & distributes traffic, player<->traffic collisions
    TrafficRig.js   # transform rig for the new multi-mesh traffic models
    VehicleAssets.js # vehicle catalogue: loads every model in public/assets/vehicles/
    laneBuilder.js # builds validated lanes from the baked road mask
    VehicleRig.js   # wheel pivots, steering, wheel roll, body lean (player car)
    input.js        # keyboard -> intent
    hud.js          # speed / gear
    destructibles.js# breakable roadside props, with self-repair
    collisionDebug.js# ?hits=1 collision marker overlay
    debug.js        # runtime self-tests and diagnostics
  data/
    routes.json     # legacy offline lanes; traffic now builds lanes at runtime
public/
  assets/
    map.glb         # the town
    car1.glb        # the player car
    vehicles/       # 13 traffic models: mini-car, muscle-car, suv, minivan, pickup, ambulance, iceCream, post-truck
  README.md         # note about how public/ is served
tools/              # offline analysis + testing helpers, not shipped
```

## How it works

**Scale.** 1 world unit is 1 metre. The town is about 1000 x 600 m, roads are
~12 m wide, and the car measures 4.3 x 1.5 x 1.9 m.

**Driving.** Motion uses a kinematic bicycle model (`game/driving.js`):

```
yawRate = -(speed / wheelBase) * tan(steer)
```

The available steering angle is limited by tyre grip rather than a hand-tuned
curve, so the tightest turn the car can hold is `radius = v^2 / maxLateralAccel`.
That is why the car turns freely when parking and barely at all at speed, which
is how a real car behaves.

`steer > 0` steers left, and `heading` maps straight onto `root.rotation.y`.
Both the car and its front wheels turn the same way by construction.

**Wheels.** The car asset needed repair before its wheels could move correctly:

- The wheel *nodes* are not centred on their meshes. `rFWheel.001` and
  `rrWheel` have their origin on the opposite side of the car (off by ~1.72 m),
  so rotating them to steer would swing the wheel around the chassis. Each wheel
  gets its own pivot placed at the measured mesh centre.
- The body frame is the wheel meshes' **parent** (`amg Gt body`, a
  `TransformNode`). The visible geometry is separate sibling meshes named
  `amg Gt body_primitive0..2` whose own transforms are identity, so looking the
  body up by mesh name finds a node with no transform and silently misplaces
  every pivot.
- Wheels are re-parented off the body so that body lean does not lift them off
  the road.

**Terrain and collision.** The car is not glued to a flat ground plane. At load
(`engine/MapCollision.js`) the map's real triangles are baked once into two
compact lookup grids:

- a **layered height field** of the drivable surfaces - roads, ramps, the
  elevated bridge deck, car parks, courts. Keeping several surfaces per cell is
  what lets the car sit on the ground *under* a bridge and also drive up onto
  it: each wheel resolves against the surface nearest the one it is already on,
  so a long ramp is climbed smoothly instead of being mistaken for a wall.
- a **solid grid** of everything else - buildings, fences, parked cars, signs -
  plus the steep faces of the roads themselves, stored as bottom/top columns so
  an overhead sign stops nobody while its post does.

Each frame every wheel projects onto its own patch of that geometry
(`game/terrain.js`). The four contacts set the chassis height, its pitch and
roll, and each wheel's suspension travel, so the tyres follow the surface and
the body lies along a slope. Horizontal motion is swept against the map
substep by substep: something low enough for the tyres to roll over is climbed,
an unclimbable step is refused, and a solid column stops the chassis rather than
letting it clip through. Traffic follows the same surface.

Because the bake approximates some small props with their bounding box, a car
can stop where the grid says solid with no mesh there. Collision tests candidate
*positions*, so a car in that state reads every candidate - including standing
still - as blocked and no input can free it. The sweep therefore tests the pose
the car is already in first, and when that pose is solid it walks the car back
toward the nearest free spot a cap at a time, so a prop can never wedge the car
permanently. Player and traffic both use it.

The town imports mirrored (`__root__` has scale `(1,1,-1)`), which reverses
winding, so each mesh's triangles are oriented by the determinant of its world
matrix before being classified. Large irregular meshes are baked triangle by
triangle; small compact ones use their bounding box, since taking the AABB of a
building-plus-yard would wall off whole roads.

**Water and mountains are solid, not scenery.** Two families defeat the
ordinary bake and are handled specially:

- **Water** (`water_a`, `water_b`) is a flat sheet. It has no wall triangles, so
the solid baker - which only walks steep faces - recorded nothing, and the car
drove straight in and dropped to the fallback ground height, *below* the water
surface, which is what read as sinking into the lake. Water is now rasterised as
a solid volume over its own footprint: the plan-view footprint of every water
triangle is filled and given a column reaching from the lake bed up to the
surface, so a car at road level is stopped at the shoreline while anything
crossing above the water (a bridge, the viaduct) passes over it untouched.
Cells that already carry roadway are skipped, which is why water is baked in a
second pass, after every road: a road built out over the water keeps its
drivable surface instead of being sealed off by the lake beneath it.
- **Landscaping / mountains** (`landscape`) and the **raised roadway with a
barrier down each side** (`road_c`) are drivable where they are flat but must
block where they rise, so they are baked as *both* - the surface baker keeps the
shallow faces, the solid baker records the steep ones as walls. Both need that
second half: the surface baker skips steep faces on purpose, so without it a car
drives straight through a mountainside and through the barriers on the elevated
road.

Three details make it work:

- **Fill, don't just outline** - but only for the big faces. A mountainside is
made of large triangles, so tracing their edges leaves the middle of the slope
open and the car drives into it. A road barrier is a thin wall, where the edge
trace *is* the wall; filling that one would spill onto the deck's neighbouring
cells and seal the road it guards. The fill also skips cells that already carry
roadway; the edge trace deliberately does not, because every `road_c` parapet
stands on roadway and would otherwise never be stamped at all.
- **Stamp at every height.** The solid baker normally ignores a wall whose lowest
vertex is above 2 m, the height it assumes a car can reach. That is wrong for
both of these: a mountain is a wall at 20 m, and the barriers on the elevated
road sit at ~4 m. Both are stamped regardless of height.

The one visible consequence: the elevated road's west ramp is now walled off at
its entrance. The car used to reach the deck there by driving *through* the
ramp's leading face, which the surface-only bake left non-solid. That route was
never a supported one - see the viaduct note below.

Baking the water, the mountains and the road barriers costs about 55 ms at load
and roughly 800 k obstacle cells; every runtime query is still a fixed-size
scan, and none of it adds work to the vehicle physics.

**Destructible roadside props.** Fences, street signs, benches, barrels, crates
and similar clutter stay solid until the *player* hits one above 50 km/h
(`IMPACT_SPEED_KMH`), then break free and become real rigid bodies. The
mechanics:

- **Only the player, only on a real hit.** Traffic never reports impacts, so AI
  cars still stop against these props. The trigger comes from the terrain
  sweep's blocked result - i.e. from contact that actually happened - and the
  speed gate is checked on top of that, so proximity alone does nothing. Below
  the threshold the prop behaves exactly as before.
- **A built-in integrator does the motion - not Havok, and no geometry baking.**
  Breaking a prop reparents its own mesh onto a reaction pivot: nothing is
  duplicated, hidden, replaced or rewritten, so the renderer keeps drawing the
  exact node it was drawing a frame earlier. The integrator then folds it and
  throws it with an impulse plus spin, applying gravity, friction and
  restitution as it goes. Havok was tried here first and had to be removed: a
  `PhysicsBody` built from baked geometry desynced from the prop's own transform
  on real machines, and the prop was gone from the screen the frame it was hit.
- **The prop is never hidden on impact.** The moment it is hit the mesh is
  forced visible (`isVisible`, `visibility`, `setEnabled`) and exempted from
  frustum culling (`alwaysSelectAsActiveMesh`) for the duration of the
  reaction, and culling is restored when it repairs. The instanced-mesh swap
  also refuses to dispose the original instance unless the replacement copy
  actually has vertices, so a failed swap can never delete the visible prop.
- **The throw tracks the hit.** Mass is derived from the prop's bounding volume
  (`density` 24 kg/m³, clamped 2.5-240 kg), and the launch speed is
  `carSpeed * speedFactor * sqrt(referenceMass / mass)`, clamped to 1.5-42 m/s.
  `speedFactor` is 1.0, so a reference-mass prop leaves at the speed it was hit
  and a light street sign leaves at close to twice that, while a heavy prop
  leaves at a fraction - all of them clearly carrying the impact away from the
  coordinates they were hit at. Both integrators reject a non-finite
  position/angle, so a single bad value cannot fling a prop to an invisible
  corner of the world.
- **Hinged props topple under gravity, from any direction.** Fences, gates,
  signs and poles rotate about a horizontal axis through their base under a
  torque proportional to `sin(angle)` - the inverted-pendulum term - so once the
  hit tips one off vertical it accelerates over and goes flat instead of
  springing back to a fixed lean. Because the torque comes from gravity rather
  than a scripted target, a prop hit from the side, head-on or from behind all
  end up on the ground; only the direction it falls changes. The impact's own
  speed scales how fast it tips (`tipScale`), so the fall reads as force.
- **Loose props fall onto a face instead of freezing mid-tumble.** A prop that
  pivots about its own centre gets no torque from gravity, so it used to stop
  dead in whatever pose its spin died in - a pole left leaning at 60 degrees.
  `_restOnFace` now steers the prop's shortest axis back to vertical (the pose
  with the largest face on the ground) once the tumble slows, and only then does
  it count as settled. Hinged props get the matching guarantee from the other
  side: past a few degrees a minimum angular speed means damping can never leave
  one standing at an angle.
- **The integrator rests props on the road.** `_keepAboveGround` samples the
  same baked collision the wheels use, then clamps the prop so the lowest point
  of its *actual geometry* (world AABB computed from the mesh's own vertices and
  world matrix) sits on that surface. Clamping the pivot by a half-height is what
  let a folded fence, a sign lying flat or a tumbling crate sink into the road;
  measuring the real lowest vertex cannot. Flexible props (fences, gates)
  additionally get a progressive geometry bend where they were struck.
- **Thrown props collide with the world.** Horizontal motion is swept against
  the same obstacle grid the car uses (`blockedRect`), so a sign knocked toward a
  building, kerb or another intact prop bounces/slides off it instead of passing
  through. A blocked move is refused and the velocity reflected and damped; when
  only one axis is clear, the prop slides along the wall like the car does.
- **The bake is what makes it cheap.** At load, `MapCollision` records the
  obstacle cells each prop owns (`groupKey`). Destroying one calls
  `clearGroup`, and a cell is only released when the prop was its sole author,
  so a sign smashed next to a building can never open a hole in the building.
  Adding a family is one line in `DESTRUCTIBLE_FAMILIES`; nothing else is
  touched, and no other mesh pays for the bookkeeping.

The props **repair themselves** once they are off the player's screen. The
gate is the camera: `camera.isInFrustum(mesh)` must be false, there is a short
grace period after the hit (`repairMinAge` 1.2 s) and a minimum distance
(`repairMinDistance` 14 m) so a prop beside or just behind the car never pops
back in view. With no camera to test against it falls back to plain distance
(`respawnDistance` 45 m). Repair restores the mesh to its exact original
transform, undoes any geometry change from a saved copy, drops the reaction
pivot, and calls `restoreGroup` to refill the collision cells it released. As
in circuit racers the reset always happens out of view, and the debris budget
(`maxDebris`, 60) recycles the oldest prop rather than deleting it.

**Signs are measured, not derived.** The imported hierarchy contains a mirrored
scale (`__root__` has `absScale (1, -1, 1)`), so left-handed Babylon plus the
right-to-left glTF conversion means you cannot reliably reason out which way a
rotation goes. Steering direction, wheel-roll direction and body-lean axes are
therefore all calibrated at load time by moving a pivot a known amount and
measuring the result. The measured values are in the diagnostics below.

**Traffic.** Traffic drives; it is not on rails. Lanes are built at runtime in
`src/game/laneBuilder.js` from the road cells of the baked collision mask
(the same triangles the player collides with), so the lanes are always in sync
with the map that is actually loaded rather than with a checked-in data file.
Each ring is filleted into real corners, densified to 1 m so a lane can never
have a gap long enough to hide a car, and validated against the collision grid.

A lane is only accepted where the car fits *with room to spare*. A lane whose
centre line merely clears the kerb is not good enough, because a car tracks a
lane rather than sitting on it and runs a metre or so wide through a bend, where
it scrapes the roadside props, wedges, and stops. Each loop is therefore tried
against a ladder of clearances (2.2 m, then 1.7 m, then 1.2 m) and takes the
widest one it can manage; routes are ranked by the clearance they achieved, so
narrow streets are only used when there is nothing better. Loops that cannot
clear even the loosest margin are dropped, and anything that cannot be driven
at all is discarded.

Vehicles then track the lane by pure pursuit, with motion swept against the
map every frame and sliding along walls, exactly as the player does. Height,
pitch, roll and suspension come from their own wheel contacts, so they ride the
surface rather than being placed on it. Speed eases down for corners and for
obstacles ahead, and a car that genuinely boxes itself in is re-seeded onto its
own lane rather than left to occupy the road.

Some generated loops are nested and share roads. Running traffic on all of them
would place two cars in the same lane, so only a low-overlap subset is used.

**Small props do not block traffic.** The kerb furniture - fences, gates, street
signs, benches, barrels - is solid to the player but ignored by traffic. It
stands at the roadside by the dozen, and treating it as a wall pinched most lanes
shut and stranded cars against scenery. `MapCollision` marks those cells in a
separate `softObstacle` mask, and a vehicle opts out of it via
`TerrainFollower({ ignoreSoftProps: true })`. Softness is decided by the first
mesh to claim a cell and *revoked* by the first hard mesh to claim it, so a
fence panel sharing a cell with the wall behind it does not open a hole through
a building. The oversized street signs that are meant to stop a car are excluded
from the soft set and still stop one.

**Distance LOD.** The fleet keeps a spatial hash (12 m cells) and updates each
car by tier: full simulation under 70 m, a coarse lane-following pass out to
160 m, heading-only updates out to 300 m, and nothing at all beyond that. Far
cars resume exactly where they were frozen, since distance along the lane is
preserved. The car-ahead query also goes through the hash, which drops the
per-frame neighbour scan from O(n²) to a handful of candidates.

**The elevated roadway is not used by traffic.** The map's high structure is a
viaduct, not a bridge: it holds a near-constant 6.0-6.3 m from one end of the
map to the other and the ground simply stops at both ends instead of sloping
down to street level. There is no point on it a car could drive onto from a
road, so no closed route can use it and the lane search correctly reports no
bridge route. The deck itself is wide, flat and clear, so a route placed on it
would drive perfectly - it just cannot be entered from below.

## Self-tests

Append `?debug=1` to the URL and the game publishes a report into `#debug-out`
after a few frames: wheel pivot accuracy, calibration results, wheelbase and
wheel radius, and per-vehicle on-road checks.

```bash
node tools/browser-probe.mjs --url="http://localhost:5173/?debug=1&frames=6" \
  --expr-file=tools/summary-expr.js
```

`tools/browser-probe.mjs` drives headless Chrome over the DevTools protocol. It
exists because `chrome --dump-dom` dumps at the load event, which fires long
before a 20 MB glTF finishes loading, and because it relays console errors.
Note the `--name=value` form: a bare `--name value` is silently ignored.

## Seeing where collision happens

Append `?hits=1` to mark every collision contact in the world. This is
instrumentation for answering one question by eye: *is the car being stopped by
something it can see, or by empty space?*

```
http://localhost:5173/?hits=1
```

Markers are colour-coded by how the block was decided:

| Colour | Meaning |
| --- | --- |
| green | blocked by a real triangle of a solid mesh — expected |
| red | blocked only by that mesh's **bounding box** — the mesh is not here |
| blue | an unclimbable step, from the height field rather than a solid |

Fresh contacts are large and solid and fade as they age, so "what is touching
me now" reads separately from "where has this happened". Red wireframe boxes
are drawn around the meshes responsible for box-only blocks, and a panel in the
corner tallies hits by cause. `?hits=1` turns on provenance tracking in the
bake, which costs about 3 bytes per 0.5 m cell, so it is off for normal play.

The distinction matters because the bake takes two shortcuts that can both
produce a cell with no geometry on it: a mesh under 25 m² with no side over 8 m
is baked as its world AABB, so a rotated mesh gets a rectangular footprint
bigger than itself; and large meshes contribute only their steep wall triangles,
so roofs and floors are not solid and a car passes under an overhang.

Three probes read the overlay:

```bash
# what is being hit, and by what
node tools/browser-probe.mjs --url="http://localhost:5173/?debug=1&frames=8&hits=1" \
  --expr-file=tools/hits-test-expr.js

# how far each contact is from the real geometry of the mesh that caused it
node tools/browser-probe.mjs --url="http://localhost:5173/?debug=1&frames=8&hits=1" \
  --expr-file=tools/hits-analyse-expr.js

# the same check over the whole collision grid, not just observed contacts
node tools/browser-probe.mjs --url="http://localhost:5173/?debug=1&frames=8&hits=1" \
  --expr-file=tools/hits-grid-expr.js
```

`--shot=<file.png>` saves a screenshot, which is useful for parking the camera
on one contact and inspecting it.

Other helpers:

```bash
node tools/analyze-car.mjs public/assets/car1.glb  # measure wheels, bounds
node tools/analyze-map.mjs public/assets/map.glb   # name families, road layout
node tools/road-ascii.mjs public/assets/map.glb 8  # print the road grid as ASCII
```

`tools/physics-test-expr.js` steps the vehicle model at a fixed timestep and
checks turning, braking, reverse, top speed and wheel behaviour independently of
the render frame rate (with map collision detached, so it measures the car and
not the map).

`tools/terrain-test-expr.js` exercises the collision model instead: it reports
what got baked, drives the west ramp up onto the elevated bridge, confirms a
building blocks the car, and measures how far it gets along a real lane before
touching anything.

```bash
node tools/browser-probe.mjs --url "http://localhost:5173/?debug=1&frames=6" \
  --expr-file=tools/terrain-test-expr.js
```

## Known limitations / tuning

- **Player <-> traffic collisions are rigid-body.** When the player's swept
  motion overlaps a traffic vehicle's oriented rectangle, an impulse is
  applied to the traffic vehicle (linear velocity + a spin proportional to
  how off-centre the hit was), the player is bounced back along the contact
  normal, and the player's speed is reduced by a mass-share ratio. The
  shoved AI car is paused while the impulse decays (capped so nothing flies
  off), and the AI resumes cleanly once it has slowed enough. Off-screen,
  any wedged / spun / out-of-bounds AI car snaps back onto its lane.
- **13 traffic models ship.** The catalogue in `public/assets/vehicles/`
  covers `mini-car`, `mini-car2`, `muscle-car`, `muscle-car2`,
  `muscle-car3`, `suv`, `minivan`, `minivan2`, `pickup`, `pickup2`,
  `ambulance-truck`, `iceCream-truck`, `post-truck`. Add another `.glb`
  there and add an entry to `VEHICLE_CATALOG` in `src/game/VehicleAssets.js`
  to extend the mix.
- **Traffic model facing is measured from wheels.** Each model has 4 (SUV:
  6) wheel meshes named `<BodyName>_TireFL/FR/BL/BR`. `TrafficRig` measures
  the front-vs-rear axle midpoint to derive the model's forward, applies a
  yaw fix so forward reads as +Z, and scales the model to the
  `targetLength` set in `VEHICLE_CATALOG`. If a model drives backwards in
  game, the wheel naming convention is wrong - fix it in the `.glb`.
- **Traffic follows lanes plus avoids obstacles.** Traffic uses
  pure-pursuit steering with a short look-ahead (so it does not cut corners),
  scans ahead for other traffic and the player car, and slows to maintain a
  safe following distance. If a lane is fully blocked the AI stops and
  waits; if it cannot free itself after a few attempts it is re-seeded onto
  the lane.
- **Side objects do not block traffic.** Street signs, fences, barrels and
  the rest of the destructible families are solid to the player (who smashes
  through them at speed) but ignored by traffic, so a misplaced kerb-side
  prop cannot strand an AI car. Walls, buildings and other non-destructible
  obstacles still block traffic - this only relaxes the small roadside
  clutter.
- **Race rivals hit props like the player, but pay nothing for it.** A sign is
  solid to a rival's sweep exactly as it is to the player's, so a prop in the
  racing line is a real hit - the same block, the same break, via the same
  hook. Two things differ: the gate is `AI_IMPACT_SPEED_KMH` (well below the
  player's 50 km/h, because a racer clipping the kerb at racing pace is not
  "crashing"), and the racer applies none of the cost - the player loses half
  their speed ploughing through a sign, a rival re-sweeps the same motion
  through the gap the break left and carries on at the speed it arrived with.
  Clutter is looked past in exactly two places: the pass-probe (`_sideClear`),
  so the AI never *chooses* a line through a sign, and the fallback after a
  block that broke nothing - a prop whose baked cells sit clear of its own mesh
  (the loose-AABB cases above) is passed through rather than allowed to wedge
  the car. Both are the traffic rule, kept as a backstop; every genuine hit
  still breaks.
- **Racer <-> racer contact transfers momentum, not a shove.** Arcade rules:
  the struck car is nudged and driven forward along its own heading by its
  share of the CLOSING speed, so a rear-end shunts the car in front down the
  road and both keep racing. Two cars at the same pace are leaning on each
  other rather than colliding, so they trade paint and lose nothing - the old
  full-figure impulse scrubbed ~9% of the speed on every contact frame and
  welded a queue of rivals to the spot. A hit is never allowed to drive a car
  backwards against the way it is going, and the player's own reaction is
  capped on both axes (the yaw kick hardest) so a pack leaning on the player
  knocks the line about without taking the wheel: sustained contact costs the
  player no speed at all, only a fresh hit does, and that one is bounded by
  the closing speed.
- **Checkpoints keep off the bridge, and the arch you can see is the gate you
  must pass.** The deck is a different surface from the road it crosses, and
  the node the circuit's path is built from at the span is the whole bridge
  structure's centre - roughly 19 m above its carriageway - so a gate placed
  there found no ground within reach, fell back to that node height and hung in
  the air above the deck it was supposed to span. Gate placement now rejects
  bridge cells (the centre and both legs) alongside corners and junctions, so a
  checkpoint is walked ahead of the span or before it, onto the road either
  side. The crossing test also uses the span the arch is DRAWN at - every arch
  is one repeated structure built at the widest road on the circuit, not each
  gate's own measured width - plus a car's body half-width, so threading a
  checkpoint at its very edge registers instead of driving through a gate you
  can see and being told you missed it.
- **No traffic on the viaduct.** The elevated roadway has no drivable
  connection to the street network, so no closed route can use it. See above.
- **Collision is a bake, not a rigid-body sim.** ~50 k surface triangles and a
  triangle walk over the large solid meshes are reduced to two grids in a few
  hundred milliseconds at load; every runtime query is then a handful of array
  reads. Water and mountains are the two places where a rigid-body world would
  "just work" and this model has to special-case them - see above. The trade-off is that a single height per cell means overhangs and
  undersides are approximated rather than modelled exactly. Small meshes are
  baked as bounding boxes, and about 5% of those cells sit more than half a cell
  from the mesh itself — visible as red markers under `?hits=1`, worst on
  barrels, crates and café shells whose boxes are looser than their shapes.
- **Map weight.** 3150 meshes and ~13 M vertices. Static meshes are
  world-matrix-frozen and picking is disabled, but if the frame rate suffers the
  next step is merging the map meshes (they share a single material).
- **Handling is deliberately grip-limited** (`CAR.maxLateralAccel = 9.5` m/s²,
  ~1 g). Lower it for a heavier feel, raise it for arcade slide. Other handling
  values live in `src/game/driving.js`.
