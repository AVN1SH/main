import { defineConfig } from "vite";

// Relative asset base so the production build works from ANY serving path:
// - `npm run preview` (serves dist/ at root), and
// - a static server on the workspace root opening /dist/index.html
//   (e.g. VS Code Live Server).
// With Vite's default base '/' every JS/CSS URL is absolute (/assets/...),
// which 404s under a subpath and leaves a raw unstyled page that never boots.
export default defineConfig({
  base: "./",
});
