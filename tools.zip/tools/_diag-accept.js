// Acceptance checks for the destructible roadside props, run against the real
// game loop rather than the reaction in isolation:
//
//   1. the prop is NEVER hidden, disabled or removed while it reacts
//   2. the reaction is spread over many frames, not applied instantly
//   3. the player only breaks props above IMPACT_SPEED_KMH
//   4. below that speed the prop keeps its normal collision behaviour
//   5. AI cars never break props, at any speed, and are still stopped by them
//   6. the reaction finishes before the prop is recycled
(() => {
  const g = window.game;
  const d = g.destruction;
  const player = g.player;
  const results = [];
  const check = (name, pass, detail) => results.push({ name, pass, detail });

  const water = g.scene.meshes
    .filter((m) => /^water/i.test(m.name ?? ""))
    .map((m) => m.getBoundingInfo().boundingBox);
  const inWater = (x, z) =>
    water.some(
      (b) => x > b.minimumWorld.x && x < b.maximumWorld.x && z > b.minimumWorld.z && z < b.maximumWorld.z,
    );

  // A prop the player's own sweep genuinely blocks, reachable along dry road.
  const findRunUp = (familyId) => {
    for (const o of d.objects) {
      if (!o.alive || o.family.id !== familyId) continue;
      for (let ai = 0; ai < 24; ai++) {
        const h = (ai / 24) * Math.PI * 2;
        const fx = Math.sin(h);
        const fz = Math.cos(h);
        for (const dist of [14, 10, 18]) {
          const px = o.center.x - fx * dist;
          const pz = o.center.z - fz * dist;
          let ok = true;
          for (let s = 0; s <= dist && ok; s += 1) ok = !inWater(px + fx * s, pz + fz * s);
          if (!ok) continue;
          if (player.terrain.sweep(px - fx, pz - fz, px, pz, h).blocked) continue;
          if (!player.terrain.sweep(px, pz, px + fx * 6, pz + fz * 6, h).blocked) continue;
          return { o, h, px, pz, dist };
        }
      }
    }
    return null;
  };

  const wait = (n) =>
    new Promise((res) => {
      let i = 0;
      const ob = g.scene.onAfterRenderObservable.add(() => {
        if (++i >= n) {
          g.scene.onAfterRenderObservable.remove(ob);
          res();
        }
      });
    });

  const infoFor = (o, speedMps) => {
    const gg = player.terrain?.g ?? { halfLength: 2, halfWidth: 1 };
    return {
      x: o.center.x,
      z: o.center.z,
      prevX: o.center.x,
      prevZ: o.center.z,
      y: o.box.minY - 0.4,
      heading: 0,
      speed: speedMps,
      clearance: 0,
      height: o.box.maxY - o.box.minY + 3,
      halfLength: gg.halfLength ?? 2,
      halfWidth: gg.halfWidth ?? 1,
    };
  };

  const run = (familyId, speedMps, frames, sample) => {
    const pick = findRunUp(familyId);
    if (!pick) return Promise.resolve(null);
    const o = pick.o;
    const mesh = o.mesh;
    const verts = mesh.getTotalVertices();
    const inSceneBefore = g.scene.meshes.indexOf(mesh) >= 0;
    const trace = [];
    let broke = false;
    // The player stays out of the way; the sweep result is fed in directly, the
    // same information PlayerVehicle passes to handleImpact.
    let fed = false;
    g.scene.onBeforeRenderObservable.add(() => {
      if (fed) return;
      fed = true;
      broke = d.handleImpact(infoFor(o, speedMps));
    });
    if (sample) {
      g.scene.onBeforeRenderObservable.add(() => {
        mesh.computeWorldMatrix(true);
        const w = mesh.getAbsolutePosition();
        const q = mesh.rotationQuaternion;
        trace.push({
          vis: mesh.isVisible,
          en: mesh.isEnabled(),
          scene: g.scene.meshes.indexOf(mesh) >= 0,
          verts: mesh.getTotalVertices(),
          moved: +Math.hypot(w.x - o.center.x, w.z - o.center.z).toFixed(2),
          y: +w.y.toFixed(2),
          tilt: q ? +(2 * Math.acos(Math.min(1, Math.abs(q.w))) * 57.2958).toFixed(1) : 0,
          alive: o.alive,
        });
      });
    }
    return wait(frames).then(() => ({
      broke,
      trace,
      verts,
      inSceneBefore,
      alive: o.alive,
      restored: d.stats.restored,
      family: o.family.id,
      behavior: o.family.behavior,
      obj: o,
    }));
  };

  return (async () => {
    const stage = [];
    try {
      // ---- 3/4: the speed gate -----------------------------------------
      const slow = await run("fence", 40 / 3.6, 10, false); // under the gate
      stage.push("slow");
      check(
        "under 50 km/h nothing breaks",
        !!slow && slow.broke === false && slow.alive === true,
        `broke=${slow?.broke} stillSolid=${slow?.alive}`,
      );

      const fast = await run("fence", 80 / 3.6, 4, false); // over the gate
      stage.push("fast");
      check(
        "over 50 km/h the player breaks it",
        !!fast && fast.broke === true && fast.alive === false,
        `broke=${fast?.broke} broken=${!!fast && !fast.alive}`,
      );
      // leave the town as we found it
      if (fast?.obj) d._restore(fast.obj);
      stage.push("restored");

    // ---- 5: AI cars ------------------------------------------------------
    const aiHaveHook = g.traffic.vehicles.filter((v) => v.onImpact != null).length;
    const d0 = d.stats.destroyed;
    stage.push("ai-hook");
    const v = g.traffic.vehicles[0];
    if (v) {
      // Park an AI car on a run-up into a surviving fence at well over the gate
      // and hold it there, so the only thing that can break the prop is the AI.
      const pick = findRunUp("fence");
      stage.push("ai-pick");
      if (pick) {
        const y = g.collision.groundAt(pick.px, pick.pz, 6, { stepUp: 3, reach: 6 })?.y ?? 0;
        const hold = g.scene.onBeforeRenderObservable.add(() => {
          v.state.x = pick.px;
          v.state.y = y;
          v.state.z = pick.pz;
          v.state.heading = pick.h;
          v.state.speed = 22;
        });
        await wait(20);
        g.scene.onBeforeRenderObservable.remove(hold);
        stage.push("ai-ran");
        check(
          "AI car at 79 km/h does not break a fence",
          pick.o.alive && d.stats.destroyed === d0,
          `propIntact=${pick.o.alive} destroyedDelta=${d.stats.destroyed - d0}`,
        );
      } else {
        check("AI car at 79 km/h does not break a fence", false, "no run-up found");
      }
    }
    check("no AI car carries an impact hook", aiHaveHook === 0, `hooks=${aiHaveHook}`);

    // ---- 1/2/6: the reaction itself -------------------------------------
    const r = await run("sign", 80 / 3.6, 34, true);
    stage.push("reaction");
    if (!r) return JSON.stringify({ stage, results, error: "no reaction run-up" }, null, 1);
    const hidden = r.trace.filter((s) => !s.vis || !s.en || !s.scene).length;
    const vertsChanged = r.trace.filter((s) => s.verts !== r.verts).length;
    const moving = new Set(r.trace.map((s) => s.moved)).size;
    const maxTilt = Math.max(...r.trace.map((s) => s.tilt));
    const maxMoved = Math.max(...r.trace.map((s) => s.moved));
    const brokenFrames = r.trace.filter((s) => !s.alive).length;

    check("prop is never hidden, disabled or removed", hidden === 0, `badFrames=${hidden}/${r.trace.length}`);
    check("prop geometry is never swapped out", vertsChanged === 0 && r.verts > 0, `verts=${r.verts} changed=${vertsChanged}`);
    check("reaction spans many frames", brokenFrames >= 8, `brokenFrames=${brokenFrames}`);
    check("prop visibly moves", maxMoved > 2, `maxMoved=${maxMoved}m over ${moving} distinct positions`);
    check("prop visibly rotates", maxTilt > 45, `maxTilt=${maxTilt}deg`);
    stage.push("done");

    return JSON.stringify({ stage, results }, null, 1);
    } catch (e) {
      return JSON.stringify({ stage, results, error: String(e?.stack ?? e) }, null, 1);
    }
  })();
})();
