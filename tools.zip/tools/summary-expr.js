(() => {
  const d = JSON.parse(document.getElementById("debug-out").textContent);
  const lines = [`${d.passed} passed / ${d.failed} failed`, ""];
  for (const r of d.results) {
    lines.push(`${r.pass ? "PASS" : "FAIL"}  ${r.name} :: ${r.detail}`);
  }
  lines.push("");
  lines.push(`steer/spin calibration: ${JSON.stringify(d.rig.calibration)}`);
  lines.push(`body tilt calibration : ${JSON.stringify(d.rig.tilt)}`);
  lines.push(`wheelbase ${d.rig.wheelBase} m, wheel radius ${d.rig.wheelRadius} m`);
  lines.push(`map: ${JSON.stringify(d.map)}`);
  lines.push(`routes considered -> used: ${d.traffic.length} plan entries`);
  lines.push(`errors: ${JSON.stringify(d.errors)}`);
  return lines.join("\n");
})();
