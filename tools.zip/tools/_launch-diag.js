(async () => {
  const g = window.game, race = g.race;
  race.debugForceStart();
  race.debugStep(4.0);
  const out = [];
  const snap = (t) => out.push({ t, r: race.rivals.map(r => { const d = r.debugInfo();
    return [r.name.slice(0,4), d.speed, d.total, d.grace, d.stuck, d.net, d.win, r.stats.recoveries, r.stats.reseats, r.stats.impacts]; }) });
  snap(0);
  for (let i = 0; i < 14; i++) { race.debugStep(1.0); snap(i+1); }
  return { out };
})();
