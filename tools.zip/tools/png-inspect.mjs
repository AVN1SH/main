// Minimal PNG reader + pixel inspector.
//
// The model cannot view images, so screenshots are verified by MEASURING them
// instead: decode the pixels and report what colours are actually on screen.
// Supports 8-bit greyscale / RGB / RGBA / palette, non-interlaced, which is
// what Chrome's screenshot path produces.
import { readFileSync } from "node:fs";
import { inflateSync } from "node:zlib";

const paeth = (a, b, c) => {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
};

export function decodePng(path) {
  const buf = readFileSync(path);
  if (buf.slice(0, 8).toString("hex") !== "89504e470d0a1a0a") throw new Error("not a PNG");
  let off = 8;
  let width = 0;
  let height = 0;
  let depth = 0;
  let colorType = 0;
  const idat = [];
  let palette = null;
  let trns = null;

  while (off < buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.slice(off + 4, off + 8).toString("ascii");
    const data = buf.slice(off + 8, off + 8 + len);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      depth = data[8];
      colorType = data[9];
      if (data[12] !== 0) throw new Error("interlaced PNG not supported");
    } else if (type === "PLTE") palette = data;
    else if (type === "tRNS") trns = data;
    else if (type === "IDAT") idat.push(data);
    else if (type === "IEND") break;
    off += 12 + len;
  }
  if (depth !== 8) throw new Error(`unsupported bit depth ${depth}`);

  const channels = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[colorType];
  if (!channels) throw new Error(`unsupported colour type ${colorType}`);
  const bpp = channels;
  const raw = inflateSync(Buffer.concat(idat));
  const stride = width * bpp;
  const out = Buffer.alloc(height * stride);

  let pos = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[pos++];
    const line = raw.subarray(pos, pos + stride);
    pos += stride;
    const cur = out.subarray(y * stride, (y + 1) * stride);
    const prev = y > 0 ? out.subarray((y - 1) * stride, y * stride) : null;
    for (let i = 0; i < stride; i++) {
      const a = i >= bpp ? cur[i - bpp] : 0;
      const b = prev ? prev[i] : 0;
      const c = prev && i >= bpp ? prev[i - bpp] : 0;
      let v = line[i];
      if (filter === 1) v += a;
      else if (filter === 2) v += b;
      else if (filter === 3) v += (a + b) >> 1;
      else if (filter === 4) v += paeth(a, b, c);
      cur[i] = v & 0xff;
    }
  }

  // Normalise to RGB triplets.
  const rgb = new Uint8Array(width * height * 3);
  for (let i = 0; i < width * height; i++) {
    let r;
    let g;
    let b;
    if (colorType === 3) {
      const p = out[i] * 3;
      r = palette[p];
      g = palette[p + 1];
      b = palette[p + 2];
    } else if (colorType === 0 || colorType === 4) {
      r = g = b = out[i * bpp];
    } else {
      r = out[i * bpp];
      g = out[i * bpp + 1];
      b = out[i * bpp + 2];
    }
    rgb[i * 3] = r;
    rgb[i * 3 + 1] = g;
    rgb[i * 3 + 2] = b;
  }
  return { width, height, rgb, colourType: colorType };
}

export const pixelAt = (img, x, y) => {
  const i = (y * img.width + x) * 3;
  return [img.rgb[i], img.rgb[i + 1], img.rgb[i + 2]];
};

/**
 * Counts pixels matching a predicate and groups them into blobs, so a few
 * scattered hits can be told apart from one solid mass.
 */
export function findBlobs(img, pred, { minPixels = 3 } = {}) {
  const { width, height, rgb } = img;
  const seen = new Uint8Array(width * height);
  const blobs = [];
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      if (seen[idx]) continue;
      const r = rgb[idx * 3];
      const g = rgb[idx * 3 + 1];
      const b = rgb[idx * 3 + 2];
      if (!pred(r, g, b)) continue;
      // flood fill
      let n = 0;
      let minX = x;
      let maxX = x;
      let minY = y;
      let maxY = y;
      let sr = 0;
      let sg = 0;
      let sb = 0;
      const stack = [idx];
      seen[idx] = 1;
      while (stack.length) {
        const p = stack.pop();
        const py = Math.floor(p / width);
        const px = p % width;
        n++;
        sr += rgb[p * 3];
        sg += rgb[p * 3 + 1];
        sb += rgb[p * 3 + 2];
        if (px < minX) minX = px;
        if (px > maxX) maxX = px;
        if (py < minY) minY = py;
        if (py > maxY) maxY = py;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = px + dx;
          const ny = py + dy;
          if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
          const q = ny * width + nx;
          if (seen[q]) continue;
          const qr = rgb[q * 3];
          const qg = rgb[q * 3 + 1];
          const qb = rgb[q * 3 + 2];
          if (!pred(qr, qg, qb)) continue;
          seen[q] = 1;
          stack.push(q);
        }
      }
      if (n >= minPixels) {
        blobs.push({ x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1, pixels: n, rgb: [sr / n, sg / n, sb / n] });
      }
    }
  }
  return blobs.sort((a, b) => b.pixels - a.pixels);
}
