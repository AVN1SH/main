// Hunt NaN/Inf in the traffic sim and trace whichever car misbehaves worst.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision: c } = g;
  const dt = 1 / 60;
  const bad = (v) =>
    !Number.isFinite(v.state.x) ||
    !Number.isFinite(v.state.y) ||
    !Number.isFinite(v.state.z) ||
    !Number.isFinite(v.state.heading) ||
    !Number.isFinite(v.state.speed) ||
    !Number.isFinite(v.terrain.y) ||
    !Number.isFinite(v.distance);

  const nanFrame = traffic.vehicles.map((v, i) => (bad(v) ? i : -1)).filter((i) => i >= 0);
  const out = { nanAtSpawn: nanFrame, firstNanFrame: null, nanCar: null, trace: [] };

  let worstIdx = 0;
  let worstMove = Infinity;
  const start = traffic.vehicles.map((v) => ({ x: v.state.x, z: v.state.z, moved: 0 }));
  let nanAt = -1;
  let nanIdx = -1;

  for (let f = 0; f < 3600; f++) {
    traffic.update(dt);
    for (let i = 0; i < traffic.vehicles.length; i++) {
      const v = traffic.vehicles[i];
      const s = start[i];
      s.moved += Math.hypot(v.state.x - s.x, v.state.z - s.z);
      s.x = v.state.x;
      s.z = v.state.z;
      if (nanAt < 0 && bad(v)) {
        nanAt = f;
        nanIdx = i;
        out.nanCar = {
          i,
          state: {
            x: v.state.x,
            y: v.state.y,
            z: v.state.z,
            heading: v.state.heading,
            speed: v.state.speed,
          },
          distance: v.distance,
          steer: v.steerAngle,
          terrainY: v.terrain.y,
          terrainVy: v.terrain.vy,
          pitch: v.terrain.pitch,
          roll: v.terrain.roll,
          cornerLimit: (() => {
            try {
              return v._cornerSpeedLimit();
            } catch (e) {
              return "throw:" + e.message;
            }
          })(),
        };
      }
    }
    if (f % 120 === 0) {
      const v = traffic.vehicles[worstIdx];
      out.trace.push(
        `t=${(f / 60).toFixed(0)}s car${worstIdx} p=(${num(v.state.x)},${num(v.state.z)}) v=${num(
          v.state.speed,
        )} y=${num(v.terrain.y)} road=${c.isRoadAt(v.state.x, v.state.z) ? 1 : 0} blocked=${
          v.terrain.blocked(v.state.x, v.state.z, v.state.heading) ? 1 : 0
        }`,
      );
    }
  }
  function num(n) {
    return Number.isFinite(n) ? n.toFixed(1) : String(n);
  }

  for (let i = 0; i < traffic.vehicles.length; i++) {
    if (start[i].moved < worstMove) {
      worstMove = start[i].moved;
      worstIdx = i;
    }
  }
  out.firstNanFrame = nanAt;
  out.worstCar = worstIdx;
  out.worstMoved = +worstMove.toFixed(1);
  out.movedAll = start.map((s, i) => `#${i}:${s.moved.toFixed(0)}`).join(" ");

  return JSON.stringify(out, null, 1);
})();
