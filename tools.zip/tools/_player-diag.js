(async () => {
  const g = window.game, race = g.race, t = race.track;
  const off = location.search.includes('notraffic');
  if (off) { race.traffic = null; if (g.traffic) g.traffic.vehicles.length = 0; }
  race.debugForceStart();
  race.debugStep(4.0);
  const out = [];
  for (let i = 0; i < 24; i++) {
    race.debugStep(1.0);
    const s = g.player.state;
    const pd = race.playerProgress.distance;
    const p = t.path.sample(pd);
    out.push({ t: i+1, x:+s.x.toFixed(1), z:+s.z.toFixed(1), hd:+((s.heading*180/Math.PI)).toFixed(0),
      spd:+s.speed.toFixed(1), pd:+pd.toFixed(0), off:+Math.hypot(p.x-s.x,p.z-s.z).toFixed(1), col: g.player.collided?1:0 });
  }
  return { off, out };
})();
