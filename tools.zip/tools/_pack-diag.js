(async () => {
  const g = window.game, race = g.race, t = race.track;
  race.debugForceStart();
  race.debugStep(4.0);
  g.player.state.x = t.startPose.x + 1400; g.player.state.z = t.startPose.z + 1400; g.player.state.speed = 0;
  g.player.state.heading = 0;
  const out = [];
  const snap = (tt) => out.push({ t: tt, r: race.rivals.map(r => { const d = r.debugInfo();
    return [r.name.slice(0,4), +d.total.toFixed(0), d.speed, d.target, d.blocker?d.blocker.name+'@'+d.blocker.gap:'-', r.stats.recoveries, r.stats.reseats, r.stats.impacts]; }) });
  snap(0);
  for (let i = 0; i < 14; i++) { race.debugStep(1.0, 1/60, { autopilot:false }); snap(i+1); }
  return { out };
})();
