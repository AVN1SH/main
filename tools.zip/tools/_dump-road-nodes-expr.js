(() => {
  const s = window.game && window.game.scene;
  if (!s) return "ERR_NO_SCENE";
  const out = {};
  let n = 0;
  for (const m of s.meshes) {
    if (!m || !/^(road_|bridge_)/i.test(m.name || "")) continue;
    try {
      m.computeWorldMatrix(true);
      const bb = m.getBoundingInfo().boundingBox;
      const c = bb.centerWorld;
      const e = bb.extendSizeWorld;
      out[m.name] = {
        x: +c.x.toFixed(2), y: +c.y.toFixed(2), z: +c.z.toFixed(2),
        sx: +(e.x * 2).toFixed(2), sz: +(e.z * 2).toFixed(2),
      };
      n++;
    } catch (e) { /* skip */ }
  }
  // Spot-check landmarks: gas stations should sit near known in-game coords.
  const gas = {};
  for (const m of s.meshes) {
    if (/^gasstation_/i.test(m.name || "")) {
      const p = m.getAbsolutePosition();
      gas[m.name] = { x: +p.x.toFixed(1), z: +p.z.toFixed(1) };
    }
  }
  return JSON.stringify({ count: n, gas, nodes: out });
})()
