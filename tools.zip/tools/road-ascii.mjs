// Rasterizes the road meshes into an ASCII occupancy map so traffic routes
// can be designed against the real geometry instead of guessed coordinates.
// Usage: node tools/road-ascii.mjs <map.glb> [cellSize] [maxY] [filterRegex]
import { loadGlb, meshBounds, worldMatrix, transformPoint, r3, round } from "./glb.mjs";

const file = process.argv[2] ?? "public/assets/map.glb";
const cell = Number(process.argv[3] ?? 4);
const maxY = Number(process.argv[4] ?? 1.0);
const filter = new RegExp(process.argv[5] ?? "road", "i");

const { g, nodes, parents } = loadGlb(file);
const cache = new Map();

console.log(`cell=${cell}u  maxY=${maxY}  filter=/${filter.source}/i`);

// --- collect road pieces, expand each into world cells ---
const pieces = [];
nodes.forEach((node, i) => {
  if (!node.name || !filter.test(node.name)) return;
  const b = meshBounds(g, i);
  if (!b) return;
  const wm = worldMatrix(nodes, parents, i, cache);
  const center = transformPoint(wm, [
    (b.min[0] + b.max[0]) / 2,
    (b.min[1] + b.max[1]) / 2,
    (b.min[2] + b.max[2]) / 2,
  ]);
  if (center[1] > maxY) return;
  pieces.push({ name: node.name, wm, min: b.min, max: b.max, center });
});

console.log(`pieces: ${pieces.length}`);

/** world point -> mesh-local point (assumes TRS, no shear) */
function toLocal(wm, p) {
  const t = [wm[12], wm[13], wm[14]];
  const out = [0, 0, 0];
  for (let a = 0; a < 3; a++) {
    const basis = [wm[a * 4], wm[a * 4 + 1], wm[a * 4 + 2]];
    const s = Math.hypot(basis[0], basis[1], basis[2]) || 1;
    let d = 0;
    for (let k = 0; k < 3; k++) d += (p[k] - t[k]) * (basis[k] / s);
    out[a] = d / s;
  }
  return out;
}

// bounds of ground-level road surface
const lo = [Infinity, Infinity, Infinity];
const hi = [-Infinity, -Infinity, -Infinity];
for (const p of pieces) {
  const corners = [];
  for (let i = 0; i < 8; i++) {
    corners.push([
      i & 1 ? p.max[0] : p.min[0],
      i & 2 ? p.max[1] : p.min[1],
      i & 4 ? p.max[2] : p.min[2],
    ]);
  }
  for (const c of corners) {
    const w = transformPoint(p.wm, c);
    for (let a = 0; a < 3; a++) {
      lo[a] = Math.min(lo[a], w[a]);
      hi[a] = Math.max(hi[a], w[a]);
    }
  }
}
console.log(`ground-road bounds: min ${r3(lo)}  max ${r3(hi)}`);

const cols = Math.ceil((hi[0] - lo[0]) / cell);
const rows = Math.ceil((hi[2] - lo[2]) / cell);
console.log(`grid: ${cols} x ${rows} cells (X x Z), cell=${cell}u`);

const grid = new Uint8Array(cols * rows);
// count vertices per cell so heavier road geometry stands out
const weight = new Uint16Array(cols * rows);
for (const p of pieces) {
  const cz = p.center[2];
  const cx = p.center[0];
  const pad = 0.5;
  for (let r = 0; r < rows; r++) {
    const z = lo[2] + (r + 0.5) * cell;
    if (Math.abs(z - cz) > 60) continue;
    for (let c = 0; c < cols; c++) {
      const x = lo[0] + (c + 0.5) * cell;
      if (Math.abs(x - cx) > 60) continue;
      const local = toLocal(p.wm, [x, p.center[1], z]);
      if (
        local[0] >= p.min[0] - pad && local[0] <= p.max[0] + pad &&
        local[2] >= p.min[2] - pad && local[2] <= p.max[2] + pad
      ) {
        grid[r * cols + c] = 1;
      }
    }
  }
}

// --- print ASCII ---
console.log("\nlegend: '#'=road  ' '=empty   (X left->right, Z top->bottom)\n");
const colHeader = "     " + Array.from({ length: cols }, (_, c) =>
  c % 10 === 0 ? String(Math.floor((lo[0] + c * cell) / 10) % 10) : " ").join("");
console.log(colHeader);
for (let r = 0; r < rows; r++) {
  let line = "";
  for (let c = 0; c < cols; c++) line += grid[r * cols + c] ? "#" : " ";
  const zLabel = round(lo[2] + r * cell).toString().padStart(7);
  console.log(`${zLabel} ${line}`);
}

// --- component analysis: connected road regions ---
const seen = new Uint8Array(cols * rows);
const comps = [];
for (let i = 0; i < grid.length; i++) {
  if (!grid[i] || seen[i]) continue;
  const stack = [i];
  seen[i] = 1;
  const cells = [];
  while (stack.length) {
    const cur = stack.pop();
    cells.push(cur);
    const r = Math.floor(cur / cols);
    const c = cur % cols;
    const neighbours = [
      r > 0 ? cur - cols : -1,
      r < rows - 1 ? cur + cols : -1,
      c > 0 ? cur - 1 : -1,
      c < cols - 1 ? cur + 1 : -1,
    ];
    for (const n of neighbours) {
      if (n >= 0 && grid[n] && !seen[n]) {
        seen[n] = 1;
        stack.push(n);
      }
    }
  }
  comps.push(cells);
}
comps.sort((a, b) => b.length - a.length);
console.log(`\nconnected road regions: ${comps.length}`);
for (const cells of comps.slice(0, 8)) {
  const xs = cells.map((i) => lo[0] + (i % cols) * cell);
  const zs = cells.map((i) => lo[2] + Math.floor(i / cols) * cell);
  console.log(
    `  cells=${String(cells.length).padStart(5)}  X ${round(Math.min(...xs))}..${round(Math.max(...xs))}  Z ${round(Math.min(...zs))}..${round(Math.max(...zs))}`,
  );
}
