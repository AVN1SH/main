// Headless verification of the race: circuit, grid, rival rigs, countdown,
// checkpoints, laps, finish and leaderboard.
//
// Run:
//   node tools/browser-probe.mjs --url="http://localhost:5173/?debug=1&frames=8" \
//     --expr-file=tools/race-test-expr.js
//
// The expression runs in the page and is returned as JSON by the probe. It
// drives the real RaceSystem with its own fixed-timestep stepper, so it tests
// the shipped rules rather than a copy of them.
(async () => {
  const g = window.game;
  const out = { checks: [], notes: {} };
  const check = (name, pass, detail) => out.checks.push({ name, pass: !!pass, detail: detail ?? "" });
  const render = () => new Promise((r) => requestAnimationFrame(() => r()));

  const race = g.race;
  if (!race) {
    return { fatal: "window.game.race is missing" };
  }
  const track = race.track;
  const grid = track.grid;

  // ---------------------------------------------------------------- circuit
  out.notes.track = race.debugReport().track;
  out.notes.laps = track.laps;
  out.notes.start = race.debugReport().startPose;
  check("circuit is a closed loop", track.path.open === false);
  check("circuit is long enough to race", track.stats.length > 300, `${track.stats.length} m`);
  check("circuit has 5-12 checkpoints", track.gateCount >= 5 && track.gateCount <= 12, `${track.gateCount} gates`);
  check(
    "the race starts at the player's spawn (event is discoverable)",
    Math.hypot(track.startPose.x - g.player.state.x, track.startPose.z - g.player.state.z) < 900,
    `${race.debugReport().track.distanceFromPaddock} m from the paddock`,
  );

  // ---------------------------------------------------------------- grid
  out.notes.grid = race.debugReport().grid;
  check("grid has one slot per car", grid.length === race.field.length + 1, `${grid.length} slots`);
  check("grid never has more than 6 cars", grid.length <= 6, `${grid.length}`);
  check("grid slots are not stacked on each other", (() => {
    for (let i = 0; i < grid.length; i++) {
      for (let j = i + 1; j < grid.length; j++) {
        if (Math.hypot(grid[i].x - grid[j].x, grid[i].z - grid[j].z) < 2.0) return false;
      }
    }
    return true;
  })(), JSON.stringify(grid.map((s) => [s.slot, +s.x.toFixed(1), +s.z.toFixed(1)])));
  check("every grid slot is on drivable road", grid.every((s) => g.collision.isRoadAt(s.x, s.z)));
  check("no grid slot fell back into geometry", race.track.warnings.gridFallback === 0, `${race.track.warnings.gridFallback} fallbacks`);

  // ---------------------------------------------------------------- rivals
  const assets = g.raceAssets.map((a) => a.spec.file);
  out.notes.assets = assets;
  check("rivals never use the player's car", !assets.some((f) => /car1\.glb/.test(f)), assets.join(", "));
  check("rivals never use a vehicles/ traffic model", !assets.some((f) => /vehicles\//.test(f)));
  check("a full field is gridded", race.field.length === 5, `${race.field.length} rivals`);
  check("rivals are all different models", new Set(race.rivals.map((r) => r.name)).size === race.rivals.length);

  const rigs = race.rivals.map((r) => ({ name: r.name, rig: r.rig }));
  out.notes.rigs = rigs.map((r) => ({
    name: r.name,
    source: r.rig.asset.spec.file,
    longAxis: r.rig.diagnostics.longAxis,
    votes: r.rig.diagnostics.axleVotes,
    ends: r.rig.diagnostics.wheelEnds,
    steerSign: r.rig.diagnostics.calibration?.steerSign,
    spinSign: r.rig.diagnostics.calibration?.spinSign,
    seat: r.rig.diagnostics.wheelSeatY,
    footprint: r.rig.diagnostics.footprint,
    wheels: r.rig.diagnostics.wheels.map((w) => `${w.name}[${w.front ? "F" : "R"} ${w.steerAxis}/${w.spinAxis}]`),
  }));

  for (const { name, rig } of rigs) {
    const d = rig.diagnostics;
    const frontCount = d.wheels.filter((w) => w.front).length;
    check(`${name}: two wheels on each axle`, frontCount === 2, `${frontCount} front`);
    check(`${name}: steering and spin axes disagree`, d.wheels.every((w) => w.steerAxis !== w.spinAxis), JSON.stringify(d.wheels[0]));
    check(`${name}: steer axis is the vertical`, d.wheels.every((w) => w.steerAxis === "y"), d.wheels.map((w) => w.steerAxis).join("/"));
    check(`${name}: steer sign measured`, Math.abs(d.calibration?.steerSign ?? 0) > 0.5, `steerSign=${d.calibration?.steerSign}`);
    check(`${name}: spin sign measured`, Math.abs(d.calibration?.spinSign ?? 0) === 1, `spinSign=${d.calibration?.spinSign}`);
    check(
      `${name}: wheel pivots sit on the wheel centres`,
      d.wheels.every((w) => w.pivotError < 0.02),
      `max ${Math.max(...d.wheels.map((w) => w.pivotError))} m`,
    );
    check(`${name}: tyres meet the road (seated)`, Math.abs(d.wheelSeatY) < 0.06, `seat=${d.wheelSeatY}`);
    check(
      `${name}: footprint inside the player envelope`,
      d.footprint.length <= 4.35 && d.footprint.width <= 1.95,
      `${d.footprint.length} x ${d.footprint.width} x ${d.footprint.height} m`,
    );
    check(
      `${name}: wheel radius plausible`,
      d.wheelRadius > 0.15 && d.wheelRadius < 0.65,
      `r=${d.wheelRadius}`,
    );
    check(`${name}: wheelbase plausible`, d.wheelBase > 1.5 && d.wheelBase < 4.0, `wb=${d.wheelBase}`);
  }

  // ---------------------------------------------------------------- arming
  // Park the player far away: the event must be idle, not armed.
  g.player.state.x = track.startPose.x + 1400;
  g.player.state.z = track.startPose.z + 1400;
  g.race.update(1 / 60, null);
  await render();
  check("event is idle when the player is away", race.state === "idle", race.state);
  check("prompt is hidden far from the event", document.getElementById("race-prompt").classList.contains("is-visible") === false);
  check("event board hides far from the event", race.eventBoard.board.isVisible === false);
  check(
    "event sells name, prize, difficulty and reward message",
    !!race.event?.name && race.event?.prize > 0 && !!race.event?.difficulty &&
      /claim reward/i.test(race.event?.message ?? ""),
    JSON.stringify(race.event),
  );

  // Nearby but outside the ring: event style is icon-only — no DOM signpost.
  // The floating board (up close) + the minimap diamond are the signpost; the
  // prompt and START appear only inside the zone.
  g.player.state.x = track.startPose.x;
  g.player.state.z = track.startPose.z + 300;
  g.race.update(1 / 60, null);
  await render();
  check("event stays icon-only from a distance (no prompt)", document.getElementById("race-prompt").classList.contains("is-visible") === false);
  check(
    "minimap shows the event icon from a distance",
    (() => {
      const d = race.getMinimapData();
      return !!d.event && Math.hypot(d.event.x - track.startPose.x, d.event.z - track.startPose.z) < 1;
    })(),
    "event badge at the start line",
  );
  check(
    "field is hidden before the race (icon, not cars)",
    race.rivals.every((r) => r.hidden === true),
    race.rivals.map((r) => String(r.hidden)).join(","),
  );
  check(
    "checkpoint gates are hidden before the race",
    race.markers.gates.every((g) => g.meshes.every((m) => m.isVisible === false)) &&
      race.getMinimapData().gates.length === 0 &&
      race.getMinimapData().points.length === 0,
    `${race.markers.gates.length} gates`,
  );

  // Drive into the zone -> armed. Pinned slow: the start offer needs <10 km/h.
  g.player.state.x = track.startPose.x;
  g.player.state.z = track.startPose.z;
  g.player.state.speed = 0;
  g.race.update(1 / 60, null);
  await render();
  check("event arms when the player reaches the start line", race.state === "armed", race.state);
  check("prompt appears in the zone", document.getElementById("race-prompt").classList.contains("is-visible"));
  check("START button is offered", document.getElementById("race-start-btn").style.display !== "none");
  // Fast drive-by through the zone: the offer dies above 10 km/h...
  g.player.state.speed = 20;
  g.race.update(1 / 60, null);
  await render();
  check(
    "start modal hides on a fast drive-by",
    document.getElementById("race-prompt").classList.contains("is-visible") === false &&
      document.getElementById("race-start-btn").style.display === "none",
  );
  // ...and comes back the moment the car is nearly stopped again.
  g.player.state.speed = 0;
  g.race.update(1 / 60, null);
  await render();
  check(
    "start modal returns once stopped",
    document.getElementById("race-prompt").classList.contains("is-visible") &&
      document.getElementById("race-start-btn").style.display !== "none",
  );
  check("event board appears near the event", race.eventBoard.board.isVisible === true);
  check(
    "prompt shows the event name and prize",
    (document.getElementById("race-prompt-title")?.textContent ?? "").length > 0 &&
      /\+\d[\d,]* SP/.test(document.getElementById("race-prompt-sub")?.textContent ?? ""),
    document.getElementById("race-prompt-sub")?.textContent ?? "",
  );

  // ---------------------------------------------------------------- intro + countdown
  const beforeCountdown = { x: g.player.state.x, z: g.player.state.z };
  race.requestStart();
  check("START opens the intro cinematic", race.state === "intro", race.state);
  check("controls are locked for the intro", race.controlsLocked === true);
  check(
    "field spawns + aligns on START",
    race.fieldVisible === true && race.rivals.every((r) => r.hidden === false),
    `visible=${race.fieldVisible}`,
  );
  check(
    "checkpoint gates rise with the intro",
    race.markers.gates.every((g) => g.meshes.every((m) => m.isVisible === true)) &&
      race.getMinimapData().gates.length === track.gateCount &&
      race.getMinimapData().points.length > 50,
  );
  check(
    "cars stage behind the grid for the rollout",
    Math.hypot(g.player.state.x - grid[race.playerSlot].x, g.player.state.z - grid[race.playerSlot].z) > 2,
    "player starts back, rolls in during the intro",
  );
  await render();
  check("intro event card is shown", document.getElementById("race-intro").classList.contains("is-visible"));
  out.notes.introStepped = race.debugStep(5.2).state;
  check("intro hands off to the countdown", race.state === "countdown", race.state);
  check("event diamond hides once the race starts", race.getMinimapData().event === null);
  check(
    "the rollout lands the player on their grid slot",
    Math.hypot(g.player.state.x - grid[race.playerSlot].x, g.player.state.z - grid[race.playerSlot].z) < 0.01,
    `slot ${race.playerSlot}`,
  );
  check(
    "every car is fully revealed by the countdown",
    [...race.rivals.map((r) => r.rig), g.playerRig].every((rig) =>
      rig.root.getChildMeshes(false).every((m) => m.visibility === 1),
    ),
  );
  await render();
  check(
    "intro card is gone by the countdown",
    document.getElementById("race-intro").classList.contains("is-visible") === false,
  );
  const rivalPoses = race.rivals.map((r) => ({ x: r.state.x, z: r.state.z }));
  out.notes.countdownStepped = race.debugStep(3.0).state;
  check("countdown holds the player still", Math.hypot(g.player.state.x - beforeCountdown.x, g.player.state.z - beforeCountdown.z) < 60);
  check(
    "rivals are held on the grid during the countdown",
    race.rivals.every((r, i) => Math.hypot(r.state.x - rivalPoses[i].x, r.state.z - rivalPoses[i].z) < 0.01),
  );
  out.notes.afterCountdown = race.debugStep(1.2).state;
  check("countdown expires into racing", race.state === "racing", race.state);
  check("rivals released at GO", race.rivals.every((r) => r.locked === false));
  await render();
  check("live readout shows while racing", document.getElementById("race-hud").classList.contains("is-visible"));

  // ---------------------------------------------------------------- rival rigs in motion
  // Isolate the AI before measuring it: park the player far off the circuit.
  // This window is asking "do the rivals race?", and a probe driver that cannot
  // steer would otherwise sit on the racing line and the answer would be about
  // the player, not the AI. The race stays in its racing state regardless of
  // where the player is.
  g.player.state.x = track.startPose.x + 1400;
  g.player.state.z = track.startPose.z + 1400;
  g.player.state.speed = 0;
  const spinBefore = race.rivals.map((r) => r.rig.wheels.map((w) => w.spinPivot.rotation[w.spinAxis]));
  const startTotal = race.rivals.map((r) => r.progress.total);
  const startGate = race.rivals.map((r) => r.progress.gate);
  race.debugStep(14, 1 / 60, { autopilot: false });
  const spinAfter = race.rivals.map((r) => r.rig.wheels.map((w) => w.spinPivot.rotation[w.spinAxis]));
  out.notes.rivalsAfter14s = race.debugReport().rivals.map((r) => ({
    name: r.name,
    total: r.total,
    speed: r.state.speed,
    gate: r.gate,
    target: r.target,
    blocker: r.blocker,
    stuck: r.stuck,
  }));
  check(
    "rivals actually drive",
    race.rivals.every((r, i) => r.progress.total - startTotal[i] > 120),
    race.rivals.map((r, i) => `${r.name} +${(r.progress.total - startTotal[i]).toFixed(0)}m`).join(", "),
  );
  check(
    "rival wheels roll while driving",
    race.rivals.every((r, i) => r.rig.wheels.some((w, k) => Math.abs(spinAfter[i][k] - spinBefore[i][k]) > 0.5)),
    "spin delivered through RaceRig.spinWheels",
  );
  check(
    "rivals pass checkpoints in order",
    race.rivals.some((r, i) => r.progress.gate !== startGate[i] || r.progress.checkpointsPassed > 0),
    race.rivals.map((r) => `${r.name} cp=${r.progress.checkpointsPassed} gate=${r.progress.gate}`).join(", "),
  );
  check(
    "rivals stay on the circuit",
    race.rivals.every((r) => {
      const p = track.path.sample(r.progress.distance);
      return Math.hypot(p.x - r.state.x, p.z - r.state.z) < 12;
    }),
    race.rivals.map((r) => Math.hypot(track.path.sample(r.progress.distance).x - r.state.x, track.path.sample(r.progress.distance).z - r.state.z).toFixed(1)).join(", "),
  );
  check(
    "rivals are all on drivable road",
    race.rivals.every((r) => g.collision.isRoadAt(r.state.x, r.state.z)),
    race.rivals.map((r) => (g.collision.isRoadAt(r.state.x, r.state.z) ? "ok" : `${r.name} off`)).join(", "),
  );
  check(
    "rivals do not drive like a road train (spread out)",
    Math.max(...race.rivals.map((r) => r.progress.total)) - Math.min(...race.rivals.map((r) => r.progress.total)) > 3,
    race.rivals.map((r) => r.progress.total.toFixed(0)).join(" / "),
  );

  // ---------------------------------------------------------------- player lap
  const goto = (s) => {
    const p = track.path.sample(s);
    const a = track.path.sample(s - 2);
    const b = track.path.sample(s + 2);
    g.player.state.x = p.x;
    g.player.state.y = p.y;
    g.player.state.z = p.z;
    g.player.state.heading = Math.atan2(b.x - a.x, b.z - a.z);
  };
  const stepOnce = () => {
    race.update(1 / 60, null);
    g.player.update(1 / 60, { steer: 0, throttle: 0, brake: 0, handbrake: false });
  };

  race.playerProgress.reset(track.startDistance, { x: g.player.state.x, z: g.player.state.z });
  check("the player starts with no checkpoints", race.playerProgress.checkpointsPassed === 0);

  // Skipping a checkpoint must not count: jump straight to gate 3 and cross it.
  goto(track.gates[3].s - 6);
  stepOnce();
  goto(track.gates[3].s + 2);
  stepOnce();
  check(
    "crossing a checkpoint out of order is ignored",
    race.playerProgress.gate === 1 && race.playerProgress.checkpointsPassed === 0,
    `gate=${race.playerProgress.gate}`,
  );

  let lapsSeen = 0;
  let gateEvents = 0;
  for (let lap = 0; lap < track.laps; lap++) {
    for (let k = 1; k < track.gateCount; k++) {
      const s = track.gates[k].s;
      const before = race.playerProgress.gate;
      goto(s - 6);
      stepOnce();
      goto(s + 2);
      stepOnce();
      if (race.playerProgress.gate !== before) gateEvents++;
    }
    const beforeLap = race.playerProgress.lap;
    goto(track.gates[0].s - 6);
    stepOnce();
    goto(track.gates[0].s + 2);
    stepOnce();
    if (race.playerProgress.lap > beforeLap) lapsSeen++;
  }
  out.notes.playerProgress = race.debugReport().playerProgress;
  check("every checkpoint in the lap was credited", gateEvents === (track.gateCount - 1) * track.laps, `${gateEvents} gate events`);
  check("lap counted only after the whole circuit", lapsSeen === track.laps, `${lapsSeen} laps`);
  check("player is finished", race.playerProgress.finished === true);
  check("race state is finished", race.state === "finished", race.state);

  // ---------------------------------------------------------------- leaderboard
  out.notes.results = race.debugReport().results;
  await render();
  const board = document.getElementById("race-board");
  check(
    "leaderboard is ordered and the player is placed",
    race.results.every((e, i) => e.position === i + 1) && race.results.some((e) => e.isPlayer && e.finished),
    `player P${race.results.find((e) => e.isPlayer)?.position}`,
  );
  // Beat panel slides in over the locked orbit (controls held).
  race.debugStep(1.0);
  await render();
  check("controls lock for the finish cinematic", race.controlsLocked === true);
  check(
    "beat panel names the beaten rival",
    document.getElementById("race-beat").classList.contains("is-visible") &&
      /YOU BEAT THE|TAKES THE WIN/.test(document.getElementById("race-beat-beaten")?.textContent ?? "") &&
      /FINISHED (1ST|2ND|3RD|[4-9]TH)/.test(document.getElementById("race-beat-finish")?.textContent ?? ""),
    document.getElementById("race-beat-beaten")?.textContent ?? "",
  );
  check("shade dims the game behind the beat", document.getElementById("race-shade").classList.contains("is-visible"));
  // Results screen: orbit holds while payouts land.
  race.debugStep(5.0);
  await render();
  check("orbit holds through results", race.cineActive === true && race.controlsLocked === true);
  check("beat hands over to results", document.getElementById("race-beat").classList.contains("is-visible") === false);
  check("result board is shown", board.classList.contains("is-visible"));
  check("shade dims the game behind results", document.getElementById("race-shade").classList.contains("is-visible"));
  const rows = [...document.querySelectorAll("#race-board-list li")];
  check("leaderboard lists the whole field", rows.length === race.field.length + 1, `${rows.length} rows`);
  check("speedwall strip is shown", document.getElementById("race-wall").classList.contains("is-visible"));
  check("player rank is on the board", /^P\d+$/.test(document.getElementById("race-board-rank").textContent));
  check(
    "results show finish rank, time and earned reward",
    /FINISHED (1ST|2ND|3RD|[4-9]TH)/.test(document.getElementById("race-board-finish")?.textContent ?? "") &&
      /\+[\d,]+ SP/.test(document.getElementById("race-board-meta")?.textContent ?? ""),
    `${document.getElementById("race-board-finish")?.textContent} · ${document.getElementById("race-board-meta")?.textContent}`,
  );
  check(
    "restart and continue are offered",
    !!document.getElementById("race-again-btn") && !!document.getElementById("race-continue-btn"),
  );
  document.getElementById("race-continue-btn").click();
  await render();
  check(
    "continue hides the board",
    document.getElementById("race-board").classList.contains("is-visible") === false,
  );
  check(
    "continue lifts the shade",
    document.getElementById("race-shade").classList.contains("is-visible") === false,
  );
  check("continue hands control back", race.controlsLocked === false && race.cineActive === false);
  check("event is fully over after continue", race.state === "idle", race.state);
  check(
    "event diamond returns once out of the race",
    (() => {
      const d = race.getMinimapData();
      return !!d.event && Math.hypot(d.event.x - track.startPose.x, d.event.z - track.startPose.z) < 1;
    })(),
  );
  check(
    "traffic owns the road again",
    race.traffic.circuitHeld === false && (race.traffic.extraVehicles?.length ?? 0) === 0,
  );
  check(
    "field parked invisible after continue",
    race.rivals.every((r) => r.hidden === true),
  );
  check(
    "gates down and map clean after continue",
    race.markers.gates.every((g) => g.meshes.every((m) => m.isVisible === false)) &&
      race.getMinimapData().gates.length === 0 &&
      race.getMinimapData().points.length === 0,
  );
  // Parked on the line must NOT instantly re-offer the event...
  g.player.state.x = track.startPose.x;
  g.player.state.z = track.startPose.z;
  g.player.state.speed = 0;
  g.race.update(1 / 60, null);
  await render();
  check(
    "no instant re-arm on the line",
    race.state === "idle" &&
      document.getElementById("race-prompt").classList.contains("is-visible") === false,
    race.state,
  );
  // ...drive out past the exit radius and come back: the offer returns.
  g.player.state.x = track.startPose.x + 500;
  g.player.state.z = track.startPose.z;
  g.race.update(1 / 60, null);
  g.player.state.x = track.startPose.x;
  g.player.state.z = track.startPose.z;
  g.player.state.speed = 0;
  g.race.update(1 / 60, null);
  await render();
  check(
    "offer returns after leaving and coming back",
    race.state === "armed" &&
      document.getElementById("race-prompt").classList.contains("is-visible"),
    race.state,
  );
  check(
    "live readout stands down after the finish",
    document.getElementById("race-hud").classList.contains("is-visible") === false,
  );
  check(
    "the minimap knows the race track",
    (() => {
      const d = race.getMinimapData();
      // Dots show the visible field only: finished rivals that left the
      // player's sight despawn and must not linger as ghosts on the map.
      const visible = race.rivals.filter((r) => !r.hidden).length;
      return d.points.length > 50 && d.gates.length === track.gateCount && d.racers.length === visible;
    })(),
    `${race.getMinimapData().points.length} track points`,
  );
  check(
    "finished rivals run a cooldown lap instead of parking",
    race.rivals.every((r) => !r.progress.finished || r.hidden || (r.debugTarget ?? 0) > 0),
    race.rivals.map((r) => `${r.name} fin=${r.progress.finished} tgt=${r.debugTarget}`).join(", "),
  );

  // ---------------------------------------------------------------- errors
  out.notes.errors = (() => {
    try {
      return JSON.parse(document.getElementById("debug-out").textContent).errors ?? [];
    } catch {
      return [];
    }
  })();
  out.notes.passed = out.checks.filter((c) => c.pass).length;
  out.notes.failed = out.checks.filter((c) => !c.pass).length;
  out.notes.failures = out.checks.filter((c) => !c.pass).map((c) => `${c.name} :: ${c.detail}`);
  return out;
})();
