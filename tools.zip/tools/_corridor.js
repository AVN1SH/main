// Walk the drivable corridor of a road mesh and report exactly which spans are
// sealed, and by what. Answers "why can I not drive onto this deck".
(() => {
  const g = window.game;
  const C = g.collision;
  const NAMES = ["road_c_02.003", "road_c_02.004", "road_c_04.002"];
  const out = {};

  for (const name of NAMES) {
    const mesh = g.scene.meshes.find((m) => m.name === name);
    if (!mesh) { out[name] = { error: "not found" }; continue; }
    mesh.computeWorldMatrix(true);
    const b = mesh.getBoundingInfo().boundingBox;
    const minX = b.minimumWorld.x, maxX = b.maximumWorld.x;
    const minZ = b.minimumWorld.z, maxZ = b.maximumWorld.z;

    const spanX = maxX - minX, spanZ = maxZ - minZ;
    // Walk along the LONG axis, sampling a 5 m wide strip centred on the deck.
    const alongX = spanX >= spanZ;
    const lo = alongX ? minX : minZ;
    const hi = alongX ? maxX : maxZ;
    const crossMid = alongX ? (minZ + maxZ) / 2 : (minX + maxX) / 2;

    const steps = [];
    const N = Math.max(20, Math.round((hi - lo) / 0.5));
    for (let i = 0; i <= N; i++) {
      const p = lo + ((hi - lo) * i) / N;
      const x = alongX ? p : crossMid;
      const z = alongX ? crossMid : p;
      const ref = alongX ? 8 : 8;
      const gy = C.groundAt(x, z, ref, { stepUp: 1.5, reach: 14 });
      const surf = gy ? gy.y : null;
      // Sample the 5 m strip at 1 m across so a barrier on one side still shows.
      let blockedHits = 0, roadHits = 0, samples = 0;
      let blocker = null;
      for (let o = -2.5; o <= 2.5; o += 0.5) {
        const sx = alongX ? p : crossMid + o;
        const sz = alongX ? crossMid + o : p;
        const s2 = C.groundAt(sx, sz, ref, { stepUp: 1.5, reach: 14 });
        if (!s2) continue;
        samples++;
        if (C.isRoadAt(sx, sz)) roadHits++;
        if (C.blockedAt(sx, sz, s2.y + 0.15, s2.y + 1.45)) {
          blockedHits++;
          const cell = C._obstacleCell(sx, sz);
          const src = C.obstacleSource ? C.obstacleSource[cell] : 0;
          const rec = src ? C.solidMeshes[src - 1] : null;
          blocker = rec ? rec.mesh.name : "no-source";
        }
      }
      steps.push({
        p: +p.toFixed(1),
        surf: surf == null ? null : +surf.toFixed(2),
        road: samples ? +(roadHits / samples).toFixed(2) : 0,
        blk: +(blockedHits / Math.max(1, samples)).toFixed(2),
        by: blocker,
      });
    }

    // Collapse to contiguous "sealed" spans.
    const spans = [];
    let cur = null;
    for (const s of steps) {
      const sealed = s.blk > 0.5;
      if (sealed && !cur) cur = { from: s.p, to: s.p, by: s.by };
      else if (sealed && cur) { cur.to = s.p; if (s.by && !cur.by) cur.by = s.by; }
      else if (!sealed && cur) { spans.push(cur); cur = null; }
    }
    if (cur) spans.push(cur);

    out[name] = {
      alongAxis: alongX ? "X" : "Z",
      span: [+(alongX ? minX : minZ).toFixed(1), +(alongX ? maxX : maxZ).toFixed(1)],
      cross: +crossMid.toFixed(1),
      yRange: [+b.minimumWorld.y.toFixed(2), +b.maximumWorld.y.toFixed(2)],
      sealedSpans: spans,
      surfProfile: steps.filter((_, i) => i % 6 === 0).map((s) => `${s.p}:${s.surf}`).join(" "),
    };
  }

  // Neighbouring road meshes, so the layout is visible.
  out._neighbours = g.scene.meshes
    .filter((m) => /^(road_c_02|road_c_04)/.test(m.name ?? ""))
    .map((m) => {
      m.computeWorldMatrix(true);
      const b = m.getBoundingInfo().boundingBox;
      return {
        n: m.name,
        x: [+b.minimumWorld.x.toFixed(0), +b.maximumWorld.x.toFixed(0)],
        z: [+b.minimumWorld.z.toFixed(0), +b.maximumWorld.z.toFixed(0)],
        y: [+b.minimumWorld.y.toFixed(1), +b.maximumWorld.y.toFixed(1)],
      };
    })
    .sort((a, b) => a.n.localeCompare(b.n));
  return JSON.stringify(out, null, 1);
})();