(async () => {
  const g = window.game, race = g.race, t = race.track;
  const rows = [];
  for (let s = 640; s <= 770; s += 5) {
    const p = t.path.sample(s), a = t.path.sample(s-4), b = t.path.sample(s+4);
    const hd = Math.atan2(b.x-a.x, b.z-a.z);
    const h2 = Math.atan2(t.path.sample(s+8).x-t.path.sample(s+4).x, t.path.sample(s+8).z-t.path.sample(s+4).z);
    let turn = (h2-hd+Math.PI*3)%(Math.PI*2)-Math.PI;
    const radius = Math.abs(turn)>1e-4 ? 4/Math.abs(turn) : 999;
    rows.push({s, x:+p.x.toFixed(1), z:+p.z.toFixed(1), hd:+(hd*180/Math.PI).toFixed(0), radius:+radius.toFixed(0), road:g.collision.isRoadAt(p.x,p.z)});
  }
  // Also: does the path cross a wall region? check blocked along path
  return { len: Math.round(t.length), start: +t.startDistance.toFixed(0), rows };
})();
