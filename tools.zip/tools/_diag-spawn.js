// Is each traffic vehicle's SPAWN point actually valid against the lane it uses?
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision: c } = g;
  const out = { spawns: [], geoCompare: {} };

  const v0 = traffic.vehicles[0];
  out.geoCompare = {
    rig: {
      halfLength: v0.terrain.g.halfLength,
      halfWidth: v0.terrain.g.halfWidth,
      clearance: v0.terrain.g.clearance,
      height: v0.terrain.g.height,
      wheels: v0.terrain.g.wheels,
    },
    car: { length: 4.3, width: 1.9, clearance: 0.26, height: 1.42 },
  };

  for (const v of traffic.vehicles) {
    const start = v.path.sample(v.distance);
    const ahead = v.path.sample(v.distance + 6);
    const heading = Math.atan2(ahead.x - start.x, ahead.z - start.z);
    const gr = c.groundAt(start.x, start.z, start.y + 1, { stepUp: 3, reach: 4 });
    out.spawns.push(
      `#${traffic.vehicles.indexOf(v)} route=${v.route.bridge ? "BRIDGE" : "gen"} ` +
        `lane=(${start.x.toFixed(1)},${start.z.toFixed(1)}) y=${start.y.toFixed(2)} ` +
        `ground=${gr.kind}${gr.y === null ? "" : "@" + gr.y.toFixed(2)} ` +
        `road=${c.isRoadAt(start.x, start.z) ? 1 : 0} ` +
        `pos=(${v.state.x.toFixed(1)},${v.state.z.toFixed(1)}) ` +
        `blockedNow=${v.terrain.blocked(v.state.x, v.state.z, v.state.heading) ? 1 : 0}`,
    );
  }

  // for each distinct route, how many of its points are blocked / off-surface?
  const seen = new Set();
  out.routes = [];
  for (const v of traffic.vehicles) {
    if (seen.has(v.route)) continue;
    seen.add(v.route);
    const pts = v.route.path.points;
    let blocked = 0;
    let offSurf = 0;
    let offRoad = 0;
    const probeY = [];
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i];
      const q = pts[(i + 1) % pts.length];
      const hh = Math.atan2(q.x - p.x, q.z - p.z);
      v.terrain.teleport(p.y);
      if (v.terrain.blocked(p.x, p.z, hh)) blocked++;
      const r = c.groundAt(p.x, p.z, p.y, { stepUp: 3, reach: 4 });
      if (r.kind !== "ground") offSurf++;
      if (!c.isRoadAt(p.x, p.z)) offRoad++;
      if (probeY.length < 3) probeY.push(+p.y.toFixed(2));
    }
    out.routes.push(
      `pts=${pts.length} blocked=${blocked} offSurface=${offSurf} offRoad=${offRoad} y=${probeY.join(",")}`,
    );
  }
  return JSON.stringify(out, null, 1);
})();
