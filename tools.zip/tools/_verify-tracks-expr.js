(async () => {
  const col = window.game && window.game.collision;
  if (!col) return "no collision";
  const { buildTrackFromNodes } = await import('/src/game/raceTrack.js');
  const { RACE_EVENTS } = await import('/src/data/raceEvents.js');
  const nodes = await (await fetch('/src/data/road-nodes.json')).json();
  const out = [];
  for (const ev of RACE_EVENTS) {
    const miss = ev.nodes.filter((n) => !nodes[n]);
    const pts = ev.nodes.map((n) => nodes[n]).filter(Boolean).map((p) => ({ x: p.x, y: p.y, z: p.z }));
    try {
      const t = buildTrackFromNodes(col, pts, {
        open: ev.open, laps: ev.laps, fieldSize: ev.opponents + 1, id: ev.id, name: ev.name,
      });
      const gridNaN = t.grid.some((g) => !isFinite(g.x) || !isFinite(g.z) || !isFinite(g.y));
      const ptsNaN = t.points.some((p) => !isFinite(p.x) || !isFinite(p.z) || !isFinite(p.y));
      out.push({
        id: ev.id, type: ev.type, open: t.open, len: Math.round(t.length),
        gates: t.gateCount, grid: t.grid.length, offRoadPct: Math.round((100 * t.warnings.offRoad) / t.points.length),
        gridFallback: t.warnings.gridFallback, finishIdx: t.gates.findIndex((g) => g.isFinish),
        gridNaN, ptsNaN, miss: miss.length,
      });
    } catch (e) {
      out.push({ id: ev.id, error: String(e && e.message || e) });
    }
  }
  return JSON.stringify(out);
})()
