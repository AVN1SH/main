// Frame-by-frame reaction timeline for one prop, to answer "can I see it?".
(() => {
  const g = window.game;
  const d = g.destruction;
  const sleep = (n) => new Promise((r) => setTimeout(r, n));

  return (async () => {
    const want = new URLSearchParams(location.search).get("fam") || "streetsign";
    const o = d.objects.find((x) => x.family && x.family.id === want);
    if (!o) return JSON.stringify({ error: "no " + want });

    const mesh = o.mesh;
    const wasInstance = typeof mesh.bakeCurrentTransformIntoVertices !== "function";
    const before = {
      family: o.family.id, behavior: o.family.behavior,
      instanced: wasInstance,
      pos: mesh.getAbsolutePosition().asArray().map((v) => +v.toFixed(2)),
    };

    // Frame the mesh against world up, straight from its world matrix basis.
    const tilt = (m) => {
      const w = m.computeWorldMatrix(true).m;
      const up = [w[4], w[5], w[6]];
      return +(Math.acos(Math.min(1, Math.max(-1, up[1]))) * 57.2958).toFixed(1);
    };
    const snap = () => {
      const mm = mesh;
      mm.computeWorldMatrix(true);
      return {
        p: mm.getAbsolutePosition().asArray().map((v) => +v.toFixed(2)),
        tilt: tilt(mm),
        vis: mm.isVisible !== false && mm.isEnabled() !== false,
        sx: mm.scaling.x,
      };
    };

    const start = snap();
    const back = Math.max(1.2, o.halfZ + 0.4);
    const px = o.center.x, pz = o.center.z - back;
    const gy = g.collision.groundAt(px, pz, o.center.y + 2, { stepUp: 4, reach: 8 })?.y ?? 0;
    const t0 = performance.now();
    d.handleImpact({
      x: px, z: pz, y: gy, heading: 0, speed: 26,
      clearance: 0.25, height: 1.6, halfLength: 2.2, halfWidth: 0.9,
    });

    const frames = [];
    const marks = {};
    let collided = null;
    for (let i = 0; i < 200; i++) {
      await sleep(16);
      const s = snap();
      const dt = (performance.now() - t0) / 1000;
      frames.push({ t: +dt.toFixed(2), tilt: s.tilt, x: s.p[0], y: s.p[1], z: s.p[2], vis: s.vis, sx: s.sx });
      if (marks.firstMove === undefined && (Math.abs(s.p[0] - start.p[0]) > 0.05
        || Math.abs(s.p[2] - start.p[2]) > 0.05 || s.tilt - start.tilt > 2)) marks.firstMove = +dt.toFixed(2);
      if (marks.bent === undefined && Math.abs(s.sx - 1) > 0.02) marks.bent = +dt.toFixed(2);
      if (marks.released === undefined && !d.active.some((a) => a.object === o && a.mode === "hinge")) {
        marks.released = +dt.toFixed(2);
      }
      if (marks.collisionOpen === undefined && !d.active.some((a) => a.object === o)) {
        // Collision is released the moment the prop stops being a blocker.
        marks.collisionOpen = +dt.toFixed(2);
      }
      if (marks.restored === undefined && !d.damaged.includes(o)) marks.restored = +dt.toFixed(2);
      if (marks.restored !== undefined) break;
      void collided;
    }

    const at = (t) => frames.find((f) => f.t >= t) || null;
    return JSON.stringify({
      before,
      marks,
      // How long the prop stayed visibly off its start pose.
      movedFor: marks.restored != null && marks.firstMove != null
        ? +(marks.restored - marks.firstMove).toFixed(2) : null,
      biggestTilt: Math.max(...frames.map((f) => f.tilt)),
      farthest: +Math.max(...frames.map((f) => Math.hypot(f.x - start.pos[0], f.z - start.pos[2]))).toFixed(2),
      invisibleFrames: frames.filter((f) => !f.vis).length,
      sample: [at(0), at(0.25), at(0.5), at(0.75), at(1), at(1.5), at(2)].filter(Boolean),
    }, null, 1);
  })();
})();