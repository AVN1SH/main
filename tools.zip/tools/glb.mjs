// GLB analysis helpers: hierarchy, TRS matrices, world-space bounds.
// Needed because the car's wheel nodes do NOT sit at the wheel centres,
// so real pivots and dimensions must be measured rather than assumed.
import { readFileSync } from "node:fs";

export function loadGlb(file) {
  const buf = readFileSync(file);
  if (buf.toString("utf8", 0, 4) !== "glTF") throw new Error("not a GLB");

  let offset = 12;
  let json = null;
  while (offset < buf.length) {
    const chunkLen = buf.readUInt32LE(offset);
    const chunkType = buf.toString("utf8", offset + 4, offset + 8);
    const data = buf.subarray(offset + 8, offset + 8 + chunkLen);
    if (chunkType === "JSON") json = JSON.parse(data.toString("utf8"));
    offset += 8 + chunkLen;
  }

  const g = json;
  const nodes = g.nodes ?? [];
  const parents = new Map();
  nodes.forEach((n, i) => (n.children ?? []).forEach((c) => parents.set(c, i)));

  return { g, nodes, parents, byteLength: buf.length };
}

// --- column-major 4x4 helpers (glTF/WebGL convention) ---

export function identity() {
  return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
}

export function multiply(a, b) {
  const out = new Array(16).fill(0);
  for (let col = 0; col < 4; col++) {
    for (let row = 0; row < 4; row++) {
      let sum = 0;
      for (let k = 0; k < 4; k++) sum += a[k * 4 + row] * b[col * 4 + k];
      out[col * 4 + row] = sum;
    }
  }
  return out;
}

export function compose([tx, ty, tz], [x, y, z, w], [sx, sy, sz]) {
  const m = [
    (1 - 2 * (y * y + z * z)) * sx, 2 * (x * y + z * w) * sx, 2 * (x * z - y * w) * sx, 0,
    2 * (x * y - z * w) * sy, (1 - 2 * (x * x + z * z)) * sy, 2 * (y * z + x * w) * sy, 0,
    2 * (x * z + y * w) * sz, 2 * (y * z - x * w) * sz, (1 - 2 * (x * x + y * y)) * sz, 0,
    tx, ty, tz, 1,
  ];
  return m;
}

export function localMatrix(node) {
  if (node.matrix) return node.matrix.slice();
  return compose(node.translation ?? [0, 0, 0], node.rotation ?? [0, 0, 0, 1], node.scale ?? [1, 1, 1]);
}

export function worldMatrix(nodes, parents, index, cache = new Map()) {
  if (cache.has(index)) return cache.get(index);
  const local = localMatrix(nodes[index]);
  const parent = parents.get(index);
  const world = parent === undefined ? local : multiply(worldMatrix(nodes, parents, parent, cache), local);
  cache.set(index, world);
  return world;
}

export function transformPoint(m, [x, y, z]) {
  return [
    m[0] * x + m[4] * y + m[8] * z + m[12],
    m[1] * x + m[5] * y + m[9] * z + m[13],
    m[2] * x + m[6] * y + m[10] * z + m[14],
  ];
}

export function transformAabb(m, min, max) {
  const lo = [Infinity, Infinity, Infinity];
  const hi = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < 8; i++) {
    const corner = [i & 1 ? max[0] : min[0], i & 2 ? max[1] : min[1], i & 4 ? max[2] : min[2]];
    const p = transformPoint(m, corner);
    for (let a = 0; a < 3; a++) {
      lo[a] = Math.min(lo[a], p[a]);
      hi[a] = Math.max(hi[a], p[a]);
    }
  }
  return { min: lo, max: hi };
}

/** POSITION accessor min/max for a node's mesh, in mesh-local space. */
export function meshBounds(g, nodeIndex) {
  const node = g.nodes[nodeIndex];
  if (node.mesh === undefined) return null;
  const mesh = g.meshes[node.mesh];
  let min = [Infinity, Infinity, Infinity];
  let max = [-Infinity, -Infinity, -Infinity];
  let vertices = 0;
  for (const prim of mesh.primitives ?? []) {
    const acc = g.accessors?.[prim.attributes?.POSITION];
    if (!acc?.min || !acc?.max) continue;
    vertices += acc.count;
    for (let a = 0; a < 3; a++) {
      min[a] = Math.min(min[a], acc.min[a]);
      max[a] = Math.max(max[a], acc.max[a]);
    }
  }
  return Number.isFinite(min[0]) ? { min, max, vertices, meshName: mesh.name } : null;
}

/** World-space AABB for every node that has a mesh. */
export function worldBounds(nodes, parents, g) {
  const cache = new Map();
  const out = [];
  nodes.forEach((node, i) => {
    const b = meshBounds(g, i);
    if (!b) return;
    const wm = worldMatrix(nodes, parents, i, cache);
    const box = transformAabb(wm, b.min, b.max);
    const center = box.min.map((v, a) => (v + box.max[a]) / 2);
    const size = box.max.map((v, a) => v - box.min[a]);
    out.push({ index: i, name: node.name ?? `#${i}`, world: wm, box, center, size, vertices: b.vertices });
  });
  return out;
}

export const round = (v, d = 2) => Math.round(v * 10 ** d) / 10 ** d;
export const r3 = (a) => a.map((v) => round(v));
