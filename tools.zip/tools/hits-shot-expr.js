// Drive traffic until contacts accumulate, then park a camera on the busiest
// one so a screenshot shows the marker sitting on real geometry.
(() => {
  try {
    const g = window.game;
    if (!g) return "no window.game";
    const d = g.hitDebug;
    if (!d) return "overlay not enabled (needs ?hits=1)";

    const dt = 1 / 60;
    for (let f = 0; f < 2400; f++) {
      g.traffic.update(dt);
      g.player.update(dt, g.input);
      d.update(dt);
    }

    const hits = d.hits.filter((h) => h.meshRef);
    if (!hits.length) return "no contacts recorded";
    // Busiest AABB-only contact is the interesting one: that is the case where
    // the car can be blocked by a bounding box rather than by geometry.
    const target = hits.find((h) => h.bucket === "aabb") ?? hits[0];

    const cam = g.chase.camera;
    // Assign components rather than calling .set(): the chase camera is a custom
    // rig, and reaching its constructor to build a fresh camera is fragile.
    cam.position.x = target.x + 9;
    cam.position.y = target.y + 6;
    cam.position.z = target.z + 9;
    if (cam.setTarget) cam.setTarget(new g.Vector3(target.x, target.y, target.z));
    cam.minZ = 0.1;
    cam.maxZ = 4000;
    g.scene.activeCamera = cam;
    g.chase.update = () => {}; // stop the chase camera reclaiming the view

    d.update(0.016);
    g.scene.render();

    return JSON.stringify(
      {
        lookingAt: {
          mesh: target.mesh,
          bucket: target.bucket,
          x: +target.x.toFixed(2),
          y: +target.y.toFixed(2),
          z: +target.z.toFixed(2),
          box: target.box
            ? [
                +(target.box.maxX - target.box.minX).toFixed(2),
                +(target.box.maxY - target.box.minY).toFixed(2),
                +(target.box.maxZ - target.box.minZ).toFixed(2),
              ]
            : null,
        },
        markers: d.marker.thinInstanceCount,
        boxes: d.boxes.filter((b) => b.isEnabled()).length,
        tally: d.tally,
      },
      null,
      1,
    );
  } catch (e) {
    return "ERR " + e.message + "\n" + e.stack;
  }
})();
