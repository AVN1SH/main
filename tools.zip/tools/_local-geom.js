// Which triangles of the deck mesh actually cover a sealed cell?
(() => {
  const g = window.game;
  const C = g.collision;
  const CX = -0.9, CZ = 74.2;
  const out = { at: [CX, CZ], maxSlopeCos: C.maxSlopeCos, layersPerCell: C.layers };

  const road = C.roadSurfaceAt(CX, CZ);
  const i = C._obstacleCell(CX, CZ);
  out.span = i >= 0 ? [+C.obstacleBottom[i].toFixed(2), +C.obstacleTop[i].toFixed(2)] : null;
  out.road = road != null ? +road.toFixed(2) : null;

  const rows = [];
  for (const mesh of g.scene.meshes) {
    if (!/^road_c_02\.003$/.test(mesh.name)) continue;
    const pos = mesh.getVerticesData("position");
    const idx = mesh.getIndices();
    const tri = idx ? idx.length / 3 : pos.length / 9;
    mesh.computeWorldMatrix(true);
    const m = mesh.getWorldMatrix().m;
    const wx = (k) => [
      m[0] * pos[k] + m[4] * pos[k + 1] + m[8] * pos[k + 2] + m[12],
      m[1] * pos[k] + m[5] * pos[k + 1] + m[9] * pos[k + 2] + m[13],
      m[2] * pos[k] + m[6] * pos[k + 1] + m[10] * pos[k + 2] + m[14],
    ];
    out.meshTriCount = tri;
    for (let t = 0; t < tri; t++) {
      const A = wx((idx ? idx[t * 3] : t * 3) * 3);
      const B = wx((idx ? idx[t * 3 + 1] : t * 3 + 1) * 3);
      const Cc = wx((idx ? idx[t * 3 + 2] : t * 3 + 2) * 3);
      // XZ bounding box overlap with the sealed cell.
      const xs = [A[0], B[0], Cc[0]], zs = [A[2], B[2], Cc[2]];
      if (Math.min(...xs) > CX + 0.5 || Math.max(...xs) < CX - 0.5) continue;
      if (Math.min(...zs) > CZ + 0.5 || Math.max(...zs) < CZ - 0.5) continue;
      const ux = B[0] - A[0], uy = B[1] - A[1], uz = B[2] - A[2];
      const vx = Cc[0] - A[0], vy = Cc[1] - A[1], vz = Cc[2] - A[2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const len = Math.hypot(nx, ny, nz) || 1;
      const ys = [A[1], B[1], Cc[1]];
      const nyR = Math.abs(ny) / len;
      rows.push({
        t,
        span: [+Math.min(...ys).toFixed(2), +Math.max(...ys).toFixed(2)],
        nyR: +nyR.toFixed(3),
        stamp: nyR < C.maxSlopeCos,
        aboveRoad: +(Math.max(...ys) - (road ?? 0)).toFixed(2),
        v: [[+A[0].toFixed(1), +A[1].toFixed(2), +A[2].toFixed(1)],
            [+B[0].toFixed(1), +B[1].toFixed(2), +B[2].toFixed(1)],
            [+Cc[0].toFixed(1), +Cc[1].toFixed(2), +Cc[2].toFixed(1)]],
        area: +(len / 2).toFixed(1),
      });
    }
  }
  out.count = rows.length;
  rows.sort((a, b) => b.span[1] - a.span[1]);
  out.triangles = rows;
  return JSON.stringify(out, null, 1);
})();