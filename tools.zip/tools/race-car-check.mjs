/**
 * Offline check for the race cars' axle/naming rules.
 *
 * The race rig has to cope with two different authoring conventions in
 * `public/assets/` (and one model whose wheel NAMES contradict its POSITIONS),
 * so the rules that decide "which end is the front" are pure functions and live
 * in `src/game/raceCarAxles.js` away from Babylon. This drives them with the
 * real `.glb` files, so a change to the naming or axis rules is caught here
 * instead of in the game.
 *
 * Nothing here needs the browser: `tools/glb.mjs` reads the GLB directly. Note
 * that Babylon mirrors the imported scene on Z (`__root__` has scale (1,1,-1)),
 * which swaps the SIGN of the Z axis but never which axis is long, so the
 * expectations below are stated per asset family rather than per exact number.
 *
 * Run: node tools/race-car-check.mjs
 */
import { loadGlb, worldBounds } from "./glb.mjs";
import { classifyAxles, wheelEndFromName, WHEEL_RE } from "../src/game/raceCarAxles.js";

let failures = 0;
let checks = 0;
function check(label, ok, detail = "") {
  checks++;
  if (!ok) failures++;
  console.log(`  [${ok ? "PASS" : "FAIL"}] ${label}${detail ? ` - ${detail}` : ""}`);
}

/**
 * The eight rival cars (everything in `public/assets/` that is neither the
 * player's `car1.glb` nor one of the `vehicles/` traffic models), each with the
 * convention its wheels are authored in.
 *
 * `car*` models put the FRONT axle at negative X; the race pack (`<Name> FL
 * Tire`) puts it at positive Z. Both are authoring conventions, confirmed by
 * the wheel names AND by the steering wheels' positions in each file.
 */
const CARS = [
  { file: "public/assets/car2.glb", family: "car", label: "Landy" },
  { file: "public/assets/car3.glb", family: "car", label: "Beetle" },
  { file: "public/assets/car4.glb", family: "car", label: "Hilux" },
  { file: "public/assets/Classic Car_9.glb", family: "pack", label: "Classic Car 9" },
  { file: "public/assets/Hatchback Car_15.glb", family: "pack", label: "Hatchback 15" },
  { file: "public/assets/Monster Truck_15.glb", family: "pack", label: "Monster Truck" },
  { file: "public/assets/N_Muscle Car_10.glb", family: "pack", label: "N Muscle 10" },
  { file: "public/assets/Sport Car_39.glb", family: "pack", label: "Sport Car 39" },
];

// --- 1. the naming rules, including the ones that must NOT match -----------
{
  console.log("wheel name -> axle token");
  const cases = [
    ["Classic Car_9 BL Tire", "rear"],
    ["Classic Car_9 BR Tire", "rear"],
    ["Classic Car_9 FL Tire", "front"],
    ["Classic Car_9 FR Tire", "front"],
    ["lfWheel.001", "front"],
    ["rFWheel.001", "front"],
    ["lrWheel.002", "rear"],
    ["rrWheel", "rear"],
    ["lfWheel.003", "front"],
    ["N_Muscle Car_10 BR Tire", "rear"],
    // The model name must never be read as an axle: "Backpack" contains "back"
    // only as a substring, and "Nice" contains no axle token at all.
    ["Backpack Carrier", null],
    ["Sport Car 39", null],
  ];
  for (const [name, expect] of cases) {
    const got = wheelEndFromName(name);
    check(`${JSON.stringify(name)} -> ${expect === null ? "null" : expect}`, got === expect, `got ${got}`);
  }
}

// --- 2. the real models ---------------------------------------------------
for (const car of CARS) {
  console.log(`\n${car.label}  (${car.file})`);
  const { g, nodes, parents } = loadGlb(car.file);
  const all = worldBounds(nodes, parents, g);

  const wheelNodes = all.filter((b) => WHEEL_RE.test(b.name));
  const bodyNodes = all.filter((b) => !WHEEL_RE.test(b.name));
  check("four wheels found", wheelNodes.length === 4, `${wheelNodes.length} wheels: ${wheelNodes.map((w) => w.name).join(", ")}`);
  check("body geometry found", bodyNodes.length > 0, `${bodyNodes.length} body meshes`);

  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (const b of bodyNodes) {
    for (let a = 0; a < 3; a++) {
      min[a] = Math.min(min[a], b.box.min[a]);
      max[a] = Math.max(max[a], b.box.max[a]);
    }
  }
  const bodyBox = {
    min: { x: min[0], y: min[1], z: min[2] },
    max: { x: max[0], y: max[1], z: max[2] },
  };

  // `worldBounds` reports centres as arrays; the classifier takes plain {x,y,z}.
  const centres = wheelNodes.map((w) => ({ x: w.center[0], y: w.center[1], z: w.center[2] }));
  const axles = classifyAxles(bodyBox, centres, wheelNodes.map((w) => w.name));

  console.log(`    long axis: ${axles.longAxis}   axle votes [pos, neg]: [${axles.votes.join(", ")}]`);
  for (let i = 0; i < axles.ends.length; i++) {
    const e = axles.ends[i];
    console.log(`      ${wheelNodes[i].name}: named=${e.named} measured=${e.measured}`);
  }

  const fronts = axles.isFront.filter(Boolean).length;
  check("two wheels on each axle", fronts === 2, `${fronts} front / ${4 - fronts} rear`);
  // A tie would mean the vote failed and the fallback decided it - which for
  // one of the two families would be the WRONG end. No shipped car may tie.
  check("name vote resolved (no tie)", axles.votes[0] !== axles.votes[1], `votes [${axles.votes.join(", ")}]`);

  // The front axle must land where the convention says it is. In glTF space the
  // `car*` family has it at negative X and the race pack at positive Z.
  const frontMean = centres.filter((_, i) => axles.isFront[i]).reduce((s, c) => s + c[axles.longAxis], 0) / 2;
  const rearMean = centres.filter((_, i) => !axles.isFront[i]).reduce((s, c) => s + c[axles.longAxis], 0) / 2;
  const expectedAxis = car.family === "car" ? "x" : "z";
  const expectedSign = car.family === "car" ? -1 : 1;
  check(
    `long axis is ${expectedAxis}`,
    axles.longAxis === expectedAxis,
    `got ${axles.longAxis}`,
  );
  check(
    "front axle is the named-front end",
    Math.sign(frontMean - rearMean) === expectedSign,
    `front mean ${frontMean.toFixed(2)} vs rear mean ${rearMean.toFixed(2)} along ${axles.longAxis}`,
  );

  // Every wheel whose name reads clearly must agree with the cluster it landed
  // in - EXCEPT on car2, where two wheels are called `rfWheel` and one of them
  // is on the rear axle. That model is the reason this is a vote at all.
  const contradictions = axles.ends
    .map((e, i) => ({ ...e, name: wheelNodes[i].name }))
    .filter((e) => e.named && e.named !== e.measured);
  if (car.file.endsWith("car2.glb")) {
    check(
      "car2's duplicated wheel name is tolerated",
      contradictions.length >= 1,
      `${contradictions.map((c) => c.name).join(", ") || "none"} (expected: two wheels named rfWheel)`,
    );
  } else {
    check(
      "every readable wheel name agrees with its axle",
      contradictions.length === 0,
      contradictions.map((c) => `${c.name}(${c.named}/${c.measured})`).join(", "),
    );
  }
}

// --- 3. the player car must stay on the old rig ---------------------------
{
  console.log("\nplayer car is not a race opponent");
  const { readFileSync } = await import("node:fs");
  const vehicles = ["Sport Car_39.glb", "car1.glb"];
  void vehicles;
  const src = readFileSync(new URL("../src/game/VehicleAssets.js", import.meta.url), "utf8");
  const block = src.slice(src.indexOf("RACE_CAR_CATALOG"), src.indexOf("const SITE_ASSETS"));
  check("RACE_CAR_CATALOG never lists car1.glb", !/car1\.glb/.test(block));
  check("RACE_CAR_CATALOG never lists a vehicles/ model", !/vehicles\//.test(block));
  const listed = (block.match(/\.glb/g) ?? []).length;
  check("catalogue has the eight rival cars", listed === 8, `${listed} entries`);
}

console.log(`\n${checks - failures}/${checks} checks passed`);
process.exit(failures ? 1 : 0);
