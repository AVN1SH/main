// Drives headless Chrome over the DevTools protocol.
//
// Written because `chrome --dump-dom` dumps at the load event, which fires long
// before a 20 MB glTF map finishes loading. This waits for a real condition
// (an expression in the page) and relays console output and uncaught
// exceptions, which is the only practical way to see runtime errors headlessly.
//
// Usage:
//   node tools/browser-probe.mjs --url <url> --wait <js-expr> --expr <js-expr>
// Options:
//   --timeout=<ms>   default 180000
//   --shot=<path>    also capture a PNG screenshot
//   --port=<n>       remote debugging port, default 9333
//   --no-launch      attach to an already-running Chrome on --port
import { spawn } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

const argv = process.argv.slice(2);
const arg = (name, fallback) => {
  const hit = argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? hit.slice(name.length + 3) : fallback;
};
const has = (name) => argv.includes(`--${name}`);

const PAGE_URL = arg("url", "http://localhost:5173/?debug=1&frames=6");
const WAIT_EXPR = arg("wait", "document.getElementById('debug-out')?.dataset.ready === '1'");
// Prefer --expr-file: passing a multi-line expression through the shell breaks
// it (a `//` comment ends up commenting out the rest of the joined line).
const EXPR_FILE = arg("expr-file", null);
const RESULT_EXPR = EXPR_FILE
  ? readFileSync(EXPR_FILE, "utf8")
  : arg("expr", "document.getElementById('debug-out')?.textContent ?? ''");
const TIMEOUT = Number(arg("timeout", 180000));
const PORT = Number(arg("port", 9333));
const SHOT = arg("shot", null);
// Optional window size as WxH (default 1280x720); useful for
// checking responsive layouts at phone sizes, e.g. --size=375,667.
const SIZE = arg("size", "1280,720");

const CHROME_CANDIDATES = [
  arg("chrome", null),
  "C:/Program Files/Google/Chrome/Application/chrome.exe",
  "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
  `${process.env.LOCALAPPDATA}/Google/Chrome/Application/chrome.exe`,
  "/usr/bin/google-chrome",
  "/usr/bin/chromium",
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function findChrome() {
  for (const p of CHROME_CANDIDATES) if (p && existsSync(p)) return p;
  throw new Error("chrome not found; pass --chrome=<path>");
}

/** Minimal CDP client over the built-in WebSocket. */
class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    this.handlers = new Map();
    ws.addEventListener("message", (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id !== undefined) {
        const p = this.pending.get(msg.id);
        if (p) {
          this.pending.delete(msg.id);
          msg.error ? p.reject(new Error(JSON.stringify(msg.error))) : p.resolve(msg.result);
        }
      } else {
        (this.handlers.get(msg.method) ?? []).forEach((fn) => fn(msg.params));
      }
    });
  }

  on(method, fn) {
    if (!this.handlers.has(method)) this.handlers.set(method, []);
    this.handlers.get(method).push(fn);
  }

  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  /** Evaluates an expression in the page and returns its value. */
  async eval(expression) {
    const res = await this.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (res.exceptionDetails) {
      throw new Error(res.exceptionDetails.exception?.description ?? "evaluate failed");
    }
    return res.result.value;
  }
}

async function getJson(path) {
  const res = await fetch(`http://127.0.0.1:${PORT}${path}`);
  return res.json();
}

function describeArg(a) {
  if (a.value !== undefined) return typeof a.value === "string" ? a.value : JSON.stringify(a.value);
  return a.description ?? a.type ?? "?";
}

async function main() {
  const logs = [];
  let chrome = null;

  if (!has("no-launch")) {
    chrome = spawn(
      findChrome(),
      [
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--enable-unsafe-swiftshader",
        "--use-angle=swiftshader",
        "--mute-audio",
        "--no-first-run",
        "--disable-extensions",
        "--disable-dev-shm-usage",
        `--remote-debugging-port=${PORT}`,
        `--user-data-dir=${(process.env.TEMP ?? "/tmp").replace(/\\/g, "/")}/chrome-probe-${PORT}`,
        `--window-size=${SIZE}`,
        PAGE_URL,
      ],
      { stdio: "ignore" },
    );
  }

  const deadline = Date.now() + TIMEOUT;
  let pageTarget = null;
  while (Date.now() < deadline && !pageTarget) {
    try {
      const list = await getJson("/json/list");
      pageTarget = list.find((t) => t.type === "page" && t.webSocketDebuggerUrl);
    } catch {
      /* endpoint not up yet */
    }
    if (!pageTarget) await sleep(300);
  }
  if (!pageTarget) throw new Error("chrome debugging endpoint never became available");

  const ws = new WebSocket(pageTarget.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener("open", resolve);
    ws.addEventListener("error", () => reject(new Error("websocket failed")));
  });

  const cdp = new Cdp(ws);
  cdp.on("Runtime.consoleAPICalled", (p) => {
    logs.push(`[console.${p.type}] ${p.args.map(describeArg).join(" ")}`);
  });
  cdp.on("Runtime.exceptionThrown", (p) => {
    const d = p.exceptionDetails;
    logs.push(`[exception] ${d.exception?.description ?? d.text}`);
  });
  cdp.on("Log.entryAdded", (p) => {
    const e = p.entry;
    if (e.level === "error" || e.level === "warning") logs.push(`[log.${e.level}] ${e.text}`);
  });

  await cdp.send("Runtime.enable");
  await cdp.send("Log.enable");
  await cdp.send("Page.enable");

  // --size=WxH: force the page viewport via device emulation
  // (the Chrome --window-size flag alone is unreliable in
  // headless mode, especially with a reused profile).
  if (SIZE && SIZE !== "1280,720") {
    const [w, h] = SIZE.split(",").map(Number);
    if (w && h) {
      await cdp.send("Emulation.setDeviceMetricsOverride", {
        width: w,
        height: h,
        deviceScaleFactor: 1,
        mobile: false,
      });
    }
  }

  // --- wait for the page to reach the state we care about ---
  let ready = false;
  let waitError = null;
  while (Date.now() < deadline) {
    try {
      if (await cdp.eval(`!!(${WAIT_EXPR})`)) {
        ready = true;
        break;
      }
    } catch (err) {
      waitError = err.message;
    }
    await sleep(500);
  }

  let result = null;
  try {
    result = await cdp.eval(RESULT_EXPR);
  } catch (err) {
    waitError = waitError ?? err.message;
  }

  if (SHOT) {
    const shot = await cdp.send("Page.captureScreenshot", { format: "png" });
    writeFileSync(SHOT, Buffer.from(shot.data, "base64"));
  }

  console.log(`ready: ${ready}${waitError ? `  (wait issue: ${waitError})` : ""}`);
  console.log("--- console ---");
  console.log(logs.length ? logs.slice(0, 60).join("\n") : "(no console output)");
  console.log("--- result ---");
  console.log(typeof result === "string" ? result : JSON.stringify(result, null, 1));

  ws.close();
  if (chrome) {
    if (process.platform === "win32") {
      spawn("taskkill", ["/F", "/T", "/PID", String(chrome.pid)], { stdio: "ignore" });
    } else {
      chrome.kill("SIGKILL");
    }
  }

  if (!ready) process.exitCode = 2;
}

main().catch((err) => {
  console.error("probe failed:", err.message);
  process.exitCode = 1;
});
