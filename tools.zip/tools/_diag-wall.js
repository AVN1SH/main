// Simulate until car 11 is stuck, then dissect exactly what stops it.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision: c } = g;
  const dt = 1 / 60;
  const car = traffic.vehicles[11];

  // run until it stops dead
  let f = 0;
  for (; f < 3600; f++) {
    traffic.update(dt);
    if (f > 120 && Math.abs(car.state.speed) < 0.3) break;
  }

  const px = car.state.x;
  const pz = car.state.z;
  const h = car.state.heading;
  const out = { stoppedAtFrame: f, at: [+px.toFixed(2), +pz.toFixed(2)], speed: +car.state.speed.toFixed(2) };

  const cellInfo = (x, z) => {
    const col = Math.floor((x - c.minX) / c.cell);
    const row = Math.floor((z - c.minZ) / c.cell);
    const i = row * c.cols + col;
    const ys = [];
    for (let k = 0; k < c.layerCount[i]; k++) ys.push(+c.layerY[i * c.layers + k].toFixed(2));
    return `${ys.length ? ys.join("/") : "empty"} road=${c.roadMask[i] ? 1 : 0}`;
  };

  // walk forward along the car's heading and report every blocking factor
  const fx = Math.sin(h);
  const fz = Math.cos(h);
  out.forward = [];
  for (let d = -2; d <= 10; d += 1) {
    const x = px + fx * d;
    const z = pz + fz * d;
    const gy = car.terrain.y;
    // footprint column test, per corner, exactly like TerrainFollower.blocked
    const g2 = car.terrain.g;
    const cols = [];
    for (const [sx, sz] of [
      [0, g2.halfLength],
      [g2.halfWidth, g2.halfLength * 0.6],
      [-g2.halfWidth, g2.halfLength * 0.6],
      [0, -g2.halfLength],
    ]) {
      const cx = x + Math.sin(h) * sz + Math.cos(h) * sx;
      const cz = z + Math.cos(h) * sz - Math.sin(h) * sx;
      const b = c.blockedAt(cx, cz, gy + g2.clearance, gy + g2.height);
      if (b) cols.push(`(${cx.toFixed(1)},${cz.toFixed(1)})`);
    }
    out.forward.push(
      `d=${String(d).padStart(3)} (${x.toFixed(1)},${z.toFixed(1)}) cell=[${cellInfo(x, z)}] ` +
        `followerBlocked=${car.terrain.blocked(x, z, h) ? 1 : 0} cols=${cols.length}${cols.length ? " " + cols.join(" ") : ""}`,
    );
  }

  // what does the lane itself say about that stretch?
  out.lane = [];
  for (let d = -8; d <= 16; d += 2) {
    const s = car.path.sample(car.distance + d);
    out.lane.push(
      `d=${String(d).padStart(3)} lane=(${s.x.toFixed(1)},${s.z.toFixed(1)}) y=${s.y.toFixed(2)} cell=[${cellInfo(s.x, s.z)}]`,
    );
  }

  // real geometry: raycast down and up at the blocker footprint
  const ray = g.scene.createPickingRay(0, 0, null, g.scene.activeCamera);
  const hitsAt = (x, z, from, to) => {
    ray.origin.set(x, from, z);
    ray.direction.set(0, to > from ? 1 : -1, 0);
    const r = [];
    for (const m of g.scene.meshes) {
      if (!m.name || m.getTotalVertices() < 3) continue;
      const info = ray.intersectsMesh(m, false);
      if (info && info.hit) r.push(`${m.name}@${info.pickedPoint.y.toFixed(2)}`);
    }
    return r;
  };
  out.meshesAt = {
    down: hitsAt(px + fx * 2, pz + fz * 2, 12, -2).slice(0, 8),
    up: hitsAt(px + fx * 2, pz + fz * 2, 0.2, 12).slice(0, 8),
  };

  return JSON.stringify(out, null, 1);
})();
