// Dump everything about the specific obstacle cells that seal the bridge decks:
// their stored span, the road surface, and which triangle of which mesh set it.
(() => {
  const g = window.game;
  const C = g.collision;
  const G = { halfLength: 2.15, halfWidth: 0.95, height: 1.42, clearance: 0.26 };
  const out = {};

  const probes = [
    { n: "003 centre", x: 0, z: 75.4 },
    { n: "003 centre2", x: 15, z: 75.4 },
    { n: "004 centre", x: -120, z: 75.4 },
    { n: "004 centre2", x: -135, z: 75.4 },
    { n: "04.002 mid", x: -315, z: 4 },
  ];

  out.cells = [];
  for (const p of probes) {
    const gy = C.groundAt(p.x, p.z, 16, { stepUp: 2.5, reach: 20 });
    const hits = [];
    const blocked = C.blockedRect(
      p.x, p.z, 0, G.halfLength, G.halfWidth,
      (gy ? gy.y : 0) + G.clearance, (gy ? gy.y : 0) + G.height, hits,
    );
    const rec = {
      probe: p.n, x: p.x, z: p.z,
      ground: gy ? +gy.y.toFixed(2) : null,
      roadSurface: C.roadSurfaceAt(p.x, p.z) != null ? +C.roadSurfaceAt(p.x, p.z).toFixed(2) : null,
      isRoad: C.isRoadAt(p.x, p.z),
      blocked,
      cells: [],
    };
    const seen = new Set();
    for (const hh of hits) {
      const i = C._obstacleCell(hh.x, hh.z);
      if (seen.has(i)) continue;
      seen.add(i);
      rec.cells.push({
        mesh: hh.mesh,
        src: hh.from,
        span: [+C.obstacleBottom[i].toFixed(2), +C.obstacleTop[i].toFixed(2)],
        cellCenter: [+hh.x.toFixed(1), +hh.z.toFixed(1)],
        roadHere: C.roadSurfaceAt(hh.x, hh.z) != null ? +C.roadSurfaceAt(hh.x, hh.z).toFixed(2) : null,
      });
      if (rec.cells.length >= 6) break;
    }
    out.cells.push(rec);
  }

  // For one offending mesh, list the triangles that produce the sealing spans.
  const meshName = "road_c_02.003";
  const mesh = g.scene.meshes.find((m) => m.name === meshName);
  out.triangles = { mesh: meshName };
  if (mesh) {
    mesh.computeWorldMatrix(true);
    const m = mesh.getWorldMatrix().m;
    const pos = mesh.getVerticesData("position");
    const idx = mesh.getIndices();
    const tri = idx ? idx.length / 3 : pos.length / 9;
    const rows = [];
    const near = (x, z) => x > -8 && x < 40 && z > 64 && z < 87;
    for (let t = 0; t < tri; t++) {
      const ia = (idx ? idx[t * 3] : t * 3) * 3;
      const ib = (idx ? idx[t * 3 + 1] : t * 3 + 1) * 3;
      const ic = (idx ? idx[t * 3 + 2] : t * 3 + 2) * 3;
      const wx = (i) => [
        m[0] * pos[i] + m[4] * pos[i + 1] + m[8] * pos[i + 2] + m[12],
        m[1] * pos[i] + m[5] * pos[i + 1] + m[9] * pos[i + 2] + m[13],
        m[2] * pos[i] + m[6] * pos[i + 1] + m[10] * pos[i + 2] + m[14],
      ];
      const A = wx(ia), B = wx(ib), Cc = wx(ic);
      const cx = (A[0] + B[0] + Cc[0]) / 3, cz = (A[2] + B[2] + Cc[2]) / 3;
      if (!near(cx, cz)) continue;
      const ux = B[0] - A[0], uy = B[1] - A[1], uz = B[2] - A[2];
      const vx = Cc[0] - A[0], vy = Cc[1] - A[1], vz = Cc[2] - A[2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const len = Math.hypot(nx, ny, nz) || 1;
      const ys = [A[1], B[1], Cc[1]];
      const bottom = Math.min(...ys), top = Math.max(...ys);
      // Only the ones that could seal: wall-ish and reaching above the road.
      if (Math.abs(ny) / len >= 0.55) continue;
      if (bottom > 8) continue;
      const roadHere = C.roadSurfaceAt(cx, cz);
      if (roadHere === null || top <= roadHere + 0.4) continue;
      rows.push({
        c: [+cx.toFixed(1), +cz.toFixed(1)],
        span: [+bottom.toFixed(2), +top.toFixed(2)],
        road: +roadHere.toFixed(2),
        above: +(top - roadHere).toFixed(2),
        nyRatio: +(Math.abs(ny) / len).toFixed(3),
        slope: +Math.hypot(ux, uz).toFixed(1),
      });
    }
    rows.sort((a, b) => b.span[1] - a.span[1]);
    out.triangles.count = rows.length;
    out.triangles.samples = rows.slice(0, 10);
    // How much of the deck area does this mesh account for above the road?
    out.triangles.totalTris = tri;
  }
  return JSON.stringify(out, null, 1);
})();