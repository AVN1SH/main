// Derives traffic routes from map.glb and writes src/data/routes.json.
//
// Why offline: reading the road topology out of 1,300 meshes at runtime is
// slow and fragile. Here we rasterise the real road geometry, pull out the
// axis-aligned road bands, find closed rectangular loops on the city grid,
// and validate every loop point actually sits on road before shipping it.
//
// Usage: node tools/build-routes.mjs [map.glb] [options]
//   --cell=2        rasterisation cell size in world units
//   --min-side=90   minimum loop side length
//   --dry           print analysis, do not write routes.json
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { loadGlb, meshBounds, worldMatrix, transformPoint, round } from "./glb.mjs";

const argv = process.argv.slice(2);
const file = argv.find((a) => !a.startsWith("--")) ?? "public/assets/map.glb";
const opt = (name, fallback) => {
  const hit = argv.find((a) => a.startsWith(`--${name}=`));
  return hit ? Number(hit.split("=")[1]) : fallback;
};
const CELL = opt("cell", 2);
const MIN_SIDE = opt("min-side", 90);
const DRY = argv.includes("--dry");
const OUT = "src/data/routes.json";

// ---------------------------------------------------------------- load + rasterise

const { g, nodes, parents } = loadGlb(file);
const cache = new Map();
const GROUND_MAX_Y = 1.0;

const pieces = [];
for (let i = 0; i < nodes.length; i++) {
  const node = nodes[i];
  if (!node.name || !/road/i.test(node.name)) continue;
  const b = meshBounds(g, i);
  if (!b) continue;
  const wm = worldMatrix(nodes, parents, i, cache);
  const center = transformPoint(wm, [
    (b.min[0] + b.max[0]) / 2,
    (b.min[1] + b.max[1]) / 2,
    (b.min[2] + b.max[2]) / 2,
  ]);
  if (center[1] > GROUND_MAX_Y) continue; // skip overpasses
  pieces.push({ wm, min: b.min, max: b.max, center, y: center[1] });
}

// world point -> mesh-local (TRS, no shear)
function toLocal(wm, p) {
  const t = [wm[12], wm[13], wm[14]];
  const out = [0, 0, 0];
  for (let a = 0; a < 3; a++) {
    const basis = [wm[a * 4], wm[a * 4 + 1], wm[a * 4 + 2]];
    const s = Math.hypot(basis[0], basis[1], basis[2]) || 1;
    let d = 0;
    for (let k = 0; k < 3; k++) d += (p[k] - t[k]) * (basis[k] / s);
    out[a] = d / s;
  }
  return out;
}

const lo = [Infinity, Infinity, Infinity];
const hi = [-Infinity, -Infinity, -Infinity];
for (const p of pieces) {
  for (let i = 0; i < 8; i++) {
    const w = transformPoint(p.wm, [
      i & 1 ? p.max[0] : p.min[0],
      i & 2 ? p.max[1] : p.min[1],
      i & 4 ? p.max[2] : p.min[2],
    ]);
    for (let a = 0; a < 3; a++) {
      lo[a] = Math.min(lo[a], w[a]);
      hi[a] = Math.max(hi[a], w[a]);
    }
  }
}

const cols = Math.ceil((hi[0] - lo[0]) / CELL);
const rows = Math.ceil((hi[2] - lo[2]) / CELL);
const grid = new Uint8Array(cols * rows);
const yGrid = new Float32Array(cols * rows);

const cellX = (c) => lo[0] + (c + 0.5) * CELL;
const cellZ = (r) => lo[2] + (r + 0.5) * CELL;
const colOf = (x) => Math.floor((x - lo[0]) / CELL);
const rowOf = (z) => Math.floor((z - lo[2]) / CELL);

for (const p of pieces) {
  // AABB of this piece in world space, then only scan its cells
  let pmin = [Infinity, Infinity, Infinity];
  let pmax = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < 8; i++) {
    const w = transformPoint(p.wm, [
      i & 1 ? p.max[0] : p.min[0],
      i & 2 ? p.max[1] : p.min[1],
      i & 4 ? p.max[2] : p.min[2],
    ]);
    for (let a = 0; a < 3; a++) {
      pmin[a] = Math.min(pmin[a], w[a]);
      pmax[a] = Math.max(pmax[a], w[a]);
    }
  }
  const c0 = Math.max(0, colOf(pmin[0]));
  const c1 = Math.min(cols - 1, colOf(pmax[0]));
  const r0 = Math.max(0, rowOf(pmin[2]));
  const r1 = Math.min(rows - 1, rowOf(pmax[2]));
  for (let r = r0; r <= r1; r++) {
    for (let c = c0; c <= c1; c++) {
      const local = toLocal(p.wm, [cellX(c), p.center[1], cellZ(r)]);
      if (
        local[0] >= p.min[0] - 0.5 && local[0] <= p.max[0] + 0.5 &&
        local[2] >= p.min[2] - 0.5 && local[2] <= p.max[2] + 0.5
      ) {
        grid[r * cols + c] = 1;
        yGrid[r * cols + c] = Math.max(yGrid[r * cols + c], p.y);
      }
    }
  }
}

const isRoad = (x, z) => {
  const c = colOf(x);
  const r = rowOf(z);
  if (c < 0 || r < 0 || c >= cols || r >= rows) return false;
  return grid[r * cols + c] === 1;
};

console.log(`rasterised ${pieces.length} ground road pieces -> ${cols}x${rows} cells @ ${CELL}u`);
console.log(`road bounds X ${round(lo[0])}..${round(hi[0])}  Z ${round(lo[2])}..${round(hi[2])}`);

// ---------------------------------------------------------------- band extraction

const MIN_RUN_CELLS = Math.round(24 / CELL);

/** Collect runs of road cells per row (horizontal) or per column (vertical). */
function runs(isRowPass) {
  const out = [];
  const outer = isRowPass ? rows : cols;
  const inner = isRowPass ? cols : rows;
  for (let o = 0; o < outer; o++) {
    let start = -1;
    for (let i = 0; i <= inner; i++) {
      const on = i < inner && grid[isRowPass ? o * cols + i : i * cols + o] === 1;
      if (on && start < 0) start = i;
      if (!on && start >= 0) {
        if (i - start >= MIN_RUN_CELLS) out.push({ o, start, end: i - 1 });
        start = -1;
      }
    }
  }
  return out;
}

/**
 * Merge per-row runs into bands.
 *
 * Only runs from the SAME road may merge, so besides being adjacent the runs
 * must be of similar length. Without that similarity test a short run - e.g. a
 * column clipping a thick horizontal boulevard - gets swallowed by an
 * ever-expanding long run, which is how a 12u road previously reported a
 * 212u width.
 */
const LEN_SIMILARITY = 0.6;

function toBands(list) {
  const bands = [];
  for (const run of list) {
    const len = run.end - run.start + 1;
    const candidate = bands.find((b) => {
      if (run.o - b.lastO > 2) return false;
      const otherLen = b.end - b.start + 1;
      const overlap = Math.min(run.end, b.end) - Math.max(run.start, b.start) + 1;
      if (overlap < 0.5 * Math.min(len, otherLen)) return false;
      return Math.min(len, otherLen) / Math.max(len, otherLen) >= LEN_SIMILARITY;
    });
    if (candidate) {
      candidate.lastO = run.o;
      candidate.os.push(run.o);
      candidate.start = Math.min(candidate.start, run.start);
      candidate.end = Math.max(candidate.end, run.end);
    } else {
      bands.push({ firstO: run.o, lastO: run.o, os: [run.o], start: run.start, end: run.end });
    }
  }
  return bands;
}

const horizontal = toBands(runs(true));
const vertical = toBands(runs(false));

/** Project bands into world-space road descriptors with measured width + y. */
function describe(bands, axis) {
  return bands.map((b) => {
    const centerO = (Math.min(...b.os) + Math.max(...b.os) + 1) / 2;
    const spanMin = Math.min(...b.os);
    const spanMax = Math.max(...b.os) + 1;
    const width = (spanMax - spanMin) * CELL;

    let ySum = 0;
    let yCount = 0;
    const oIdx = Math.round(centerO);
    for (let i = b.start; i <= b.end; i++) {
      const r = axis === "z" ? oIdx : i;
      const c = axis === "z" ? i : oIdx;
      if (r < 0 || c < 0 || r >= rows || c >= cols) continue;
      const y = yGrid[r * cols + c];
      if (y > 0) {
        ySum += y;
        yCount++;
      }
    }
    const center = axis === "z" ? cellZ(centerO) : cellX(centerO);
    const from = axis === "z" ? cellX(b.start) : cellZ(b.start);
    const to = axis === "z" ? cellX(b.end + 1) : cellZ(b.end + 1);
    return {
      axis, // 'z' = road runs along X at fixed Z; 'x' = road runs along Z at fixed X
      center: round(center, 1),
      from: round(from, 1),
      to: round(to, 1),
      width: round(width, 1),
      y: yCount ? round(ySum / yCount, 3) : 0.056,
    };
  });
}

// Guard against runaway merges: no real road here is wider than this.
const MAX_ROAD_WIDTH = 60;
const hRoads = describe(horizontal, "z").filter((r) => r.width <= MAX_ROAD_WIDTH);
const vRoads = describe(vertical, "x").filter((r) => r.width <= MAX_ROAD_WIDTH);

console.log(`\nhorizontal road bands: ${hRoads.length}`);
for (const r of hRoads) console.log(`  Z=${r.center}  X ${r.from}..${r.to}  width=${r.width}  y=${r.y}`);
console.log(`\nvertical road bands: ${vRoads.length}`);
for (const r of vRoads) console.log(`  X=${r.center}  Z ${r.from}..${r.to}  width=${r.width}  y=${r.y}`);

// ---------------------------------------------------------------- loops

const indexes = {
  straight: new WeakMap(),
};

/** Sample the road surface height along a lane, using measured band heights. */
function yFor(x, z) {
  const c = Math.max(0, Math.min(cols - 1, colOf(x)));
  const r = Math.max(0, Math.min(rows - 1, rowOf(z)));
  const y = yGrid[r * cols + c];
  return y > 0 ? y : 0.056;
}

const loops = [];
const usedKey = new Set();

for (let i = 0; i < hRoads.length; i++) {
  for (let j = i + 1; j < hRoads.length; j++) {
    const hA = hRoads[i];
    const hB = hRoads[j];
    const sideZ = Math.abs(hA.center - hB.center);
    if (sideZ < MIN_SIDE) continue;

    for (let k = 0; k < vRoads.length; k++) {
      for (let l = k + 1; l < vRoads.length; l++) {
        const vA = vRoads[k];
        const vB = vRoads[l];
        const sideX = Math.abs(vA.center - vB.center);
        if (sideX < MIN_SIDE) continue;

        // all four corners must be a real intersection of both roads
        const cornersOk = [
          [vA.center, hA.center],
          [vB.center, hA.center],
          [vB.center, hB.center],
          [vA.center, hB.center],
        ].every(([x, z]) => isRoad(x, z));
        if (!cornersOk) continue;

        // each road must actually span the other pair of roads
        const spanOk =
          hA.from <= Math.min(vA.center, vB.center) && hA.to >= Math.max(vA.center, vB.center) &&
          hB.from <= Math.min(vA.center, vB.center) && hB.to >= Math.max(vA.center, vB.center) &&
          vA.from <= Math.min(hA.center, hB.center) && vA.to >= Math.max(hA.center, hB.center) &&
          vB.from <= Math.min(hA.center, hB.center) && vB.to >= Math.max(hA.center, hB.center);
        if (!spanOk) continue;

        const key = [hA.center, hB.center, vA.center, vB.center].join(",");
        if (usedKey.has(key)) continue;
        usedKey.add(key);
        loops.push({ hA, hB, vA, vB, sideX: round(sideX), sideZ: round(sideZ), perimeter: round(2 * (sideX + sideZ)) });
      }
    }
  }
}

loops.sort((a, b) => b.perimeter - a.perimeter);
console.log(`\nrectangular loops found: ${loops.length}`);
for (const loop of loops.slice(0, 12)) {
  console.log(
    `  X ${loop.vA.center}..${loop.vB.center} (${loop.sideX})  Z ${loop.hA.center}..${loop.hB.center} (${loop.sideZ})  perimeter=${loop.perimeter}`,
  );
}

// ---------------------------------------------------------------- lane building

const LANE_OFFSET = 4.0; // metres from road centre to lane centre

/**
 * Build a lane polyline for a loop.
 *
 * Corners are emitted in clockwise screen order (+X right, +Z down), which
 * makes the inward side the right-hand side of travel. Traffic therefore keeps
 * right with a deterministic inset rather than one chosen per-loop, so two
 * loops sharing a road end up on opposite sides of it (real two-way traffic).
 *
 * Edges are then densified so a pursuit controller has a lane to track instead
 * of four far-apart corners it would cut across.
 */
const DENSIFY_STEP = 8;

function buildLane(loop) {
  const cx = (loop.vA.center + loop.vB.center) / 2;
  const cz = (loop.hA.center + loop.hB.center) / 2;
  const inset = LANE_OFFSET;

  const corners = [
    { x: loop.vA.center, z: loop.hA.center },
    { x: loop.vB.center, z: loop.hA.center },
    { x: loop.vB.center, z: loop.hB.center },
    { x: loop.vA.center, z: loop.hB.center },
  ].map((p) => ({
    x: p.x + (p.x < cx ? inset : -inset),
    z: p.z + (p.z < cz ? inset : -inset),
  }));

  const ring = [];
  for (let s = 0; s < corners.length; s++) {
    const a = corners[s];
    const b = corners[(s + 1) % corners.length];
    const len = Math.hypot(b.x - a.x, b.z - a.z);
    const steps = Math.max(1, Math.round(len / DENSIFY_STEP));
    for (let t = 0; t < steps; t++) {
      ring.push({ x: a.x + ((b.x - a.x) * t) / steps, z: a.z + ((b.z - a.z) * t) / steps });
    }
  }

  // validate the lane stays on road
  let onRoad = 0;
  for (const p of ring) if (isRoad(p.x, p.z)) onRoad++;
  const ratio = onRoad / ring.length;
  if (ratio < 0.9) return null;

  return {
    points: ring.map((p) => ({ x: round(p.x, 2), y: round(yFor(p.x, p.z), 3), z: round(p.z, 2) })),
    onRoadRatio: round(ratio, 3),
  };
}

const routes = [];
for (const loop of loops) {
  const lane = buildLane(loop);
  if (!lane) continue;
  routes.push({
    id: routes.length,
    sideX: loop.sideX,
    sideZ: loop.sideZ,
    perimeter: lane.points.reduce((sum, p, i) => {
      const q = lane.points[(i + 1) % lane.points.length];
      return sum + Math.hypot(q.x - p.x, q.z - p.z);
    }, 0),
    onRoadRatio: lane.onRoadRatio,
    points: lane.points,
  });
}

console.log(`\nvalidated lanes (>=90% on road): ${routes.length}`);
const distinct = routes.filter((r) => r.onRoadRatio >= 0.98);
console.log(`lanes with >=98% on road: ${distinct.length}`);

if (routes.length) {
  const best = routes.reduce((a, b) => (a.perimeter > b.perimeter ? a : b));
  console.log(`longest loop: id=${best.id} perimeter=${round(best.perimeter)}m ratio=${best.onRoadRatio} points=${best.points.length}`);
  console.log(`  start point: ${JSON.stringify(best.points[0])}`);
  const sizes = routes.map((r) => r.points.length);
  console.log(`route waypoint counts: min=${Math.min(...sizes)} max=${Math.max(...sizes)}`);
}

// ---------------------------------------------------------------- write

// Spawn the player on a wide road in the busiest region, facing along it.
const spawnRoad =
  hRoads.filter((r) => r.width >= 18 && r.to - r.from > 150).sort((a, b) => b.width - a.width)[0] ??
  hRoads[0];
const playerSpawn = spawnRoad
  ? {
      x: round((spawnRoad.from + spawnRoad.to) / 2, 2),
      y: round(spawnRoad.y + 0.02, 3),
      z: round(spawnRoad.center, 2),
      headingDeg: 90, // facing +X along the road
    }
  : { x: 0, y: 0.1, z: 0, headingDeg: 0 };

const payload = {
  generatedFrom: file,
  cell: CELL,
  bounds: { min: lo.map((v) => round(v, 1)), max: hi.map((v) => round(v, 1)) },
  groundY: 0.056,
  laneOffset: LANE_OFFSET,
  playerSpawn,
  roads: { horizontal: hRoads, vertical: vRoads },
  routes,
};

if (DRY) {
  console.log("\n(dry run - nothing written)");
} else {
  mkdirSync(dirname(OUT), { recursive: true });
  writeFileSync(OUT, JSON.stringify(payload, null, 1));
  console.log(`\nwrote ${OUT}: ${routes.length} routes, ${hRoads.length + vRoads.length} roads`);
}
