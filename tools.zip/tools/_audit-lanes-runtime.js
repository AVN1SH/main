// Audits every traffic lane point against the BAKED collision model:
//  - is there drivable surface under the point?
//  - is the car footprint blocked there (buildings/walls)?
//  - how far is the point from the nearest drivable surface (edge distance)?
// This is the ground truth the game actually drives on, unlike the road-band
// test which only validates the lanes against their own source descriptors.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const c = g.collision;
  const p = g.player;
  const R = g.routeData;
  const out = { routes: R.routes.length, points: 0, noSurface: 0, blocked: 0, edgeFar: 0 };
  out.samples = [];
  out.blockedList = [];

  // distance from a point to the nearest cell that has surface, up to 6 m
  const edgeDistance = (x, z) => {
    for (let d = 0; d <= 6; d += 0.5) {
      for (let a = 0; a < 16; a++) {
        const th = (a / 16) * Math.PI * 2;
        const r = c.groundAt(x + Math.cos(th) * d, z + Math.sin(th) * d, 3, { stepUp: 5, reach: 5 });
        if (r.kind === "ground") return d;
      }
    }
    return Infinity;
  };

  const geo = p.terrain.g;
  for (const route of R.routes) {
    for (const pt of route.points) {
      out.points++;
      const gy = c.groundAt(pt.x, pt.z, pt.y + 2, { stepUp: 4, reach: 4 });
      if (gy.kind !== "ground") {
        out.noSurface++;
        if (out.samples.length < 8) out.samples.push({ route: route.id, x: pt.x, z: pt.z, kind: gy.kind });
        continue;
      }
      p.terrain.teleport(gy.y);
      if (p.terrain.blocked(pt.x, pt.z, 0)) {
        out.blocked++;
        if (out.blockedList.length < 12) out.blockedList.push({ route: route.id, x: +pt.x.toFixed(1), z: +pt.z.toFixed(1) });
        continue;
      }
      const d = edgeDistance(pt.x, pt.z);
      if (d > 2.0) {
        out.edgeFar++;
        if (out.samples.length < 8) out.samples.push({ route: route.id, x: pt.x, z: pt.z, edgeDist: d });
      }
    }
  }
  out.pctNoSurface = +((100 * out.noSurface) / out.points).toFixed(1);
  out.pctBlocked = +((100 * out.blocked) / out.points).toFixed(1);
  out.pctEdgeFar = +((100 * out.edgeFar) / out.points).toFixed(1);
  p.reset();
  return JSON.stringify(out, null, 1);
})();
