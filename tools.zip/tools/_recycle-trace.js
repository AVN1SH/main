// Temporary: inspect the recycled route's geometry and whether cars traverse
// the whole cycle and recycle at the end.
(() => {
  const g = window.game;
  const traffic = g.traffic;
  const route = (traffic.allRoutes ?? []).find((r) => r.recycle);
  if (!route) return "no recycle route";
  const pts = route.points;
  const ys = pts.map((p) => p.y);
  const xs = pts.map((p) => p.x);
  const zs = pts.map((p) => p.z);

  // downsampled waypoints
  const step = Math.max(1, Math.floor(pts.length / 24));
  const wp = [];
  for (let i = 0; i < pts.length; i += step) {
    wp.push(`${pts[i].x.toFixed(0)},${pts[i].z.toFixed(0)}`);
  }

  // does the route actually cross the bridge deck (x -104..-4, z 62..88)?
  let onBridge = 0;
  let onHighway = 0;
  for (const p of pts) {
    if (p.x > -104 && p.x < -4 && p.z > 62 && p.z < 89) onBridge++;
    if (Math.abs(p.x - 356) < 12 && p.z > -80 && p.z < 366) onHighway++;
  }

  // simulate ~90 s and track recycle-route vehicles
  const dt = 1 / 60;
  const cars = traffic.vehicles.filter((v) => v.route.recycle);
  const maxD = cars.map(() => 0);
  const recycles = cars.map(() => 0);
  const prevD = cars.map((v) => v.distance);
  for (let f = 0; f < 5400; f++) {
    traffic.update(dt);
    for (let i = 0; i < cars.length; i++) {
      const v = cars[i];
      if (v.distance < prevD[i] - 5) recycles[i]++; // wrapped back to start
      prevD[i] = v.distance;
      if (v.distance > maxD[i]) maxD[i] = v.distance;
    }
  }

  return JSON.stringify({
    length: Math.round(route.path.length),
    points: pts.length,
    open: route.path.open,
    xRange: [Math.round(Math.min(...xs)), Math.round(Math.max(...xs))],
    zRange: [Math.round(Math.min(...zs)), Math.round(Math.max(...zs))],
    yRange: [+Math.min(...ys).toFixed(2), +Math.max(...ys).toFixed(2)],
    onBridgePoints: onBridge,
    onHighwayPoints: onHighway,
    first: `${pts[0].x.toFixed(0)},${pts[0].z.toFixed(0)}`,
    last: `${pts[pts.length - 1].x.toFixed(0)},${pts[pts.length - 1].z.toFixed(0)}`,
    waypoints: wp.join(" "),
    cars: cars.length,
    maxDistance: maxD.map((d) => Math.round(d)),
    recycles,
  }, null, 1);
})();
