// Measures the player car: real wheel centres, pivots, orientation, size.
// Usage: node tools/analyze-car.mjs public/assets/car1.glb
import { loadGlb, worldBounds, worldMatrix, meshBounds, r3, round } from "./glb.mjs";

const file = process.argv[2] ?? "public/assets/car1.glb";
const { g, nodes, parents } = loadGlb(file);
const cache = new Map();
const all = worldBounds(nodes, parents, g);

console.log("=== scene graph ===");
nodes.forEach((n, i) => {
  const parent = parents.get(i);
  console.log(`  ${i}: ${JSON.stringify(n.name)} parent=${parent === undefined ? "(root)" : JSON.stringify(nodes[parent].name)}`);
});

console.log("\n=== world AABB per mesh node ===");
for (const b of all) {
  console.log(`  ${b.name}`);
  console.log(`    center ${r3(b.center)}  size ${r3(b.size)}`);
}

// overall car bounds
const lo = [Infinity, Infinity, Infinity];
const hi = [-Infinity, -Infinity, -Infinity];
for (const b of all) {
  for (let a = 0; a < 3; a++) {
    lo[a] = Math.min(lo[a], b.box.min[a]);
    hi[a] = Math.max(hi[a], b.box.max[a]);
  }
}
console.log(`\n=== car world bounds (glTF, Y-up) ===`);
console.log(`  min ${r3(lo)}  max ${r3(hi)}`);
console.log(`  size ${r3(hi.map((v, a) => v - lo[a]))}`);

console.log("\n=== wheels: is the pivot at the wheel centre? ===");
const wheelRe = /wheel/i;
for (const b of all.filter((x) => wheelRe.test(x.name))) {
  const parent = parents.get(b.index);
  const parentName = parent === undefined ? "(root)" : nodes[parent].name;
  const pivot = worldMatrix(nodes, parents, b.index, cache).slice(12, 15);
  const offset = b.center.map((v, a) => v - pivot[a]);
  console.log(`\n  ${b.name} (parent ${parentName})`);
  console.log(`    node pivot (world)   ${r3(pivot)}`);
  console.log(`    mesh centre (world)  ${r3(b.center)}`);
  console.log(`    offset pivot->centre ${r3(offset)}   <-- non-zero means rotating this node swings the wheel`);
  console.log(`    wheel size           ${r3(b.size)}`);
  console.log(`    mesh-local bounds    min ${r3(meshBounds(g, b.index).min)} max ${r3(meshBounds(g, b.index).max)}`);

  // spin axis check: smallest world extent is the axle width direction
  const widths = b.size.map((v, a) => ({ axis: "XYZ"[a], v }));
  widths.sort((p, q) => p.v - q.v);
  console.log(`    smallest extent is ${widths[0].axis} (${round(widths[0].v)}) -> likely axle/width axis`);
}

console.log("\n=== body vs wheels separation (front/back, left/right) ===");
const body = all.find((b) => /body/i.test(b.name));
const wheels = all.filter((x) => wheelRe.test(x.name));
if (body) {
  console.log(`  body centre ${r3(body.center)}  size ${r3(body.size)}`);
  for (const w of wheels) {
    const d = w.center.map((v, a) => v - body.center[a]);
    console.log(`  ${w.name} relative to body: ${r3(d)}`);
  }
  console.log(`\n  NOTE: in the body's LOCAL space (before its own rotation/scale) the`);
  console.log(`  wheel nodes sit at:`);
  for (const w of wheels) {
    const node = nodes[w.index];
    console.log(`    ${w.name} local t=${r3(node.translation ?? [0, 0, 0])} parent=${JSON.stringify(nodes[parents.get(w.index)].name)}`);
  }
}
