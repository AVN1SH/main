// Focused diagnostic: step the race a second at a time and report every rival's
// state, so a launch problem can be read instead of guessed at.
(async () => {
  const g = window.game;
  const race = g.race;
  race.debugForceStart();
  race.debugStep(4.2); // countdown out, GO
  const rows = [];
  const snap = (t) => {
    rows.push({
      t,
      state: race.state,
      player: {
        x: +g.player.state.x.toFixed(2),
        z: +g.player.state.z.toFixed(2),
        speed: +g.player.state.speed.toFixed(2),
        headingDeg: +((g.player.state.heading * 180) / Math.PI).toFixed(0),
      },
      rivals: race.rivals.map((r) => ({
        name: r.name,
        x: +r.state.x.toFixed(2),
        z: +r.state.z.toFixed(2),
        speed: +r.state.speed.toFixed(2),
        headingDeg: +((r.state.heading * 180) / Math.PI).toFixed(0),
        target: r.debugInfo().target,
        blocker: r.debugInfo().blocker,
        shoved: r.shoved,
        shoveTime: +r.shove.time.toFixed(2),
        recover: +r.recover.toFixed(2),
        stuck: +r.stuckTime.toFixed(2),
        idle: +r.idleTime.toFixed(2),
        impacts: r.stats.impacts,
        recoveries: r.stats.recoveries,
        reseats: r.stats.reseats,
        total: +r.progress.total.toFixed(1),
      })),
    });
  };
  snap(0);
  for (let t = 2; t <= 16; t += 2) {
    race.debugStep(2);
    snap(t);
  }
  return {
    track: race.debugReport().track,
    laps: race.track.laps,
    grid: race.debugReport().grid,
    playerSlot: race.playerSlot,
    playerGrid: race.playerGridPose,
    frames: rows,
  };
})();
