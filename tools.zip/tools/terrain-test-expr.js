// Exercises the map collision + terrain following without the render loop.
//
// The player is stepped at a fixed dt (like physics-test-expr.js) and reports:
//   - what geometry got baked
//   - that the car climbs a ramp onto the elevated bridge instead of staying on
//     the ground beneath it
//   - that a building blocks it
//   - how far it drives along a real lane before touching anything
//
// Usage:
//   node tools/browser-probe.mjs --url "http://localhost:5174/?debug=1&frames=8" \
//     --expr-file=tools/terrain-test-expr.js
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { collision, player } = g;
  if (!collision) return "no collision model on window.game";
  const out = { stats: collision.stats };
  const dt = 1 / 60;

  // --- surface sampling somewhere flat, and on the elevated bridge ----------
  out.samples = {
    spawnGround: collision.groundAt(-169.8, 76.9, 0.2).y,
    bridgeDeck: collision.groundAt(-60, 75, 6.2).y,
    bridgeUnder: collision.groundAt(-60, 75, 0.1).kind,
  };

  const drive = (x, z, y, heading, frames) => {
    player.state.x = x;
    player.state.z = z;
    player.state.heading = heading;
    player.state.speed = 0;
    player.terrain.teleport(y);
    let maxY = -Infinity;
    let minY = Infinity;
    let blockedAt = null;
    for (let i = 0; i < frames; i++) {
      player.update(dt, { steer: 0, throttle: 1, brake: 0, handbrake: false });
      maxY = Math.max(maxY, player.state.y);
      minY = Math.min(minY, player.state.y);
      if (player.collided && !blockedAt) blockedAt = [+player.state.x.toFixed(1), +player.state.z.toFixed(1)];
    }
    return {
      x: +player.state.x.toFixed(1),
      z: +player.state.z.toFixed(1),
      y: +player.state.y.toFixed(2),
      minY: +minY.toFixed(2),
      maxY: +maxY.toFixed(2),
      pitch: +player.terrain.pitch.toFixed(3),
      blockedAt,
    };
  };

  // Drive at the west ramp of the elevated road (runs along X at z ~ 75).
  //
  // This used to report a climb to ~6 m: the car reached the deck by driving
  // THROUGH the ramp's leading face, because `road_c` was baked as a surface
  // only and the surface baker deliberately skips steep faces - so the ramp
  // wall and the barrier down each side were not solid at all. Those faces are
  // now solid, so the car is correctly stopped at the entrance. Climbing onto
  // the deck from the street was never a supported route anyway; the README
  // describes the high structure as a viaduct with no drivable connection.
  out.bridgeClimb = drive(-168, 75, collision.groundAt(-168, 75, 0.3).y ?? 0.1, Math.PI / 2, 700);
  out.bridgeClimb.entranceIsWalled = out.bridgeClimb.maxY < 1;

  // Drive straight at a building.
  let building = null;
  for (const mesh of g.scene.meshes) {
    if (mesh.name && /^(house_|hotel_|businesscenter|skyscraper)/i.test(mesh.name) && mesh.getTotalVertices() > 500) {
      building = mesh;
      break;
    }
  }
  if (building) {
    building.computeWorldMatrix(true);
    const bb = building.getBoundingInfo().boundingBox;
    const cx = bb.centerWorld.x;
    const cz = bb.centerWorld.z;
    const ex = bb.extendSizeWorld.x;
    const ez = bb.extendSizeWorld.z;
    // The walls are what block, not the (empty) interior, so probe the footprint
    // outline rather than the centre.
    let hits = 0;
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      if (collision.blockedAt(cx + Math.cos(a) * ex, cz + Math.sin(a) * ez, 0.4, 1.6)) hits++;
    }
    out.building = { name: building.name, x: +cx.toFixed(1), z: +cz.toFixed(1), wallHits: hits };
    out.buildingBlocks = hits > 0;
  }

  // Drive along a real traffic lane and see how far it gets before hitting.
  //
  // Use the RUNTIME lanes the cars actually follow (`traffic.routes`, built by
  // laneBuilder), not routes.json: those loops are legacy, and a couple of them
  // run straight across the lake, which is no longer drivable now that water is
  // baked solid.
  const route = g.traffic?.routes?.[0] ?? g.routeData.routes[0];
  const pts = route.points;
  const start = pts[0];
  player.reset();
  player.state.x = start.x;
  player.state.z = start.z;
  player.state.heading = Math.atan2(pts[1].x - start.x, pts[1].z - start.z);
  player.state.speed = 0;
  player.terrain.teleport(collision.groundAt(start.x, start.z, start.y + 0.2, { stepUp: 0.6, reach: 0.6 }).y ?? start.y);
  let moved = 0;
  let prevX = start.x;
  let prevZ = start.z;
  let firstHit = null;
  for (let i = 0; i < 3000; i++) {
    let bi = 0;
    let bd = Infinity;
    for (let k = 0; k < pts.length; k++) {
      const d = (pts[k].x - player.state.x) ** 2 + (pts[k].z - player.state.z) ** 2;
      if (d < bd) {
        bd = d;
        bi = k;
      }
    }
    const target = pts[(bi + 1) % pts.length];
    let diff = Math.atan2(target.x - player.state.x, target.z - player.state.z) - player.state.heading;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    player.update(dt, { steer: Math.max(-1, Math.min(1, -diff * 2)), throttle: 0.35, brake: 0, handbrake: false });
    moved += Math.hypot(player.state.x - prevX, player.state.z - prevZ);
    prevX = player.state.x;
    prevZ = player.state.z;
    if (player.collided && !firstHit) firstHit = [+player.state.x.toFixed(1), +player.state.z.toFixed(1)];
  }
  out.laneDrive = { movedM: +moved.toFixed(0), firstHit };

  player.reset();
  return JSON.stringify(out, null, 1);
})();
