// Steps the player's driving model at a fixed dt, so results do not depend on
// the render frame rate. Under software WebGL the game runs at well under
// 1 fps, which makes timing-based testing through the render loop useless.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const p = g.player;
  const rig = g.playerRig;
  const out = {};

  // These tests characterise the bicycle model on its own, so detach the map
  // collision for the duration: otherwise a car driving in a straight line out
  // of its spawn simply hits the bridge wall and the "top speed" result would
  // be measuring the map, not the model. Restored before returning.
  const savedTerrain = p.terrain;
  p.terrain = null;

  const sim = (frames, input, dt = 1 / 60) => {
    for (let i = 0; i < frames; i++) {
      p.update(dt, input);
      p.spin(dt);
    }
  };
  const straight = { steer: 0, throttle: 1, brake: 0, handbrake: false };
  const left = { steer: 1, throttle: 1, brake: 0, handbrake: false };
  const right = { steer: -1, throttle: 1, brake: 0, handbrake: false };
  const coast = { steer: 0, throttle: 0, brake: 0, handbrake: false };
  const brake = { steer: 0, throttle: 0, brake: 1, handbrake: false };

  // --- straight line ---
  p.reset();
  const h0 = p.state.heading;
  sim(180, straight); // 3 s
  out.straight = {
    speedKmh: +p.speedKmh.toFixed(1),
    headingDrift: +(p.state.heading - h0).toFixed(5),
    gear: p.gear,
  };

  // --- LEFT turn: heading must DECREASE ---
  const h1 = p.state.heading;
  sim(120, left); // 2 s
  out.leftTurn = {
    headingDelta: +(p.state.heading - h1).toFixed(4),
    steerAngle: +p.steerAngle.toFixed(4),
    speedKmh: +p.speedKmh.toFixed(1),
    bodyRoll: +p.roll.toFixed(4),
  };

  // --- RIGHT turn: heading must INCREASE ---
  const h2 = p.state.heading;
  sim(120, right);
  out.rightTurn = {
    headingDelta: +(p.state.heading - h2).toFixed(4),
    steerAngle: +p.steerAngle.toFixed(4),
    bodyRoll: +p.roll.toFixed(4),
  };

  // --- turning must depend on speed (turn radius grows with velocity) ---
  const turnRadius = (speed, frames) => {
    p.reset();
    p.state.speed = speed;
    const before = p.state.heading;
    sim(frames, { steer: 1, throttle: 1, brake: 0, handbrake: false });
    const dt = (frames / 60);
    const yawRate = (p.state.heading - before) / dt;
    return {
      speedKmh: +p.speedKmh.toFixed(1),
      steerAngle: +p.steerAngle.toFixed(4),
      radiusM: +Math.abs(yawRate) > 1e-6 ? +(Math.abs(p.state.speed / yawRate)).toFixed(1) : Infinity,
    };
  };
  out.radiusAtLowSpeed = turnRadius(6, 60);
  out.radiusAtHighSpeed = turnRadius(35, 60);

  // --- braking then coasting to rest ---
  p.reset();
  sim(300, straight);
  out.brakeFromKmh = +p.speedKmh.toFixed(1);
  sim(90, brake);
  out.afterBrakeKmh = +p.speedKmh.toFixed(1);
  sim(600, coast);
  out.afterCoastKmh = +p.speedKmh.toFixed(1);

  // --- reverse ---
  p.reset();
  sim(120, brake);
  out.reverse = { speed: +p.state.speed.toFixed(2), gear: p.gear };

  // --- top speed (60 s of full throttle) ---
  p.reset();
  sim(3600, straight);
  out.topSpeedKmh = +p.speedKmh.toFixed(1);

  // --- front wheels must steer, rear wheels must not ---
  p.reset();
  sim(120, left);
  const front = rig.wheels.find((w) => w.isFront);
  const rear = rig.wheels.find((w) => !w.isFront);
  out.wheelSteering = {
    frontPivotY: +front.steerPivot.rotation.y.toFixed(4),
    rearPivotY: +rear.steerPivot.rotation.y.toFixed(4),
    leftSteerAngle: +p.steerAngle.toFixed(4),
  };

  // --- wheels must roll while driving, and not while parked ---
  const spinBefore = +front.spinPivot.rotation.z.toFixed(4);
  p.reset();
  sim(120, straight);
  out.wheelSpin = {
    parkedBefore: spinBefore,
    afterDriving: +front.spinPivot.rotation.z.toFixed(4),
    radius: +rig.wheelRadius.toFixed(3),
  };

  // --- body attitude should be near zero when parked straight ---
  p.reset();
  sim(120, straight);
  out.bodyTiltStraight = { roll: +p.roll.toFixed(4), pitch: +p.pitch.toFixed(4) };
  p.reset();
  sim(150, left);
  out.bodyTiltTurning = { roll: +p.roll.toFixed(4), pitch: +p.pitch.toFixed(4) };

  p.reset();
  p.terrain = savedTerrain;
  p.reset();
  return JSON.stringify(out, null, 1);
})();
