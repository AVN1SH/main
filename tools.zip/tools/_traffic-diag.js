(async () => {
  const g = window.game, race = g.race, t = race.track;
  const vs = g.traffic ? g.traffic.vehicles : [];
  const same = vs.filter(v => v.path === t.path);
  const near = vs.filter(v => {
    let best = Infinity;
    for (let d = 0; d < t.path.length; d += 6) { const p = t.path.sample(d); const q = Math.hypot(p.x - v.state.x, p.z - v.state.z); if (q < best) best = q; }
    return best < 40;
  });
  return {
    total: vs.length,
    samePath: same.length,
    samePathNames: same.slice(0,8).map(v => v.name ?? v.asset?.spec?.label ?? '?'),
    nearCircuit: near.length,
    nearOnSamePath: near.filter(v => v.path === t.path).length,
    routeCount: g.traffic.routeCount,
    circuitId: t.id,
    routeIds: (g.traffic.routes||[]).map(r => r.id),
  };
})();
