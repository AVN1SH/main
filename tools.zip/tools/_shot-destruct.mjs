// Multi-frame capture around a live destruction, so the impact can be judged by
// eye instead of inferred from numbers. Like browser-probe, but it arms a run-up
// in the page and then screenshots the game as the loop plays it out.
//
// Usage:
//   node tools/_shot-destruct.mjs --family=fence --out=<dir> [--frames=8] [--gap=450]
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";

const argv = process.argv.slice(2);
const arg = (n, f) => {
  const hit = argv.find((a) => a.startsWith(`--${n}=`));
  return hit ? hit.slice(n.length + 3) : f;
};
const has = (n) => argv.includes(`--${n}`);
const FAMILY = arg("family", "fence");
const OUT = arg("out", "C:/Users/walsi/AppData/Local/Temp/opencode/shots");
const FRAMES = Number(arg("frames", 8));
const GAP = Number(arg("gap", 450));
const TIMEOUT = Number(arg("timeout", 300000));
const PORT = Number(arg("port", 9345));
const PAGE_URL = arg("url", "http://localhost:5173/?debug=1&frames=6");

const CHROME = [
  "C:/Program Files/Google/Chrome/Application/chrome.exe",
  "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
  `${process.env.LOCALAPPDATA}/Google/Chrome/Application/chrome.exe`,
].find((p) => existsSync(p));
if (!CHROME) throw new Error("chrome not found");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    this.onEvent = null;
    ws.addEventListener("message", (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id !== undefined) {
        const p = this.pending.get(m.id);
        if (p) {
          this.pending.delete(m.id);
          m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result);
        }
      } else if (this.onEvent) {
        // Without this an exception inside the render loop is invisible: the
        // loop dies, every sampled value freezes, and the run looks like a
        // physics problem rather than a crash.
        this.onEvent(m.method, m.params);
      }
    });
  }
  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((res, rej) => {
      this.pending.set(id, { resolve: res, reject: rej });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expression) {
    const r = await this.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description ?? "eval failed");
    return r.result.value;
  }
}

async function main() {
  mkdirSync(OUT, { recursive: true });
  const chrome = spawn(
    CHROME,
    [
      "--headless=new",
      "--disable-gpu",
      "--no-sandbox",
      "--enable-unsafe-swiftshader",
      "--use-angle=swiftshader",
      "--mute-audio",
      "--no-first-run",
      "--disable-extensions",
      "--disable-dev-shm-usage",
      `--remote-debugging-port=${PORT}`,
      `--user-data-dir=${(process.env.TEMP ?? "/tmp").replace(/\\/g, "/")}/chrome-shot-${PORT}`,
      "--window-size=1280,720",
      PAGE_URL,
    ],
    { stdio: "ignore" },
  );

  let target = null;
  const deadline = Date.now() + TIMEOUT;
  while (Date.now() < deadline && !target) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
      target = list.find((t) => t.type === "page" && t.webSocketDebuggerUrl);
    } catch {
      /* not up yet */
    }
    if (!target) await sleep(300);
  }
  if (!target) throw new Error("no debugging endpoint");

  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((res, rej) => {
    ws.addEventListener("open", res);
    ws.addEventListener("error", () => rej(new Error("ws failed")));
  });
  const cdp = new Cdp(ws);
  const errors = [];
  cdp.onEvent = (method, params) => {
    if (method === "Runtime.exceptionThrown") {
      errors.push(params.exceptionDetails?.exception?.description ?? params.exceptionDetails?.text);
    } else if (method === "Runtime.consoleAPICalled" && params.type === "error") {
      errors.push("console.error: " + params.args.map((a) => a.value ?? a.description).join(" "));
    }
  };
  await cdp.send("Runtime.enable");
  await cdp.send("Page.enable");

  while (Date.now() < deadline) {
    if (await cdp.eval("!!(document.getElementById('debug-out')?.dataset.ready === '1')")) break;
    await sleep(500);
  }

  const script = readFileSync(new URL("./_drive-destruct.js", import.meta.url), "utf8");
  const noPhysics = has("no-physics") ? "true" : "false";
  const armed = await cdp.eval(`(()=>{${script}\n})();`);
  console.log("install:", armed);
  console.log("arm:", await cdp.eval(`window.__arm(${JSON.stringify(FAMILY)}, ${noPhysics})`));

  const rows = [];
  for (let i = 0; i < FRAMES; i++) {
    await sleep(GAP);
    const state = await cdp.eval("window.__state()");
    const shot = await cdp.send("Page.captureScreenshot", { format: "png" });
    const file = `${OUT}/${FAMILY}-${String(i).padStart(2, "0")}.png`;
    writeFileSync(file, Buffer.from(shot.data, "base64"));
    rows.push({ i, file, state });
    console.log(`[${i}] ${state}`);
  }

  console.log("\nsummary:");
  if (errors.length) console.log("PAGE ERRORS:\n  " + errors.slice(0, 8).join("\n  "));
  for (const r of rows) {
    let s;
    try {
      s = JSON.parse(r.state);
    } catch {
      console.log(`  f${r.i}: ${r.state}`);
      continue;
    }
    console.log(
      `  f${r.i}: destroyed=${s.destroyed} moved=${s.movedM}m tilt=${s.tiltDeg}deg ` +
        `alive=${s.alive} restored=${s.restored} mass=${s.mass}`,
    );
  }

  ws.close();
  if (process.platform === "win32") spawn("taskkill", ["/F", "/T", "/PID", String(chrome.pid)], { stdio: "ignore" });
  else chrome.kill("SIGKILL");
}

main().catch((e) => {
  console.error("shot probe failed:", e.message);
  process.exitCode = 1;
});
