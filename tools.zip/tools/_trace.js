// Focused trace: arm, launch, then sample rivals every 2s.
(async () => {
  const g = window.game;
  const race = g.race;
  const track = race.track;
  const start = track.startDistance;
  // park player far away
  g.player.state.x = track.startPose.x + 1400;
  g.player.state.z = track.startPose.z + 1400;
  g.player.state.speed = 0;
  race.requestStart();
  race.debugStep(3.0);
  race.debugStep(1.2); // into racing
  const log = [];
  for (let t = 0; t <= 14; t += 2) {
    race.debugStep(2, 1/60, { autopilot: false });
    const row = race.rivals.map((r) => {
      const d = r.debugInfo();
      return `${r.name}: tot=${r.progress.total.toFixed(0)} spd=${d.speed} tgt=${d.target} blk=${d.blocker ? d.blocker.name+" g"+d.blocker.gap+" c"+d.blocker.closing : "nil"} st=${d.stuck} net=${d.net} w=${d.win}`;
    });
    log.push(`t=${t+4.2}s: ` + row.join(" | "));
  }
  return { trace: log };
})();
