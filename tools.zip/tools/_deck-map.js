// Map which lanes of each deck are actually drivable, using the car's real
// footprint. Prints a coarse ASCII grid: '#' sealed, '.' clear, ' ' no ground.
(() => {
  const g = window.game;
  const C = g.collision;
  const G = { halfLength: 2.15, halfWidth: 0.95, height: 1.42, clearance: 0.26 };
  const out = {};

  const decks = [
    { name: "road_c_02.003", minX: -6, maxX: 38, minZ: 64, maxZ: 87 },
    { name: "road_c_02.004", minX: -146, maxX: -102, minZ: 64, maxZ: 87 },
    { name: "road_c_04.002", minX: -328, maxX: -303, minZ: -7, maxZ: 15 },
  ];

  out.maps = [];
  for (const d of decks) {
    const cols = 26;
    const rows = 13;
    const lines = [];
    const blockers = new Map();
    for (let r = 0; r < rows; r++) {
      let line = "";
      const z = d.minZ + ((d.maxZ - d.minZ) * (r + 0.5)) / rows;
      for (let c = 0; c < cols; c++) {
        const x = d.minX + ((d.maxX - d.minX) * (c + 0.5)) / cols;
        const gy = C.groundAt(x, z, 16, { stepUp: 2.5, reach: 20 });
        if (!gy) { line += " "; continue; }
        const hits = [];
        const blocked = C.blockedRect(
          x, z, 0, G.halfLength, G.halfWidth,
          gy.y + G.clearance, gy.y + G.height, hits,
        );
        if (blocked) {
          line += "#";
          for (const hh of hits) {
            const k = `${hh.mesh}:${hh.kind}`;
            blockers.set(k, (blockers.get(k) ?? 0) + 1);
          }
        } else line += ".";
      }
      lines.push(line);
    }
    // Where are the signs sitting?
    const signs = g.destruction.objects
      .filter((o) => o.alive && o.family.id === "sign")
      .map((o) => ({
        x: +o.center.x.toFixed(1), z: +o.center.z.toFixed(1),
        h: +(o.halfX * 2).toFixed(1), hd: +(o.halfZ * 2).toFixed(1),
      }))
      .filter((o) =>
        o.x > d.minX - 6 && o.x < d.maxX + 6 && o.z > d.minZ - 6 && o.z < d.maxZ + 6);
    out.maps.push({
      deck: d.name,
      x: [d.minX, d.maxX], z: [d.minZ, d.maxZ],
      legend: "x across " + d.minX + "->" + d.maxX + " (left->right), rows z " + d.minZ + "->" + d.maxZ,
      grid: lines,
      blockers: [...blockers.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10),
      signsOnDeck: signs,
    });
  }
  return JSON.stringify(out, null, 1);
})();