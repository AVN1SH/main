// Temporary: is the bridge a CUT in the road graph? Flood-fill the roadway
// mask with and without the bridge cells and report connectivity.
(() => {
  const g = window.game;
  const C = g.collision;
  const { cols: cc, rows: cr, minX, minZ, cell: cs } = C;
  const N = cc * cr;
  const road = new Uint8Array(N);
  let roadCells = 0;
  for (let r = 0; r < cr; r++) {
    for (let c = 0; c < cc; c++) {
      const x = minX + (c + 0.5) * cs;
      const z = minZ + (r + 0.5) * cs;
      if (C.isRoadAt(x, z)) { road[r * cc + c] = 1; roadCells++; }
    }
  }
  const bridge = C.bridgeMask ? new Uint8Array(C.bridgeMask) : null;
  let bridgeCells = 0;
  if (bridge) for (let i = 0; i < N; i++) if (bridge[i]) bridgeCells++;

  // find the deck's X extent so we can pick a west and east seed.
  let bMinX = Infinity, bMaxX = -Infinity, bMinZ = Infinity, bMaxZ = -Infinity;
  if (bridge) {
    for (let r = 0; r < cr; r++) {
      for (let c = 0; c < cc; c++) {
        if (!bridge[r * cc + c]) continue;
        const x = minX + (c + 0.5) * cs;
        const z = minZ + (r + 0.5) * cs;
        if (x < bMinX) bMinX = x; if (x > bMaxX) bMaxX = x;
        if (z < bMinZ) bMinZ = z; if (z > bMaxZ) bMaxZ = z;
      }
    }
  }

  const flood = (blockBridge, sx, sz) => {
    const seen = new Uint8Array(N);
    const seedC = Math.floor((sx - minX) / cs);
    const seedR = Math.floor((sz - minZ) / cs);
    const stack = [];
    const push = (c, r) => {
      if (c < 0 || r < 0 || c >= cc || r >= cr) return;
      const i = r * cc + c;
      if (seen[i] || !road[i]) return;
      if (blockBridge && bridge && bridge[i]) return;
      seen[i] = 1;
      stack.push(i);
    };
    push(seedC, seedR);
    while (stack.length) {
      const i = stack.pop();
      const c = i % cc, r = (i / cc) | 0;
      push(c + 1, r); push(c - 1, r); push(c, r + 1); push(c, r - 1);
    }
    return seen;
  };

  const onEast = (seen, x) => {
    const c = Math.floor((x - minX) / cs);
    if (c < 0 || c >= cc) return false;
    for (let r = 0; r < cr; r++) if (seen[r * cc + c]) return true;
    return false;
  };

  // Seed on the WEST side of the deck (just left of bMinX) at deck Z.
  const deckZ = (bMinZ + bMaxZ) / 2;
  const westSeedX = bMinX - 6;
  const eastTargetX = bMaxX + 6;

  const withBridge = flood(false, westSeedX, deckZ);
  const noBridge = flood(true, westSeedX, deckZ);

  // count road cells on the east side reachable only when the bridge is open
  let eastWith = 0, eastWithout = 0;
  if (withBridge) { const s = flood(false, eastTargetX, deckZ); for (let i = 0; i < N; i++) if (s[i]) eastWith++; }
  if (noBridge) { /* west component size */ }

  const out = {
    roadCells, bridgeCells,
    deck: { bMinX: +bMinX.toFixed(1), bMaxX: +bMaxX.toFixed(1), bMinZ: +bMinZ.toFixed(1), bMaxZ: +bMaxZ.toFixed(1), deckZ: +deckZ.toFixed(1) },
    westSeed: { x: +westSeedX.toFixed(1), z: +deckZ.toFixed(1) },
    eastTarget: { x: +eastTargetX.toFixed(1), z: +deckZ.toFixed(1) },
    westCanReachEastWithBridge: onEast(withBridge, eastTargetX),
    westCanReachEastWithoutBridge: onEast(noBridge, eastTargetX),
    bridgeIsCut: onEast(withBridge, eastTargetX) && !onEast(noBridge, eastTargetX),
  };
  return JSON.stringify(out, null, 1);
})();
