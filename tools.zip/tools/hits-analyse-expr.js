// For every recorded contact, measure how far the blocking point is from the
// source mesh's REAL triangles.
//
// The bake uses two routes: big meshes contribute their steep wall triangles
// (so a contact is genuinely on the mesh), while small meshes contribute their
// world bounding box (a rectangle, which can cover empty space). Contacts from
// the second route are the suspicious ones, so this checks whether the car was
// really touching anything or was stopped by a box with nothing in it.
(() => {
  try {
    const g = window.game;
    if (!g) return "no window.game";
    const d = g.hitDebug;
    if (!d) return "overlay not enabled (needs ?hits=1)";

    const dt = 1 / 60;
    for (let f = 0; f < 1800; f++) {
      g.traffic.update(dt);
      g.player.update(dt, g.input);
      d.update(dt);
    }

    /** Distance from (x,z) to the mesh's real triangles in plan view. 0 = on it. */
    const distToMesh = (mesh, x, z) => {
      const m = mesh.getWorldMatrix().m;
      const pos = mesh.getVerticesData("position");
      if (!pos) return null;
      const idx = mesh.getIndices();
      const n = idx ? idx.length / 3 : pos.length / 9;
      let best = Infinity;
      const seg = (x0, z0, x1, z1) => {
        const dx = x1 - x0;
        const dz = z1 - z0;
        const L2 = dx * dx + dz * dz;
        let t = L2 > 0 ? ((x - x0) * dx + (z - z0) * dz) / L2 : 0;
        t = Math.max(0, Math.min(1, t));
        return Math.hypot(x - (x0 + t * dx), z - (z0 + t * dz));
      };
      for (let t = 0; t < n; t++) {
        const a = idx ? idx[t * 3] : t * 3;
        const b = idx ? idx[t * 3 + 1] : t * 3 + 1;
        const c = idx ? idx[t * 3 + 2] : t * 3 + 2;
        const ax = m[0] * pos[a * 3] + m[4] * pos[a * 3 + 1] + m[8] * pos[a * 3 + 2] + m[12];
        const az = m[2] * pos[a * 3] + m[6] * pos[a * 3 + 1] + m[10] * pos[a * 3 + 2] + m[14];
        const bx = m[0] * pos[b * 3] + m[4] * pos[b * 3 + 1] + m[8] * pos[b * 3 + 2] + m[12];
        const bz = m[2] * pos[b * 3] + m[6] * pos[b * 3 + 1] + m[10] * pos[b * 3 + 2] + m[14];
        const cx = m[0] * pos[c * 3] + m[4] * pos[c * 3 + 1] + m[8] * pos[c * 3 + 2] + m[12];
        const cz = m[2] * pos[c * 3] + m[6] * pos[c * 3 + 1] + m[10] * pos[c * 3 + 2] + m[14];
        const w0 = (bx - ax) * (z - az) - (bz - az) * (x - ax);
        const w1 = (cx - bx) * (z - bz) - (cz - bz) * (x - bx);
        const w2 = (ax - cx) * (z - cz) - (az - cz) * (x - cx);
        if ((w0 >= 0 && w1 >= 0 && w2 >= 0) || (w0 <= 0 && w1 <= 0 && w2 <= 0)) return 0;
        const dd = Math.min(seg(ax, az, bx, bz), seg(bx, bz, cx, cz), seg(cx, cz, ax, az));
        if (dd < best) best = dd;
      }
      return best;
    };

    // A contact is recorded at the obstacle cell's CENTRE, which can sit up to
    // ~0.35 m (half a diagonal of a 0.5 m cell) from the surface the car
    // actually touches. So a small positive distance is that sampling offset,
    // not a phantom. Only well beyond it is the car being stopped by empty air.
    const PHANTOM_M = 0.6;

    // Sample distinct spots from the raw log so one car grinding a wall for ten
    // seconds does not swamp the statistics.
    const seen = new Set();
    const picked = [];
    for (const h of d.raw) {
      if (!h.meshRef) continue;
      const key = `${h.mesh}@${Math.round(h.x)},${Math.round(h.z)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      picked.push(h);
    }

    const dists = [];
    const perMesh = new Map();
    let phantom = 0;
    let worst = [];
    for (const h of picked) {
      const dd = distToMesh(h.meshRef, h.x, h.z);
      if (dd === null) continue;
      dists.push(dd);
      if (dd > PHANTOM_M) {
        phantom++;
        worst.push({ mesh: h.mesh, d: +dd.toFixed(2), x: Math.round(h.x), z: Math.round(h.z) });
      }
      const m = perMesh.get(h.mesh) ?? { n: 0, max: 0, bucket: h.bucket };
      m.n++;
      m.max = Math.max(m.max, dd);
      perMesh.set(h.mesh, m);
    }

    dists.sort((a, b) => a - b);
    const q = (f) => (dists.length ? +dists[Math.floor(dists.length * f)].toFixed(2) : null);
    const byMesh = [...perMesh.entries()]
      .sort((a, b) => b[1].n - a[1].n)
      .slice(0, 16)
      .map(
        ([name, m]) =>
          `  ${m.bucket === "aabb" ? "AABB " : "TRI  "} n=${String(m.n).padStart(3)} maxDist=${m.max.toFixed(2)}m  ${name}`,
      );

    return JSON.stringify(
      {
        tally: d.tally,
        note: `distinct contacts: distance from the blocking cell centre to the source mesh's real triangles (phantom = >${PHANTOM_M} m)`,
        sampled: dists.length,
        phantom: `${phantom}/${dists.length}`,
        distanceToMesh: {
          median: q(0.5),
          p90: q(0.9),
          p99: q(0.99),
          max: dists.length ? +dists[dists.length - 1].toFixed(2) : null,
        },
        byMesh,
        worstOffMesh: worst.sort((a, b) => b.d - a.d).slice(0, 10),
      },
      null,
      1,
    );
  } catch (e) {
    return "ERR " + e.message + "\n" + e.stack;
  }
})();
