// Long-run traffic behaviour test.
//
// Steps the whole traffic system at a fixed dt (independent of render rate)
// and measures, per vehicle:
//   - fraction of samples ON roadway (the mask) and on drivable surface
//   - fraction of samples physically blocked (inside a building's columns)
//   - whether a vehicle crossed the bridge (max height > 3 m)
//   - stuck time (boxed-in recovery use)
// plus a full-surface summary. A healthy system has ~100% roadway, ~0%
// blocked, and bridge cars present if the bridge loop exists.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision, routeData } = g;
  if (!traffic) return "no traffic";
  const c = collision;
  const dt = 1 / 60;
  const FRAMES = 3600; // one simulated minute

  const per = traffic.vehicles.map((v, i) => ({
    i,
    samples: 0,
    onRoadway: 0,
    onSurface: 0,
    blocked: 0,
    stuck: 0,
    maxY: -Infinity,
    minY: Infinity,
    dist: 0,
    prev: { x: v.state.x, z: v.state.z },
  }));

  for (let f = 0; f < FRAMES; f++) {
    traffic.update(dt);
    if (f % 10 !== 0) continue; // sample every 10th frame
    for (let i = 0; i < traffic.vehicles.length; i++) {
      const v = traffic.vehicles[i];
      const s = per[i];
      s.samples++;
      s.dist += Math.hypot(v.state.x - s.prev.x, v.state.z - s.prev.z);
      s.prev.x = v.state.x;
      s.prev.z = v.state.z;
      if (c.isRoadAt(v.state.x, v.state.z)) s.onRoadway++;
      const r = c.groundAt(v.state.x, v.state.z, v.state.y + 1, { stepUp: 3, reach: 4 });
      if (r.kind === "ground") s.onSurface++;
      if (v.terrain && v.terrain.blocked(v.state.x, v.state.z, v.state.heading)) s.blocked++;
      if (v.stuckTime > 0.5) s.stuck++;
      s.maxY = Math.max(s.maxY, v.state.y);
      s.minY = Math.min(s.minY, v.state.y);
    }
  }

  const pct = (n, d) => (d ? +((100 * n) / d).toFixed(1) : 0);
  let sum = { onRoadway: 0, onSurface: 0, blocked: 0, stuck: 0, samples: 0 };
  const cars = per.map((s) => {
    sum.onRoadway += s.onRoadway;
    sum.onSurface += s.onSurface;
    sum.blocked += s.blocked;
    sum.stuck += s.stuck;
    sum.samples += s.samples;
    return {
      i: s.i,
      roadPct: pct(s.onRoadway, s.samples),
      surfPct: pct(s.onSurface, s.samples),
      blockedPct: pct(s.blocked, s.samples),
      stuckPct: pct(s.stuck, s.samples),
      climbed: s.maxY > 3,
      maxY: +s.maxY.toFixed(1),
      movedM: +s.dist.toFixed(0),
    };
  });

  // nearest building mesh, to sanity check the blocked test still bites
  let buildingBlocked = 0;
  for (const m of g.scene.meshes) {
    if (m.name && /^(house_|hotel_|businesscenter)/i.test(m.name)) {
      m.computeWorldMatrix(true);
      const bb = m.getBoundingInfo().boundingBox;
      buildingBlocked = c.blockedAt(bb.centerWorld.x, bb.centerWorld.z, 0.4, 1.6) ? 1 : 0;
      break;
    }
  }

  // store a screenshot-friendly final state
  window.__trafficTest = cars;

  return JSON.stringify(
    {
      frames: FRAMES,
      bridgeFound: traffic.bridgeFound,
      laneStats: traffic.laneStats,
      plan: traffic.plan,
      totals: {
        roadPct: pct(sum.onRoadway, sum.samples),
        surfPct: pct(sum.onSurface, sum.samples),
        blockedPct: pct(sum.blocked, sum.samples),
        stuckPct: pct(sum.stuck, sum.samples),
      },
      buildingStillBlocks: !!buildingBlocked,
      bridgeCars: cars.filter((v) => v.climbed).length,
      worst: [...cars].sort((a, b) => a.roadPct - b.roadPct).slice(0, 5),
      staleBandCheck: {
        oldSpawnOnRoad: c.isRoadAt(routeData.playerSpawn.x, routeData.playerSpawn.z),
      },
    },
    null,
    1,
  );
})();
