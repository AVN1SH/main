// Map-wide check of the collision grid: for solid cells that were marked from a
// mesh's BOUNDING BOX, how far is the cell from that mesh's real triangles?
//
// This is the direct test of "does collision happen outside the mesh?". It
// samples the grid rather than observed contacts, so it covers the whole town
// instead of wherever traffic happened to drive.
(() => {
  try {
    const g = window.game;
    if (!g) return "no window.game";
    const c = g.collision;
    if (!c.obstacleSource) return "provenance not tracked (needs ?hits=1)";

    const distToMesh = (mesh, x, z) => {
      const m = mesh.getWorldMatrix().m;
      const pos = mesh.getVerticesData("position");
      if (!pos) return null;
      const idx = mesh.getIndices();
      const n = idx ? idx.length / 3 : pos.length / 9;
      let best = Infinity;
      const seg = (x0, z0, x1, z1) => {
        const dx = x1 - x0;
        const dz = z1 - z0;
        const L2 = dx * dx + dz * dz;
        let t = L2 > 0 ? ((x - x0) * dx + (z - z0) * dz) / L2 : 0;
        t = Math.max(0, Math.min(1, t));
        return Math.hypot(x - (x0 + t * dx), z - (z0 + t * dz));
      };
      for (let t = 0; t < n; t++) {
        const a = idx ? idx[t * 3] : t * 3;
        const b = idx ? idx[t * 3 + 1] : t * 3 + 1;
        const cc = idx ? idx[t * 3 + 2] : t * 3 + 2;
        const ax = m[0] * pos[a * 3] + m[4] * pos[a * 3 + 1] + m[8] * pos[a * 3 + 2] + m[12];
        const az = m[2] * pos[a * 3] + m[6] * pos[a * 3 + 1] + m[10] * pos[a * 3 + 2] + m[14];
        const bx = m[0] * pos[b * 3] + m[4] * pos[b * 3 + 1] + m[8] * pos[b * 3 + 2] + m[12];
        const bz = m[2] * pos[b * 3] + m[6] * pos[b * 3 + 1] + m[10] * pos[b * 3 + 2] + m[14];
        const cx = m[0] * pos[cc * 3] + m[4] * pos[cc * 3 + 1] + m[8] * pos[cc * 3 + 2] + m[12];
        const cz = m[2] * pos[cc * 3] + m[6] * pos[cc * 3 + 1] + m[10] * pos[cc * 3 + 2] + m[14];
        const w0 = (bx - ax) * (z - az) - (bz - az) * (x - ax);
        const w1 = (cx - bx) * (z - bz) - (cz - bz) * (x - bx);
        const w2 = (ax - cx) * (z - cz) - (az - cz) * (x - cx);
        if ((w0 >= 0 && w1 >= 0 && w2 >= 0) || (w0 <= 0 && w1 <= 0 && w2 <= 0)) return 0;
        const dd = Math.min(seg(ax, az, bx, bz), seg(bx, bz, cx, cz), seg(cx, cz, ax, az));
        if (dd < best) best = dd;
      }
      return best;
    };

    // Half a cell diagonal: beyond this a cell centre is unambiguously not on
    // the mesh, so the cell is a phantom regardless of the tolerance debate.
    const PHANTOM_M = 0.36;

    // Collect candidate cells: every AABB-marked cell, grouped by source mesh.
    const byMesh = new Map();
    let aabbCells = 0;
    let triangleCells = 0;
    for (let i = 0; i < c.obstacleMask.length; i++) {
      if (!c.obstacleMask[i]) continue;
      if (c.obstacleKind[i] === 2) triangleCells++;
      else aabbCells++;
    }
    for (let i = 0; i < c.obstacleMask.length; i++) {
      if (!c.obstacleMask[i] || c.obstacleKind[i] !== 1) continue;
      const src = c.obstacleSource[i];
      if (!src) continue;
      const col = i % c.oCols;
      const row = Math.floor(i / c.oCols);
      const x = c.minX + (col + 0.5) * c.obstacleCell;
      const z = c.minZ + (row + 0.5) * c.obstacleCell;
      if (!byMesh.has(src)) byMesh.set(src, []);
      byMesh.get(src).push([x, z]);
    }

    const entries = [...byMesh.entries()].sort((a, b) => b[1].length - a[1].length);
    const out = [];
    const all = [];
    let checkedCells = 0;
    for (const [src, pts] of entries) {
      const solid = c.solidMeshes[src - 1];
      // A handful of cells per mesh is enough; these meshes are small boxes.
      const take = pts.length <= 6 ? pts : pts.filter((_, i) => i % Math.ceil(pts.length / 6) === 0);
      let far = 0;
      let maxD = 0;
      for (const [x, z] of take) {
        const dd = distToMesh(solid.mesh, x, z);
        if (dd === null) continue;
        checkedCells++;
        all.push(dd);
        if (dd > maxD) maxD = dd;
        if (dd > PHANTOM_M) far++;
      }
      if (far > 0) {
        out.push(
          `  ${solid.mesh.name}: ${far}/${take.length} cells off-mesh, max ${maxD.toFixed(2)}m ` +
            `(box ${(solid.box.maxX - solid.box.minX).toFixed(1)}x${(solid.box.maxY - solid.box.minY).toFixed(1)}x${(
              solid.box.maxZ - solid.box.minZ
            ).toFixed(1)}m, ${pts.length} cells)`,
        );
      }
    }

    all.sort((a, b) => a - b);
    const q = (f) => (all.length ? +all[Math.floor(all.length * f)].toFixed(2) : null);
    const phantoms = all.filter((v) => v > PHANTOM_M).length;

    return JSON.stringify(
      {
        grid: { aabbCells, triangleCells, totalSolid: aabbCells + triangleCells },
        note: `AABB-marked cells vs their source mesh's triangles; phantom threshold ${PHANTOM_M} m (half a cell diagonal)`,
        meshesWithABBCells: byMesh.size,
        cellsChecked: checkedCells,
        phantomCells: `${phantoms}/${all.length}`,
        distanceToMesh: { median: q(0.5), p90: q(0.9), p99: q(0.99), max: all.length ? +all[all.length - 1].toFixed(2) : null },
        worstMeshes: out.sort().slice(0, 25),
      },
      null,
      1,
    );
  } catch (e) {
    return "ERR " + e.message + "\n" + e.stack;
  }
})();
