// Map the real blocked footprint around the wall, and check pickability.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { collision: c } = g;
  const out = {};

  const sign = g.scene.meshes.find((m) => m.name === "streetsigns.034");
  if (sign) {
    sign.computeWorldMatrix(true);
    const bb = sign.getBoundingInfo().boundingBox;
    out.sign = {
      cls: sign.getClassName(),
      isPickable: sign.isPickable,
      isVisible: sign.isVisible,
      isEnabled: sign.isEnabled(),
      verts: sign.getTotalVertices(),
      hasPos: !!sign.getVerticesData("position"),
      aabb: {
        x: [+bb.minimumWorld.x.toFixed(2), +bb.maximumWorld.x.toFixed(2)],
        y: [+bb.minimumWorld.y.toFixed(2), +bb.maximumWorld.y.toFixed(2)],
        z: [+bb.minimumWorld.z.toFixed(2), +bb.maximumWorld.z.toFixed(2)],
      },
    };
    // where does its ACTUAL geometry sit in plan view?
    const m = sign.getWorldMatrix().m;
    const pos = sign.getVerticesData("position");
    let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (let i = 0; i < pos.length; i += 3) {
      const x = m[0] * pos[i] + m[4] * pos[i + 1] + m[8] * pos[i + 2] + m[12];
      const z = m[2] * pos[i] + m[6] * pos[i + 1] + m[10] * pos[i + 2] + m[14];
      if (x < x0) x0 = x;
      if (x > x1) x1 = x;
      if (z < z0) z0 = z;
      if (z > z1) z1 = z;
    }
    out.sign.realGeometry = { x: [+x0.toFixed(2), +x1.toFixed(2)], z: [+z0.toFixed(2), +z1.toFixed(2)] };
    out.sign.bboxAgrees = Math.abs(x0 - bb.minimumWorld.x) < 0.01;
  }

  // how many meshes are pickable at all?
  let pickable = 0;
  for (const m of g.scene.meshes) if (m.isPickable) pickable++;
  out.pickable = `${pickable}/${g.scene.meshes.length}`;

  // obstacle mask map at 0.5 m: x 294..299, z 62..78
  const oc = 0.5;
  let map = "obstacleMask (cell 0.5m) '#'=solid, digits=how many z-cells at this x\n";
  map += "  x:   ";
  for (let x = 294; x <= 299; x += oc) map += String(Math.round(x * 2) % 10);
  map += "\n";
  for (let z = 62; z <= 78; z += oc) {
    map += `z${z.toFixed(1).padStart(5)} `;
    for (let x = 294; x <= 299; x += oc) {
      const i = c._obstacleCell(x + 0.001, z + 0.001);
      map += i >= 0 && c.obstacleMask[i] ? " #" : " .";
    }
    map += "\n";
  }
  out.maskMap = map;

  // and the road mask at the same place
  let rmap = "roadMask (cell " + c.cell + "m)\n";
  for (let z = 62; z <= 78; z += c.cell) {
    rmap += `z${z.toFixed(1).padStart(5)} `;
    for (let x = 294; x <= 299; x += c.cell) {
      rmap += c.isRoadAt(x + 0.001, z + 0.001) ? " #" : " .";
    }
    rmap += "\n";
  }
  out.roadMap = rmap;

  return JSON.stringify(out, null, 1);
})();
