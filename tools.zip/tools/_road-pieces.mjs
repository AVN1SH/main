// Extract every drivable road/bridge piece's world AABB from the GLB to JSON.
// Accessor min/max survive Draco, and the kit tiles are axis-aligned, so these
// AABBs are exact footprints even though the geometry itself cannot be decoded.
import { writeFileSync } from "node:fs";
import { loadGlb, meshBounds, worldMatrix, transformAabb, round } from "./glb.mjs";

const file = process.argv[2] ?? "public/assets/map.glb";
const outFile = process.argv[3] ?? "tools/road-pieces.json";
const filter = /^(road_|bridge_a)/i;

const { g, nodes, parents } = loadGlb(file);
const cache = new Map();
const pieces = [];
nodes.forEach((node, i) => {
  if (!node.name || !filter.test(node.name)) return;
  const b = meshBounds(g, i);
  if (!b) return;
  const wm = worldMatrix(nodes, parents, i, cache);
  const box = transformAabb(wm, b.min, b.max);
  // world matrix column 0 gives the tile's local +X axis in world space
  const yaw = Math.atan2(wm[2], wm[0]);
  pieces.push({
    name: node.name,
    family: node.name.replace(/\.\d+$/, ""),
    minX: round(box.min[0]),
    maxX: round(box.max[0]),
    minY: round(box.min[1]),
    maxY: round(box.max[1]),
    minZ: round(box.min[2]),
    maxZ: round(box.max[2]),
    yaw: round(yaw),
  });
});
pieces.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
writeFileSync(outFile, JSON.stringify(pieces, null, 1));
console.log(`wrote ${pieces.length} pieces to ${outFile}`);
