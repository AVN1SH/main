// Runs traffic with the collision overlay on and reports where hits land,
// split by whether the blocking cell is backed by a real triangle.
(() => {
  try {
    const g = window.game;
    if (!g) return "no window.game";
    const d = g.hitDebug;
    if (!d) return "overlay not enabled (needs ?hits=1)";

    const dt = 1 / 60;
    for (let f = 0; f < 1800; f++) {
      g.traffic.update(dt);
      g.player.update(dt, g.input);
      d.update(dt);
    }

    const byMesh = new Map();
    for (const h of d.hits) {
      if (!h.mesh) continue;
      const k = `${h.mesh}|${h.bucket}`;
      byMesh.set(k, (byMesh.get(k) ?? 0) + 1);
    }
    const rows = [...byMesh.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20)
      .map(([k, n]) => {
        const [mesh, bucket] = k.split("|");
        return `  ${bucket === "aabb" ? "AABB-ONLY" : "triangle"}  ${String(n).padStart(4)}  ${mesh}`;
      });

    return JSON.stringify(
      {
        tally: d.tally,
        tracked: d.hits.length,
        markersDrawn: d.marker.thinInstanceCount,
        boxesDrawn: d.boxes.filter((b) => b.isEnabled()).length,
        topSources: rows,
      },
      null,
      1,
    );
  } catch (e) {
    return "ERR " + e.message + "\n" + e.stack;
  }
})();
