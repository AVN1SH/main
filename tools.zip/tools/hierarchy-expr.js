(() => {
  const rig = window.game?.playerRig;
  if (!rig) return "no rig";
  const lines = [];
  const f = (v) => (v ? `(${v.x?.toFixed(3)},${v.y?.toFixed(3)},${v.z?.toFixed(3)})` : "-");
  const walk = (node, depth) => {
    const cls = node.getClassName();
    const local = node.position ? f(node.position) : "-";
    const abs = node.absolutePosition ? f(node.absolutePosition) : "-";
    const absS = node.absoluteScaling ? f(node.absoluteScaling) : "-";
    const meshInfo = node.getTotalVertices ? ` verts=${node.getTotalVertices()}` : "";
    lines.push(
      `${"  ".repeat(depth)}${node.name} [${cls}] local=${local} abs=${abs} absScale=${absS}${meshInfo}`,
    );
    for (const c of node.getChildren()) walk(c, depth + 1);
  };
  walk(rig.root, 0);
  lines.push("");
  lines.push(`root.pos=${f(rig.root.position)} heading=${rig.root.rotation.y.toFixed(3)}`);
  lines.push(`wheel parents: ${rig.wheels.map((w) => `${w.name}->${w.mesh.parent?.name}`).join(", ")}`);
  lines.push(
    `hub absScale=${f(rig.wheelHub.absoluteScaling)} abs=${f(rig.wheelHub.absolutePosition)}`,
  );
  lines.push(`bodyTilt absScale=${f(rig.bodyTilt.absoluteScaling)}`);
  return lines.join("\n");
})();
