// Installed in the page by _shot-destruct.mjs. Finds a prop of a given family
// that the player's own sweep actually blocks, parks the car on a run-up to it
// at speed, and exposes the prop's live state for frame-by-frame sampling.
(() => {
  const g = window.game;
  const d = g.destruction;
  const player = g.player;

  const pick = (familyId) => {
    // Water bodies are baked as solid barriers, so a run-up that crosses a lake
    // parks the car in the river and never reaches the prop. `groundAt` cannot
    // see this - the water's own surface is a legal "ground" answer - so the
    // run-up is rejected against the water meshes' own world bounds.
    const water = g.scene.meshes
      .filter((m) => /^water/i.test(m.name ?? ""))
      .map((m) => m.getBoundingInfo().boundingBox);
    const inWater = (x, z) =>
      water.some(
        (b) => x > b.minimumWorld.x && x < b.maximumWorld.x && z > b.minimumWorld.z && z < b.maximumWorld.z,
      );

    const list = d.objects.filter((o) => o.alive && (!familyId || o.family.id === familyId));
    for (const o of list) {
      for (let ai = 0; ai < 24; ai++) {
        const h = (ai / 24) * Math.PI * 2;
        const fx = Math.sin(h);
        const fz = Math.cos(h);
        for (const dist of [16, 12, 20, 9, 26]) {
          const px = o.center.x - fx * dist;
          const pz = o.center.z - fz * dist;
          // No step of the run-up may be over water.
          let ok = true;
          for (let s = 0; s <= dist && ok; s += 1) ok = !inWater(px + fx * s, pz + fz * s);
          if (!ok) continue;
          // Prefer a run-up that is mostly roadway, so the prop is genuinely
          // roadside rather than a thing in a back garden.
          let road = 0;
          for (let s = 0; s <= dist; s += 2) if (g.collision.isRoadAt(px + fx * s, pz + fz * s)) road++;
          if (road < dist / 2 / 2) continue;
          // The run-up itself must be clear, otherwise the car starts wedged.
          if (player.terrain.sweep(px - fx, pz - fz, px, pz, h).blocked) continue;
          // ...and driving on from there must be blocked, which is what makes
          // this a real collision rather than a proximity trigger.
          if (!player.terrain.sweep(px, pz, px + fx * 7, pz + fz * 7, h).blocked) continue;
          return { o, h, px, pz, dist };
        }
      }
    }
    return null;
  };

  // Software WebGL runs at a few frames a second and the loop clamps dt to
  // 0.05 s, so the car would coast to a stop before it ever reached the prop.
  // Pinning the speed each frame makes it a sustained run-in instead.
  window.__pin = () => {
    if (window.__pinObs) g.scene.onBeforeRenderObservable.remove(window.__pinObs);
    window.__pinObs = g.scene.onBeforeRenderObservable.add(() => {
      const p = window.__target;
      if (!p || d.stats.destroyed > window.__d0) return;
      player.state.speed = 24;
    });
    return "pinned";
  };

  window.__arm = (familyId, noPhysics) => {
    const p = pick(familyId);
    if (!p) return "NO_TARGET";
    // Exercises the built-in integrator instead of Havok, which is the path
    // taken when the wasm is blocked.
    if (noPhysics) {
      d.physicsReady = false;
      d.stats.physics = false;
    }
    window.__target = p;
    const y = g.collision.groundAt(p.px, p.pz, 6, { stepUp: 3, reach: 6 })?.y ?? p.o.box.minY;
    player.state.x = p.px;
    player.state.y = y;
    player.state.z = p.pz;
    player.state.heading = p.h;
    player.state.speed = 24;
    player.sync();
    g.chase.snap();
    window.__d0 = d.stats.destroyed;
    window.__r0 = d.stats.restored;
    window.__pin();
    return JSON.stringify({
      mesh: p.o.mesh.name,
      family: p.o.family.id,
      behavior: p.o.family.behavior,
      dist: p.dist,
      headingDeg: Math.round((p.h * 180) / Math.PI),
      carY: +y.toFixed(2),
    });
  };

  window.__state = () => {
    const p = window.__target;
    if (!p) return "NO_TARGET";
    const o = p.o;
    const m = o.mesh;
    m.computeWorldMatrix(true);
    const w = m.getAbsolutePosition();
    // Tilt from the WORLD matrix rather than `mesh.rotationQuaternion`: the
    // fallback integrator rotates the reaction pivot and leaves the mesh's own
    // transform at identity, so reading the mesh alone reports zero there.
    // Rows 1-3 of a Babylon matrix are the transformed local axes, so the
    // prop's own up axis is (m[4], m[5], m[6]) and its tilt is the angle that
    // axis makes with world up.
    const wm = m.getWorldMatrix().m;
    const len = Math.hypot(wm[4], wm[5], wm[6]) || 1;
    const cos = Math.max(-1, Math.min(1, wm[5] / len));
    const tilt = Math.acos(cos) * 57.2958;
    const car = player.state;
    return JSON.stringify({
      destroyed: d.stats.destroyed - window.__d0,
      restored: d.stats.restored - window.__r0,
      alive: o.alive,
      vis: m.isVisible,
      enabled: m.isEnabled(),
      car: [+car.x.toFixed(2), +car.z.toFixed(2), +car.speed.toFixed(1)],
      prop: [+w.x.toFixed(2), +w.y.toFixed(2), +w.z.toFixed(2)],
      movedM: +Math.hypot(w.x - o.center.x, w.z - o.center.z).toFixed(2),
      tiltDeg: +tilt.toFixed(1),
      mode: o.state?.mode ?? null,
      mass: o.state?.mass != null ? +o.state.mass.toFixed(1) : null,
      name: m.name,
    });
  };

  return "OK";
})();
