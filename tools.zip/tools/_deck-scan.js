// Walk each deck centreline using the CAR's real footprint (blockedRect), and
// report the sealed spans plus the exact cell height ranges and source meshes.
(() => {
  const g = window.game;
  const C = g.collision;
  const G = { halfLength: 2.15, halfWidth: 0.95, height: 1.42, clearance: 0.26 };
  const out = {};

  const decks = [
    { name: "road_c_02.003", axis: "x", lo: -6, hi: 38, cross: 75.4, h: 0 },
    { name: "road_c_02.003", axis: "x", lo: -6, hi: 38, cross: 75.4, h: Math.PI },
    { name: "road_c_02.004", axis: "x", lo: -146, hi: -102, cross: 75.4, h: 0 },
    { name: "road_c_02.004", axis: "x", lo: -146, hi: -102, cross: 75.4, h: Math.PI },
    { name: "road_c_04.002", axis: "x", lo: -328, hi: -303, cross: 3.9, h: 0 },
    { name: "road_c_04.002", axis: "x", lo: -328, hi: -303, cross: 3.9, h: Math.PI },
  ];

  out.decks = [];
  for (const d of decks) {
    const steps = [];
    const N = Math.round((d.hi - d.lo) / 0.5);
    const spans = [];
    let cur = null;
    for (let i = 0; i <= N; i++) {
      const p = d.lo + ((d.hi - d.lo) * i) / N;
      const x = d.axis === "x" ? p : d.cross;
      const z = d.axis === "x" ? d.cross : p;
      const gy = C.groundAt(x, z, 14, { stepUp: 2, reach: 18 });
      if (!gy) { steps.push({ p: +p.toFixed(1), surf: null }); continue; }
      const surf = gy.y;
      const hits = [];
      const blocked = C.blockedRect(
        x, z, d.h, G.halfLength, G.halfWidth,
        surf + G.clearance, surf + G.height, hits,
      );
      const by = [...new Set(hits.map((hh) => hh.mesh))];
      steps.push({
        p: +p.toFixed(1), surf: +surf.toFixed(2), blocked,
        by: by.length ? by : null,
        detail: hits.length
          ? hits.slice(0, 3).map((hh) => ({
              m: hh.mesh, k: hh.kind, f: hh.from, y: +hh.y.toFixed(2),
              d: +Math.hypot(hh.x - x, hh.z - z).toFixed(1),
            }))
          : null,
      });
      if (blocked && !cur) cur = { from: +p.toFixed(1), by: [...new Set(hits.map((hh) => hh.mesh))] };
      else if (blocked && cur) cur.to = +p.toFixed(1);
      else if (!blocked && cur) { spans.push(cur); cur = null; }
    }
    if (cur) spans.push(cur);
    const sealed = steps.filter((s) => s.blocked).length;
    out.decks.push({
      deck: d.name, heading: d.h === 0 ? "+X" : "-X", cross: d.cross,
      steps: steps.length, sealedSteps: sealed,
      sealedFrac: +(sealed / steps.length).toFixed(3),
      spans,
      firstSealed: steps.find((s) => s.blocked) ?? null,
      surfStart: steps[0]?.surf, surfEnd: steps[steps.length - 1]?.surf,
    });
  }

  // What does the obstacle grid look like right on the deck centreline?
  out.column = [];
  for (const d of decks.slice(0, 2)) {
    for (const p of [-4, 0, 10, 20, 30, 36]) {
      const x = p, z = d.cross;
      const gy = C.groundAt(x, z, 14, { stepUp: 2, reach: 18 });
      if (!gy) continue;
      const hits = [];
      C.blockedRect(x, z, 0, G.halfLength, G.halfWidth,
        gy.y + G.clearance, gy.y + G.height, hits);
      if (!hits.length) continue;
      out.column.push({
        deck: d.name, x, z, surf: +gy.y.toFixed(2),
        carBottom: +(gy.y + G.clearance).toFixed(2),
        carTop: +(gy.y + G.height).toFixed(2),
        hits: hits.slice(0, 4).map((hh) => {
          const i = C._obstacleCell(hh.x, hh.z);
          return {
            m: hh.mesh, kind: hh.kind, from: hh.from,
            cellBottom: +C.obstacleBottom[i].toFixed(2),
            cellTop: +C.obstacleTop[i].toFixed(2),
            at: [+hh.x.toFixed(1), +hh.z.toFixed(1)],
          };
        }),
      });
    }
  }
  return JSON.stringify(out, null, 1);
})();