/**
 * Offline checks for the car's height/clearance rules.
 *
 * `map.glb` is Draco-compressed and there is no decoder outside the browser, so
 * this drives the real `MapCollision` + `TerrainFollower` + `CAR` with synthetic
 * geometry. It is about the height rules, not the map.
 *
 * Each case states the physical rule it pins down, and every rule here was
 * first confirmed against the previous behaviour (see the notes on each block)
 * so a failure means the rule changed, not that the expectation was guessed.
 *
 * Run: node tools/vehicle-height-check.mjs
 */

import { MapCollision } from "../src/engine/MapCollision.js";
import { TerrainFollower, TERRAIN } from "../src/game/terrain.js";
import { CAR } from "../src/game/driving.js";

let failures = 0;
let checks = 0;
function check(label, ok, detail = "") {
  checks++;
  if (!ok) failures++;
  console.log(`  [${ok ? "PASS" : "FAIL"}] ${label}${detail ? ` - ${detail}` : ""}`);
}

// --- geometry helpers -----------------------------------------------------

/** Minimal Babylon-Mesh stand-in: identity world matrix, explicit bounds. */
function stubMesh(name, positions, indices) {
  const min = [Infinity, Infinity, Infinity];
  const max = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < positions.length; i += 3) {
    for (let a = 0; a < 3; a++) {
      min[a] = Math.min(min[a], positions[i + a]);
      max[a] = Math.max(max[a], positions[i + a]);
    }
  }
  const m = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
  return {
    name,
    getTotalVertices: () => positions.length / 3,
    computeWorldMatrix: () => {},
    getWorldMatrix: () => ({ m }),
    getVerticesData: (k) => (k === "position" ? new Float32Array(positions) : null),
    getIndices: () => new Uint32Array(indices),
    getBoundingInfo: () => ({
      boundingBox: {
        minimum: { x: min[0], y: min[1], z: min[2] },
        maximum: { x: max[0], y: max[1], z: max[2] },
      },
    }),
  };
}

/**
 * A quad, wound so the world-space normal points +Y. bakeSurface only accepts a
 * face as drivable when that normal is within ~57 degrees of straight up, so
 * getting this backwards silently bakes nothing at all and every check below
 * would pass for the wrong reason.
 */
function face(p, idx, a, b, c, d) {
  const base = p.length / 3;
  p.push(...a, ...b, ...c, ...d);
  idx.push(base, base + 2, base + 1, base, base + 3, base + 2);
}

function pad(name, x0, z0, x1, z1, y) {
  const p = [];
  const idx = [];
  face(p, idx, [x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1]);
  return stubMesh(name, p, idx);
}

/** A continuous strip climbing +Z from y0 at z0 to y1 at z1. */
function ramp(name, x0, z0, x1, z1, y0, y1, steps = 20) {
  const p = [];
  const idx = [];
  for (let i = 0; i < steps; i++) {
    const za = z0 + ((z1 - z0) * i) / steps;
    const zb = z0 + ((z1 - z0) * (i + 1)) / steps;
    const ya = y0 + ((y1 - y0) * i) / steps;
    const yb = y0 + ((y1 - y0) * (i + 1)) / steps;
    face(p, idx, [x0, ya, za], [x1, ya, za], [x1, yb, zb], [x0, yb, zb]);
  }
  return stubMesh(name, p, idx);
}

/**
 * Tarmac over the whole extent PLUS a raised band on top of it.
 *
 * Both surfaces belong to one `road_*` mesh, so bakeSurface records them in the
 * SAME cell and the height field holds two layers there. That co-existence is
 * the whole bug: the old step test asked what the car could stand on, the
 * tarmac answered, and the obstacle was never mentioned.
 *
 * @param run  length of the slopes at each end, metres. 0 gives vertical faces.
 */
function roadWithBand(name, x0, z0, x1, z1, y, bandZ0, bandZ1, top, run) {
  const p = [];
  const idx = [];
  face(p, idx, [x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1]); // tarmac
  if (run > 0) {
    face(p, idx, [x0, y, bandZ0 - run], [x1, y, bandZ0 - run], [x1, top, bandZ0], [x0, top, bandZ0]);
    face(p, idx, [x0, top, bandZ1], [x1, top, bandZ1], [x1, y, bandZ1 + run], [x0, y, bandZ1 + run]);
  }
  face(p, idx, [x0, top, bandZ0], [x1, top, bandZ0], [x1, top, bandZ1], [x0, top, bandZ1]);
  return stubMesh(name, p, idx);
}

/** A steep prop: a block, which bakes as a solid column rather than ground. */
function block(name, x0, z0, x1, z1, y0, y1) {
  const p = [];
  const idx = [];
  face(p, idx, [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]);
  face(p, idx, [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]);
  face(p, idx, [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [x1, y0, z0]);
  face(p, idx, [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]);
  face(p, idx, [x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]);
  face(p, idx, [x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]);
  return stubMesh(name, p, idx);
}

/** Just enough car to satisfy TerrainFollower, with no rig. */
function geometry() {
  return {
    wheels: [
      { x: -0.87, z: 1.48, radius: 0.305, front: true },
      { x: 0.87, z: 1.48, radius: 0.305, front: true },
      { x: -0.87, z: -0.87, radius: 0.305, front: false },
      { x: 0.87, z: -0.87, radius: 0.305, front: false },
    ],
    wheelBase: 2.35,
    track: 1.74,
    frontZ: 1.48,
    rearZ: -0.87,
    wheelRadius: 0.305,
    halfLength: CAR.length / 2,
    halfWidth: CAR.width / 2,
    height: CAR.height,
    clearance: CAR.clearance,
  };
}

/**
 * Drive the car from `start` toward `goal` at 8 m/s, 60 Hz, sweeping and
 * following every frame, and report how far it got. This is the end-to-end
 * version: it exercises the same sweep/blocked/follow cycle the game does, so
 * it catches cases where an individual probe looks right but the drive does
 * not.
 */
function drive(meshes, { start = -6, goal = 16, speed = 8 } = {}) {
  const col = new MapCollision(meshes);
  const geo = geometry();
  const tf = new TerrainFollower(col, geo, 0);
  const dt = 1 / 60;
  let x = 0;
  let z = start;
  tf.y = 0;
  tf.wheelY = geo.wheels.map(() => 0);
  for (let f = 0; f < 3000; f++) {
    const r = tf.sweep(x, z, x, z + speed * dt, 0);
    x = r.x;
    z = r.z;
    tf.follow(dt, x, z, 0);
    if (r.blocked) return { col, tf, stoppedAt: z, cleared: false };
    if (z >= goal) return { col, tf, stoppedAt: z, cleared: true };
  }
  return { col, tf, stoppedAt: z, cleared: z >= goal };
}

console.log(
  `cell=1 m  wheel step limit=${TERRAIN.maxStepUp} m  chassis=${CAR.clearance}..${CAR.height} m\n`,
);

// --- 1. a sharp step in the road: the reported bug -------------------------
// Before the fix the car drove over every one of these, including 1 m, because
// the tarmac layer answered "what height is the ground here" and the step was
// never considered. Below the step limit is drive-on; up to the roof blocks;
// above the roof is an overhead structure.
{
  console.log("sharp step in the road mesh (vertical faces, the real hurdle)");
  for (const [h, expect] of [
    [0.15, true],
    [0.3, true],
    [0.34, true],
    [0.45, false],
    [0.6, false],
    [1.0, false],
    [1.8, true], // taller than the car: pass underneath
  ]) {
    const r = drive([roadWithBand("road_c_03", -20, -20, 20, 20, 0, 4, 6, h, 0)]);
    check(
      `step h=${h.toFixed(2)} m ${expect ? "drivable" : "blocked"}`,
      r.cleared === expect,
      r.cleared ? `reached z=${r.stoppedAt.toFixed(2)}` : `stopped at z=${r.stoppedAt.toFixed(2)}`,
    );
  }
}

// --- 2. a sloped band is a ramp, and ramps are climbable -------------------
// Same obstacle, but spread over a metre of run. A 0.6 m rise over 1 m is a 31
// degree slope, which a car really can drive over, so it must NOT be treated as
// a wall. This is what keeps the fix from turning every speed breaker into an
// invisible barrier.
{
  console.log("\nsloped band, 1 m of run each end (a ramp, not a step)");
  for (const [h, expect] of [
    [0.15, true],
    [0.34, true],
    [0.45, true],
    [0.6, true],
    [1.0, false], // 45 degrees
  ]) {
    const r = drive([roadWithBand("road_c_03", -20, -20, 20, 20, 0, 4, 6, h, 1)]);
    check(`band h=${h.toFixed(2)} m ${expect ? "drivable" : "blocked"}`, r.cleared === expect);
  }
}

// --- 3. real ramps must stay climbable ------------------------------------
// Before the fix the car was stopped by any ramp past about 9 degrees, because
// the per-wheel test compared each wheel against the car's CENTRE height: on a
// slope the front wheels sit above the centre, and the test read that difference
// as a step. Referencing each wheel's own height is what fixes it.
{
  console.log("\nramps (regression: these were impassable before)");
  for (const [rise, deg, expect] of [
    [1.2, "5.7", true],
    [2.4, "11", true],
    [4.4, "20", true],
    [7.0, "30", false], // beyond what a car should climb
  ]) {
    // The goal sits ON the ramp, inside the world: since world-edge walls
    // landed, the world ends where the geometry ends (z=12 here), so the old
    // goal at z=16 would stop every run at the edge instead of testing the
    // climb. z=9 is three-quarters up the ramp face.
    const r = drive([pad("road_a", -20, -20, 20, 0, 0), ramp("road_ramp", -20, 0, 20, 12, 0, rise)], {
      goal: 9,
    });
    check(`${deg} deg ramp ${expect ? "climbable" : "too steep"}`, r.cleared === expect);
  }
}

// --- 4. overhead structures must not block ---------------------------------
{
  console.log("\noverhead structures (the car drives underneath)");
  const deck = drive([
    pad("road_a", -20, -20, 20, 20, 0),
    pad("bridge_a", -20, 4, 20, 20, 5.0),
  ]);
  check("road under a 5 m bridge deck is drivable", deck.cleared);

  // A deck in the same cells as the road is the layered case the headroom
  // bound exists for: both layers are present, only one of them is in the way.
  const col = new MapCollision([
    pad("road_a", -20, -20, 20, 20, 0),
    pad("bridge_a", -20, 4, 20, 20, 5.0),
  ]);
  const under = col.groundAt(0, 10, 0, {
    stepUp: TERRAIN.maxStepUp,
    reach: 1.5,
    headroom: CAR.height,
  });
  check("layered road+deck reads as ground, not a wall", under.kind === "ground", `kind=${under.kind}`);
}

// --- 5. a steep prop still blocks, via the other route ---------------------
{
  console.log("\nsteep prop baked as a solid column");
  const r = drive([pad("road_a", -20, -20, 20, 20, 0), block("barrier_01", -4, 4, 4, 6, 0, 1.0)]);
  check("1 m barrier stops the car", !r.cleared);
  const clear = drive([pad("road_a", -20, -20, 20, 20, 0), block("barrier_01", -4, 30, 4, 32, 0, 1.0)]);
  check("barrier off to the side does not", clear.cleared);
}

// --- 6. headroom defaults off for non-vehicle callers ----------------------
// laneBuilder and the spawn code call groundAt without a headroom, and must keep
// getting the plain height-field answer.
{
  console.log("\nheadroom defaults off for non-vehicle callers");
  const col = new MapCollision([roadWithBand("road_c_03", -20, -20, 20, 20, 0, 4, 6, 0.5, 0)]);
  const plain = col.groundAt(0, 5, 0, { stepUp: TERRAIN.maxStepUp, reach: 1.5 });
  check("no headroom -> plain answer, not a wall", plain.kind !== "wall", `kind=${plain.kind}`);
  const skipped = col.groundAt(0, 5, 0, { stepUp: TERRAIN.maxStepUp, reach: 1.5, skipInterp: true });
  check("skipInterp still returns a height", typeof skipped.y === "number", `y=${skipped.y}`);
}

// --- 7. a kerb exactly at the step limit ----------------------------------
// Layer heights are baked into a Float32Array, so a 0.34 m kerb is stored as
// 0.3400000035762787 and a naive comparison against a 0.34 limit calls it
// unclimbable. This pins the tolerance that stops that.
{
  console.log("\nfloat32 storage at the step limit");
  const col = new MapCollision([roadWithBand("road_c_03", -20, -20, 20, 20, 0, 4, 6, 0.34, 0)]);
  const cell = col._groundCell(0, 5);
  const base = cell * col.layers;
  const stored = col.layerY[base];
  console.log(`  (a ${0.34} m kerb is stored as ${stored})`);
  const r = col.groundAt(0, 5, 0, {
    stepUp: TERRAIN.maxStepUp,
    reach: 1.5,
    headroom: CAR.height,
  });
  check("a kerb exactly at the limit is still drive-on", r.kind !== "wall", `kind=${r.kind}`);
}

// --- 8. escaping a pose the collision grid calls solid ---------------------
// The bake boxes some props, so a car can stop where the grid says solid with
// no mesh there. `blocked()` tests candidate positions, so such a car reads
// every candidate - including standing still - as blocked and is frozen for
// good. `sweep` must walk it back out.
{
  console.log("\nescaping a pose the collision grid calls solid");
  const col = new MapCollision([
    pad("road_a", -20, -20, 20, 20, 0),
    block("barrier_01", -4, 4, 4, 6, 0, 1.0),
  ]);
  const geo = geometry();
  const tf = new TerrainFollower(col, geo, 0);

  let x = 0;
  let z = 4; // right on the barrier's front wall
  check("the starting pose really is blocked", tf.blocked(x, z, 0));

  // Keep asking to drive INTO the barrier; the car must still get itself out.
  let escaped = false;
  for (let i = 0; i < 30; i++) {
    const r = tf.sweep(x, z, x, z + 0.4, 0);
    if (r.escaped) escaped = true;
    x = r.x;
    z = r.z;
    tf.follow(1 / 60, x, z, 0);
    if (!tf.blocked(x, z, 0)) break;
  }
  check("sweep escaped instead of freezing", escaped);
  check("car ends up free", !tf.blocked(x, z, 0), `freed at z=${z.toFixed(2)}`);
}

// --- 9. destructible group bookkeeping -------------------------------------
// Clearing a destroyed prop's collision must remove exactly that prop and
// nothing else. A cell the prop only shares with a building is never claimed by
// the prop (first writer wins), so it survives the clear.
{
  console.log("\ndestructible-cell bookkeeping");
  const fence = block("fence_g001_Mesh", -4, 4, 4, 6, 0, 1.5);
  const house = block("house_01", 0, 4, 4, 6, 0, 6);
  const road = pad("road_a", -20, -20, 20, 20, 0);
  const groupKey = (mesh) => (/^fence_/.test(mesh.name) ? mesh : null);
  const col = new MapCollision([road, house, fence], { groupKey });

  // A box bakes only its perimeter walls, so probe the front face (z = 4).
  check("only grouped meshes claim cells", col.groups.has(fence) && !col.groups.has(house));
  check("prop-only cell blocks before the hit", col.blockedAt(-2, 4, 0, 1.4));
  check("shared cell belongs to the building (blocks before too)", col.blockedAt(2, 4, 0, 1.4));

  const cleared = col.clearGroup(fence);
  check("clearGroup released the prop's cells", cleared > 0, `cleared=${cleared}`);
  check("prop-only cell is now passable", !col.blockedAt(-2, 4, 0, 1.4));
  check("building cell still blocks", col.blockedAt(2, 4, 0, 6));

  // Respawn: the prop repairs itself once the player has driven away.
  const restored = col.restoreGroup(fence);
  check("restoreGroup refills the prop's cells", restored > 0, `restored=${restored}`);
  check("prop blocks again after respawn", col.blockedAt(-2, 4, 0, 1.4));
  check("restore leaves the building alone", col.blockedAt(2, 4, 0, 6));
  // A cleared-then-restored group must be clearable once more.
  check("restored prop can be cleared again", col.clearGroup(fence) > 0);

  // Without a groupKey the whole feature is inert - normal play pays nothing.
  const plain = new MapCollision([road, fence]);
  check("no groupKey -> no bookkeeping", plain.groups === null);
  check("no groupKey -> clearGroup is a no-op", plain.clearGroup(fence) === 0);
  check("normal collision is untouched", plain.blockedAt(-2, 4, 0, 1.4));
}

console.log(`\n${checks - failures}/${checks} checks passed`);
process.exit(failures ? 1 : 0);
