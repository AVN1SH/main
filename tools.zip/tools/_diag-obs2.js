// Which mesh bakes the solid column at (296.4, 66.9)? Find by AABB containment.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { collision: c } = g;
  const targets = [
    [296.4, 66.9],
    [296.4, 74.9],
  ];
  const out = { found: {}, classes: {}, meshes: 0 };

  for (const m of g.scene.meshes) {
    if (!m.name) continue;
    out.meshes++;
    const cls = m.getClassName();
    out.classes[cls] = (out.classes[cls] || 0) + 1;
    if (m.getTotalVertices() < 3) continue;
    m.computeWorldMatrix(true);
    const bb = m.getBoundingInfo().boundingBox;
    for (const [x, z] of targets) {
      if (bb.minimumWorld.x > x || bb.maximumWorld.x < x) continue;
      if (bb.minimumWorld.z > z || bb.maximumWorld.z < z) continue;
      if (bb.maximumWorld.y < 0.5) continue; // must reach above the road
      const key = `${x},${z}`;
      (out.found[key] = out.found[key] || []).push(
        `${m.name} [${cls} verts=${m.getTotalVertices()}] ` +
          `x[${bb.minimumWorld.x.toFixed(1)},${bb.maximumWorld.x.toFixed(1)}] ` +
          `y[${bb.minimumWorld.y.toFixed(1)},${bb.maximumWorld.y.toFixed(1)}] ` +
          `z[${bb.minimumWorld.z.toFixed(1)},${bb.maximumWorld.z.toFixed(1)}]`,
      );
    }
  }

  // what does the bake consider solid? re-derive the name filters
  out.nameSample = [];
  for (const m of g.scene.meshes) {
    if (!m.name) continue;
    if (m.name.length > 24) continue;
    out.nameSample.push(m.name);
  }
  out.nameSample = [...new Set(out.nameSample)].slice(0, 80);

  return JSON.stringify(out, null, 1);
})();
