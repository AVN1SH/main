// Offline-ish runtime query: what is standing on these road meshes?
// Run with:  node tools/browser-probe.mjs --url=... --wait=... --expr-file=tools/_what-blocks.js
(() => {
  const g = window.game;
  const C = g.collision;
  const NAMES = ["road_c_02.003", "road_c_02.004", "road_c_04.002"];
  const out = {};

  for (const name of NAMES) {
    const mesh = g.scene.meshes.find((m) => m.name === name);
    if (!mesh) {
      out[name] = { error: "mesh not found" };
      continue;
    }
    mesh.computeWorldMatrix(true);
    const b = mesh.getBoundingInfo().boundingBox;
    const minX = b.minimumWorld.x, maxX = b.maximumWorld.x;
    const minZ = b.minimumWorld.z, maxZ = b.maximumWorld.z;
    const minY = b.minimumWorld.y, maxY = b.maximumWorld.y;

    // Sample the road surface and the chassis volume across the mesh.
    const N = 9;
    let roadHits = 0, cells = 0;
    let blocked = 0, noGround = 0, lowGround = 0, high = 0;
    const blockers = new Map();
    const samples = [];

    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        const x = minX + ((i + 0.5) / N) * (maxX - minX);
        const z = minZ + ((j + 0.5) / N) * (maxZ - minZ);
        cells++;
        const isRoad = C.isRoadAt(x, z);
        if (isRoad) roadHits++;
        const gy = C.groundAt(x, z, maxY + 2, { stepUp: 1.2, reach: 12 });
        if (!gy) { noGround++; samples.push({ x, z, isRoad, gy: null }); continue; }
        const surf = gy.y;
        // Chassis occupies roughly surf .. surf+1.4
        const b0 = surf + 0.15;
        const b1 = surf + 1.45;
        const hit = C.blockedAt(x, z, b0, b1);
        if (hit) {
          blocked++;
          const cell = C._obstacleCell(x, z);
          const src = C.obstacleSource ? C.obstacleSource[cell] : 0;
          const rec = src ? C.solidMeshes[src - 1] : null;
          const key = rec ? rec.mesh.name : "no-source";
          blockers.set(key, (blockers.get(key) ?? 0) + 1);
          if (samples.length < 8)
            samples.push({ x: +x.toFixed(1), z: +z.toFixed(1), isRoad, surf: +surf.toFixed(2), blockedBy: key });
        }
        if (surf < 0.02) lowGround++;
        if (surf > 3) high++;
      }
    }
    out[name] = {
      aabb: {
        x: [+minX.toFixed(1), +maxX.toFixed(1)],
        z: [+minZ.toFixed(1), +maxZ.toFixed(1)],
        y: [+minY.toFixed(2), +maxY.toFixed(2)],
        size: [+(maxX - minX).toFixed(1), +(maxY - minY).toFixed(2), +(maxZ - minZ).toFixed(1)],
      },
      isRoadMesh: C.isRoadMesh ? C.isRoadMesh(mesh) : null,
      cells,
      roadHits,
      blockedCells: blocked,
      noGround,
      samples,
      blockers: [...blockers.entries()].sort((a, b2) => b2[1] - a[1]).slice(0, 12),
    };
  }
  return JSON.stringify(out, null, 1);
})();