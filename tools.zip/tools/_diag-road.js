(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const c = g.collision;
  const out = {};

  const ray = g.scene.createPickingRay(0, 0, null, g.scene.activeCamera);
  const hits = (x, z) => {
    ray.origin.set(x, 40, z);
    ray.direction.set(0, -1, 0);
    const r = [];
    for (const m of g.scene.meshes) {
      if (!m.name || m.getTotalVertices() < 3) continue;
      const info = ray.intersectsMesh(m, false);
      if (info && info.hit) r.push(`${m.name}:${info.pickedPoint.y.toFixed(3)}`);
    }
    return r.sort((a, b) => parseFloat(b.split(":")[1]) - parseFloat(a.split(":")[1])).slice(0, 5);
  };

  const layers = (x, z) => {
    const col = Math.floor((x - c.minX) / c.cell);
    const row = Math.floor((z - c.minZ) / c.cell);
    const i = row * c.cols + col;
    const ys = [];
    for (let j = 0; j < c.layerCount[i]; j++) ys.push(+c.layerY[i * c.layers + j].toFixed(3));
    return { ys: ys.length ? ys : "empty", road: !!c.roadMask[i] };
  };

  out.spawn = { ray: hits(-169.8, 76.9), layers: layers(-169.8, 76.9) };
  out.near = [];
  for (const [x, z] of [[-169.8, 75], [-169.8, 72], [-169.8, 80], [-165, 76.9], [-160, 76.9], [-175, 76.9]]) {
    out.near.push({ x, z, ray: hits(x, z).slice(0, 2), layers: layers(x, z) });
  }
  out.roadCells = c.stats.roadCells;
  out.isRoadAtSpawn = c.isRoadAt(-169.8, 76.9);
  return JSON.stringify(out, null, 1);
})();
