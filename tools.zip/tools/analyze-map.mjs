// Analyzes map.glb: name families, road layout, vehicle props.
// Usage: node tools/analyze-map.mjs public/assets/map.glb [familyRegex]
import { loadGlb, worldBounds, r3, round } from "./glb.mjs";

const file = process.argv[2] ?? "public/assets/map.glb";
const familyFilter = process.argv[3];
const { g, nodes, parents } = loadGlb(file);
const all = worldBounds(nodes, parents, g);

// --- overall map extents ---
const lo = [Infinity, Infinity, Infinity];
const hi = [-Infinity, -Infinity, -Infinity];
for (const b of all) {
  for (let a = 0; a < 3; a++) {
    lo[a] = Math.min(lo[a], b.box.min[a]);
    hi[a] = Math.max(hi[a], b.box.max[a]);
  }
}
console.log(`meshes: ${all.length}   total vertices: ${all.reduce((s, b) => s + b.vertices, 0).toLocaleString()}`);
console.log(`map bounds: min ${r3(lo)}  max ${r3(hi)}  size ${r3(hi.map((v, a) => v - lo[a]))}`);

// --- name families (strip trailing .NNN) ---
const fam = new Map();
for (const b of all) {
  const name = b.name.replace(/\.\d+$/, "");
  if (!fam.has(name)) fam.set(name, []);
  fam.get(name).push(b);
}
const families = [...fam.entries()].sort((a, b) => b[1].length - a[1].length);
console.log(`\nname families: ${families.length}`);
for (const [name, items] of families.slice(0, 40)) {
  const ys = items.map((b) => b.center[1]);
  console.log(`  ${name.padEnd(28)} count=${String(items.length).padStart(4)}  y ${round(Math.min(...ys))}..${round(Math.max(...ys))}  verts=${items.reduce((s, b) => s + b.vertices, 0).toLocaleString()}`);
}
if (families.length > 40) console.log(`  ... ${families.length - 40} more families`);

// --- anything that looks like a vehicle or path helper ---
const vehicleRe = /bus|truck|van|car|taxi|vehicle|traffic|spawn|waypoint|path|route|lane|node|point/i;
console.log("\n=== vehicle / path candidates ===");
for (const [name, items] of families) {
  if (vehicleRe.test(name)) console.log(`  ${name.padEnd(28)} count=${items.length}`);
}

// --- road families: geometry + orientation ---
const roadFamilies = families.filter(([name]) => /road/i.test(name));
console.log(`\n=== roads: ${roadFamilies.length} families, ${roadFamilies.reduce((s, [, i]) => s + i.length, 0)} pieces ===`);

function yawDeg(b) {
  // world matrix column 0 is the local +X axis in world space
  const m = b.world;
  const ax = [m[0], m[2]]; // x,z of +X axis
  return round((Math.atan2(ax[1], ax[0]) * 180) / Math.PI, 0);
}

for (const [name, items] of roadFamilies) {
  if (familyFilter && !new RegExp(familyFilter, "i").test(name)) continue;

  const sizes = new Map();
  for (const b of items) sizes.set(r3(b.size).join("x"), (sizes.get(r3(b.size).join("x")) ?? 0) + 1);

  const yaws = new Map();
  for (const b of items) {
    const y = ((yawDeg(b) % 180) + 180) % 180;
    yaws.set(y, (yaws.get(y) ?? 0) + 1);
  }

  const ys = items.map((b) => b.center[1]);
  console.log(`\n--- ${name}: ${items.length} pieces, y ${round(Math.min(...ys), 3)}..${round(Math.max(...ys), 3)}`);
  console.log(`    sizes: ${[...sizes.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([s, c]) => `${s}(${c})`).join("  ")}`);
  console.log(`    yaw(deg mod 180): ${[...yaws.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([a, c]) => `${a}deg(${c})`).join("  ")}`);

  const xs = [...new Set(items.map((b) => round(b.center[0])))].sort((a, b) => a - b);
  const zs = [...new Set(items.map((b) => round(b.center[2])))].sort((a, b) => a - b);
  if (xs.length <= 24) console.log(`    distinct X: ${xs.join(", ")}`);
  if (zs.length <= 24) console.log(`    distinct Z: ${zs.join(", ")}`);
}
