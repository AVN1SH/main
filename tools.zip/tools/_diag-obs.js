// What exactly is baked as solid at (296.4, 66.9) and (296.4, 74.9)?
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision: c } = g;
  const out = {};

  // vertical scan: at which heights is the cell blocked?
  const scan = (x, z) => {
    const rows = [];
    for (let y = -1; y <= 6; y += 0.25) {
      if (c.blockedAt(x, z, y, y + 0.25)) rows.push(+y.toFixed(2));
    }
    return rows;
  };
  out.blockedBands = {
    "296.4,66.9": scan(296.4, 66.9),
    "296.4,74.9": scan(296.4, 74.9),
    "296.8,66.9": scan(296.8, 66.9),
    "296.4,62.9": scan(296.4, 62.9),
  };

  // ASCII map of the obstacle grid around x=294..300, z=60..80
  const col = (x) => Math.floor((x - c.minX) / c.cell);
  const row = (z) => Math.floor((z - c.minZ) / c.cell);
  let map = "obstacle map, '#'=solid  (cell=" + c.cell + " m)\n";
  map += "        ";
  for (let x = 294; x <= 300; x += c.cell) map += String(Math.round(x)).padStart(3);
  map += "\n";
  for (let z = 60; z <= 82; z += c.cell) {
    map += `z=${String(Math.round(z)).padStart(3)} `;
    for (let x = 294; x <= 300; x += c.cell) {
      const i = row(z) * c.cols + col(x);
      map += (c.obstacleTop && c.obstacleTop[i] > 0.1 ? "###" : " . ");
    }
    map += "\n";
  }
  out.obstacleMap = map;

  // names of the raw fields MapCollision exposes
  out.fields = Object.keys(c).filter((k) => ArrayBuffer.isView(c[k]));
  out.obstacleFieldStats = {};
  for (const k of out.fields) {
    const arr = c[k];
    let nz = 0;
    let mx = -Infinity;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]) {
        nz++;
        if (arr[i] > mx) mx = arr[i];
      }
    }
    out.obstacleFieldStats[k] = { nonzero: nz, max: mx === -Infinity ? null : +mx.toFixed(2) };
  }

  return JSON.stringify(out, null, 1);
})();
