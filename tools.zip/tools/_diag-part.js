// Which part of blocked() fires for a stuck car, and what is around it?
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision: c } = g;
  const dt = 1 / 60;
  const car = traffic.vehicles[4];
  const T = { stepUp: 0.6, reach: 1.5 };

  let f = 0;
  for (; f < 3600; f++) {
    traffic.update(dt);
    if (f > 120 && Math.abs(car.state.speed) < 0.3) break;
  }

  const x = car.state.x;
  const z = car.state.z;
  const h = car.state.heading;
  const g2 = car.terrain.g;
  const bottom = car.terrain.y + g2.clearance;
  const top = car.terrain.y + g2.height;

  const out = {
    at: [+x.toFixed(2), +z.toFixed(2)],
    y: +car.terrain.y.toFixed(2),
    heading: +h.toFixed(3),
    halfLength: g2.halfLength,
    halfWidth: g2.halfWidth,
    span: [+bottom.toFixed(2), +top.toFixed(2)],
    wholeBlocked: car.terrain.blocked(x, z, h),
  };

  // part 1 alone
  out.part1 = c.blockedRect(x, z, h, g2.halfLength, g2.halfWidth, bottom, top);

  // which masked cells near the car are in the car's height span?
  const oc = c.obstacleCell;
  const cells = [];
  for (let dz = -2.5; dz <= 2.5; dz += oc) {
    for (let dx = -2.5; dx <= 2.5; dx += oc) {
      const cx = x + dx;
      const cz = z + dz;
      const i = c._obstacleCell(cx, cz);
      if (i < 0 || !c.obstacleMask[i]) continue;
      const b = +c.obstacleBottom[i].toFixed(2);
      const t = +c.obstacleTop[i].toFixed(2);
      const over = b < top && t > bottom;
      const rx = cx - x;
      const rz = cz - z;
      const along = Math.abs(rx * Math.sin(h) + rz * Math.cos(h));
      const across = Math.abs(rx * Math.cos(h) - rz * Math.sin(h));
      if (over) cells.push(`(${cx.toFixed(1)},${cz.toFixed(1)}) y[${b},${t}] along=${along.toFixed(2)} across=${across.toFixed(2)}`);
    }
  }
  out.overlappingCells = cells;

  // part 2: unclimbable step ahead
  const steps = [];
  let prevY = car.terrain.y;
  const step = 0.4;
  for (let d = step; d <= g2.halfLength + step; d += step) {
    const r = c.groundAt(x + Math.sin(h) * d, z + Math.cos(h) * d, prevY, {
      stepUp: T.stepUp,
      reach: T.reach,
    });
    steps.push(`d=${d.toFixed(1)} kind=${r.kind} y=${r.y === null ? "-" : r.y.toFixed(2)}`);
    if (r.kind === "ground") prevY = r.y;
  }
  out.stepChain = steps;

  // part 3: wheels
  out.wheels = car.terrain.g.wheels.map((w) => {
    const p = car.terrain.wheelWorld(x, z, h, w);
    const r = c.groundAt(p.x, p.z, car.terrain.y, { stepUp: T.stepUp, reach: T.reach });
    return `(${p.x.toFixed(1)},${p.z.toFixed(1)}) ${r.kind} y=${r.y === null ? "-" : r.y.toFixed(2)}`;
  });

  // is the nearest lane point itself clear?
  const here = car.path.sample(car.distance);
  out.lanePoint = {
    at: [+here.x.toFixed(2), +here.z.toFixed(2)],
    blocked: car.terrain.blocked(here.x, here.z, h),
    part1: c.blockedRect(here.x, here.z, h, g2.halfLength, g2.halfWidth, bottom, top),
    lat: +((here.x - x) * Math.cos(h) - (here.z - z) * Math.sin(h)).toFixed(2),
  };

  return JSON.stringify(out, null, 1);
})();
