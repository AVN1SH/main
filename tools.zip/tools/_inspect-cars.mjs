import { loadGlb, worldBounds } from "./glb.mjs";
const files = process.argv.slice(2);
for (const f of files) {
  const { g, nodes, parents } = loadGlb(f);
  console.log(`\n===== ${f} =====`);
  nodes.forEach((n, i) => {
    const p = parents.get(i);
    const t = n.translation ? n.translation.map(v=>Math.round(v*100)/100) : null;
    const s = n.scale ? n.scale.map(v=>Math.round(v*1000)/1000) : null;
    console.log(`  ${i}: ${JSON.stringify(n.name)} parent=${p===undefined?"(root)":nodes[p].name} mesh=${n.mesh ?? "-"} t=${t} s=${s}`);
  });
  const all = worldBounds(nodes, parents, g);
  console.log("  --- world bounds ---");
  for (const b of all) {
    console.log(`  ${b.name}: center ${b.center.map(v=>Math.round(v*100)/100)} size ${b.size.map(v=>Math.round(v*100)/100)}`);
  }
}
