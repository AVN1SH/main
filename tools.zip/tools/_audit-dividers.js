// Divider-discipline audit for the traffic lane system.
//
// Run it through tools/browser-probe.mjs with --expr-file=tools/_audit-dividers.js
// against a `?debug=1` page. It reports, first over every built lane point and
// then over a simulated minute of driving, how often traffic touches a raised
// road divider (the `road_b` median). A healthy system reports 0 both times.
(() => {
  const g = window.game;
  const { traffic, collision } = g;
  const out = { dividerCells: collision.stats.dividerCells, roadCells: collision.stats.roadCells };

  // route points on dividers
  let total = 0, onDiv = 0;
  const offenders = [];
  for (const r of traffic.routes ?? []) {
    for (const p of r.points) {
      if (!collision.isRoadAt(p.x, p.z)) continue;
      total++;
      // widen the test to the car's half-width via a short perpendicular probe
      let hit = collision.isDividerAt(p.x, p.z);
      if (!hit) {
        for (let s = 0.5; s <= 1.2 && !hit; s += 0.5) {
          hit = collision.isDividerAt(p.x + s, p.z) || collision.isDividerAt(p.x - s, p.z) ||
                collision.isDividerAt(p.x, p.z + s) || collision.isDividerAt(p.x, p.z - s);
        }
      }
      if (hit) { onDiv++; if (offenders.length < 12) offenders.push({ route: r.id, x: +p.x.toFixed(1), z: +p.z.toFixed(1) }); }
    }
  }
  out.routePoints = total;
  out.routePointsNearDivider = onDiv;
  out.offenders = offenders;

  // simulate: does any car step onto a divider cell?
  const dt = 1 / 60;
  let divFrames = 0, frames = 0;
  const per = traffic.vehicles.map(() => 0);
  for (let f = 0; f < 1200; f++) {
    traffic.update(dt);
    for (let i = 0; i < traffic.vehicles.length; i++) {
      const v = traffic.vehicles[i];
      frames++;
      let hit = collision.isDividerAt(v.state.x, v.state.z);
      if (!hit) {
        for (let s = 0.5; s <= 1.0 && !hit; s += 0.5) {
          hit = collision.isDividerAt(v.state.x + s, v.state.z) || collision.isDividerAt(v.state.x - s, v.state.z) ||
                collision.isDividerAt(v.state.x, v.state.z + s) || collision.isDividerAt(v.state.x, v.state.z - s);
        }
      }
      if (hit) { divFrames++; per[i]++; }
    }
  }
  out.sim = { divFrames, frames, perCar: per };
  return JSON.stringify(out, null, 1);
})();
