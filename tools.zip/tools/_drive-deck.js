// Drive the real car onto the bridge approach decks and record, frame by frame,
// whether it is blocked and by which mesh. Uses the game's own sweep/blocked.
(() => {
  const g = window.game;
  const C = g.collision;
  const P = g.player;
  const out = {};

  const groundY = (x, z) => {
    const r = C.groundAt(x, z, 12, { stepUp: 2, reach: 16 });
    return r ? r.y : null;
  };

  // Start points: the middle of each deck, heading along +X (and -X).
  const cases = [
    { name: "road_c_02.003", x: 30, z: 75.4, heading: 0, label: "003 low end -> +X (bridge side)" },
    { name: "road_c_02.003", x: 30, z: 75.4, heading: Math.PI, label: "003 low end -> -X (down ramp)" },
    { name: "road_c_02.004", x: -110, z: 75.4, heading: Math.PI, label: "004 high end -> -X (bridge side)" },
    { name: "road_c_02.004", x: -110, z: 75.4, heading: 0, label: "004 high end -> +X (down ramp)" },
    { name: "road_c_04.002", x: -312, z: 3.9, heading: 0, label: "04.002 -> +X" },
    { name: "road_c_04.002", x: -312, z: 3.9, heading: Math.PI, label: "04.002 -> -X" },
  ];

  out.cases = [];
  for (const c of cases) {
    const y = groundY(c.x, c.z);
    const rec = {
      name: c.name, label: c.label, start: [+c.x.toFixed(1), +c.z.toFixed(1)],
      startY: y == null ? null : +y.toFixed(2), blockedAtStart: null, drive: null,
    };
    if (y == null) { rec.error = "no ground at start"; out.cases.push(rec); continue; }

    // Ask the game's own test what is blocking, with contact records.
    const hits = [];
    const blocked = P.terrain.blocked(c.x, c.z, c.heading, hits);
    rec.blockedAtStart = blocked;
    rec.blockers = [...new Set(hits.map((h) => `${h.mesh}:${h.kind}:${h.from}`))].slice(0, 8);

    // Now actually drive: hold the throttle and record where the car ends up.
    P.state.x = c.x; P.state.z = c.z; P.state.y = y;
    P.state.heading = c.heading; P.state.speed = 12;
    P.terrain.y = y; P.terrain.sync?.(c.x, c.z, c.heading);
    const path = [];
    let stopped = 0;
    const obs = g.scene.onBeforeRenderObservable.add(() => {
      P.state.speed = 14;
      const s = P.state;
      path.push({
        x: +s.x.toFixed(1), z: +s.z.toFixed(1), y: +s.y.toFixed(2),
        spd: +s.speed.toFixed(1), col: !!P.collided,
      });
    });
    out.cases.push(rec);
    rec._path = path;
    rec._obs = obs;
    rec._stopped = () => stopped;
  }

  // Drive is asynchronous; run it here with a real wait, sequentially.
  return (async () => {
    for (const rec of out.cases) {
      if (!rec._obs) continue;
      await new Promise((r) => setTimeout(r, 2600));
      g.scene.onBeforeRenderObservable.remove(rec._obs);
      const p = rec._path;
      const start = rec.start;
      const moved = p.length
        ? Math.hypot(p[p.length - 1].x - start[0], p[p.length - 1].z - start[1])
        : 0;
      rec.drive = {
        frames: p.length,
        travelledM: +moved.toFixed(1),
        end: p.length ? p[p.length - 1] : null,
        collidedFrames: p.filter((s) => s.col).length,
        path: p.filter((_, i) => i % 2 === 0).slice(0, 12),
      };
      delete rec._path; delete rec._obs; delete rec._stopped;
    }
    return JSON.stringify(out, null, 1);
  })();
})();