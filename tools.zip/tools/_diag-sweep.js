// Sweep every destructible family plus a sample of the instanced ones, checking
// that each one reacts and that none of them ever goes hidden, disabled, NaN or
// throws. This is the regression net for the whole system: it is the sweep that
// catches a family the hand-picked acceptance cases happen to miss.
(() => {
  const g = window.game;
  const d = g.destruction;

  const errors = [];
  const prevError = window.onerror;
  window.onerror = (m, s, l, c, e) => {
    errors.push(String(e?.stack ?? m));
    return prevError?.(m, s, l, c, e);
  };

  const wait = (n) => new Promise((res) => {
    let i = 0;
    const ob = g.scene.onAfterRenderObservable.add(() => {
      if (++i >= n) { g.scene.onAfterRenderObservable.remove(ob); res(); }
    });
  });

  const isInstance = (o) => typeof o.mesh.bakeCurrentTransformIntoVertices !== "function";

  /** Deliver the same call PlayerVehicle.onImpact would, aimed so it overlaps. */
  const smash = (o) => {
    const back = Math.max(1.2, o.halfZ + 0.4);
    const px = o.center.x;
    const pz = o.center.z - back;
    const gy = g.collision.groundAt(px, pz, o.center.y + 2, { stepUp: 4, reach: 8 })?.y ?? 0;
    return d.handleImpact({
      x: px, z: pz, y: gy, heading: 0, speed: 26,
      clearance: 0.25, height: 1.6, halfLength: 2.2, halfWidth: 0.9,
    });
  };

  /** Sample one prop across its reaction, looking for anything that would read as a bug. */
  const probe = async (o) => {
    const before = o.mesh;
    // Must be read BEFORE the impact: the smash converts an InstancedMesh into
    // a standalone copy, so asking afterwards always says "Mesh".
    const wasInstance = isInstance(o);
    const hit = smash(o);
    const trace = [];
    const ob = g.scene.onBeforeRenderObservable.add(() => {
      if (!o.alive) {
        const m = o.mesh;
        const p = m.getAbsolutePosition();
        trace.push({
          vis: m.isVisible,
          en: m.isEnabled(),
          scene: m.isEnabled() && g.scene.meshes.includes(m),
          finite: Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z),
          moved: Math.hypot(p.x - o.center.x, p.z - o.center.z),
        });
      }
    });
    await wait(8);
    g.scene.onBeforeRenderObservable.remove(ob);
    const swapped = o.mesh !== before;
    const bad = trace.filter((s) => !s.vis || !s.en || !s.scene || !s.finite);
    const out = {
      family: o.family.id,
      behavior: o.family.behavior,
      instanced: wasInstance,
      swappedToStandalone: swapped,
      hit,
      frames: trace.length,
      moved: +(Math.max(0, ...trace.map((s) => s.moved))).toFixed(2),
      badFrames: bad.length,
    };
    d._restore(o);
    return out;
  };

  return (async () => {
    const rows = [];
    const instAlive0 = d.objects.filter((o) => o.alive && isInstance(o)).length;
    const instAll = d.objects.filter((o) => isInstance(o)).length;
    try {
      const byFamily = new Map();
      for (const o of d.objects) {
        if (o.alive && !byFamily.has(o.family.id)) byFamily.set(o.family.id, o);
      }
      for (const o of byFamily.values()) rows.push(await probe(o));

      // Every instanced prop shares one source mesh, so a handful proves the
      // conversion; they are the ones that silently threw before.
      const inst = d.objects.filter((o) => o.alive && isInstance(o)).slice(0, 8);
      for (const o of inst) rows.push(await probe(o));
    } catch (e) {
      errors.push(String(e?.stack ?? e));
    }
    window.onerror = prevError;

    const failed = rows.filter((r) => r.badFrames > 0 || r.frames === 0 || !r.hit);
    return JSON.stringify({
      pageErrors: errors.length,
      instancedInIndex: instAll,
      instancedAliveAtStart: instAlive0,
      errors: errors.slice(0, 3),
      tested: rows.length,
      families: [...new Set(rows.map((r) => r.family))],
      instancedTested: rows.filter((r) => r.instanced).length,
      allReacted: failed.length === 0,
      failed,
      rows,
    }, null, 1);
  })();
})();
