// Audits src/data/routes.json lanes against the ROAD BANDS stored in the same
// file, using the same margin semantics as debug.js's isOnRoad (so "on road"
// here means exactly what the game's own self-test accepts).
//
// Usage: node tools/audit-lanes.mjs [margin]
import { readFileSync } from "node:fs";

const R = JSON.parse(readFileSync("src/data/routes.json", "utf8"));
const margin = Number(process.argv[2] ?? 1.0);

const onRoad = (x, z) => {
  for (const r of R.roads.horizontal) {
    if (x >= r.from - margin && x <= r.to + margin) {
      if (Math.abs(z - r.center) <= r.width / 2 + margin) return r;
    }
  }
  for (const r of R.roads.vertical) {
    if (z >= r.from - margin && z <= r.to + margin) {
      if (Math.abs(x - r.center) <= r.width / 2 + margin) return r;
    }
  }
  return null;
};

let total = 0;
let off = 0;
const perRoute = [];
const worst = [];
for (const route of R.routes) {
  let routeOff = 0;
  for (const p of route.points) {
    total++;
    const r = onRoad(p.x, p.z);
    if (!r) {
      off++;
      routeOff++;
      if (worst.length < 15) worst.push({ route: route.id, x: p.x, z: p.z });
    }
  }
  perRoute.push({ id: route.id, points: route.points.length, off: routeOff });
}

console.log(`lanes: ${R.routes.length} routes, ${total} points`);
console.log(`off-road points (margin=${margin}): ${off} (${((100 * off) / total).toFixed(1)}%)`);
for (const r of perRoute.filter((r) => r.off > 0)) {
  console.log(`  route ${r.id}: ${r.off}/${r.points} points off road`);
}
if (worst.length) {
  console.log("first offenders:");
  for (const w of worst) console.log(`  route ${w.route}: (${w.x}, ${w.z})`);
}

// Also: pairwise point spacing (corner fidelity) and loop closure
let minSeg = Infinity;
let maxSeg = 0;
for (const route of R.routes) {
  const pts = route.points;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    const d = Math.hypot(b.x - a.x, b.z - a.z);
    minSeg = Math.min(minSeg, d);
    maxSeg = Math.max(maxSeg, d);
  }
}
console.log(`segment length: min ${minSeg.toFixed(2)} m, max ${maxSeg.toFixed(2)} m`);
