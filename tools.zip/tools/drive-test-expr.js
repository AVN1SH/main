(async () => {
  const g = window.game;
  if (!g) return "no window.game";

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const key = (code, type = "keydown") =>
    window.dispatchEvent(new KeyboardEvent(type, { code, bubbles: true }));
  const snap = () => ({
    x: +g.player.state.x.toFixed(3),
    z: +g.player.state.z.toFixed(3),
    heading: +g.player.state.heading.toFixed(4),
    speed: +g.player.state.speed.toFixed(3),
    steer: +g.player.steerAngle.toFixed(4),
    gear: g.player.gear,
    kmh: +g.player.speedKmh.toFixed(1),
  });

  const out = {};
  out.start = snap();

  // --- throttle ---
  key("KeyW");
  await wait(2500);
  out.afterThrottle = snap();
  out.movedM = +Math.hypot(
    out.afterThrottle.x - out.start.x,
    out.afterThrottle.z - out.start.z,
  ).toFixed(2);

  // --- steer left while moving ---
  key("KeyA");
  await wait(2000);
  out.afterLeftSteer = snap();
  out.leftSteerHeadingDelta = +(out.afterLeftSteer.heading - out.afterThrottle.heading).toFixed(4);

  // --- steer right, from the same speed ---
  key("KeyA", "keyup");
  key("KeyD");
  await wait(2000);
  out.afterRightSteer = snap();
  out.rightSteerHeadingDelta = +(out.afterRightSteer.heading - out.afterLeftSteer.heading).toFixed(4);
  key("KeyD", "keyup");

  // --- brake to a stop ---
  key("KeyW", "keyup");
  key("KeyS");
  await wait(1800);
  out.afterBrake = snap();
  key("KeyS", "keyup");

  // --- reverse ---
  key("KeyS");
  await wait(1500);
  out.afterReverse = snap();
  key("KeyS", "keyup");

  // --- traffic must be moving and looping ---
  const v = g.traffic.vehicles[0];
  out.traffic = {
    start: { d: +v.distance.toFixed(2), x: +v.state.x.toFixed(2), z: +v.state.z.toFixed(2), speed: +v.speed.toFixed(2) },
    pathLength: +v.path.length.toFixed(2),
  };
  await wait(2500);
  out.traffic.after = {
    d: +v.distance.toFixed(2),
    x: +v.state.x.toFixed(2),
    z: +v.state.z.toFixed(2),
    speed: +v.speed.toFixed(2),
  };
  out.traffic.advancedM = +(out.traffic.after.d - out.traffic.start.d).toFixed(2);

  // loop check: does the distance wrap back into range over a long run?
  v.distance = v.path.length - 3;
  await wait(1500);
  out.traffic.wrappedTo = +v.distance.toFixed(2);
  out.traffic.wrapOk = v.distance >= 0 && v.distance < v.path.length;

  out.fps = +g.engine.getFps().toFixed(1);
  out.frames = g.engine.frameId ?? null;
  return JSON.stringify(out, null, 1);
})();
