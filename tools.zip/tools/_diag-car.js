// Trace one crawling traffic car and audit its route's geometry.
(() => {
  const g = window.game;
  if (!g) return "no window.game";
  const { traffic, collision: c } = g;
  const target = Number(window.__car ?? 11);

  // --- which route does the car think it is on? ---
  const v = traffic.vehicles[target];
  const routes = new Map();
  for (const veh of traffic.vehicles) routes.set(veh.route, (routes.get(veh.route) || 0) + 1);

  // --- audit every route: segment lengths, on-road, zigzag repair seams -----
  const audit = [];
  let ri = 0;
  for (const [route, n] of routes) {
    const pts = route.path.points;
    const seg = [];
    let bad = 0;
    let maxSeg = 0;
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i];
      const b = pts[(i + 1) % pts.length];
      const d = Math.hypot(b.x - a.x, b.z - a.z);
      seg.push(d);
      maxSeg = Math.max(maxSeg, d);
      if (!c.isRoadAt(a.x, a.z)) bad++;
    }
    seg.sort((p, q) => q - p);
    // turn angle at each point = how sharp the ring is
    let maxTurn = 0;
    let sumTurn = 0;
    for (let i = 0; i < pts.length; i++) {
      const p = pts[(i - 1 + pts.length) % pts.length];
      const q = pts[i];
      const n2 = pts[(i + 1) % pts.length];
      const h1 = Math.atan2(q.x - p.x, q.z - p.z);
      const h2 = Math.atan2(n2.x - q.x, n2.z - q.z);
      let d = h2 - h1;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      maxTurn = Math.max(maxTurn, Math.abs(d));
      sumTurn += Math.abs(d);
    }
    audit.push(
      `#${ri} cars=${n} bridge=${!!route.bridge} pts=${pts.length} len=${Math.round(
        route.path.length,
      )} offRoad=${bad} medSeg=${seg[Math.floor(seg.length / 2)].toFixed(2)} maxSeg=${maxSeg.toFixed(
        2,
      )} maxTurnDeg=${((maxTurn * 180) / Math.PI).toFixed(1)} avgTurnDeg=${(
        (sumTurn / pts.length) *
        180 /
        Math.PI
      ).toFixed(1)}`,
    );
    ri++;
  }

  // --- trace the car for 1800 frames (30 s) ---
  const dt = 1 / 60;
  const trace = [];
  let onRoad = 0;
  let samples = 0;
  let stuckTotal = 0;
  let maxLateral = 0;
  for (let f = 0; f < 1800; f++) {
    traffic.update(dt);
    if (f % 60) continue;
    const veh = traffic.vehicles[target];
    const here = veh.path.sample(veh.distance);
    const dxh = here.x - veh.state.x;
    const dzh = here.z - veh.state.z;
    const lat = dxh * Math.cos(veh.state.heading) - dzh * Math.sin(veh.state.heading);
    maxLateral = Math.max(maxLateral, Math.abs(lat));
    if (c.isRoadAt(veh.state.x, veh.state.z)) onRoad++;
    samples++;
    stuckTotal += veh.stuckTime;
    trace.push(
      `t=${(f / 60).toFixed(0)}s p=(${veh.state.x.toFixed(1)},${veh.state.z.toFixed(1)}) y=${veh.state.y.toFixed(
        2,
      )} v=${veh.state.speed.toFixed(1)} dist=${veh.distance.toFixed(0)} lat=${lat.toFixed(1)} road=${
        c.isRoadAt(veh.state.x, veh.state.z) ? 1 : 0
      } stuck=${veh.stuckTime.toFixed(1)} rec=${(veh.recover || 0).toFixed(1)}`,
    );
  }

  return JSON.stringify(
    {
      car: target,
      carRouteIdx: ri,
      routeCount: routes.size,
      audit,
      traceOnRoadPct: +((100 * onRoad) / samples).toFixed(1),
      maxLateral: +maxLateral.toFixed(1),
      stuckTotal: +stuckTotal.toFixed(1),
      staleSpeed: v.speed,
      liveSpeed: v.state.speed,
      trace,
    },
    null,
    1,
  );
})();
