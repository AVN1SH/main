(async () => {
  const g = window.game, race = g.race, t = race.track;
  const roadAt = (x,z)=>g.collision.isRoadAt(x,z);
  return {
    playerSlot: race.playerSlot,
    rivalSlots: race.rivalSlots,
    fieldSize: race.track.fieldSize,
    start: {x:+t.startPose.x.toFixed(2), z:+t.startPose.z.toFixed(2), headingDeg:+(t.startPose.heading*180/Math.PI).toFixed(1)},
    grid: t.grid.map((s,i)=>({i, slot:s.slot, x:+s.x.toFixed(2), z:+s.z.toFixed(2), hd:+(s.heading*180/Math.PI).toFixed(1), road:roadAt(s.x,s.z)})),
    rivals: race.rivals.map((r,i)=>({
      name:r.name, slot:race.rivalSlots[i],
      x:+r.state.x.toFixed(2), z:+r.state.z.toFixed(2), hd:+(r.state.heading*180/Math.PI).toFixed(1),
      pathDist: +r.progress.distance.toFixed(1),
      ahead5: (()=>{const p=t.path.sample(r.progress.distance+5); return {x:+p.x.toFixed(2),z:+p.z.toFixed(2)};})(),
      aheadAt0: (()=>{const p=t.path.sample(0); return {x:+p.x.toFixed(2),z:+p.z.toFixed(2)};})(),
    })),
    warnings: t.warnings,
  };
})();
